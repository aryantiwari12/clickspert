importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js")
importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js")

// Initialize the Firebase app in the service worker by passing the generated config
const firebaseConfig = {
  apiKey: "AIzaSyACW8mZ7U3nNRmNdDzpHvMedyuARP1bRqw",
  authDomain: "clickspert-2f3a9.firebaseapp.com",
  projectId: "clickspert-2f3a9",
  storageBucket: "clickspert-2f3a9.appspot.com",
  messagingSenderId: "367955507046",
  appId: "1:367955507046:web:4c62b07bf3507295d47aa7",
  measurementId: "G-NWVCS92QPF"
};

firebase.initializeApp(firebaseConfig)

// Retrieve firebase messaging
const messaging = firebase.messaging()
let data;
messaging.onBackgroundMessage(function (payload) {
  console.log(payload, "payload");
  data = payload
  const notificationTitle = payload.notification.title
  const notificationOptions = {
    body: payload.notification.body,
  }

  self.registration.showNotification(notificationTitle, notificationOptions)
})
console.log(data, "data");
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  console.log(event, "event");
  console.log(data, "data");
  const BASE_URL='https://staging.admin.clickspert.co'
  // Add logic here to determine the URL you want to navigate to
  const VENDOR_DETAILS = ["NEW_VENDOR", "NEW_DOCUMENT", "MANAGE_VENDOR_LOCATION_REQUEST", "MANAGE_SUBSERVIE_AREA_REQUEST", "MANAGE_SUBSERVIES_REQUEST", "UPDATE_SUBSERVIES_LOCATION_REQUEST", "UPDATE_SUBSERVIES_REQUEST"]?.includes(data?.data?.type)
  const ORDER_REQUEST_DETAILS = ["ORDER_REQUEST", "VENDOR_ACCEPTED"]?.includes(data?.data?.type)
  const ORDER_DETAILS = ["ORDER_RESCHEDULE", "EXTRA_WORK_QUOTATION", "QUOTATION", "ORDER_FINISH", "ORDER_START", "ORDER_CONFIRMED", "ORDER_CANCELLED"]?.includes(data?.data?.type)
  const USER_DETAILS = ["NEW_USER"]?.includes(data?.data?.type)
  const VENDOR_REQUEST_DETAILS = ["VENDOR_REQUEST"]?.includes(data?.data?.type)
  const REDIRECT_TO_PAGE = VENDOR_DETAILS ? `${BASE_URL}/vendor/${data?.data?.sent_by_vendor}/view` : ORDER_DETAILS ? `${BASE_URL}/orders/${data?.data?.order_id}/view` : VENDOR_REQUEST_DETAILS ? `${BASE_URL}/vendor-request/${data?.data?.sent_by_vendor}/view` : ORDER_REQUEST_DETAILS ? `${BASE_URL}/order-request/${data?.data?.order_id}/view` : USER_DETAILS ? `${BASE_URL}/user/${data?.data?.sent_by}/view` : ""
  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then((clientList) => {
      for (const client of clientList) {
        if ('navigate' in client) {
          return client.navigate(REDIRECT_TO_PAGE);
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(REDIRECT_TO_PAGE);
      }
    })
  );
})

