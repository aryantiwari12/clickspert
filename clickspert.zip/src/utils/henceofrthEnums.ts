enum InquiryStatus {
    pending = "PENDING",
    resolved = "RESOLVED",
}
enum InquiryColor {
    pending = "#FF9100",
    resolved = "#32CD32",
}
enum PriceFilter {
    high_to_low = "HIGH_TO_LOW",
    low_to_high = "LOW_TO_HIGH"
}
enum NotificationType {
    email = "EMAIL",
    push = "PUSH"
}
enum NotificationPageType {
    contact_us = "CONTACT_US"
}
enum Selects {
    all = "ALL",
    selected = "SELECTED"
}
enum GraphType {
    Yearly = 'Yearly',
    Monthly = 'Monthly',
    Six_Months = 'Six_Months',
    Weekly = 'Weekly',
    Daily = 'Daily',
}
enum OrderStatus {
    Active = "ACTIVE",
    Upcoming = "UPCOMING",
    Complete = "COMPLETE"
}
enum ContectUsStatus {
    pending = "PENDING",
    resolved = "RESOLVED",
}
enum Promo {
    active = "ACTIVE",
    inactive = "INACTIVE",
}
enum Complaint {
    open = "OPEN",
    resolved = "RESOLVED",
}
enum Points {
    active = "ACTIVE",
    inactive = "INACTIVE",
}
enum Cleaning {
    HomeCleaning = "Home Cleaning",
    DeepCleaning = "Deep Cleaning",
    FurnitureCleaning = "Furniture Cleaning",
    windowCleaning = "Windows Cleaning",
    petTriming = "Pet Trimming",
    PestControl = "Pest Control",
    Disinfection = "Disinfection",
    PacksMove = "Pack & Move",
    PacksPoints = "Move & Paint",
    SaloonSpa = "Saloon Spa",
    MoveOutInspection = "Move Out Inspection",
    AcCleaning = "AC Service",
    Electrical = "Electrician",
    Plumber = "Plumber",
    Handyman = "Handyman",
    Painting = "Painting",
    Landscaping = "Landscaping",
    smartInteriorAutomation = "Smart Home Automation",
    PetWashing = "Pet Washing",
    SwimmingPool = "Swimming Pool",
    PetWashingTrimming = "Pet Washing & Trimming",
    MenSaloonAndSpa = "Men Saloon And Spa",
    WomenSaloonAndSpa = "Women Salon And Spa",
    GroomingPackage = "Full Grooming Package ( Washing & Trimming )",
    AnnualMaintainceContract = "Annual Maintenance Contract",
    SwimmingPoolCleaning="Swimming Pool Cleaning",
    SwimmingPoolMaintenance="Swimming Pool Maintenance",
}
enum Roles {
    DASHBOARD = "DASHBOARD",
    USERS = "USERS",
    VENDOR_REQUEST = "VENDOR_REQUEST",
    VENDORS = "VENDOR",
    SERVICES = "SERVICES",
    ORDER_REQUEST = "ORDER_REQUEST",
    ORDERS = "ORDERS",
    FEEDBACK = "FEEDBACK",
    DOCUMENT = "DOCUMENT",
    HOME_PAGE = "HOME_PAGE",
    LANGUAGE = "LANGUAGE",
    TRANSACTION_PAYOUTS = "TRANSACTION_PAYOUTS",
    TRANSACTIONS = "TRANSACTIONS",
    TRANSACTION_CLICKSPERT_POINT = "TRANSACTION_CLICKSPERT_POINT",
    TRANSACTION_APP_WALLET = "TRANSACTION_APP_WALLET",
    PAGES = "PAGES",
    FAQ = "FAQ",
    FAQ_VENDOR = "VENDOR_FAQ",
    FAQ_USER = "USER_FAQ",
    CONTACT = "CONTACT",
    NOTIFICATION = "NOTIFICATION",
    DB_BACKUP = "DB_BACKUP",
    CLOUD_MESSAGING = "Cloud Messaging",
    CONTENT_LIST_COMMISSION = "CONTENT_LIST_COMMISSION",
    CONTENT_LIST_CLICKSPERT_POINT = "CONTENT_LIST_CLICKSPERT_POINT",
    CONTENT_LIST_PROMO_CODE = "CONTENT_LIST_PROMO_CODE",
    CONTENT_LIST_COMPLAINTS = "CONTENT_LIST_COMPLAINTS",
    CONTENT_LIST_LOCATIONS = "CONTENT_LIST_LOCATIONS",
    CONTENT_LIST_SERVICE_FEE = "CONTENT_LIST_SERVICE_FEE",
    CONTENT_LIST_REFER_A_FRIEND = "CONTENT_LIST_REFER_A_FRIEND",
    SALON = "SALON"
}
enum recurring {
    ONCE = 'Once',
    EVERY_WEEK = 'Every week',
    EVERY_2_WEEK = 'Every 2 week',
    MULTIPLE = 'Multiple',
    MONTHLY = 'Monthly',
    MULTIPLE_TIMES_A_WEEK = 'Multiple times a week',
    EVERY_MONTH = 'Every month',
    EVERY_2_MONTH = 'Every 2 month',
    EVERY_6_MONTH = 'Every 6 month',


    // ["Once", "Every month", "Every 2 month", "Every 6 month"]

}
enum Socket {
    RECIVED_MESSAGE = "recived_message",
    SEND_HEART = 'send_heart',
    SEND_PRIVATE_REQ_JOIN_GROUP = "send_private_req_join_group",
    CHAT_HISTORY_UPDATE = "chat_history_update",
    OTHER_USER_LIST = "other_user_list",
    EDIT_MESSAGE = "edit_message",
    DELETE_MESSAGE = "delete_message",
    SEND_LINK = "send_link",
    JOIN_GROUP_SOCKET = "join_group_socket",
    SEND_MESSAGE = "send_message",
    EDIT_LIVE_SCHEDUEL = "edit_live_scheduel",
    START_LIVE = "start_live",
    LEAVE_LIVE = "leave_live",
    SEND_USER_LIST = "send_user_list",
    ORDER_REQUEST_ADMIN = "order_request_admin",
    ORDER_ACCEPT = 'order_accept',
    USER_ACCEPT_QUOTATION = 'user_accept_quotation',
    ORDER_REQUEST_VENDOR = 'order_request_vendor',
    USER_FEEDBACK = 'user_feedback',
    DOCUMENT_UPDATE = 'document',
    USER_CONTACT = 'user_contact',
    VENDOR_CONTACT = 'vendor_contact',
    FAQ = 'faq',
    USER_COMPLAINT = 'user_complaint',
    WALLET = 'wallet',
    NEW_USER = 'new_user',
    ORDER_COMPLETED = 'order_completed',
    PROMO_CODE = 'promo_code',
    VENDOR_ACCEPT = 'vendor_accept',
    VENDOR_REJECT = 'vendor_reject',
    VENDOR_REQUEST = 'vendor_request',
    NOTIFICATION = 'notification',
    LOCATION = 'location',
    NEW_SUB_SERVICES = "new_sub_services",
    NEW_LOCATIONS = "new_locations",
    DOCUMENT = "document",
    BANNER = "banner",
    SERVICES_ENABLE_DISABLE = "subservice_enable_disable",
    ORDER_CANCELLED = "order_cancelled",
    QUOTATION = "quotation",
    COMMISION = "commision",
    POINT_STATUS = "point_status",
    
}
export default {
    InquiryStatus,
    Socket,
    recurring,
    Promo,
    Complaint,
    PriceFilter,
    GraphType,
    InquiryColor,
    Points,
    ContectUsStatus,
    Cleaning,
    NotificationType,
    OrderStatus,
    Roles,
    NotificationPageType,
    Selects
}