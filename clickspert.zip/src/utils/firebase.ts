// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getMessaging, getToken, isSupported } from "firebase/messaging";

const firebaseConfig = {
  apiKey:  process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGE_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASURMENT_ID
};

// Initialize Firebase
let app:any;
if(typeof window !== "undefined"){
   app = initializeApp(firebaseConfig);
}
// if (!firebase.apps.length) {
//   firebase.initializeApp({});
// }
if (typeof window !== "undefined") {
  const analytics = getAnalytics(app);
}
export const getFirebaseMessageToken = async () => {
  let isSupport = await isSupported();
  if (isSupport) {
    const messaging = getMessaging(app);
    try {
      let tokenId = await getToken(messaging, {
        vapidKey: process.env.NEXT_PUBLIC_FIREBASE_VAP_ID_KEY,
      });
      return { tokenId };
    } catch (error) {
      return { error };
    }
  } else {
    return { error: " Notification Not Supported" };
  }
};
// export const onMessageListener = () => {
//     const messaging = getMessaging(app);
//     return new Promise((resolve, reject) => {
//         if (messaging) {
//             messaging.onMessage((payload) => {
//                 resolve(payload)
//             })
//         } else {
//             reject(null)
//         }
//     })
// }

export default app;
