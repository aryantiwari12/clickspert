import React from "react";

export const useOnOutsideClickCheck = () => {
    const [isOpen, setIsOpen] = React.useState<any>({})
    const menuRef = React.useRef(null) as any
    function handleClickOutside(event: any) {
        console.log(event);

        if (menuRef.current && !menuRef.current.contains(event.target)) {
            setIsOpen({});
        }
    }
    React.useEffect(() => {
        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, [])
    return {
        isOpen, setIsOpen, menuRef
    }
}
export function useDebounce<T>(value: T, delay: number): T {
    const [debouncedValue, setDebouncedValue] = React.useState<T>(value);
    // State and setters for debounced value
    React.useEffect(
        () => {
            // Update debounced value after delay
            const handler = setTimeout(() => {
                setDebouncedValue(value);
            }, delay);
            // Cancel the timeout if value changes (also on delay change or unmount)
            // This is how we prevent debounced value from updating if value is changed ...
            // .. within the delay period. Timeout gets cleared and restarted.
            return () => {
                clearTimeout(handler);
            };
        },
        [value, delay] // Only re-call effect if value or delay changes
    );
    return debouncedValue;
}