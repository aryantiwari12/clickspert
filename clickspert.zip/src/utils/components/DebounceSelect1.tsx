import React, { useEffect, useState } from "react";
import dynamic from 'next/dynamic';
import { useRouter } from "next/router";
const { Spin, Select } = {
    Spin: dynamic(() => import("antd").then(module => module.Spin), { ssr: false }),
    Select: dynamic(() => import("antd").then(module => module.Select), { ssr: false }),

}

function useDebounce<T>(value: T, delay: number): T {
    const [debouncedValue, setDebouncedValue] = useState<T>(value);
    // State and setters for debounced value
    useEffect(
        () => {
            // Update debounced value after delay
            const handler = setTimeout(() => {
                setDebouncedValue(value);
            }, delay);
            return () => {
                clearTimeout(handler);
            };
        },
        [value, delay] // Only re-call effect if value or delay changes
    );
    return debouncedValue;
}


const Debounce = (props: any) => {
    const [isSearching, setIsSearching] = useState<boolean>(false)
    const [searchTerm, setSearchTerm] = useState<any>("");
    const [results, setResults] = useState<any[]>([]);
    const debouncedSearchTerm: string = useDebounce<string>(searchTerm, 1000);

    // Hook
    // T is a generic type for value parameter, our case this will be string


    const searchValue = (value: string) => {
        props?.searchCharacters(value, results).then((results: any) => {
            setIsSearching(false);
            setResults(results ? [...results] : []);
        });

    }
    const onChange = (value: string) => {
        setIsSearching(true);
        setSearchTerm(value.trim())
        if (!value) { searchValue('') }
    };
    // Effect for API call
    useEffect(() => {
        if (props.searchSelect) {
            setIsSearching(true);
            searchValue(props.searchSelect)
        }
    }, [props.searchSelect])
    useEffect(() => {
        setIsSearching(true);
        if (props?.callbackSetValue) {
            props?.callbackSetValue()
        }
    }, [props?.render])
    useEffect(
        () => {

            if (debouncedSearchTerm || props?.stopRounting) {
                searchValue(debouncedSearchTerm)
            }
        },
        [debouncedSearchTerm,props?.render] // Only call effect if debounced search term changes
    );
    const router = useRouter()
    // const onChange1 = (value: string) => {
    //     let old = router.query
    //     if (!value) {
    //         delete old.search
    //         router.replace({ query: old })
    //     } else {
    //         old.search = value.trim()
    //         // old.page = '1'
    //         router.replace({ query: old })
    //     }
    // }

    const showSea = isSearching ? { notFoundContent: <Spin size="small" className="d-block py-2 text-center w-100" /> } : {}
    return (
        <div>
            <Select
                size={props?.size}
                className={`${props?.debounceClass}`}
                mode="multiple"
                suffixIcon={null}
                placeholder="Select Users"
                showSearch
                onClick={props?.onClick}
                allowClear={true}
                onClear={() => {
                    if (props?.onClear) {
                        props?.onClear()
                    }
                    onChange("")
                }}
                {...props?.others}
                onSearch={onChange}
                onChange={(e) => {
                    props?.onChange(e)
                    if (props?.stopRounting) {
                        props?.callback(e)
                        return
                    }
                }}
                {...showSea}
                dropdownRender={(menu) => (
                    <>
                        {menu}
                      
                    </>
                )}
                options={isSearching ? [] : props?.options(results)}
                filterOption={false}
            />
        </div>
    )
}

export default Debounce
