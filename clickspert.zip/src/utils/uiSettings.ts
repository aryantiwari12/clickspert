
const sliceStr = (str: string, count: number) => {
    return str.length > count ? `${str.slice(0, count)}....${str.slice(str.length - count, str.length)}` : str
}
const capitalizeFirstLetter = (string: string) => {
    if (string) {
        return string?.charAt(0).toUpperCase() + string?.slice(1);
    } else {
        return `_`
    }
}
const serialNumber = (page: any, index: number, limit: any) => {
    let _page = Number(page)
    let _limit = Number(limit || 10)
    return (_limit * (_page - 1)) + (index + 1)
}
const uiSettings = {
    sliceStr,
    capitalizeFirstLetter,
    serialNumber,
}

export default uiSettings