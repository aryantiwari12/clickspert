import React, { forwardRef } from "react";
import GoogleMapReact from "google-map-react";
import { count } from "console";

const GoogleMap = forwardRef((props: any, refs: any) => {
    
    return <GoogleMapReact
      ref={refs}
      bootstrapURLKeys={{
        key: "AIzaSyDcjhHJd7Yx6Je19s8m3qH5hK2jdT9Kk8E",
        libraries: ['places']
      }}
      key={props?.count}
      defaultCenter={props.defaultCenter}
      center={props.center}
      zoom={props.zoom}
      defaultZoom={props.defaultZoom}
      onZoomAnimationEnd={props.onZoomAnimationEnd}
      onDrag={props.onDrag}
      onGoogleApiLoaded={props.onGoogleApiLoaded}
    >
    </GoogleMapReact>
  })
  GoogleMap.displayName="GoogleMap"
  export default React.memo(GoogleMap)