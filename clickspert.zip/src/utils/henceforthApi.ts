import FurnitureCleaning from '@/pages/services/[_id]/edit/furniture-cleaning';
import React from 'react';
import _superagent, { search } from 'superagent';
const SuperagentPromise = require('superagent-promise');
const superagent = SuperagentPromise(_superagent, global.Promise);

// const API_ROOT = `${process.env.NEXT_PUBLIC_DEV_API_URL}/`;
// const BUCKET_ROOT = `https://clickspertdev.fra1.digitaloceanspaces.com/`;

const BUCKET_ROOT = `https://clickspertstaging.fra1.digitaloceanspaces.com/`;
const API_ROOT = `${process.env.NEXT_PUBLIC_STAGING_API_URL}/`;

// const API_ROOT = `${process.env.NEXT_PUBLIC_LIVE_API_URL}/`;
// const BUCKET_ROOT = `https://clickspert-live.fra1.digitaloceanspaces.com/`;

const API_FILE_ROOT_MEDIUM = `${BUCKET_ROOT}image/medium/`;
const API_FILE_ROOT_ORIGINAL = `${BUCKET_ROOT}image/original/`;
const API_FILE_ROOT_SMALL = `${BUCKET_ROOT}image/small/`;
const API_FILE_ROOT_AUDIO = `${BUCKET_ROOT}audio/`;
const API_FILE_ROOT_VIDEO = `${BUCKET_ROOT}video/`;
const API_FILE_ROOT_DOCUMENTS = `${BUCKET_ROOT}documents/`;
const API_FILE_ROOT_DB_BACKUP = `${BUCKET_ROOT}backup/`;
const encode = encodeURIComponent;
const responseBody = (res: any) => res.body;
let token: any = null;
const tokenPlugin = (req: any) => {
  if (token) {
    req.set('Authorization', `Bearer ${token}`);
    // req.set('token', token || "mim");
  }
}
const requests = {
  del: (url: string) =>
    superagent.del(`${API_ROOT}${url}`).use(tokenPlugin).then(responseBody),
  get: (url: string) =>
    superagent.get(`${API_ROOT}${url}`).use(tokenPlugin).then(responseBody),
  put: (url: string, body: any) =>
    superagent.put(`${API_ROOT}${url}`, body).use(tokenPlugin).then(responseBody),
  patch: (url: string, body: any) =>
    superagent.patch(`${API_ROOT}${url}`, body).use(tokenPlugin).then(responseBody),
  post: (url: string, body: any) =>
    superagent.post(`${API_ROOT}${url}`, body).use(tokenPlugin).then(responseBody),
  file: (url: string, key: string, file: any) =>
    superagent.post(`${API_ROOT}${url}`).attach(key, file).use(tokenPlugin).then(responseBody)
};

const Auth = {
  login: (info: any) =>
    requests.post('admin/login', info),
  loginAsUser: (info: any) =>
    requests.post('admin/users/login_as_user', info),
  logout: () =>
    requests.put('admin/logout', {}),
  changePassword: (info: any) =>
    requests.put('admin/password', info),
  profile: () =>
    requests.get(`admin/profile`),
  // edit: (info: any) =>
  //   requests.put('admin/profile/edit', info),
  edit: (info: any) =>
    requests.put('admin/profile', info),
};
const Search = {
  pagination: (search: string, nft_type: string) =>
    requests.get(`Nft/search?search=${search}&nft_type=${nft_type}&limit=10&pagination=0&language=ENGLISH`),
};

const Category = {
  create: (info: any) =>
    requests.post('admin/category', info),
  getById: (id: string) =>
    requests.get(`admin/category/${id}`),
  listing: (q?: string) =>
    requests.get(`admin/category${q ? `?${q}` : ""}`),
  delete: (_id: string) =>
    requests.del(`admin/category/${_id}`),
  edit: (_id?: string, info?: any) =>
    requests.put(`admin/category/${_id}`, info),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/category?start_date=${start_date}&end_date=${end_date}`),
};

const Common = {
  uploadFile: (key: string, file: any) =>
    requests.file(`upload/file`, key, file),
  uploadFileMultiple: (key: string, file: any) =>
    requests.file(`Upload/do_spaces_file_upload_multiple`, key, file),
  dbBackup: () =>
    requests.post(`admin/db/backup`, {}),
}
const Service = {
  servicelisting: (q: string, limit: number) =>
    requests.get(`admin/services${q ? `?${q}` : ""}&limit=${limit}`),
  listing: (q: string) =>
    requests.get(`admin/services${q ? `?${q}` : ""}`),
  edit: (items: any) => requests.put(`admin/services`, items),
  getServiceFee: () =>
    requests.get(`admin/service-fee`),
  detail: () =>
    requests.get(`admin/service-fee`),
  getById: (_id: any) =>
    requests.get(`admin/service/${_id}`),
  create: (info: any) =>
    requests.post(`admin/service-fee`, info),
  addServiceFee: (info: any) =>
    requests.post(`admin/service-fee`, info),
  editServiceFee: (info: any) =>
    requests.put(`admin/service-fee`, info),
  normal_cleaning: (info: any) =>
    requests.put('admin/sub-services/normal-cleaning', info),
  sub_service: (_id: any, swimming_pool_id?: string) =>
    requests.get(`admin/sub-services/${_id}${swimming_pool_id ? `?swimming_pool_id=${swimming_pool_id}` : ""}`),
  enableDisable: (id: string) => requests.put(`admin/subservice-enable?_id=${id}`, {}),
  saloonPackageListing: (_id: any) =>
    requests.get(`admin/sub-services/saloon-list/${_id}`),
  addPackage: (info: any) =>
    requests.post(`admin/sub-services/saloon-packages`, info),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/services?start_date=${start_date}&end_date=${end_date}`),
}

const WomenSaloon = {
  saloonPackageListing: (_id: any) =>
    requests.get(`admin/sub-services/saloon-list/${_id}`),
  edit: (items: any) => requests.put(`admin/sub-services/saloon`, items),
  addPackage: (info: any) =>
    requests.post(`admin/sub-services/saloon-packages`, info),
  sub_serviceList: (_id: any) =>
    requests.get(`admin/sub-services/saloon-packages-list/${_id}`),
  deletePackage: (_id: string) =>
    requests.del(`admin/sub-services/saloon-packages/${_id}`),
  editPackage: (items: any) => requests.put(`admin/sub-services/saloon-packages`, items),
  subServiceItemList: (id: string, type: string, sub_type: string) =>
    requests.get(`admin/sub-services/saloon-items-list/${id}?type=${type}&sub_type=${sub_type}`),
  addSubserviceItems: (items: any) => requests.post(`admin/sub-services/saloon-items`, items),
  editSubserviceItems: (items: any) => requests.put(`admin/sub-services/saloon-items`, items),
  delSubserviceItems: (_id: string) => requests.del(`admin/sub-services/saloon-items/${_id}`),
}

const PetCareService = {
  editPetGrooming: (items: any) => requests.put(`admin/sub-services/pet-grooming`, items),
  editPetWashing: (items: any) => requests.put(`admin/sub-services/pet-washing`, items),
  editPetWashingAndGrooming: (id: any) => requests.del(`admin/sub-services/saloon-items/${id}`),
  editPetWashingAndgrooming: (info: any) => requests.put(`admin/sub-services/pet-grooming-washing`, info),

}

const DeepCleaning = {
  villaCreate: (info: any) =>
    requests.post(`admin/villa`, info),
  listingVilla: (name: string, type: string) =>
    requests.get(`admin/${name}?type=${type}`),
  delete: (_id: any, type?: string) =>
    requests.del(`admin/villa/${_id}`),
  Apartment: (info: any) =>
    requests.post(`admin/apartment`, info),
  EditListing: (endPoint: string, info: any) =>
    requests.put(`admin/${endPoint}`, info),
  editSubService: (items: any) =>
    requests.put(`admin/sub-services/deep-cleaning`, items),
  apartmentDelete: (_id: string) => requests.del(`admin/apartment/${_id}`)
}

const serviceFee = {
  listing: () =>
    requests.get(`admin/service-fee`)
}
const editSubService = {
  packAndMove: (items: any) => requests.put(`admin/sub-services/pack-and-move`, items),
  edit: (endPoint: string, items: any) => requests.put(`admin/sub-services/${endPoint}`, items)
}
const WaterTank = {
  add: (items: any) => requests.post(`admin/sub-services/water-tank/tank-type-size`, items),
  edit: (items: any) => requests.put(`admin/sub-services/water-tank/tank-type-size`, items),
  delete: (id: any) => requests.del(`admin/sub-services/water-tank/tank-type-size/${id}`),
}

const landscaping = {
  addSize: (items: any) => requests.post(`admin/sub-services/size`, items),
  editSize: (items: any) => requests.put(`admin/sub-services/size`, items),
  deleteSize: (_id: any) => requests.del(`admin/sub-services/size/${_id}`),
  getSize: (_id: any) => requests.get(`admin/sub-services/size-list/${_id}`),
}
const Swimming = {
  get: (_id: string) => requests.get(`admin/subservice/swimming-pool/${_id}`)
}

const Calender = {
  getDateCalender: (id: string) => requests.get(`admin/sub-services/calender/dates/${id}`),
  editDateCalender: (items: any) => requests.put(`admin/sub-services/calender/dates`, items),
  editDayCalender: (items: any) => requests.put(`admin/sub-services/calender/days`, items),
  addDateCalender: (items: any) => requests.post(`admin/sub-services/calender/dates`, items),
  deleteDateSlot: (id: any) => requests.del(`admin/sub-services/calender/dates/${id}`),
  getByDate: (sub_service: string, date: string) => requests.get(`admin/sub-services/calender/dates-detail?sub_service_id=${sub_service}&date=${date}`),
  addDays: (items: any) => requests.post(`admin/sub-services/calender/days`, items),
  editDays: (items: any) => requests.put(`admin/sub-services/calender/days`, items),
  getDays: (id: string) => requests.get(`admin/sub-services/calender/days/${id}`),
  deleteDaySlot: (id: any) => requests.del(`admin/sub-services/calender/days/${id}`),
  copyDays: (items: any) => requests.post(`admin/sub-services/calender/days/copy`, items),
  daysStatus: (items: any) => requests.put(`admin/sub-services/calender/days/status`, items),
  dateStatus: (items: any) => requests.put(`admin/sub-services/calender/dates/status`, items),
  getMonthlyCalender: (id: string, date:number) => requests.get(`admin/sub-services/calender/month-detail?sub_service_id=${id}&months=${date}`),
  slotDateDelete: (days: any) =>
    requests.del(`admin/sub-services/calender/slots/${days}`)


}
// furniture-cleaning
// Admin Edit Sub Service Furniture Cleaning Api


const Cleaning = {
  furnitureCleaning: (items: any) =>
    requests.put(`admin/sub-services/furniture-cleaning`, items),
  furnitureMaterialByType: (_id: string, type: string) => requests.get(`admin/sub-services/furniture-cleaning/material?sub_service_id=${_id}&material_type=${type}`),
  addMaterial: (items: any) => requests.post(`admin/sub-services/furniture-cleaning/material`, items),
  editMaterial: (items: any) => requests.put(`admin/sub-services/furniture-cleaning/material`, items),
  deleteMaterial: (_id: string) => requests.del(`admin/sub-services/furniture-cleaning/material/${_id}`),
  windowCleaning: (items: any) => requests.put(`admin/sub-services/window-cleaning`, items)
}


const ContactUs = {
  listing: (q: string ) =>
    requests.get(`admin/contact${q ? `?${q}` : ""}`),
  getById: (id: string) =>
    requests.get(`admin/contact/${id}`),
  getContactInfo: () =>
    requests.get(`admin/contact/phone-whatsapp`),
  delete: (_id: string) =>
    requests.del(`admin/contact/${_id}`),
  edit: (_id: string, info: any) =>
    requests.put(`admin/contact/status/${_id}`, info),
  editContactInfo: (info: any) =>
    requests.put(`admin/contact/phone-whatsapp`, info),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/contact_export?start_date=${start_date}&end_date=${end_date}`),
};
const PestControl = {
  editPestControl: (items: any) => requests.put(`admin/sub-services/pest-control`, items),
  editDisinfection: (items: any) => requests.put(`admin/sub-services/disinfection`, items)
}

// const PackerAndMovers = {
// editPestControl: (items: any) => requests.put(`admin/sub-services/pack-and-move`, items),
// }

const Content = {
  create: (info: any) =>
    requests.post('admin/v1/pages', info),
  getByID: (id: string) =>
    requests.get(`admin/v1/pages/${id}`),
  listing: (q: string, limit: number) =>
    requests.get(`admin/v1/pages${q ? `?${q}` : ''}&limit=${limit}`),
  delete: (_id: string) =>
    requests.del(`admin/v1/pages/${_id}`),
  edit: (_id: string, info: any) =>
    requests.patch(`admin/v1/pages/${_id}`, info),
};
const Documents = {
  listing: (q?: any, limit?: number) =>
    requests.get(`admin/get-document${q ? `?${q}` : ""}&limit=${limit}`),
  create: (info: any) =>
    requests.post(`admin/add-document`, info),
  delete: (_id: any) =>
    requests.del(`admin/delete-document?_id=${_id}`),
  documentEdit: (_id: any, name: string, info: any) =>
    requests.put(`admin/edit-document?_id=${_id}&name=${name}`, info),
  getbyId: (_id: any) =>
    requests.get(`admin/document/${_id}`)
}
const Dashboard = {
  listing: (q: string) =>
    requests.get(`admin/dashboard?${q}`),
  dashBoard: () =>
    requests.get(`admin/dashboard`),
  subServiceList: () =>
    requests.get(`admin/subservice`),
  userListing: (limit: number) =>
    requests.get(`admin/users?limit=${limit}`),
  vendorListing: (limit: number) =>
    requests.get(`admin/vendor-requests?pagination=0&limit=${limit}`),
  orderListing: (limit: number) =>
    requests.get(`admin/order-requests?pagination=0&limit=${limit}`),
};
const Currency = {
  get: () => requests.get(`admin/currency`)
}

const Faq = {
  faq: (q?: string) =>
    requests.get(`admin/faq${q ? `?${q}` : ""}`),
  listing: (q: string, service_id: any ,type:string) =>
    requests.get(`admin/faq-detail?type=${type}${service_id ? `&service_id=${service_id}` : ''}${q ? `&${q}` : ""}`),
  create: (info: any) =>
    requests.post('admin/faq', info),
  getByID: (id: string) =>
    requests.get(`admin/faq/${id}`),
  edit: (_id: string, info: any) =>
    requests.put(`admin/faq/${_id}`, info),
  delete: (_id: string) =>
    requests.del(`admin/faq/${_id}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/faq?start_date=${start_date}&end_date=${end_date}`),
};

const Graph = {
  create: (q?: string) =>
    requests.get(`admin/graph?${q}`),
}

const Homepage = {
  create: (info: any) =>
    requests.post('admin/home-page/banners', info),
  getByID: (id: string) =>
    requests.get(`admin/home-page/banners/${id}`),
  listing: (q: string) =>
    requests.get(`admin/home-page/banners${q ? `?${q}` : ''}`),
  delete: (_id: string) =>
    requests.del(`admin/home-page/banners/${_id}`),
  edit: (info: any) =>
    requests.put(`admin/home-page/banners`, info),
  promocode: () =>
    requests.get(`admin/promo-code-list`),
  introduction: () =>
    requests.get(`admin/home-page/introduction`),
  introductionId: (_id: any) =>
    requests.get(`admin/home-page/introduction/${_id}`),
  EditInt: (info: any) =>
    requests.put(`admin/home-page/introduction`, info),
  isEnable: (_id: any, info: any) =>
    requests.put(`admin/home-page/subservice-enable?_id=${_id}`, info),
  delIntr: (_id: any) =>
    requests.del(`admin/home-page/introduction/${_id}`),

};

const LanguageParent = {
  create: (info: any) =>
    requests.post('admin/v1/language', info),
  // getById: (id: string, q?: string) =>
  //   requests.get(`admin/v1/language/child/${id}${q ? `?${q}` : ""}`),
  listing: (q?: string) =>
    requests.get(`admin/v1/language${q ? `?${q}` : ""}`),
  delete: (_id: string) =>
    requests.del(`admin/v1/language/${_id}`),
  edit: (_id: string, info: any) =>
    requests.patch(`admin/v1/language/${_id}`, info),
}

const LanguageChild = {
  create: (info: any) =>
    requests.post('admin/v1/language/child', info),
  listing: (_id: string, q?: string) =>
    requests.get(`admin/v1/language/childs/${_id}${q ? `?${q}` : ""}`),
  getById: (_id: string) =>
    requests.get(`admin/v1/language/child/${_id}}`),
  delete: (_id: string) =>
    requests.del(`admin/v1/language/child/${_id}`),
  edit: (_id: string, info: any) =>
    requests.put(`admin/v1/language/child/${_id}`, info),
}

const Notification = {
  create: (info: any) =>
    requests.post('admin/v1/notification', info),
  listing: (q: string) =>
    requests.get(`admin/notification-list${q ? `?${q}` : ""}`),
  readById: (id: string) =>
    requests.put(`admin/v1/notification/${id}`, {}),
  allRead: () =>
    requests.put('admin/v1/notification/allRead', {}),
  unreadCount: () =>
    requests.get(`admin/v1/notification/count`),
  emailNotifications: () =>
    requests.get(`admin/email_notifications`),
  update: (info: any) =>
    requests.put(`admin/email_notifications`, info),
  readUnreadList: (q: any) =>
    requests.get(`admin/notifications${q ? `?${q}` : ""}&limit=10`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/notification-list?start_date=${start_date}&end_date=${end_date}`),
}

const Products = {
  create: (info: any) =>
    requests.post('admin/product', info),
  listing: (q: string) =>
    requests.get(`admin/product?${q}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/product_export?start_date=${start_date}&end_date=${end_date}`),
  edit: (_id: string, info: any) =>
    requests.put(`admin/product/${_id}`, info),
  get: () =>
    requests.get(`user/product?language=ENGLISH`),
  getById: (id: string) =>
    requests.get(`admin/product/${id}`),
  delete: (_id: string) =>
    requests.del(`admin/product/${_id}`),
  import: (file: any) =>
    requests.file(`admin/product/import`, 'file', file),
  visibility: (_id: string) =>
    requests.patch(`admin/product/${_id}`, {})
};

const Staff = {
  create: (info: any) =>
    requests.post('admin/staff', info),
  listing: (q: string, limit: Number) =>
    requests.get(`admin/staff${q ? `?${q}` : ''}&limit=${limit}`),
  edit: (_id: string, info: any) =>
    requests.put(`admin/staff?_id=${_id}`, info),
  staff_delete_by_id: (id: string) =>
    requests.del(`admin/staff/delete/${id}`),
  block_delete: (id: string, info: any) =>
    requests.put(`admin/staff/block/unblock/${id}`, info),
  get: () =>
    requests.get(`User/profile?language=ENGLISH`),
  getById: (id: string) =>
    requests.get(`admin/staff/${id}`),
  changePasword: (data: any) =>
    requests.put(`admin/staff-password`, data),
  fcmToken: (fcm_token: string) =>
    requests.put('User/fcm', {
      device_type: "Web",
      fcm_token,
      language: "ENGLISH"
    }),
};
const Vendor = {
  listing: (q?: any, limit?: number) =>
    requests.get(`admin/vendor${q ? `?${q}` : ""}&limit=${limit}`),
  manage: (info: any) =>
    requests.patch(`admin/vendor-requests`, info),
  manageDocs: (info: any) =>
    requests.put(`admin/vendor/document`, info),
  getById: (_id: any) =>
    requests.get(`admin/vendor/${_id}`),
  manageService: (info: any) =>
    requests.put(`admin/vendor/manage-services`, info),
  vendorRequest: (q?: any, limit?: number) =>
    requests.get(`admin/vendor-requests${q ? `?${q}` : ""}&limit=${limit}`),
  export: (start_date?: number, end_date?: number , status?:any) =>
    requests.get(`admin/vendor-requests?status=${status?.toUpperCase()}&start_date=${start_date}&end_date=${end_date}`),
  delete: (_id: any) =>
    requests.del(`admin/vendor/${_id}`),
  get: () =>
    requests.get(`admin/services`),
  vendorOrder: (_id: any) =>
    requests.get(`admin/vendor/${_id}/order`),
  vendorTransacation: (_id: any) =>
    requests.get(`admin/vendor/${_id}/transaction`),
    vendorNewTransacation: (_id: any) =>
    requests.get(`admin/transaction/panelty-fees?vendor_id=${_id}`),
  vendorChange: (info: any) =>
    requests.put(`admin/vendor-password`, info),
  vendorBlock: (_id: any, info: any) =>
    requests.put(`admin/vendor/block/unblock/${_id}`, info),
  exportVendor: (start_date?: number, end_date?: number) =>
    requests.get(`admin/vendor?start_date=${start_date}&end_date=${end_date}`),
  deactive: (id: any, info: any) =>
    requests.patch(`admin/active-deactive-vendor?_id=${id}`, info),
  getNewServices: (id: any) =>
    requests.get(`admin/vendor/new-services?_id=${id}`),
  getOldServices: (id: any) =>
    requests.get(`admin/vendor/old-services?_id=${id}`),
  getOldLocation: (id: any) =>
    requests.get(`admin/vendor/old-locations?_id=${id}`),
  getNewLocation: (id: any) =>
    requests.get(`admin/vendor/new-locations?_id=${id}`),
  getNewServiceArea: (id: any) =>
    requests.get(`admin/vendor/new-service-area-request?_id=${id}`),
  getOldServiceArea: (id: any) =>
    requests.get(`admin/vendor/old-service-area-request?_id=${id}`),
  manageLocation: (info: any) =>
    requests.put(`admin/vendor/manage-locations`, info),
  manageServiceArea: (info: any) =>
    requests.put(`admin/vendor/manage-service-area-request`, info),
}



const Feedback = {
  listing: (q?: any, limit?: number) =>
    requests.get(`admin/feedback${q ? `?${q}` : ''}&limit=${limit}`),
  getById: (_id?: any) =>
    requests.get(`admin/feedback/${_id}`),
  reply: (info?: any) =>
    requests.post(`admin/feedback`, info),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/feedback?start_date=${start_date}&end_date=${end_date}`)
}
const Quotation = {
  create: (info: any) =>
    requests.post(`admin/orders/quotation`, info)
}
const Penality = {
  add: (info: any) =>
    requests.post(`admin/transaction/panelty-fees`, info),
    vendorOrder: (_id: any ,q:any) =>
    requests.get(`admin/vendor/${_id}/order${q ? `?${q}` : ""}`),
}

const Loction = {
  get: () =>
    requests.get(`admin/get-location`),
  checked: (_id: any, item: any) =>
    requests.put(`admin/disable-status?_id=${_id}`, item),
  delete: (_id: any) =>
    requests.del(`admin/delete-location/${_id}`),
  add: (items: any) =>
    requests.post(`admin/add-location`, items),
  view: (_id: any) =>
    requests.get(`admin/get-area/${_id}`),
  areadelete: (_id: any) =>
    requests.del(`admin/delete-area/${_id}`),
  editArea: (_id: string, body: any) =>
    requests.put(`admin/edit-area?_id=${_id}`, body),
  listing: (q?: any, limit?: number) =>
    requests.get(`admin/get-location${q ? `?${q}` : ''}&limit=${limit}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/get-location?start_date=${start_date}&end_date=${end_date}`)
}
const Order = {
  listing: (q: string, limit: number) =>
    requests.get(`admin/orders${q ? `?${q}` : ''}&limit=${limit}`),
  maxOrderDate: () =>
    requests.get(`admin/common`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/orders?start_date=${start_date}&end_date=${end_date}`),
  getById: (_id: any) =>
    requests.get(`admin/orders/${_id}`),
  decline: (info: any) =>
    requests.put(`admin/orders/extra-work-quotation/accept-reject`, info),
  extra: (info: any) =>
    requests.put(`admin/orders/extra-work-quotation`, info),
  orderRequest: (q?: any, limit?: number) =>
    requests.get(`admin/order-requests${q ? `?${q}` : ' '}&limit=${limit}`),
  assignVendor: (info: any) =>
    requests.post(`admin/assign-vendor`, info),
  listingVendor: (q?: string) =>
    requests.get(`admin/vendor-lists${q ? `?${q}` : ''}`),
  orderExport: (start_date?: number, end_date?: number) =>
    requests.get(`admin/order-requests?start_date=${start_date}&end_date=${end_date}`),
  inVoice: (_id: any) =>
    requests.get(`admin/order/${_id}/invoice`),
  getQuotation: (_id: any) =>
    requests.get(`admin/orders/quotation/${_id}`),
  createQuotation: (info: any) =>
    requests.post(`admin/orders/quotation`, info),
  editTerm: (_id: any, info: any) =>
    requests.patch(`admin/v1/pages/${_id}`, info),
  listvendor: (id?: any, q?: any) =>
    requests.get(`admin/vendor-lists?sub_service_id=${id}${q ? `&${q}` : ""}`)

}
const User = {
  listing: (q: string, limit: number) =>
    requests.get(`admin/users${q ? `?${q}` : ''}&limit=${limit}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/users?start_date=${start_date}&end_date=${end_date}`),
  getById: (id: string) =>
    requests.get(`admin/users-detail?_id=${id}`),
  block: (id: string, info: any) =>
    requests.patch(`admin/block-user?_id=${id}`, info),
  deactivate: (id: string, info: any) =>
    requests.patch(`admin/active-deactive-user?_id=${id}`, info),
  delete: (id: string, info: string) =>
    requests.patch(`admin/delete-user?_id=${id}`, info),
  import: (file: any) =>
    requests.file(`admin/user/import`, 'file', file),
  order: (id: string, q: string) =>
    requests.get(`admin/users/${id}/orders${q ? `?${q}` : ""}`),
  getPoints: (id: string) =>
    requests.get(`admin/users/${id}/clickspert-point`),
  getWallet: (id: string) =>
    requests.get(`admin/users/${id}/clickspert-wallet`),
  sendMoney: (info: any) =>
    requests.post(`admin/users/send-money`, info),
};
const Salon = {
  addItem: (body: any) =>
    requests.post('admin/service/saloon/items', body),
  addServices: (body: any) =>
    requests.post('admin/service/saloon', body),
  editItem: (body: any) =>
    requests.put('admin/service/saloon/items', body),
  deleteItem: (_id: any) =>
    requests.del(`admin/service/saloon/items/${_id}`),
  getItems: (q: string) =>
    requests.get(`admin/service/saloon/items${q ? `?${q}` : ""}`),
  getServices: (q: string) =>
    requests.get(`admin/service/saloon${q ? `?${q}` : ""}`)
}

const Transaction = {
  sub_Service: () =>
    requests.get(`admin/subservice`),
  getPoints: (q: string) =>
    requests.get(`admin/transaction/clickspert-point${q ? `?${q}` : ""}`),
  getWallets: (q: string) =>
    requests.get(`admin/transaction/app-wallet${q ? `?${q}` : ""}`),
  export: (start_date?: number, end_date?: number, type?: string) =>
    requests.get(`admin/transaction?type=${type?.toUpperCase()}&start_date=${start_date}&end_date=${end_date}`),
  getTransactions: (q: string ,limit:number) =>
    requests.get(`admin/transaction${q ? `?${q}` : `type=ALL`}`),
  getPayouts: (q: string ,limit:number) =>
    requests.get(`admin/transaction/payout${q ? `?${q}` : ""}`),
  payoutExport: (type: string, start_date?: number, end_date?: number) =>
    requests.get(`admin/transaction/payout?type=${type}&start_date=${start_date}&end_date=${end_date}`),
  pointsExport: (start_date?: number, end_date?: number) =>
    requests.get(`admin/transaction/clickspert-point?start_date=${start_date}&end_date=${end_date}`),
  walletExport: (start_date?: number, end_date?: number) =>
    requests.get(`admin/transaction/app-wallet?start_date=${start_date}&end_date=${end_date}`),
  editPayoutStatus: (id: any) =>
    requests.put(`admin/transaction/payout/${id}`, {}),
}

const Promo = {
  getlist: (q: string) =>
    requests.get(`admin/promo-code-list${q ? `?${q}` : ""}`),
  getDeatils: (id: string) =>
    requests.get(`admin/promo-code-detail?_id=${id}`),
  add: (body: any) =>
    requests.post('admin/promo-code', body),
  delete: (_id: any) =>
    requests.del(`admin/promo-code?_id=${_id}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/promo-code-list?start_date=${start_date}&end_date=${end_date}`),
  editStatus: (id: any) =>
    requests.put(`admin/change-promo-status?_id=${id}`, {}),
  edit: (info: any) =>
    requests.put(`admin/promo-code`, info),
}

const Commission = {
  getlist: (q: string) =>
    requests.get(`admin/commission/services${q ? `?${q}` : ""}`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/commission/services?start_date=${start_date}&end_date=${end_date}`),
  detail: (id: string, q: string) =>
    requests.get(`admin/commission/service/${id}${q ? `?${q}` : ""}`),
  add: (id: any) =>
    requests.post(`admin/commission/subservice/${id}`, {}),
  editCommission: (id: any, data: any) =>
    requests.put(`admin/commission/subservice/${id}`, data),
}

const Complaint = {
  getlist: (q: string) =>
    requests.get(`admin/complaint-list${q ? `?${q}` : ""}`),
  userlist: (q: string) =>
    requests.get(`admin/users${q ? `?${q}` : ""}`),
  detail: (id: string) =>
    requests.get(`admin/complaint-detail/${id}`),
  complaintType: () =>
    requests.get(`admin/complaint-type-list`),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/complaint-list?start_date=${start_date}&end_date=${end_date}`),
  add: (info: any) =>
    requests.post(`admin/complaints`, info),
  editStatus: (id: string, status: string) =>
    requests.put(`admin/complaint-status?_id=${id}&status=${status}`, {}),
  reply: (info: any) =>
    requests.post(`admin/complaint-reply`, info),
}

const Refer = {
  list: () =>
    requests.get(`admin/clickspert-refer`),
  add: (info: any) =>
    requests.post(`admin/clickspert-refer`, info),
}

const ClickspertPoints = {
  getlist: (q: string) =>
    requests.get(`admin/clickspert-point/services${q ? `?${q}` : ""}`),
  get: () =>
    requests.get(`admin/clickspert-point`),
  editAmountPoint: (id: any, data: any) =>
    requests.put(`admin/clickspert-point/${id}`, data),
  export: (start_date?: number, end_date?: number) =>
    requests.get(`admin/clickspert-point/services?start_date=${start_date}&end_date=${end_date}`),
  editPointStatus: (id: any, data: any) =>
    requests.put(`admin/clickspert-point/service/${id}`, data),
}

const FILES = {
  audio: (filename: string) => filename?.startsWith('http') ? filename : `${API_FILE_ROOT_AUDIO}${filename}`,
  video: (filename: string) => filename?.startsWith('http') ? filename : `${API_FILE_ROOT_VIDEO}${filename}`,
  imageOriginal: (filename: string, alt: any) => filename ? filename?.startsWith('http') ? filename : `${API_FILE_ROOT_ORIGINAL}${filename}` : alt,
  imageMedium: (filename: string, alt: any) => filename ? filename?.startsWith('http') ? filename : `${API_FILE_ROOT_MEDIUM}${filename}` : alt,
  imageSmall: (filename: string, alt?: any) => filename ? filename?.startsWith('http') ? filename : `${API_FILE_ROOT_SMALL}${filename}` : alt,
}

const henceforthApi = {
  Auth,
  API_ROOT,
  API_FILE_ROOT_DB_BACKUP,
  API_FILE_ROOT_SMALL,
  API_FILE_ROOT_MEDIUM,
  API_FILE_ROOT_ORIGINAL,
  API_FILE_ROOT_VIDEO,
  API_FILE_ROOT_DOCUMENTS,
  Category,
  Penality,
  Promo,
  Commission,
  Complaint,
  Refer,
  ClickspertPoints,
  Transaction,
  ContactUs,
  Content,
  Salon,
  Common,
  Dashboard,
  DeepCleaning,
  Swimming,
  WomenSaloon,
  Feedback,
  Cleaning,
  PetCareService,
  PestControl,
  editSubService,
  Quotation,
  WaterTank,
  landscaping,
  Calender,
  Documents,
  FILES,
  Faq,
  Graph,
  Order,
  serviceFee,
  Homepage,
  LanguageParent,
  LanguageChild,
  Loction,
  Notification,
  Products,
  Staff,
  Service,
  Search,
  token,
  User,
  Vendor,
  Currency,
  encode,
  setToken: (_token?: string) => { token = _token; }
};

export default henceforthApi