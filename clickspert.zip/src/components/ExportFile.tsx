import { DatePicker } from "antd";
import dynamic from "next/dynamic";
import React, { SetStateAction, useContext } from "react";
import dayjs from 'dayjs'
import { GlobalContext } from "@/context/Provider";
const { Modal } = {
    Modal: dynamic(() => import("antd").then(module => module.Modal), { ssr: false }),
}
const { RangePicker } = DatePicker;
type ToastFunction = (start_date?: number, end_date?: number) => any;

type PropsType = {
    open: boolean,
    setOpen: React.Dispatch<SetStateAction<boolean>>,
    title: string,
    setValue: any
    value: any
    export: ToastFunction
}
const ExportFile = (props: PropsType) => {
    const { maxDate } = useContext(GlobalContext)
    const e = maxDate
    // console.log(props,"maxDate");
    // const [date, setDate] = React.useState({
    //     start_date: 0,
    //     end_date: 0
    // })
    const start_date=new Date(props?.value?.[0]?.valueOf())
    const end_date=new Date(props?.value?.[1]?.valueOf())
    start_date.setHours(0,0,0,1)
    end_date.setHours(23,59,59,999)
    const handleOk = () => {
        debugger
        props.setOpen(false);
        props.export(new Date(start_date)?.getTime(), new Date(end_date)?.getTime())
        // props.export(date.start_date, date.end_date )
        
    };
    
    let currentDate = new Date(maxDate + 5.5*60*60*1000)
    let maxOrderDate=  currentDate.setHours(currentDate.getHours() + 5.5)
    
  
    const handleCancel = () => {
        props.setOpen(false);
    };


    return <Modal
        title={props.title}
        open={props.open}
        onOk={handleOk}
        okText="Export"
        onCancel={handleCancel}>
        <RangePicker style={{ width: '100%' }}
            disabledDate={(current) =>
                current.isAfter(new Date(currentDate))}
            //  new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0)
            // onChange={(e) => setDate({
            //     start_date: e?.[0]?.valueOf() || 0,
            //     end_date: e?.[1]?.valueOf() || 0
            // })}
            onChange={(val) => {
                props?.setValue(val);
            }}
            value={props?.value}
        />
    </Modal>
}
ExportFile.displayName = "ExportFile"
export default ExportFile