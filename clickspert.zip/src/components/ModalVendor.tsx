import { Col, Form, Image, Input, Modal, Row, Select, Typography } from "antd";
import { UploadOutlined, SearchOutlined } from '@ant-design/icons'

const ModalVendor = (props: any) => {
    return (
        <>
            <Modal footer={null} centered={true} open={props.isModalOpen} onOk={props.handleOk} onCancel={props.onCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700  mt-2'>Assign Vendor</Typography.Title>
                    <Form size='large' layout='vertical'>
                        <Form.Item>
                            <Input placeholder="Search" className='border-0' size='large' prefix={<SearchOutlined />} />
                        </Form.Item>
                        <Row gutter={[12, 12]}>
                            <Col span={24} md={12}>
                                <Form.Item className='mb-0'>
                                    <Select placeholder='Select services' className='text-start'>
                                        <Select.Option>a</Select.Option>
                                        <Select.Option>b</Select.Option>
                                        <Select.Option>c</Select.Option>
                                    </Select>
                                </Form.Item>
                            </Col>
                            <Col span={24} md={12}>
                                <Form.Item className='mb-0'>
                                    <Select placeholder='Select subservice' className='text-start'>
                                        <Select.Option>a</Select.Option>
                                        <Select.Option>b</Select.Option>
                                        <Select.Option>c</Select.Option>
                                    </Select>
                                </Form.Item>
                            </Col>
                            <Col span={24} md={12}>
                                <ul className='modal-list'>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <img src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <img src={''} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                </ul>
                            </Col>
                            <Col span={24} md={12}>
                                <ul className='modal-list'>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                    <li>
                                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                            <div className="user-detail-img">
                                                <Image src={'Serviceimg'} alt='img' />
                                            </div>
                                            <Typography.Text>Johny</Typography.Text>
                                        </div>
                                    </li>
                                </ul>
                            </Col>
                        </Row>
                    </Form>
                </div>
            </Modal>
        </>
    )
}
export default ModalVendor;