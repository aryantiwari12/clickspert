import { View, StyleSheet, Image } from '@react-pdf/renderer';
import footer from '@/assets/images/invoice/footer.png'

// Create styles
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
    },

    w_100: {
        width: '100%',
    },
    logo: {
        maxWidth: '100px',
        // height: '100%',
        objectFit: 'contain',
    }
});
const InvoiceFooter = () => {
    return (
        <>
            <View style={[styles.container, { margin: '40px 0', width: '100%' }]}>
                <Image src={footer.src} style={{ width: '100%' }}></Image>
            </View>
        </>
    )
}








export default InvoiceFooter;