import { View, StyleSheet, Font, Image } from '@react-pdf/renderer';
import header from "@/assets/images/invoice/header.png";
import logo from "@/assets/images/invoice/logo.png";
Font.register({
    family: 'bold',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayBold.woff",
    fontWeight: 'bold'
});

Font.register({
    family: 'medium',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayRegular.woff",
});



// Create styles
const styles = StyleSheet.create({
    titleContainer: {
        marginTop: 10,
        marginBottom: 30,
    },
    container: {
        flexDirection: 'row',
    },
});

const InvoiceHeader = (props: any) => {
    return (
        <>
            <View>
                <Image src={header.src} style={{ width: '100%', marginBottom: 40 }}></Image>
            </View>
            <View>
                <Image src={logo.src} style={{ maxWidth: 200, marginTop: 20 }}></Image>
            </View>
        </>
    )
}

export default InvoiceHeader;