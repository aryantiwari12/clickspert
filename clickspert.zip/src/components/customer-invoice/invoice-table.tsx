import { Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import { useMemo } from 'react';

Font.register({
    family: 'bold',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayBold.woff",
    fontWeight: 'bold'
});

Font.register({
    family: 'medium',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayRegular.woff",
});


// Create styles
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        // flexGrow: 1,
    },
    titleContainer: {
        marginTop: 10,
        marginBottom: 30,
    },
    reportTitle: {
        color: '#000',
        fontSize: 24,
        textAlign: 'center',
        textTransform: 'capitalize',
        fontWeight: 'black',
        textDecoration: 'underline'
    },
    font10: {
        fontSize: 10,
        color: '#000'
    },
    w_20: {
        width: '20%'
    },
    w_30: {
        width: '30%'
    },
    tableTitle: {
        fontSize: 12,
        color: '#828282',
        fontWeight: 600,
        letterSpacing: -0.16
    },
    tableDes: {
        fontSize: 12,
        color: '#121212',
        fontWeight: 600,
        letterSpacing: -0.16
    }
});
const InvoiceTable = (props: any) => {
    console.log(props?.type == "vendor");
    const subTotal = useMemo(() => {
        let s = 0
        props?.scope?.forEach((res: any) => {
            const UNIT_PRICE=(res?.unit_price)/(1-(Number(props?.commission_percentage))/100)
            const Amount=UNIT_PRICE * res?.quantity 
            s = s + Amount
        })
        return s
    }, [])
    const Type = props?.type == "vendor"
    const SUBTOTAL = Type ? props?.vendor_subtotal : props?.subtotal;
    const VAT = Type ? props?.vendor_vat : props?.vat;
    const GRANDTOTAL = Type ? props?.vendor_earning : subTotal + VAT
    const GRANDTOTAL1=Type ? props?.vendor_earning : props?.total_amount
    const QUOTATION_BASED_SUBTOTAL=Type ?  props?.vendor_subtotal :subTotal
    const NOQUOTATION_BASED_SUBTOTAL=Type ? props?.vendor_subtotal :props?.subtotal
    const UNIT_PRICE=Type ? props?.vendor_subtotal :props?.subtotal
    const EXTRA_WORK_VAT=Type ? props?.vendor_quotation_vat : props?.work_quotation_vat
    const EXTRA_WORK_AMOUNT = Type  ? props?.vendor_quotation_subtotal : props?.work_quotation_amount
    const EXTRA_WORK_TOTAL = Type  ? props?.vendor_quotation_earns : props?.quotation_total_amount
    const GRANDEXTRAWORKTOTAL=props?.is_quotation_based ? GRANDTOTAL : GRANDTOTAL1 + EXTRA_WORK_TOTAL
    return (
        <>
            {/* Table Heading  */}

            <View style={{ border: '1px solid #e5e5e5', borderRadius: 8, margin: '15px 0 10px', }}>
                {/* Table Heading */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    {/* Sr.NO. */}
                    <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Sr. No.</Text>
                    </View>
                    {/* Description */}
                    <View style={{ padding: 10, width: '39%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Description</Text>
                    </View>
                    {/* Qty */}
                    <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Qty</Text>
                    </View>
                    {/* Unit Price(AED): */}
                    <View style={{ padding: 10, width: '22.5%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Unit Price(AED)</Text>
                    </View>
                    {/* Amount: */}
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableTitle}>Amount(AED)</Text>
                    </View>
                </View>
                {/* Table Data  */}
                {/* deatil-1  */}
                {(props?.scope?.length  && props?.type == "user") ? <>
                {props?.scope?.map((item: any, index: number) => {
                    const UNIT_PRICE=(item?.unit_price)/(1-(Number(props?.commission_percentage)/100))
                    const Amount=UNIT_PRICE * item?.quantity 
                    return <View key={index} style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                        {/* Sr.NO. */}
                        <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                            <Text style={styles.tableDes}>{index + 1}</Text>
                        </View>
                        {/* Description */}
                        <View style={{ padding: 10, width: '39%', borderRight: '1px solid #e5e5e5' }}>
                            <Text style={styles.tableDes}>{props?.sub_services?.name || 'N/A'}</Text>
                        </View>
                        {/* Qty */}
                        <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                            <Text style={styles.tableDes}>{item?.quantity || 'N/A'}</Text>
                        </View>
                        {/* Unit Price(AED): */}
                        <View style={{ padding: 10, width: '22.5%', borderRight: '1px solid #e5e5e5' }}>
                            <Text style={styles.tableDes}>{((item?.unit_price)/(1-(Number(props?.commission_percentage)/100)))?.toFixed(2) || 'N/A'}</Text>
                        </View>
                        {/* Amount: */}
                        <View style={{ padding: 10, width: '22.5%' }}>
                            <Text style={styles.tableDes}>{Amount?.toFixed(2) || 'N/A'}</Text>
                        </View>
                    </View>
                })} </> 
                : 
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                {/* Sr.NO. */}
                <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{ 1}</Text>
                </View>
                {/* Description */}
                <View style={{ padding: 10, width: '39%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{props?.sub_services?.name || 'N/A'}</Text>
                </View>
                {/* Qty */}
                <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{1 || 'N/A'}</Text>
                </View>
                {/* Unit Price(AED): */}
                <View style={{ padding: 10, width: '22.5%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{UNIT_PRICE || 'N/A'}</Text>
                </View>
                {/* Amount: */}
                <View style={{ padding: 10, width: '22.5%' }}>
                    <Text style={styles.tableDes}>{UNIT_PRICE || 'N/A'}</Text>
                </View>
            </View>}

                {/* Total Amount */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Total Amount</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${props?.is_quotation_based ? QUOTATION_BASED_SUBTOTAL ?.toFixed(2): NOQUOTATION_BASED_SUBTOTAL?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
                {/* Service Fee */}
                {(props?.type == "vendor" || props?.is_quotation_based) ? "" : <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Service Fee</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${props?.service_fee?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>}
                {/* VAT */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>VAT</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${VAT?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
                {/* Grand Total(Amount+VAT) */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={{ ...styles.tableTitle, fontWeight: 'black' }}>Grand Total(Amount+VAT)</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={{ ...styles.tableDes, fontWeight: 'black' }}>{`AED ${props?.is_quotation_based ? GRANDTOTAL?.toFixed(2) : GRANDTOTAL1?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
            </View >


            {/* EXTRA WORK  */}

            {props?.is_accpted_ewq && <View style={{ border: '1px solid #e5e5e5', borderRadius: 8, margin: '15px 0 10px', }}>
                {/* Table Heading */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    {/* Sr.NO. */}
                    <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Sr. No.</Text>
                    </View>
                    {/* Description */}
                    <View style={{ padding: 10, width: '70%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Extra Work Description</Text>
                    </View>
                    {/* Qty */}
                    {/* <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Qty</Text>
                    </View> */}
                    {/* Unit Price(AED): */}
                    {/* <View style={{ padding: 10, width: '22.5%', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Unit Price(AED)</Text>
                    </View> */}
                    {/* Amount: */}
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableTitle}>Amount(AED)</Text>
                    </View>
                </View>
                {/* Table Data  */}
                {/* deatil-1  */}
                
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                {/* Sr.NO. */}
                <View style={{ padding: 10, width: '8%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{ 1}</Text>
                </View>
                {/* Description */}
                <View style={{ padding: 10, width: '69.6%', borderRight: '1px solid #e5e5e5' }}>
                    <Text style={styles.tableDes}>{props?.sub_services?.name || 'N/A'}</Text>
                </View>
                {/* Qty */}
                <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${EXTRA_WORK_AMOUNT?.toFixed(2)}`}</Text>
                    </View>
               
            </View>

                {/* Total Amount */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>Total Amount</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${EXTRA_WORK_AMOUNT?.toFixed(2)}`}</Text>
                    </View>
                </View>
               
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={styles.tableTitle}>VAT</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={styles.tableDes}>{`AED ${EXTRA_WORK_VAT?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
                {/* Grand Total(Amount+VAT) */}
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={{ ...styles.tableTitle, fontWeight: 'black' }}>Extra work Total(Amount+VAT)</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={{ ...styles.tableDes, fontWeight: 'black' }}>{`AED ${(EXTRA_WORK_TOTAL)?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
                <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: 'row', width: '100%' }}>
                    <View style={{ padding: 10, width: '77.5%', textAlign: 'right', borderRight: '1px solid #e5e5e5' }}>
                        <Text style={{ ...styles.tableTitle, fontWeight: 'black' }}>Grand Total(Total+Extra work)</Text>
                    </View>
                    <View style={{ padding: 10, width: '22.5%' }}>
                        <Text style={{ ...styles.tableDes, fontWeight: 'black' }}>{`AED ${(GRANDEXTRAWORKTOTAL)?.toFixed(2)}` || 'N/A'}</Text>
                    </View>
                </View>
            </View >}
        </>
    )
}








export default InvoiceTable;