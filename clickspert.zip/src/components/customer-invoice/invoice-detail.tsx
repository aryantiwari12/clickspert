// 'use client'
import { Text, View, StyleSheet, Font } from '@react-pdf/renderer';
import dayjs from 'dayjs';
import { capitalize } from 'lodash';

Font.register({
    family: 'bold',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayBold.woff",
    fontWeight: 'bold'
});

Font.register({
    family: 'medium',
    src: "https://fonts.cdnfonts.com/s/66603/WixMadeforDisplayRegular.woff",
});


// Create styless
const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        // flexGrow: 1,
    },
    titleContainer: {
        marginTop: 10,
        marginBottom: 30,
    },
    reportTitle: {
        color: '#000',
        fontSize: 24,
        textAlign: 'center',
        textTransform: 'capitalize',
        fontWeight: 900,
        textDecoration: 'underline'
    },
    font10: {
        fontSize: 10,
        color: '#000'
    },
    w_20: {
        width: '20%'
    },
    w_30: {
        width: '30%'
    },
    tableTitle: {
        fontSize: 12,
        color: '#828282',
        fontWeight: 600,
        letterSpacing: -0.16
    },
    tableDes: {
        fontSize: 12,
        color: '#121212',
        fontWeight: 600,
        letterSpacing: -0.16,
    }
});
const InvoiceDetail = (props: any) => {
    console.log(props, "prss");
    const  street_address=props?.address ? `${props?.address?.house_no ? `${props?.address?.house_no} , ` : " "}${props?.address?.city ? `${props?.address?.city} , ` : " "}${props?.address?.postal_code ? `${props?.address?.postal_code } , ` :  ""}${props?.address?.state ? `${props?.address?.state} , ` : " "}${props?.address?.country ? `${props?.address?.country} , ` : " "}${capitalize(props?.address?.address_type ? `${props?.address?.address_type} , ` : "")}` : "N/A"
    return (
        <>
            {/* Title  */}
            <View style={styles.titleContainer}>
                <Text style={styles.reportTitle}>Tax Invoice</Text>
            </View>

            <View style={{ border: '1px solid #e5e5e5', borderRadius: 8, margin: '15px 0 10px', }}>
                <View style={{ flexDirection: 'row', width: '100%' }}>
                    {/* left  */}
                    <View style={{ borderRight: '1px solid #e5e5e5', width: '50%' }}>
                        {/* Client */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Client:</Text>
                            <Text style={styles.tableDes}>{props?.type == "user" ? props?.users?.name ?? "N/A" : props?.vendor?.name ?? "N/A"}</Text>
                        </View>
                        {/* Address */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Address:</Text>
                            <Text style={styles.tableDes}>{(street_address || 'N/A')}</Text>
                        </View>
                        {/* Mobile No */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Mobile No:</Text>
                            <Text style={styles.tableDes}>{props?.type == 'user' ? props?.users?.phone_no ?? "N/A" : props?.vendor?.phone_no ?? "N/A"}</Text>
                        </View>
                        {/* TRN: */}
                        {props?.type != "user" && <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>TRN:</Text>
                            <Text style={styles.tableDes}>{props?.trn || 'N/A'}</Text>
                        </View>}
                    </View>
                    {/* Right  */}
                    <View style={{ width: '50%' }}>
                        {/* Order No */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Order No:</Text>
                            <Text style={styles.tableDes}>{props?.order_no ? `${props?.order_no}` : 'N/A'}</Text>
                        </View>
                        {/* Order No */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Invoice No:</Text>
                            <Text style={styles.tableDes}>{props?.invoice_no ? `${props?.invoice_no}` : 'N/A'}</Text>
                        </View>
                        {/* Date: */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Date:</Text>
                            <Text style={styles.tableDes}>{dayjs(props?.date).format("DD/MMM/YYYY")}</Text>
                        </View>
                        {/* Email: */}
                        <View style={{ borderBottom: '1px solid #e5e5e5', flexDirection: "row", justifyContent: 'space-between', padding: 10 }}>
                            <Text style={styles.tableTitle}>Email:</Text>
                            <Text style={styles.tableDes}>{props?.type == "user" ? props?.users?.email : props?.vendor?.email || 'N/A'}</Text>
                        </View>
                    </View>
                </View>
                {/* Subject */}
                {/* <View style={{ flexDirection: "row", padding: 10, gap: 4 }}>
                    <Text style={styles.tableTitle}>Subject:</Text>
                    <Text style={styles.tableDes}>{props?.subject || 'N/A'}</Text>
                </View> */}
            </View >
        </>
    )
}

export default InvoiceDetail;