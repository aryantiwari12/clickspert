import { Button, Col, Form, Input, Modal, Row, Select, Upload } from 'antd'
import Image from 'next/image'
import React, { useState } from 'react'
import { PlusOutlined } from '@ant-design/icons';
import Cardimg from '../../assets/images/banner.png'
const HomepageModal=({isModalOpen,setIsModalOpen}:any)=> {
    const [imageUrl, setImageUrl] = useState<string>();

    const uploadButton = (
    <div>
        <PlusOutlined />
        <div style={{ marginTop: 8 }}>Upload</div>
    </div>
)
  return (
   <>
   <Modal className='notification' centered={true} title={isModalOpen} open={!!isModalOpen} onCancel={() => setIsModalOpen('')} footer={false}>
                    {isModalOpen === "Services" ? <Form className='mt-3'
                        size='large'
                        layout='vertical'>
                        <Form.Item label='Name'>
                            <Input placeholder='Name' className='border-0' />
                        </Form.Item>
                        <Form.Item label="Service">
                            <Select
                                allowClear
                                placeholder='Select Service'
                            >
                                <Select.Option>a</Select.Option>
                            </Select>
                        </Form.Item>
                        <Form.Item label="Sub Service">
                            <Select
                                allowClear
                                placeholder='Select Sub Service'
                                mode='tags'
                            >
                                <Select.Option>a</Select.Option>
                            </Select>
                        </Form.Item>

                        <Form.Item>
                            <Row className='mt-2' gutter={[15, 15]}>
                                <Col span={24} lg={6}>
                                    <div className='service-modal-img'>
                                        <Image src={Cardimg} alt='img' />
                                    </div>
                                </Col>
                            </Row>
                        </Form.Item>
                        <Form.Item className='mb-0'>
                            <Button type='primary' className='mt-4' block>Save</Button>
                        </Form.Item>
                    </Form> : <>
                        <Form size='large' layout='vertical' >
                            <Form.Item className='text-center'>
                                <Upload
                                    name="avatar"
                                    listType="picture-circle"
                                    className="avatar-uploader"
                                    showUploadList={false}
                                    action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                                >
                                    {imageUrl ? <img src={imageUrl} alt="avatar" style={{ width: '100%' }} /> : uploadButton}
                                </Upload>
                            </Form.Item>
                            <Form.Item label="Title">
                                <Input placeholder='Enter Title' />
                            </Form.Item>
                            <Form.Item label='Description'>
                                <Input placeholder='Enter Description' />
                            </Form.Item>
                            <Button type='primary' icon={<PlusOutlined />} className='mt-3' block>Add</Button>
                        </Form>
                    </>}
                </Modal>
   </>
  )
}

export default HomepageModal