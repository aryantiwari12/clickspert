import { Typography } from 'antd'
import Image from 'next/image'
import Link from 'next/link'
import React from 'react'
import Cardimg from '../../assets/images/banner.png'

const Servicecard = (props:any) => {
    return (
        <>
            <Link href={''}>
                <div className='services-img'>
                    <Image src={Cardimg} alt='img' />
                    <div className="services-img-content">
                        <Typography.Title level={5} className='fw-700 text-white m-0'>{props.title}</Typography.Title>
                        <Typography.Title level={4} className='text-white m-0'>AED 50</Typography.Title>
                    </div>
                </div></Link>
        </>
    )
}

export default Servicecard