import { Avatar, Button, Card, Form, Input, Modal, Popconfirm, Table, Typography } from "antd";
import ColumnsTyped from '@/interfaces/ColumnsType';
import { ReactNode, useContext } from "react";
import user from '@/assets/images/placeholder.png'
import React from "react";
import HenceforthIcons from "./HenceforthIcons";
import dayjs from "dayjs";
import henceforthApi from "@/utils/henceforthApi";
import placeholder from "../assets/images/placeholder.png"
import { GlobalContext } from "@/context/Provider";
import { useRouter } from "next/router";
import henceforthValidations from "@/utils/henceforthValidations";

interface DataType11 {
  key: React.Key;
  srno: ReactNode,
  date: ReactNode,
  orderid: ReactNode,
  TransactionId: ReactNode,
  Type: ReactNode,
  PointsCredited: ReactNode,
  phone: ReactNode,
  email: ReactNode,
  service: ReactNode,
  name: ReactNode,
  actions: ReactNode,
}

const UserAppWallet = (props: any) => {
  const router = useRouter()
  const [form] = Form.useForm()
  const { setLoading, loading, Toast, currency } = useContext(GlobalContext)
  const [isModalOpen, setIsModalOpen] = React.useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  console.log(props, "props");
  const handleFinish = async (values: any) => {
    const data = {
      user_id: router.query._id,
      amount: Number(values.amount),
      currency: currency?._id
    }
    try {
      setLoading(true)
      const apiRes = await henceforthApi.User.sendMoney(data);
      props?.getWallets()
      Toast.success(apiRes?.message)
      setIsModalOpen(false)
    } catch (error) {

    }
    finally {
      setLoading(false)
    }
  }
  const datatwo: DataType11[] =
    props?.wallet?.data?.map((item: any, index: number) => {
      return {
        key: index + 1,
        srno: index,
        orderid: item?.unique_order_id ? `${item?.unique_order_id}` : "N/A",
        date: dayjs(item?.created_at).format("ddd, MMM DD - hh:mm a"),
        Type: henceforthValidations.capitalizeFirstLetter(item?.transaction_type),
        TransactionId: item?.transaction_id,
        name:item?.service_id ? <div className='user-detail d-inline-flex gap-2 align-items-center'>
          <Avatar size={40} shape="square" src={henceforthApi.FILES.imageSmall(item?.sub_service_id?.image) || placeholder.src}></Avatar>{item?.service_id?.name}</div> : "N/A",
        PointsCredited: "10 points",
        actions: <span className='d-flex align-items-center text-success'>{`AED ${item?.amount}`} </span>
      }
    })

  return (
    <>
      <Card className='common-card mt-4'>
        <div className="d-flex justify-content-between">
        <div className='d-flex align-items-center mb-3'>
          <Typography.Title level={3} className='m-0 me-4 fw-bold'>App Wallet</Typography.Title>
          <p className='text-muted mb-0 border p-2'>Total App Wallet: <span className='text-dark fw-semibold'>{props?.wallet?.total_amount ? `AED ${props?.wallet?.total_amount}` : "0"}</span></p>

        </div>
        <div>
        <Button type='primary' size='large' onClick={() => { showModal() }} className='text-end'>Send Money</Button>

        </div>
        </div>
        <Table dataSource={datatwo} columns={ColumnsTyped.dataSourcepointtwo} pagination={false} scroll={{ x: '100%' }} />
        {props?.wallet?.data?.length > 10 && <div className='text-end mt-4'><a className="border-0 text-dark fw-semibold text-decoration-none">View All <HenceforthIcons.LeftArrowArchive /></a></div>}

      </Card>
      <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <div className='text-center'>
          <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Send Money </Typography.Title>
          <Form size='large' form={form} layout='vertical' className='mt-2' onFinish={handleFinish}>
            <Form.Item label='Amount (AED)' name="amount" rules={[{ required: true, message: 'Please enter amount', whitespace: true }]} >
              <Input placeholder='Amount' onKeyPress={(e: any) => {
                if (!/[0-9]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                  e.preventDefault();
                }
              }} className='border-0' />
            </Form.Item>
            <Form.Item className='mb-2 mt-4'>
              <Button type='primary' loading={loading} htmlType='submit' block><span className='text-white'>Send</span></Button>
            </Form.Item>
          </Form>
        </div>
      </Modal>
    </>
  )
}
export default UserAppWallet;