import { Button, Popconfirm, Table } from "antd"
import HenceforthIcons from "../HenceforthIcons"
import { ColumnsType } from "antd/es/table"

export const ApartmentTable = (props: any) => {
    console.log(props,'props');
    
    const ApartmentColumns: ColumnsType<any> = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, object: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Rooms',
            dataIndex: 'rooms',
            width: 150,
        },
        {
            title: 'Price',
            dataIndex: 'price',
            width: 150
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { props?.showEditModal('apartment', res, res?._id, props?._id ,props) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete apartment"
                        onConfirm={() => props?.onDelete(res._id, 'apartment')}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ]


    return(
        <>
         <Table dataSource={props?.apartments} columns={ApartmentColumns} pagination={false} scroll={{ x: '100%' }} />
        </>
    )
}