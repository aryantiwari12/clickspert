import { Avatar, Button, Card, Col, Popconfirm, Table, Typography } from "antd";
import ColumnsType from '@/interfaces/ColumnsType';
import HenceforthIcons from "../HenceforthIcons";
import React, { ReactNode, useContext } from "react";
import { capitalize } from "lodash";
import Link from "next/link";
import henceforthApi from "@/utils/henceforthApi";
import { GlobalContext } from "@/context/Provider";

interface DataType2 {
  key: string;
  srno: number;
  name: ReactNode;
  email: string;
  phone: number;
  service: ReactNode;
  actions: ReactNode;
}
const DashboardUser = (props: any) => {
  const [vendor, setVendor] = React.useState(props?.vendor)
  console.log(props);

  const { Toast } = useContext(GlobalContext)
  const Managevendor = async (_id: any, name: any, index: number) => {
    try {
      const info = {
        vendor_id: _id,
        account_status: name,
        account_rejection_reason: ''
      }
      let apiRes = await henceforthApi.Vendor.manage(info)
      Toast.success(apiRes.message)
      vendor?.data?.splice(index, 1)
      setVendor({ data: vendor?.data, count: vendor.count - 1 })
    } catch (error) {

    }
  }
  const dataSource2: DataType2[] = vendor?.data?.map((item: any, index: number) => {
    return {
      key: index + 1,
      srno: index + 1,
      name: <div className='d-flex align-items-center'>
        <Avatar src={'user.src'} size={40}></Avatar><span className='ms-2'>{capitalize(item?.name)}</span>
      </div>,
      phone: item?.phone_no ? item?.country_code + "-" + item?.phone_no : "N/A",
      email: item?.email ?? "N/A",
      service: <div className="text-wrap">{item?.services?.length ? item?.services?.map((item: any) => item) : "N/A"}</div>,
      actions: <span className='d-flex align-items-center'>
        <Link href={`/vendor-request/${item?._id}/view`} style={{ textDecoration: "none" }}>      
        <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button></Link>
        <Popconfirm
          title="Accept the Vendor"
          onConfirm={() => Managevendor(item?._id, "ACCEPT", index)}
          description="Are you sure to Accept this Vendor?"
          okText="Accept"
          cancelText="No"
        >
          <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button>
        </Popconfirm>
        <Popconfirm
          title="Reject the Vendor"
          onConfirm={() => Managevendor(item?._id, "REJECT", index)}
          description="Are you sure to Reject this Vendor?"
          okText="Reject"
          cancelText="No"
        >
          <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.No />
          </Button>
        </Popconfirm></span>
    }
  })

  return (
    <>
      <Col span={24}>
        <Card className='common-card'>
          <Typography.Title level={3} className='m-0 mb-4 fw-bold'>Recent Vendors Requests</Typography.Title>
          <Table dataSource={dataSource2} columns={ColumnsType.userColumns2} pagination={false} scroll={{ x: '100%' }} />
          {props?.vendor?.count > 5 && <div className='text-end mt-4'><a className="border-0 text-dark fw-semibold text-decoration-none"><Link href={"/vendor-request/page/1"} className="text-dark" style={{ textDecoration: "none" }}>View All<HenceforthIcons.LeftArrowArchive /></Link></a></div>}
        </Card>
      </Col>
    </>
  )
}
export default DashboardUser;