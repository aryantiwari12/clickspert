import React, { Fragment, useEffect, useState } from 'react'
import logo from "@/assets/images/logo.png"
import favicon from "@/assets/images/favicon.png";
import { Typography, type MenuProps, Button } from 'antd';
import { CloseOutlined } from '@ant-design/icons'

const { Menu } = {
  Menu: dynamic(() => import("antd").then(module => module.Menu), { ssr: false }),
}

import {
  DashboardOutlined,
  MessageOutlined,
  LaptopOutlined,
  UserOutlined,
  ContactsOutlined,
  UnorderedListOutlined,
  GlobalOutlined,
  HomeOutlined,
  FileWordOutlined,
  QuestionCircleOutlined,
  MailOutlined,
  BookOutlined,
  OrderedListOutlined,
  DatabaseOutlined,
  AppstoreAddOutlined,
  CreditCardOutlined
} from '@ant-design/icons';
import Link from 'next/link';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import HenceforthIcons from '../HenceforthIcons';
import henceofrthEnums from '@/utils/henceofrthEnums';
import { useRouter } from 'next/router';

const iconSize = { fontSize: '18px' };
type MenuItem = Required<MenuProps>['items'][number];

function getItem(
  label: React.ReactNode,
  key: React.Key,
  icon?: React.ReactNode,
  children?: MenuItem[],
  type?: 'group',
): MenuItem {
  return {
    key,
    icon,
    children,
    label,
    type,
  } as MenuItem;
}



const MenuBar = ({ collapsed, setCollapsed }: any) => {
  const { userInfo, contentPages, setContentPages } = React.useContext(GlobalContext)
  // const [openKeys, setOpenKeys] = useState(['sub1']);
  const router = useRouter()
console.log(router);

  // const onOpenChange: MenuProps['onOpenChange'] = (keys) => {
  //   const latestOpenKey = keys.find((key) => openKeys.indexOf(key) === -1);
  //   if (rootSubmenuKeys.indexOf(latestOpenKey!) === -1) {
  //     setOpenKeys(keys);
  //   } else {
  //     setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
  //   }
  // };

  const initialiseContentPages = async () => {
    try {
      // let apiRes = await henceforthApi.Content.get()
      // setContentPages(Array.isArray(apiRes) ? apiRes : apiRes?.data)
    } catch (error) {

    }
  }

  useEffect(() => {
    if (contentPages?.length == 0) {
      initialiseContentPages()
    }
  }, [])
  const showCheck = (type: string | Array<string>) => {
    if (Array.isArray(type)) {
      return type?.some(res => userInfo?.roles?.includes(res)) || userInfo?.super_admin
    }
    return userInfo?.roles?.includes(type) || (userInfo?.super_admin)
  }
  function options(array: any) {
    return array.filter((res: any) => showCheck(res.key)).map((res: any) => { return res.view })
  }
  const vend = options([
    { key: henceofrthEnums.Roles.VENDOR_REQUEST, view: getItem(<Link href="/vendor-request/page/pending/1" className='text-decoration-none'>Vendor request</Link>, 'vendor-request') },
    { key: henceofrthEnums.Roles.VENDORS, view: getItem(<Link href="/vendor/page/1" className='text-decoration-none'>Vendors</Link>, 'vendor') },
  ])

  const Orders = options([
    { key: henceofrthEnums.Roles.ORDER_REQUEST, view: getItem(<Link href="/order-request/page/1" className='text-decoration-none'>Order Requests</Link>, 'order-request',) },
    { key: henceofrthEnums.Roles.ORDERS, view: getItem(<Link href="/orders/page/1" className='text-decoration-none'>Orders</Link>, 'orders',) },
  ])

  // contentPages?.length > 0 ? contentPages?.map((res) =>
  //   getItem(<Link href={`/orders/${res._id}`} className='text-decoration-none'>{res.name || res.type}</Link>, 'o'),
  // ) :
  const mainMenu = [
    { key: henceofrthEnums.Roles.DASHBOARD, view: getItem(<Link href='/' className='text-decoration-none ms-1'>Dashboard</Link>, 'dashboard', <HenceforthIcons.Dashboard />) },
    { key: henceofrthEnums.Roles.USERS, view: getItem(<Link href='/user/page/1' className='text-decoration-none'>Users</Link>, 'user', <UserOutlined style={iconSize} />) },
    { key: [henceofrthEnums.Roles.VENDOR_REQUEST, henceofrthEnums.Roles.VENDORS], view: getItem('Vendors', 'sub4', <span><HenceforthIcons.Vendors /></span>, vend,) },
    { key: henceofrthEnums.Roles.SERVICES, view: getItem(<Link href='/services/page/1' className='text-decoration-none ms-2'>Services</Link>, 'services', <HenceforthIcons.Services />) },
    { key: [henceofrthEnums.Roles.ORDERS, henceofrthEnums.Roles.ORDER_REQUEST], view: getItem('Orders', 'sub', <span><HenceforthIcons.Orders /></span>, Orders,) },
    { key: henceofrthEnums.Roles.FEEDBACK, view: getItem(<Link href='/feedback/page/1' className='text-decoration-none ms-2 '>Review</Link>, 'feedback', <HenceforthIcons.Feedback />) },
  ]
  const transactions = options([
    { key: henceofrthEnums.Roles.TRANSACTIONS, view: getItem(<Link href="/transactions/transaction/all/page/1" className='text-decoration-none'>Transaction</Link>, 'transaction') },
    { key: henceofrthEnums.Roles.TRANSACTION_PAYOUTS, view: getItem(<Link href="/transactions/payouts/all/page/1" className='text-decoration-none'>Payouts</Link>, 'payouts') },
    { key: henceofrthEnums.Roles.TRANSACTION_CLICKSPERT_POINT, view: getItem(<Link href="/transactions/clickspert-points/page/1" className='text-decoration-none'>Clickspert Points</Link>, 'clickspert-points') },
    { key: henceofrthEnums.Roles.TRANSACTION_APP_WALLET, view: getItem(<Link href="/transactions/app-wallet/page/1" className='text-decoration-none'>App Wallet</Link>, 'app-wallet') },
  ])

  const FAQ = [
    { key: henceofrthEnums.Roles.FAQ_USER, view: getItem(<Link href="/faq-user/page/1" className='text-decoration-none'>User</Link>,  'faq-user' ) },
    { key: henceofrthEnums.Roles.FAQ_VENDOR, view: getItem(<Link href="/faq/vendor/view" className='text-decoration-none'>Vendor</Link>,   'faq' ) },
  ]

  const general = [
    { key: henceofrthEnums.Roles.PAGES, view: getItem(<Link href='/content/page/1' className='text-decoration-none ms-2'>Pages</Link>, 'content', <HenceforthIcons.Pages />) },
    { key: henceofrthEnums.Roles.HOME_PAGE, view: getItem(<Link href='/homepage/page/1' className='text-decoration-none'>Home Page</Link>, 'homepage', <HomeOutlined style={iconSize} />) },
    // { key: henceofrthEnums.Roles.LANGUAGE, view: getItem(<Link href='/language/parent/1' className='text-decoration-none'>Languages</Link>, 'language', <GlobalOutlined style={iconSize} />) },
    { key: [henceofrthEnums.Roles.TRANSACTIONS, henceofrthEnums.Roles.TRANSACTION_PAYOUTS, henceofrthEnums.Roles.TRANSACTION_CLICKSPERT_POINT, henceofrthEnums.Roles.TRANSACTION_APP_WALLET], view: getItem('Transactions', 'sub1', <span><HenceforthIcons.Transactions /></span>, transactions,) },
    { key: henceofrthEnums.Roles.DOCUMENT, view: getItem(<Link href='/document/page/1' className='text-decoration-none'>Document</Link>, 'document', <FileWordOutlined style={iconSize}/>) },
    
  ]
  const ContenList = [
    { key: henceofrthEnums.Roles.CONTENT_LIST_COMMISSION, view: getItem(<Link href="/content-list/commission/page/1" className='text-decoration-none'>Commission</Link>, 'commission') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_CLICKSPERT_POINT, view: getItem(<Link href="/content-list/clickspert-point/page/1" className='text-decoration-none'>Clickspert Point</Link>, 'clickspert-point') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_PROMO_CODE, view: getItem(<Link href="/content-list/promo-code/page/1" className='text-decoration-none'>Promo Code</Link>, 'promo-code') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_COMPLAINTS, view: getItem(<Link href="/content-list/complaints/page/1" className='text-decoration-none'>Feedbacks</Link>, 'complaints') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_LOCATIONS, view: getItem(<Link href="/content-list/locations/page/1" className='text-decoration-none'>Locations</Link>, 'locations') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_SERVICE_FEE, view: getItem(<Link href="/content-list/service-fee/add" className='text-decoration-none'>Service Fee</Link>, 'service-fee') },
    { key: henceofrthEnums.Roles.CONTENT_LIST_REFER_A_FRIEND, view: getItem(<Link href="/content-list/refer-friend" className='text-decoration-none'>Refer a Friend</Link>, 'refer-friend') },
  ]
  const Salon = [
    { key: henceofrthEnums.Roles.SALON, view: getItem(<Link href="/salon/items/1" className='text-decoration-none'>Items</Link>, 'items') },
    { key: henceofrthEnums.Roles.SALON, view: getItem(<Link href="/salon/services/1" className='text-decoration-none'>Services</Link>, 'service') },
  ]
  let men = options(mainMenu.filter(res => showCheck(res.key)))

  let gen = options(general.filter(res => showCheck(res.key)))
  // console.log(gen, "gen");
  let content = options(ContenList.filter(res => showCheck(res.key)))
  let faq = options(FAQ.filter((res:any) => showCheck(res.key)))
  let salo = options(Salon.filter(res => showCheck(res.key)))
  const management = [
    {
      key: [henceofrthEnums.Roles.CONTENT_LIST_COMMISSION,
      henceofrthEnums.Roles.CONTENT_LIST_CLICKSPERT_POINT,
      henceofrthEnums.Roles.CONTENT_LIST_PROMO_CODE,
      henceofrthEnums.Roles.CONTENT_LIST_COMPLAINTS,
      henceofrthEnums.Roles.CONTENT_LIST_LOCATIONS,
      henceofrthEnums.Roles.CONTENT_LIST_SERVICE_FEE,
      henceofrthEnums.Roles.CONTENT_LIST_REFER_A_FRIEND,
      ], view: getItem('Content List', 'sub2', <span><HenceforthIcons.Services /></span>, content,)
    },
    {
      key: [henceofrthEnums.Roles.FAQ_USER,
      henceofrthEnums.Roles.FAQ_VENDOR,
      ], view: getItem('FAQ', 'sub3', <span><HenceforthIcons.Services /></span>, faq,)
    },
    // { key: henceofrthEnums.Roles.SALON, view: getItem('Salon', 'sub4', <span><HenceforthIcons.Services /></span>, salo,) },
    // { key: henceofrthEnums.Roles.FAQ, view: getItem(<Link href='/faq/page/1' className='text-decoration-none'>FAQs</Link>, 'faq', <QuestionCircleOutlined style={iconSize} />) },
    { key: henceofrthEnums.Roles.CONTACT, view: getItem(<Link href='/contact-us/page/1' className='text-decoration-none ms-2'>Contact</Link>, 'contact-us', <HenceforthIcons.Contact />) },
    // { key: henceofrthEnums.Roles.NOTIFICATION, view: getItem(<Link href='/notification/page/1' className='text-decoration-none ms-2'>Notificaion</Link>, '22', <HenceforthIcons.Notification />) },
    {
      key: henceofrthEnums.Roles.NOTIFICATION, view: getItem(<Link href='/email' className='text-decoration-none '>Email</Link>, 'email', <span className='ms-1'>
        <MailOutlined />
      </span>)
    },
    {
      key: henceofrthEnums.Roles.CLOUD_MESSAGING, view: getItem(<Link href='/notification/page/1' className='text-decoration-none '>Cloud Messaging</Link>, 'notification', <span className='ms-1'>
        <MailOutlined />
      </span>)
    },
    { key: henceofrthEnums.Roles.DB_BACKUP, view: getItem(<Link href='/database' className='text-decoration-none ms-2'>DB Backup</Link>, 'database', <HenceforthIcons.DBBackup />) }
  ]
  let mana = options(management.filter(res => showCheck(res.key)))
  // const paths = ['dashboard', 'users', 'tickets', 'payouts', 'transactions', 'contact-us', 'reports', 'commission', 'faqs', 'cloud-messaging', 'database']
  const [, root, sub, subroot] = router.pathname?.split('/');
  const subRoot = [['content-list', 'transactions'].includes(root) ? sub : root || 'dashboard']
  const items: MenuItem[] = [
    getItem(!collapsed && <Typography.Title level={5} className='m-0 fw-bold' type='secondary'>MAIN MENU</Typography.Title>, 'general', null, men, `group`),
    getItem(!collapsed && <Typography.Title level={5} className='m-0 fw-bold' type='secondary'>GENERAL</Typography.Title>, 'general', null, gen, `group`),
    getItem(!collapsed && <Typography.Title level={5} className='m-0 pt-3 fw-bold' type='secondary'>MANAGEMENT</Typography.Title>, '', null, mana, 'group'),
  ];
  if (!men.length) {
    items.splice(0, 1)
  }
  if (!gen.length) {
    items.splice(!men.length ? 0 : 1, 1)
  }
  if (!mana.length) {
    items.pop()
  }
  return (
    <div className='menu-wrapper position-relative'>
      <div className="logo ">
        <Link href="/"><img src={`${!collapsed ? logo.src : favicon.src}`} alt="logo" className='img-fluid' /></Link>
        {/* <div className='position-absolute' style={{ top: '-10px', right: '2px' }}>
          <Button className='d-lg-none p-0' shape='circle' size='small' type='primary' icon={<CloseOutlined style={{ width: '10px' }} />} onClick={() => setCollapsed(true)}></Button>
        </div> */}
      </div>
      <div className={`menu-profile-wrapper my-4 d-flex align-items-center gap-2 ${!collapsed ? "bg-light" : "p-0 bg-tranaprent"}`}>
        <img src={henceforthApi.FILES.imageMedium(userInfo?.image || "", favicon.src)} alt="avatar" className='profile-img ' />
        {!collapsed && <div>
          <Typography.Title level={5} className='m-0 fw-bold text-capitalize'>{userInfo?.name}</Typography.Title>
          <Typography.Paragraph className='m-0'>{userInfo?.super_admin ? "Super Admin" : "Admin"}</Typography.Paragraph>
        </div>}
      </div>
      <div className={`border-0 ${!collapsed ? "ps-3" : "ps-0"}`}>
        <Menu
          mode="inline"
          selectedKeys={subRoot}
          items={items}
        />
      </div>
    </div>
  )
}

export default MenuBar