import Link from 'next/link';

const DownloadPDF=()=> {
  return (
    <div>
      <h1>Download PDF</h1>
      <Link href="/pdf/your-pdf-file.pdf" download>
        <a>Click here to download PDF</a>
      </Link>
    </div>
  );
}

export default DownloadPDF;