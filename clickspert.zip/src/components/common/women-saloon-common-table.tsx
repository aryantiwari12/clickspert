import { Button, Form, Input, Modal, Popconfirm, Select, Table, Tag, Tooltip, Typography } from "antd"
import HenceforthIcons from "../HenceforthIcons"
import { ColumnsType } from "antd/es/table"
import React from "react"
import henceforthApi from "@/utils/henceforthApi"
import { useRouter } from "next/router"
import { GlobalContext } from "@/context/Provider"
import dynamic from "next/dynamic"
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const WomenCommonTable = (props: any) => {
    const router = useRouter()
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [form] = Form.useForm()
    const { Toast, loading, currency, setLoading } = React.useContext(GlobalContext)
    const [isModalOpen, setIsModalOpen] = React.useState('');
    const [modalName, setModalName] = React.useState('')
    const [edit, setEdit] = React.useState({} as any)
    const [pacakageList, setpackageList] = React.useState([] as any)

   
    const handleCancel = () => {
        setIsModalOpen('')
    };
    const saloonColumns: ColumnsType<any> = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, res: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Services',
            dataIndex: 'services',
            width: 150,
            render: (text: any, res: any, index: any) => { if (props.mainHead) { return res?.name } else return res?.items?.map((resp: any) => resp?.name).toString().replaceAll(',', ' + ') }
        },
        {
            title: 'Price',
            dataIndex: 'price',
            width: 100,
            render: (text: any, res: any, index: any) => { return res?.price ? `AED ${res?.price}`:''  }
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index: number) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' shape='circle' className='bg-transparent border-0' onClick={() => { setModalName(props.mainHead ? props.tableHeading : "Package"); setIsModalOpen('Edit'); setEdit(res) }}><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete Villa"
                        onConfirm={() => deletePackage(res?._id)}
                        okText="Yes"
                        okButtonProps={{loading}}
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent' ><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ]
 
  
    React.useEffect(() => {
        debugger
        let items = {}
        if (isModalOpen === "Edit") {
            if (props.mainHead) {
                items = {
                    rooms: edit?.name,
                    price: edit?.price,
                    disclaimer: edit?.disclaimer,
                }
            } else {
                items = {
                    rooms: Array.isArray(edit?.items) ? edit?.items.map((resp: any) => resp._id) : edit.items_ids,
                    price: edit?.price,
                    disclaimer: edit?.disclaimer,
                }
            }
            form.setFieldsValue(items)
        }
        else{
            form.resetFields()
        }
    }, [isModalOpen])
    console.log(edit, "edit");

    const addSaloonPackage = async (values: any) => {
        setLoading(true)
        try {
            const data = {
                price: Number(values.price),
                price_currency: currency?._id,
                disclaimer: values?.disclaimer,
                sub_service_id: router.query._id
            } as any
            if (props.mainHead) {
                data.type = props.mainHead
                data.sub_type = props.tableHeading
                data.gender = "WOMEN"
                data.name = values?.rooms
            } else {
                data['items_ids'] = values.rooms
            }
            if (isModalOpen == "Edit") {
                data._id = edit?._id
            }
            if (isModalOpen == "Add") {
                let apiRes: any
                if (props.mainHead) {
                    apiRes = await henceforthApi.WomenSaloon.addSubserviceItems(data)
                } else {
                    apiRes = await henceforthApi.WomenSaloon.addPackage(data)
                }
                Toast.success(apiRes?.message)
                setState((state: any) => {
                    return {
                        ...state,
                        data: [...state.data, apiRes?.data],
                        count: state.count + 1
                    }
                })
            }
            else {
                let apiRes: any
                if (props.mainHead) {
                    apiRes = await henceforthApi.WomenSaloon.editSubserviceItems(data)
                } else {
                    apiRes = await henceforthApi.WomenSaloon.editPackage(data)
                }
                const editData = state.data.findIndex((item: any) => item._id === edit?._id)
                console.log(edit?._id, "iddddd");

                Toast.success(apiRes?.message)
                setState((state: any) => {
                    const x = state.data
                    if (x !== -1) {
                        x[editData] = apiRes.data
                    }
                    console.log(editData, x);

                    return {
                        ...state,
                        data: [...x],
                        count: state.count
                    }
                })
            }
            form.resetFields()
            // setSelected([])
            handleCancel()
        } catch (error) {

        }
        finally {
            setLoading(false)
        }

    }
    const deletePackage = async (id: string) => {
        setLoading(true)
        try {
            let apiRes: any
            if (props.mainHead) {
                apiRes = await henceforthApi.WomenSaloon.delSubserviceItems(id)
            }
            else {
                apiRes = await henceforthApi.WomenSaloon.deletePackage(id)
            }
            setState((state: any) => {
                const x = state.data
                const editData = state.data.findIndex((item: any) => item._id === id)
                if (x !== -1) {
                    x.splice(editData,1) 
                }
                return {
                    ...state,
                    data: [...x],
                    count: state.count
                }
            })
            Toast.success(apiRes?.message)
            // getSubServiceList()
        } catch (error) {

        }
        finally {
            setLoading(false)
        }
    }
    const getTableDetails = async () => {
        try {
            if (props.mainHead) {
                const x = await henceforthApi.WomenSaloon.subServiceItemList(router.query._id as string, props.mainHead, props.tableHeading)
                setState(x)
            } else {
                const x = await henceforthApi.WomenSaloon.sub_serviceList(router.query._id as string)
                setState(x)
            }
        } catch (error) {

        }
    }
    const getWomenPackage = async () => {
        try {
            const apiRes = await henceforthApi.WomenSaloon.saloonPackageListing(String(router.query._id))
            console.log(apiRes, "apiRes");
            setpackageList(apiRes?.data)
        } catch (error) {

        }
    }
    // const handleRemove = async (id: string, index: number) => {
    //     selected?.splice(index, 1)
    //     setSelected([...selected])
    // }
    React.useEffect(() => {
        getTableDetails()
        if (!props.mainHead) {
            getWomenPackage()
        }
    }, [])
    // const handleChangePackage = (e: any) => {
    //     let s = e.split(",");
    //     const data = {
    //         _id: s?.[0],
    //         name: s?.[1]
    //     }
    //     selected?.push(data)
    //     setSelected([...selected])
    // }
    return <>
        <div key={props.id} className={`flex-center mt-2${props.mainHead ? ' bg-theme py-2 px-3' : ' mb-3'}`} style={props.mainHead ? { borderStartStartRadius: 8, borderStartEndRadius: 8 } : {}}>
            <Typography.Title level={5} className={`text-capitalize ${props.mainHead ? 'fw-500 m-0' : ''}`}>{props.tableHeading.replaceAll('_', ' ')}</Typography.Title>
            <span role='button' onClick={() => { setModalName(props.mainHead ? props.tableHeading : "Package"); setIsModalOpen('Add') }}>{props.mainHead ? <HenceforthIcons.Add2 /> : <HenceforthIcons.Add />}</span>
        </div>
        <Table prefixCls={props.mainHead ? 'saloon' : ''} className={props.mainHead ? 'mb-4' : ''} dataSource={state.data} columns={saloonColumns} pagination={false} scroll={{ x: '100%' }} />
        <Modal footer={null} centered={true} open={!!isModalOpen} onCancel={handleCancel}>
            <div className=''>
                <Typography.Title level={3} className='fw-700 mb-1 mt-2 text-capitalize text-center'>{isModalOpen + ' ' + modalName.toLowerCase()}</Typography.Title>
                <Form size='large' form={form} layout='vertical' onFinish={addSaloonPackage}>
                    <Form.Item className='' name="rooms" label="Service" rules={[{ required: true, message: 'Enter your Service Name' }]}>
                        {!props.mainHead ? <Select placeholder='Service Name'
                            // onChange={handleChangePackage}
                            mode="multiple"
                        >
                            {pacakageList?.map((item: any, index: number) => <Select.Option key={index} name={item?.name} value={item?._id}>{item?.name}</Select.Option>)}
                        </Select>
                            : <Input placeholder="Service Name" />}
                        {/* {selected?.map((res: any, index: number) => <Tag color="#108EE9" key={res._id} bordered={false} onClose={() => handleRemove(res?._id, index)} closable><Tooltip title={res?.name}>{res?.name}</Tooltip></Tag>)} */}
                    </Form.Item>
                    <Form.Item name="price" rules={[{ required: true, message: 'Enter your Price' }]} label='Price' >
                        <Input onKeyPress={(e) => {
                            if (!/[0-9]/.test(e.key)) {
                                e.preventDefault();
                            }
                        }} className='border-0' placeholder="price" />
                    </Form.Item>
                    <Form.Item name="disclaimer" rules={[{ required: true, message: 'Enter your Disclaimer' }]} label='Disclaimer' >
                        {/* <Input className='border-0' placeholder="Disclaimer" /> */}
                        <ReactQuill className='bg-light border-0' theme="snow" placeholder="Enter your Disclaimer" />
                    </Form.Item>
                    <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                </Form>
            </div>
        </Modal>
    </>
}
export default WomenCommonTable