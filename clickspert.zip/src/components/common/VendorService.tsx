import { Card, Col, Table, Typography } from "antd";
import ColumnsTyped from '@/interfaces/ColumnsType';
import { useRouter } from "next/router";

const VendorService = (props:any) => {
    console.log(props,"stateProps");
    const router=useRouter()
    const CHECKPAGE=router.pathname.startsWith("/vendor-request") ? props?.services :props?.data
    const dataSourcepoint =CHECKPAGE?.map((res:any,index:number)=>{
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            service: res.name || 'N/A',
            subservices: <div className='text-wrap'>
              {Array.isArray(res?.sub_services) && (res?.sub_services.length) ? res?.sub_services.map((res:any,index:number)=><span key={index}>{(index!==0?', ':'')+res.name}</span>):"N/A"}
            </div>
            }
    })
    return (
        <>
            <Col span={24} md={12}>
                <Card className='common-card mt-4 h-100' style={{maxHeight:'500px', overflow:'auto'}}>
                    <div className='d-flex align-items-center mb-3'>
                        <Typography.Title level={3} className='m-0 me-4 fw-bold'>Services</Typography.Title>
                    </div>
                    <Table dataSource={dataSourcepoint} columns={ColumnsTyped.vendorRequestService} pagination={false} scroll={{ x: '100%' }} />
                </Card>
            </Col>
        </>
    )
}
export default VendorService;