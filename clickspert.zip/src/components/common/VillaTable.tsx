import { Button, Popconfirm, Table } from "antd"
import HenceforthIcons from "../HenceforthIcons"
import { ColumnsType } from "antd/es/table"

export const VillaTable = (props: any) => {
    console.log(props, 'props');

    console.log(props?.service_type, 'props?.service_type');
    
    const villaColumns: ColumnsType<any> = props?.service_type == 'PEST_CONTROL' ? [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, object: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Rooms',
            dataIndex: 'rooms',
            width: 150,
        },
        {
            title: 'Internal Price',
            dataIndex: 'internal_price',
            width: 100
        },
        {
            title: 'Both(Internal External) Price',
            dataIndex: 'internal_external_price',
            width: 100
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { props?.showEditModal('villa', res, res?._id, props?._id,props);props?.setPaintType(res?.color) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete Villa"
                        onConfirm={() => props?.onDelete(res._id, 'villa')}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ] :
        [
            {
                title: 'Sr.no.',
                dataIndex: 'key',
                width: 100,
                render: (text: any, object: any, index: any) => { return (index + 1) }
            },
            {
                title: 'Rooms',
                dataIndex: 'rooms',
                width: 150,
            },
            {
                title: 'Price',
                dataIndex: 'price',
                width: 150
            },
            {
                title: 'Action',
                dataIndex: 'action',
                width: 100,
                render: (_: any, res: any, index) => (
                    <div className='d-flex align-items-center'>
                        <Button type='primary' size='middle' onClick={() => { props?.showEditModal('villa', res, res?._id, props?._id,props) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                        <Popconfirm
                            title="Delete"
                            description="Are you sure to delete Villa"
                            onConfirm={() => props?.onDelete(res._id, 'villa')}
                            okText="Yes"
                            cancelText="No">
                            <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                        </Popconfirm>
                    </div>
                )
            }
        ]
    return (
        <>
            <Table dataSource={props?.villas} columns={villaColumns} pagination={false} scroll={{ x: '100%' }} />
        </>
    )
}