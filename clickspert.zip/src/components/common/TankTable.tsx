import { Button, Popconfirm, Table } from "antd"
import HenceforthIcons from "../HenceforthIcons"
import { ColumnsType } from "antd/es/table"

export const TankTable = (props: any) => {
    console.log(props,'props');
    
    const Columns: ColumnsType<any> = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, object: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Tank Size',
            dataIndex: 'tank_size',
            width: 150,
        },
        {
            title: 'Price',
            dataIndex: 'price',
            width: 150
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { props?.showEditModal('apartment', res, res?._id, props) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete apartment"
                        onConfirm={() => props?.onDelete(props?._id ,res._id, 'apartment')}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ]


    return(
        <>
         <Table dataSource={props?.tanks} columns={Columns} pagination={false} scroll={{ x: '100%' }} />
        </>
    )
}