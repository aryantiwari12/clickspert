import { Button, Form, Input, Modal, Typography } from "antd";

const LocationModal = (props:any) => {
    return (
        <>
            <Modal footer={null} centered={true} open={props.isModalOpen} onOk={props.handleOk} onCancel={props.handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Location</Typography.Title>
                    <Form size='large' layout='vertical' className='mt-2'>
                        <Form.Item label='City' >
                            <Input placeholder='City' className='border-0' />
                        </Form.Item>
                        <Form.Item label='Area' >
                            <Input placeholder='Area' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' block>Add Location</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </>
    )
}
export default LocationModal;