import { Avatar, Button, Card, Col, Image, Table, Typography } from "antd"
import ColumnsTyped from '@/interfaces/ColumnsType';
// import Image from "next/image";
import Link from "next/link";
import HenceforthIcons from "../HenceforthIcons";
import { useRouter } from "next/router";
import Documentimg from '@/assets/svg/document.svg'
import placeholder from '../../assets/images/placeholder.png'
import henceforthApi from "@/utils/henceforthApi";
import henceforthValidations from "@/utils/henceforthValidations";
import React from "react";
import { capitalize } from "lodash";
const other_docs = [] as any
const VendorDocument = (props: any) => {
    const router = useRouter()

    const documentdataSource = props?.old_docs?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: henceforthValidations.capitalizeFirstLetter(res.name) || 'N/A',
            documentfile: res?.type != "OTHER_DOC" ? <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="">
                    <div style={{ width: 100, height: 70 }} className='rounded-1 bg-light-primary p-1 text-center d-flex justify-content-center align-items-center' >
                        {res?.image?.includes(".pdf") ? <img src={Documentimg.src} alt='img' /> : <Image
                            id={`${index}`}
                            width={100}
                            height={70}
                            style={{ borderRadius: 4 }}
                            src={henceforthApi.FILES.imageOriginal(res?.image, placeholder.src)}
                        />}
                    </div>
                </div>
                <div>
                    <a target="_blank" href={res?.image?.includes(".pdf") ? `${henceforthApi.API_FILE_ROOT_DOCUMENTS}${res?.image}` : `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res?.image}`} >
                        <Button type='primary' className='bg-transparent px-2'><HenceforthIcons.DownloadBtn /></Button></a>
                </div>
                <span title={res?.image}>{capitalize(res.image)?.slice(0, 15) + "..."}</span>
            </div> : res?.doc_img?.map((item: any, index: number) => {
                return (
                    <div className='service-detail d-inline-flex gap-2 align-items-center' key={index}>
                        <div className="">
                            <div style={{ width: 100, height: 70 }} className='rounded-1 bg-light-primary p-1 text-center d-flex justify-content-center align-items-center'>
                                {item?.includes(".pdf") ? <img src={Documentimg.src} alt='img' /> : <Image
                                    id={`${index}`}
                                    width={100}
                                    height={70}
                                    style={{ borderRadius: 4 }}
                                    src={henceforthApi.FILES.imageOriginal(item, placeholder.src)}
                                />}
                            </div>
                        </div>
                        <div>
                            <a target="_blank" href={item?.includes(".pdf") ? `${henceforthApi.API_FILE_ROOT_DOCUMENTS}${item}` : `${henceforthApi.API_FILE_ROOT_ORIGINAL}${item}`} >
                                <Button type='primary' className='bg-transparent px-2'><HenceforthIcons.DownloadBtn /></Button></a>
                        </div>
                        <span title={item}>{capitalize(item)?.slice(0, 15) + "..."}</span>
                    </div>
                )
            }),
            // action: <div>
            //     <a target="_blank" href={res?.value?.includes(".pdf") ? `https://clickspertstaging.fra1.digitaloceanspaces.com/documents/${res.value}` : `https://clickspertstaging.fra1.digitaloceanspaces.com/image/original/${res.value}`} >
            //         <Button type='primary' className='bg-transparent px-2'><HenceforthIcons.DownloadBtn /></Button></a>
            // </div>
        }
    })
    return (
        <>
            <Col span={24}>
                <Card className='common-card mt-4 h-100'>
                    <div className='d-flex align-items-center mb-3'>
                        <Typography.Title level={3} className='m-0 me-4 fw-bold'>Documents</Typography.Title>
                    </div>
                    <div style={{height:'500px', overflow:'hidden', overflowY:'auto'}}>
                        <Table dataSource={documentdataSource} columns={ColumnsTyped.documentColumns} pagination={false} scroll={{ x: '100%' }} />
                    </div>
                </Card>
            </Col>
        </>
    )
}
export default VendorDocument