import { Button, Card, Image, Space, Table, Typography } from "antd"
import Serviceimg from '@/assets/images/banner.png'
import ColumnsTyped from '@/interfaces/ColumnsType';
import { useRouter } from "next/router";
import henceforthApi from "@/utils/henceforthApi";
import placeholder from '@/assets/images/placeholder.png'
import { capitalize } from "lodash";
import dayjs from "dayjs";
import Link from "next/link";
const VendorTranasction = (props: any) => {
  const router = useRouter()
  const transactiondataSource = props?.data.map((res: any, index: number) => {
    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
        {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
        <div className="user-detail-img">
          <img src={henceforthApi.FILES.imageSmall(res?.user_id?.image) || placeholder.src} alt='img' />
        </div>
        <Typography.Text>{res?.user_id?.name || 'N/A'}</Typography.Text>
      </div>,
      order: <div className='service-detail d-inline-flex gap-2 align-items-center'>
        {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
        <div className="service-detail-img">
          <img src={henceforthApi.FILES.imageSmall(res?.sub_service_id?.image) || placeholder.src} alt='img' />
        </div>
        <div>
          <Typography.Text className='text-gray fw-700'>{res?.sub_service_id?.name}</Typography.Text><br />
          <Typography.Paragraph className='mb-0'>{`${res?.order_id}`}</Typography.Paragraph>
        </div>
      </div>,
      date: dayjs(res?.date).format('ddd, MMM DD - hh:mm A'),
      transactionid: `${res?.transactions?.transaction_no}`,
      status: <div className={`upcoming ${res?.transactions?.vendor_payment_status == "PAID" ? `bg-success` : 'bg-danger'}`}>
        {res?.transactions?.vendor_payment_status == "PAID" ? "Complete" : capitalize(res?.transactions?.vendor_payment_status)}
      </div>,
      price: `AED ${res?.total_amount?.toFixed(2)}`  || 'N/A',
      earning: `AED ${res?.vendor_earning?.toFixed(2)}` || 'N/A',
    }
  })
  return (
    <>
      <Card className='common-card mt-4 h-100'>
        <div className='flex-center flex-wrap mb-3'>
          <Space>
            <Typography.Title level={4} className='m-0 fw-700'>Transactions</Typography.Title>
            <span className='text-muted mb-0 border p-2' style={{ borderRadius: 4 }}>Total Earning: <span className='text-dark fw-semibold'>{props.total_earning_amount == 0 ? "AED " + 0  : `AED ${props.total_earning_amount?.toFixed(2)}`}</span></span>
          </Space>
          <Space>
            <Link href={`/vendor/${router.query._id}/panelty`}><Button type="primary">Settlement</Button></Link>
            <span className='text-muted mb-0 p-2' style={{ borderRadius: 4, background: 'rgba(236, 194, 99, 0.2)' }}>Pending Amount: <span className='text-dark fw-semibold'>{props.total_pending_amount == 0 ? "AED " + 0  : `AED ${props.total_pending_amount?.toFixed(2)}`}</span></span>
          </Space>
        </div>
        <Table dataSource={transactiondataSource} columns={ColumnsTyped.vendorTransactionColumns} pagination={false} scroll={{ x: '100%' }} />
      </Card>
    </>
  )
}
export default VendorTranasction