// const Zendesk=()=>{
//   const  onScriptLoaded=()=> {
//         if (typeof onload === "function") {
//         onload();
//         }
//       }

//  const   insertScript=(zendeskKey:any, defer:any)=> {
//         const script = document.createElement("script");
//         if (defer) {
//           script.defer = true;
//         } else {
//           script.async = true;
//         }
//         script.id = "ze-snippet";
//         script.src = `https://static.zdassets.com/ekr/snippet.js?key=${zendeskKey}`;
//         script.addEventListener("load", onScriptLoaded);
//         document.body.appendChild(script);
//       }
//       React.useEffect(()=>{
//         if (!(window as any).zE) {
//             const { defer, zendeskKey, ...other } = this.props;
//             this.insertScript(zendeskKey, defer);
//             window.zESettings = other;
//           }
//       })
//     return(

//     )
// }