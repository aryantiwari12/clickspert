import { Button, Form, Input } from "antd";
import { useRouter } from "next/router";
import { SearchOutlined } from '@ant-design/icons'
import React, { useEffect } from "react";
import { useDebounce } from "@/utils/components/commonFunction";

const SearchPage = (props: any) => {
  const { Search } = Input;
  const [form] = Form.useForm()
  const router = useRouter()
  const [inputSearch,setInputSearch]=React.useState('')
  const debounce=useDebounce(inputSearch,500)
  React.useEffect(()=>{
// if(debounce){
  onSearch(debounce)
// }
  },[debounce])
  const onSearch = (search: any) => {
// search?.preventdefault()
    if (search) {
      router.replace({
        pathname: props.pathname, query: { ...router.query, search: search }
      })
      console.log(props.pathname);

    } else if (!search) {
      let query = { ...router.query }
      delete query['search']
      router.push({ query }, undefined, { shallow: true })
    }
  }
  useEffect(() => {
    if (router.query.search) return form.setFieldValue("search", String(router.query.search))
  }, [])
  return (
    <Form form={form}>
      <div className='w-100'>
        <Form.Item className="mb-0" name="search">
          <Input size='large' prefix={<SearchOutlined />} placeholder={props.placeholder} onChange={(e) => setInputSearch(e.target.value.trim())} />
        </Form.Item>
      </div>
    </Form>

  )
}
export default SearchPage;