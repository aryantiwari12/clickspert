import { Card, Col, Typography } from "antd"
import Link from "next/link"

const DashBoardPage = (props: any) => {
    console.log(props)
    return (
        <>
            <Col span={24} md={12} lg={8} xl={6} className="gutter-row" key={props?.index}>
                <Link href={props.link ? props.link : '#'}>
                    <Card className='dashboard-widget-card text-cente h-100 border-0 py-4' style={{ background: props?.data?.cardBackground }} >
                        <div className='d-flex align-items-center justify-content-start ms-3'>
                            <div className='dashboard-widget-card-icon rounded-circle d-flex align-items-center justify-content-center' style={{ background: props?.data?.iconBackground }}>
                                {props?.data?.icon}
                            </div>
                            <div className='dashboard-widget-card-content ms-4'>
                                <Typography.Title level={3} className='m-0 mb-1 fw-bold' style={{ color: props?.data?.textColor }}>{props?.data?.title}</Typography.Title>
                                <Typography.Paragraph className="m-0" style={{ color: props?.data?.textColor }}>{props?.data?.count}</Typography.Paragraph>
                            </div>

                        </div>
                    </Card>
                </Link>

            </Col>
        </>
    )
}
export default DashBoardPage