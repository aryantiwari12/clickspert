import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import { useState } from 'react';
const QuillEditor = dynamic(() => import('@/components/common/quillEditor'), {
  ssr: false,
});
const TextEditor = (props:any) => {
  const [editorValue, setEditorValue] = useState('') 
  const uploadFile = async (files: any) => {
    let res = await henceforthApi.Common.uploadFile('file', files)
    console.log(res);
    return res
  }
  const handleEditorChange = (newValue: any) => {
    props.state(newValue)
    console.log(newValue)
    setEditorValue(newValue)}
  return (<>
    <>
      <QuillEditor value={editorValue} onChange={handleEditorChange} ImageUpload={uploadFile}/></>
    </>
  )
}
export default TextEditor;