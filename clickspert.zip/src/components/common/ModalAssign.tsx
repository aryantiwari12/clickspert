import { GlobalContext } from "@/context/Provider";
import henceforthApi from "@/utils/henceforthApi";
import { Avatar, Button, Form, Input, Modal, Table, Typography } from "antd"
import { ColumnsType } from "antd/es/table";
import { useRouter } from "next/router";
import React, { useState } from "react";

const orderRequestColumns: ColumnsType<any> = [
    {
        title: 'Sr.no.',
        dataIndex: 'key',
        width: 100
    },
    {
        title: 'User Name',
        dataIndex: 'username',
        width: 150,
    },
    {
        title: 'Email',
        dataIndex: 'email',
        width: 150
    },
    {
        title: 'Phone No.',
        dataIndex: 'phone',
        width: 150
    },

]
const ModalAssign = (props: any) => {
    const { userInfo, downloadCSV, Toast, loading, setLoading } = React.useContext(GlobalContext)
    console.log(props.orderId, "vendor");
    const router=useRouter()
    let vendor = []
    vendor.push({
        image: props?.vendor?.image,
        name: props?.vendor?.name,
        email: props?.vendor?.email,
        phone: props?.vendor?.phone_no
    })
    const dataSource = vendor.map((res: any, index: number) => {
        return {

            key: 1,
            username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <Avatar src={henceforthApi.FILES.imageSmall(res.image)} />
                <Typography.Text>{res.name || 'N/A'}</Typography.Text>
            </div>,
            email: res.email || 'N/A',
            phone: res.phone || 'N/A'

        }
    })
    const onClose=()=>{
        props.setIsModalOpenAssign(false)
    }
    const onSumit = async () => {
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Order.assignVendor(`vendor_id=${props?.vendor?._id}&order_id=${router.query._id || props.orderId }`)
            Toast.success(apiRes.message)
            router.back()
            props.setIsModalOpenAssign(false)
            props.initialise()
        } catch (error) {
            // Toast.error(error)
        }
        setLoading(false)
    }
    return (
        <>
            <Modal footer={null} centered={true} open={props.isModalOpenAssign} onCancel={props.handleCancelAssign}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Are you sure want to assign this order to</Typography.Title>
                    <Form size='large' layout='vertical' className='mt-3'>
                        <div className="mb-3">
                            <Table dataSource={dataSource} columns={orderRequestColumns} pagination={false} scroll={{ x: '100%' }} />
                        </div>
                        <Form.Item >
                            <div className='d-flex gap-2'>
                                <Button type='primary'  htmlType='submit' block loading={loading} onClick={onSumit}>Yes</Button>
                                <Button type='primary' danger htmlType='submit' onClick={onClose} block>No</Button>
                            </div>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </>
    )
}
export default ModalAssign