import { Button, Card, Image, Space, Table, Typography } from "antd"
import Serviceimg from '@/assets/images/banner.png'
import ColumnsTyped from '@/interfaces/ColumnsType';
import { useRouter } from "next/router";
import henceforthApi from "@/utils/henceforthApi";
import placeholder from '@/assets/images/placeholder.png'
import { capitalize } from "lodash";
import dayjs from "dayjs";
import Link from "next/link";
const VendorNewTranasction = (props: any) => {
  console.log(props);

  const router = useRouter()
  const transactiondataSource = props?.data?.map((res: any, index: number) => {
    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      //   username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
      //     <div className="user-detail-img">
      //       <img src={henceforthApi.FILES.imageSmall(res?.user_id?.image) || placeholder.src} alt='img' />
      //     </div>
      //     <Typography.Text>{res?.user_id?.name || 'N/A'}</Typography.Text>
      //   </div>,
      //   order: <div className='service-detail d-inline-flex gap-2 align-items-center'>
      //     {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
      //     <div className="service-detail-img">
      //       <img src={henceforthApi.FILES.imageSmall(res?.sub_service_id?.image) || placeholder.src} alt='img' />
      //     </div>
      //     <div>
      //       <Typography.Text className='text-gray fw-700'>{res?.sub_service_id?.name}</Typography.Text><br />
      //       <Typography.Paragraph className='mb-0'>{`${res?.order_id}`}</Typography.Paragraph>
      //     </div>
      //   </div>,
      orderId: res?.order_id || "N/A",
      serviceType: res?.service_type || "N/A",
      genric: res?.generic || "N/A",
      date: dayjs(res?.created_at).format('ddd, MMM DD - hh:mm A'),
      transactionid: `${res?.transaction_id}`,
      status: <div className={`upcoming ${res?.status == "SUCCESS" ? `bg-success` : 'bg-danger'}`}>
        {capitalize(res?.status)}
      </div>,
      price: res?.price ? " AED " + res?.price?.toFixed(2) : 'N/A',
      commission: res?.commission ? "AED " + res?.commission : "N/A",
      serviceFees: res?.service_fees ? " AED " + res?.service_fees : "N/A",
      remarks: <span title={res?.remarks}>{res?.remarks?.length > 20 ? res?.remarks?.slice(0, 20) + "..." : res?.remarks || 'N/A'} </span>,
    }
  })
  return (
    <>
      <Card className='common-card mt-4 h-100'>
        <div className='flex-center flex-wrap mb-3'>
          <Space>
            <Typography.Title level={4} className='m-0 fw-700'>Settlement</Typography.Title>
          </Space>
        </div>
        <Table dataSource={transactiondataSource} columns={ColumnsTyped.vendorNewTransactionColumns} pagination={false} scroll={{ x: '100%' }} />
      </Card>
    </>
  )
}
export default VendorNewTranasction