import ColumnsType from "@/interfaces/ColumnsType"
import { Button, Popconfirm, Table, message } from "antd"
import Link from "next/link"
import HenceforthIcons from "../HenceforthIcons"

const VillaPage = (props: any) => {
    const cancel = (e: React.MouseEvent<HTMLElement>) => {
        console.log(e);
        message.error('Click on No');
      };
    const dataSource = props?.data?.map((res: any, index: number) => {
        return {
            key: index + 1,
            rooms: res.rooms,
            price: res.price,
            action: <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { props?.showModal('villa', res);props?.setIndex(index)}} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                <Popconfirm
                    title="Delete"
                    description="Are you sure to delete Villa"
                    onConfirm={() =>props.onDelete(res._id,'villa')}
                    okText="Yes"
                    cancelText="No">
                    <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                </Popconfirm>
            </div>
        }
    })
    return (
        <>
            <Table dataSource={dataSource} columns={ColumnsType.apartmentColumns} pagination={false} scroll={{ x: '100%' }} />

        </>
    )
}
export default VillaPage