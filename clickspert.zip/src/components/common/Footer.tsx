import { Typography } from 'antd';
import dynamic from 'next/dynamic';
import React from 'react'
const { Row, Col } = {
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
}

function Footer() {
  const today = new Date();
  const year = today.getFullYear();
  return (
    <footer>
      <div className="container-fluid">
        <div className="row">
          <Row>
            <Col span={24} className='text-center text-xl-start'>
              <Typography.Paragraph className='m-0 p-3 fw-500'>Copyright &copy; {year} Clickspert. All Rights Reserved.</Typography.Paragraph>
            </Col>
          </Row>
        </div>
      </div>
    </footer>
  )
}

export default Footer