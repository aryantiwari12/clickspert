import { Avatar, Button, Card, Col, Form, Image, Input, Modal, Popconfirm, Table, Typography } from "antd"
import ColumnsTyped from '@/interfaces/ColumnsType';
import Link from "next/link";
import HenceforthIcons from "../HenceforthIcons";
import { useRouter } from "next/router";
import Documentimg from '@/assets/svg/document.svg'
import placeholder from '../../assets/images/placeholder.png'
import henceforthApi from "@/utils/henceforthApi";
import henceforthValidations from "@/utils/henceforthValidations";
import React, { useContext } from "react";
import { capitalize } from "lodash";
import { GlobalContext } from "@/context/Provider";
// import TextArea from "antd/es/input/TextArea";
const other_docs = [] as any
const { TextArea } = Input;
const VendorNewDocument = (props: any) => {
    const [loading, setLoading] = React.useState(false)
    const [isModalOpen, setIsModalOpen] = React.useState(false);
    const router = useRouter()
    const { Toast } = useContext(GlobalContext)
    const [docsId, setDocsId] = React.useState('')
    const [form] = Form.useForm()
    let newDocs = props?.new_docs
console.log(newDocs ,"newDocs");

    const Managevendor = async (_id: any, name: any, value: any) => {
        try {
            setLoading(true)
            const info = {
                _id: _id,
                status: name,
                reason: value.account_rejection_reason
            }
            let apiRes = await henceforthApi.Vendor.manageDocs(info)
            const ind = props?.new_docs.findIndex((item: any) => item?._id == apiRes?._id)
            newDocs?.splice(ind, 1)
            Toast.success(apiRes.message)

        } catch (error) {
            Toast.error(error)
        } finally {
            setIsModalOpen(false)
            form.resetFields()
            setLoading(false)
        }
    }
    const showModal = (_id: any) => {
        setIsModalOpen(true);
        setDocsId(_id)
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const documentdataSource = newDocs?.map((res: any, index: number) => {
        // return
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: henceforthValidations.capitalizeFirstLetter(res.name) || 'N/A',
            documentfile: res?.type != "OTHER_DOC" ? <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="">
                    <div style={{ width: 100, height: 70 }} className='rounded-1 bg-light-primary p-1 text-center d-flex justify-content-center align-items-center' >
                        {res?.image?.includes(".pdf") ? <img src={Documentimg.src} alt='img' /> : <Image
                            id={`${index}`}
                            // width={500}
                            style={{ borderRadius: 4 }}
                            src={henceforthApi.FILES.imageOriginal(res?.image, placeholder.src)}
                        />}
                    </div>
                </div>
                <div>
                    <a target="_blank" href={res?.image?.includes(".pdf") ? `${henceforthApi.API_FILE_ROOT_DOCUMENTS}${res?.image}` : `${henceforthApi.API_FILE_ROOT_ORIGINAL}${res?.image}`} >
                        <Button type='primary' className='bg-transparent px-2'><HenceforthIcons.DownloadBtn /></Button></a>
                </div>
                <span title={res?.image}>{capitalize(res.image)?.slice(0, 15) + "..."}</span>
            </div> : res?.doc_img?.map((item: any, index: number) => {
                return (
                    <div className='service-detail d-inline-flex gap-2 align-items-center' key={index}>
                        <div className="">
                            <div style={{ width: 100, height: 70 }} className='rounded-1 bg-light-primary p-1 text-center d-flex justify-content-center align-items-center'>
                                {item?.includes(".pdf") ? <img src={Documentimg.src} alt='img' /> : <Image
                                    id={`${index}`}
                                    width={500}
                                    style={{ borderRadius: 4 }}
                                    src={henceforthApi.FILES.imageOriginal(item, placeholder.src)}
                                />}
                            </div>
                        </div>
                        <div>
                            <a target="_blank" href={item?.includes(".pdf") ? `${henceforthApi.API_FILE_ROOT_DOCUMENTS}${item}` : `${henceforthApi.API_FILE_ROOT_ORIGINAL}${item}`} >
                                <Button type='primary' className='bg-transparent px-2'><HenceforthIcons.DownloadBtn /></Button></a>
                        </div>
                        <span title={item}>{capitalize(item)?.slice(0, 15) + "..."}</span>
                    </div>
                )
            }),
            action: <ul className='m-0 list-unstyled d-flex gap-1'>
                <li>
                    <Popconfirm
                        title="Accept the Document"
                        onConfirm={() => Managevendor(res._id, "ACCEPTED", '')}
                        description="Are you sure to Accept this Document?"
                        okText="Accept"
                        cancelText="No"
                    >
                        <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button>
                    </Popconfirm>
                </li>

                <li>
                    <Button type='primary' onClick={() => showModal(res._id)} shape='circle' className='bg-transparent'><HenceforthIcons.No />
                    </Button>
                    {/* </Popconfirm> */}
                </li>
            </ul>
        }
    })
    return (
        <>
            <Col span={24}>
                <Card className='common-card mt-4 h-100'>
                    <div className='d-flex align-items-center mb-3'>
                        <Typography.Title level={3} className='m-0 me-4 fw-bold'>New Documents</Typography.Title>
                    </div>
                    <Table dataSource={documentdataSource} columns={ColumnsTyped.documentNewColumns} pagination={false} scroll={{ x: '100%' }} />
                </Card>
            </Col>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Enter Reason</Typography.Title>
                    <Typography.Paragraph className='text-gray'>Please enter the reason for declining the doc’s</Typography.Paragraph>
                    <Form
                        size='large' form={form} onFinish={(name) => Managevendor(docsId, "REJECTED", name)} layout='vertical'>
                        <Form.Item name="account_rejection_reason" rules={[{ required: true, message: "Please Enter Reason" }]}>
                            <TextArea rows={4} className='border-0' placeholder="Enter reason here..." />
                        </Form.Item>
                        <Form.Item className='mb-2'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </>
    )
}
export default VendorNewDocument