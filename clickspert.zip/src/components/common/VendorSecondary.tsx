import { Card, Col, Typography } from "antd";

const VendorSecondary = (props: any) => {
    console.log(props, "propsSecondary");
    return (
        <>
            <Col span={24} md={12}>
                {/* ant table */}
                <Card className='common-card mt-4 h-100'>
                    <div className='d-flex align-items-center mb-3'>
                        <Typography.Title level={3} className='m-0 me-4 fw-bold'>Secondary Contact</Typography.Title>
                    </div>
                    {props?.secondary_contacts==null ? '' :
                    <ul className='list-unstyled mb-4 mb-md-0 flex-shrink-0'>
                        <li className='mb-3'><Typography.Text className='text-gray'>Name:</Typography.Text> <Typography.Text className='ms-1'>
                            {props?.secondary_contacts?.name || 'N/A'}
                        </Typography.Text ></li>
                        <li className='mb-3'><Typography.Text className='text-gray'>Email:</Typography.Text> <Typography.Text className='ms-1'>
                            {props?.secondary_contacts?.email || 'N/A'}
                        </Typography.Text ></li>
                        <li className='mb-3'><Typography.Text className='text-gray'>Phone no:</Typography.Text> <Typography.Text className='ms-1'>
                          {props?.country_code ? props?.country_code : ""}   { props?.secondary_contacts?.phone_no || 'N/A'}

                        </Typography.Text></li>
                        <li className='mb-3'><Typography.Text className='text-gray'>Address:</Typography.Text> <Typography.Text className='ms-1'>
                            {props?.secondary_contacts?.address_line1 || 'N/A'}
                        </Typography.Text></li>
                    </ul>}
                </Card>
            </Col>
        </>
    )
}
export default VendorSecondary;