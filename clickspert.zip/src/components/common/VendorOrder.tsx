import { Button, Card, Image, Table, Typography } from "antd";
import Link from "next/link";
import HenceforthIcons from "../HenceforthIcons";
import Serviceimg from '@/assets/images/banner.png'
import ColumnsTyped from '@/interfaces/ColumnsType';
import { useRouter } from "next/router";
import henceforthApi from "@/utils/henceforthApi";
import placeholder from "@/assets/images/placeholder.png"
import dayjs from "dayjs";
import henceofrthEnums from "@/utils/henceofrthEnums";
import { capitalize } from "lodash";
const VendorOrder = (props: any) => {
    console.log(props, "vendorOrder");
    const router=useRouter()
    const orderdataSource = props?.data.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
                <div className="user-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.user_id?.image)|| placeholder.src} alt='img' />
                </div>
                <Typography.Text>{res?.user_id?.name || 'N/A'}</Typography.Text>
            </div>,
            orderid: res.order_id || 'N/A',
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res.sub_service_id.image)|| placeholder.src} alt='img' />
                </div>
                <div>
                    <Typography.Text className='text-gray fw-700'>{res?.service_id?.name}</Typography.Text><br />
                    <Typography.Paragraph className='mb-0'>{res?.sub_service_id?.name}</Typography.Paragraph>
                </div>
            </div>,
            date: dayjs(res.time).format('DD MMM YYYY-HH:s'),
            status: <div className={`upcoming ${res?.status == "ACTIVE" ? 'bg-theme' :res?.status == "CANCELLED" ? 'bg-danger' :res?.status == "UPCOMING" ? 'bg-success' : 'bg-blue' }`}>
                {capitalize(res.status) || 'N/A'}
            </div>,
            amount: res.total_amount ? `AED ${res.total_amount}` : 'N/A',
            action: <Link href={`/orders/${res._id}/view`}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })
    return (
        <>
            <Card className='common-card mt-4 h-100'>
                <div className='d-flex align-items-center mb-3'>
                    <Typography.Title level={4} className='m-0 me-4 fw-700'>Orders</Typography.Title>
                </div>
                <Table dataSource={orderdataSource} columns={ColumnsTyped.vendorOrderColumns} pagination={false} scroll={{ x: '100%' }} />
            </Card>
        </>
    )
}
export default VendorOrder;