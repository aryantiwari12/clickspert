import { Button, Form, Input, Modal, Popconfirm, Select, Table, Tag, Tooltip, Typography } from "antd";
import React, { useEffect } from "react" ;
import HenceforthIcons from "../HenceforthIcons";
import henceforthApi from "@/utils/henceforthApi";
import { useRouter } from "next/router";
import { GlobalContext } from "@/context/Provider";

const PackageSaloon=(props:any)=>{
    const [form] =Form.useForm()
    const router=useRouter() 
    const { Toast, loading, currency, setLoading } = React.useContext(GlobalContext)
    const [isModalOpen, setIsModalOpen] = React.useState(false);
    const [subService ,setSubService] =React.useState([] as any)
    const [modalName, setModalName] = React.useState('')
    const [editPackId , setEditPackId] =React.useState() as any
    // const [loading , setLoading]=React.useState(false)
    const [editModalOpen, setEditModalOpen] = React.useState(false);
    const [selected, setSelected] = React.useState([]) as any
    const [pacakageList, setpackageList] = React.useState([] as any)
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
        setEditModalOpen(false)
    };
    const showModal = (name: string, res: any) => {
        // setAddPayload(res)
        // form.resetFields()
        setIsModalOpen(true);
        setModalName(name)

    };
    const getWomenPackage = async () => {
        try {
            const apiRes = await henceforthApi.WomenSaloon.saloonPackageListing(String(router.query._id))
            console.log(apiRes, "apiRes");
            setpackageList(apiRes?.data)
        } catch (error) {

        }
    }
    const getSubServiceList =async()=>{
        try {
            const apiRes= await henceforthApi.WomenSaloon.sub_serviceList(router.query._id)
            setSubService(apiRes?.data)
        } catch (error) {
            
        }
        finally{

        }
    }
    const deletePackage = async(id:string) =>{
        setLoading(true)
        try {
            const apiRes=await henceforthApi.WomenSaloon.deletePackage(id)
            Toast.success(apiRes?.message)
            getSubServiceList()
        } catch (error) {
            
        }
        finally{
            setLoading(false)
        }
    }
    const addSaloonPackage = async (values: any) => {
        setLoading(true)
        try {
            const data = {
                items_ids: selected?.map((item: any) => item?._id),
                price: Number(values.price),
                price_currency: currency?._id,
                disclaimer: values?.disclaimer
            } as any
            if(modalName == "Edit") {
                data._id = editPackId
            }
            else{
                data.sub_service_id= router.query?._id
            }
            if(modalName == "Add"){
                const apiRes = await henceforthApi.WomenSaloon.addPackage(data)
                Toast.success(apiRes?.message)
                setSubService([...subService , apiRes?.data])
            }
            else{
                const apiRes = await henceforthApi.WomenSaloon.editPackage(data) 
                Toast.success(apiRes?.message)
                getSubServiceList()
            }
            setSelected([])
            setEditPackId("")
            handleCancel()
        } catch (error) {

        }
        finally {
            setLoading(false)
        }

    }
    const handleChangePackage = (e: any) => {
        let s = e.split(",");
        const data = {
            _id: s?.[0],
            name: s?.[1]
        }
        selected?.push(data)
        setSelected([...selected])
    }
    const handleRemove = async (id: string, index: number) => {
        selected?.splice(index, 1)
        setSelected([...selected])
    }
    const editSubServices =async(item:any)=>{
        console.log(item?.items);
        setEditPackId(item?._id)
        setSelected(item?.items)
        console.log(selected);
        
    form.setFieldValue("price" ,item?.price)
    form.setFieldValue("disclaimer" , item?.disclaimer)
     }
    const columns = [
        {
            title: "Sr.no.",
            dataIndex: "key",
            key: "Sr.no",
        },
        {
            title: 'Services',
            dataIndex: 'Services',
            key: 'Services',
        },
        {
            title: 'Price',
            dataIndex: 'price',
            key: 'price',
        },
        {
            title: 'Action',
            dataIndex: 'action',
            key: 'action',
        },
    ]

    const dataSource = subService?.map((item:any,index:number)=>{
        console.log(item ,"item");
        
        return {
            key: index+1,
            Services: item?.items?.map((res:any ,index:number)=> {return index+1 ==  item?.items?.length ? res?.name : res?.name + ", "}),
            price: `${item?.price}`,
           action: <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' shape='circle'  onClick={() => {showModal("Edit", '');editSubServices(item)}} className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete Villa"
                        onConfirm={() => deletePackage(item?._id)}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
        }
    })
    useEffect(() => {
        getWomenPackage()

    }, [])
    useEffect(()=>{
        getSubServiceList()
    },[])
    return(<>
        <div className='flex-center mt-2 bg-theme py-2 px-3' style={{ borderStartStartRadius: 8, borderStartEndRadius: 8 }}>
        <Typography.Title level={5} className='fw-500 m-0'>Package</Typography.Title>
        <span role='button' onClick={() => showModal("Add", '')}><HenceforthIcons.Add2 /></span>
    </div>
        <Table pagination={false} dataSource={dataSource} columns={columns} />


        <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>{modalName}  Package</Typography.Title>
                    <Form size='large' form={form} layout='vertical' onFinish={addSaloonPackage}>
                        <Form.Item className='' name="rooms">
                            <Select placeholder='Select Area'
                                onChange={handleChangePackage}
                            >
                                {pacakageList?.map((item: any, index: number) => <Select.Option key={index} name={item?.name} value={`${item?._id + ',' + item?.name}`}>{item?.name}</Select.Option>)}
                            </Select>
                            {selected?.map((res: any, index: number) => <Tag color="#108EE9" key={res._id} bordered={false} onClose={() => handleRemove(res?._id, index)} closable><Tooltip title={res?.name}>{res?.name}</Tooltip></Tag>)}
                        </Form.Item>
                        <Form.Item name="price" rules={[{ required: true, message: 'Enter your Price' }]}  label='Price' >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} className='border-0' />
                        </Form.Item>
                        <Form.Item name="disclaimer" rules={[{ required: true, message: 'Enter your Disclaimer' }]}  label='Disclaimer' >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} className='border-0' />
                        </Form.Item>
                        <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                    </Form>
                </div>
            </Modal>
   </> )
}
export default PackageSaloon;