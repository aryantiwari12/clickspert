import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { COOKIES_USER_ACCESS_TOKEN } from './context/actionTypes';


// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {
    // const router=useRouter()
    const url = request.nextUrl.clone()
    console.log('middleware called');
debugger
    let isAuth = request.cookies.has(COOKIES_USER_ACCESS_TOKEN)
    const { cookies,  nextUrl } = request;

    const isAuthenticated = cookies.get('isLoggedIn');
    console.log(isAuthenticated,"isAuthenticated");
    // debugger
    // if(url.pathname != '/login'){
    //     if (isAuthenticated) {
    //         url.pathname = '/login'
    //         return NextResponse.redirect(url)
    //         }
    // }




    if (request.nextUrl.pathname.startsWith('/')) {
        if (!isAuth) {
            url.pathname = '/login'
            return NextResponse.redirect(url)
        }
    }
    return NextResponse.next()
}




// See "Matching Paths" below to learn more
export const config = {
    matcher: ['/', '/profile/:path*', '/user/:path*', '/product/:path*', '/content/:path*', '/faq/:path*'],
}

