import React, { createContext, useState, useRef, useEffect, useContext, useLayoutEffect, useCallback } from "react";
import { useRouter } from "next/router";
export const ChatContext = createContext({} as any);
// import emojisArray from './../utils/emojis.json'
// import henceforthApi from "@/utils/henceforthApi";
import { io } from "socket.io-client";
import { GlobalContext } from "./Provider";
import { measureMemory } from "vm";
// import { ConncetionResponse, ConnectionsOfChat, MessagesOfChat } from "src/interfaces/ChatInterfaces";
import henceofrthEnums from "src/utils/henceofrthEnums";
import { Socket } from "dgram";

const ChatProvider = (props: any) => {
    const { userInfo } = useContext(GlobalContext)
    const router = useRouter();
    const [messages, setMessages] = useState([] as Array<any>);
    const [connectionResponse, setconnectionResponse] = useState({} as any)
    const [connections, setConnections] = useState([] as Array<any>)
    const connectedRef = React.useRef(null) as any
    // const [socketHitType , setSocketHitType]=useState({
    //     order_request:"",
    //     vendor_request:''
    // }) as any
    const [socketHitType , setSocketHitType]=useState() as any
    const [connected, setConnected] = useState(false)
    const [page, setPage] = useState(0) as any;
    const [loading, setLoading] = useState(false);
    const [responseChat, setchatResponse] = useState({}) as any;
    const [scheduleData, setScheduleData] = useState() as any
    const videoExtensions = ['.mp4', '.webm', '.avi', '.mov'];
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp'];
    const audioExtensions = ['.mp3', '.wav', '.ogg', '.flac'];
    const documentExtensions = ['.pdf', '.doc', '.docx', '.ppt', '.pptx', '.xls', '.xlsx'];
    const [groups, setGroups] = useState({
        data: []
    })
    // const { NotificationToast } = useContext(GlobalContext)
    const socketRef = React.useRef(null) as any
const API_ROOT=process.env.NEXT_PUBLIC_STAGING_API_URL as any
    useEffect(() => {
        if (!userInfo?.access_token) return setConnected(false)
        socketRef.current = io(API_ROOT, {
            extraHeaders:
                { token: userInfo?.access_token } as any
        })
        if (connectedRef.current) {
            clearInterval(connectedRef.current)
        }
        connectedRef.current = setInterval(() => {
            if (socketRef.current.connected) {
                setConnected(true)
                console.log(socketRef.current.connected, "socketRef.current.connected111");
            }
        }, 1000)
        console.log(socketRef.current);
        return () => {
            if (connectedRef.current) {
                clearInterval(connectedRef.current)
            }
        }
    }, [userInfo?.access_token])

    console.log(router.query.campaign_id, "router.query.campaign_id");

    const socketConnect = () => {
        socketRef.current?.on('connected', () => {
            console.log('Socket  Connected');
        })
       
        socketRef.current?.on(henceofrthEnums.Socket.ORDER_REQUEST_ADMIN, (res: any) => {
            console.log(res ,"ORDER_REQUEST_ADMIN");
           
            setSocketHitType({
                ...socketHitType ,
                order_request:res?.message
            }as any)
          
        })
        socketRef.current?.on(henceofrthEnums.Socket.ORDER_REQUEST_VENDOR, (res: any) => {
            console.log(res ,"ORDER_REQUEST_VENDOR");
            setSocketHitType({
                ...socketHitType ,
                order_request:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.ORDER_ACCEPT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                order_accept:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_ACCEPT_QUOTATION, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_accept_quotation:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.PROMO_CODE, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                promo_code:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.FAQ, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                faq:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.WALLET, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                wallet:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_COMPLAINT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_complaint:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.NEW_USER, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_complaint:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.VENDOR_CONTACT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                vendor_contact:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.DOCUMENT_UPDATE, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                document_update:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_FEEDBACK, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_feedback:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.ORDER_COMPLETED, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                order_completed:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.VENDOR_REQUEST, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                vendor_request:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.VENDOR_REJECT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                vendor_reject:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.VENDOR_ACCEPT, (res: any) => {
            console.log(res ,"VENDOR_ACCEPT");
            setSocketHitType({
                ...socketHitType ,
                vendor_accept:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.NOTIFICATION, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                notification:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.LOCATION, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                location:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.NEW_SUB_SERVICES, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                new_sub_services:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.NEW_LOCATIONS, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                new_locations:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.DOCUMENT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                document:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_FEEDBACK, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_feedback:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.BANNER, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                banner:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.SERVICES_ENABLE_DISABLE, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                services_enable_disable:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.ORDER_CANCELLED, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                order_cancelled:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.QUOTATION, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                quotation:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.COMMISION, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                commission:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.POINT_STATUS, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                point_status:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_COMPLAINT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_complaint:res?.message
            }as any)
        })
        socketRef.current?.on(henceofrthEnums.Socket.USER_CONTACT, (res: any) => {
            setSocketHitType({
                ...socketHitType ,
                user_contact:res?.message
            }as any)
        })
        
      
    }
    const joinConnection = async () => {
        const data = {} as any
        if (router.query.type == "requests") {
            data.group_id = router.query.group_id
        }
        else {
            data.group_id = router.query._id
        }

        socketRef.current?.emit(henceofrthEnums.Socket.JOIN_GROUP_SOCKET, data)
    }
   
    // const editLiveStream = (values: any, id: string) => {
    //     console.log(values, id);
    //     const data = {
    //         ...values,
    //         campaign_id: id
    //     }
    //     console.log(data, "dataaaaaaaaaaaa");
    //     socketRef.current?.emit(henceofrthEnums.Socket.EDIT_LIVE_SCHEDUEL, data)
    // }
    // const deleteLiveStream = (id: string) => {
    //     const data = {
    //         campaign_id: id
    //     }
    //     socketRef.current?.emit("delete_live_scheduel", data)
    //     getSchedule(id)
    // }
    // const joinSocketForHeart = () => {
    //     socketRef.current?.emit(henceofrthEnums.Socket.JOIN_GROUP_SOCKET, { group_id: router.query._id })
    // }
    // const sendHeart = (id: string) => {
    //     const data = {
    //         campaign_id: id
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.SEND_HEART, data)
    // }
    // const deleteMessage = (id: string) => {
    //     const data = {
    //         message_id: id
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.DELETE_MESSAGE, data)
    // }
    // const shareLink = (groups: any, link: string) => {
    //     const data = {
    //         groups: groups,
    //         campaign_link: link
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.SEND_LINK, data)
    // }
    // const messageRead = (id: string) => {
    //     socketRef.current?.emit(henceofrthEnums.Socket.CHAT_HISTORY_UPDATE, { group_id: id })
    // }
    // const editMessage = (id: string, message: string) => {
    //     const data = {
    //         message_id: id,
    //         message: message
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.EDIT_MESSAGE, data)
    // }
    // const sendMessage = (message: string, file: any, mediaType: string, thumbnail: string, type: string) => {
    //     let data = {
    //         message_type: file ? mediaType : message.includes("http") ? "LINK" : "TEXT",
    //     } as any
    //     if (router.query.type == "requests") {
    //         data.group_req_id = router.query.group_id
    //     }
    //     else {
    //         data.group_id = router.query._id
    //     }
    //     if (message) {
    //         data.message = message
    //     }
    //     if (type == "live") {
    //         data.campaign_id = ""
    //     }
    //     if (file) {
    //         if (mediaType == "VIDEO") {
    //             data.thumb_nail = thumbnail
    //         }
    //         data.media_url = file
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.SEND_MESSAGE, data);
    //     // getGroups()
    //     socketRef.current?.emit(henceofrthEnums.Socket.OTHER_USER_LIST);
        
    // }

    // const sendLiveMessage = (message: string, campaign_id: string) => {
    //     let data = {
    //         message_type: "TEXT",
    //         campaign_id: campaign_id,
    //         message: message
    //     } as any
    //     socketRef.current?.emit(henceofrthEnums.Socket.SEND_MESSAGE, data);
    // }
    // const startLive = (campaign_id: string) => {
    //     debugger
    //     socketRef.current?.emit(henceofrthEnums.Socket.START_LIVE, {campaign_id: campaign_id});
    // }
    // const leaveStreams = (campaign_id: string) => {
    //     debugger
    //     let data = {
    //         campaign_id: campaign_id,
    //     }
    //     socketRef.current?.emit(henceofrthEnums.Socket.LEAVE_LIVE, data);
    // }
    // const getAllMessage = async (page: number) => {
    //     setLoading(true)
    //     setPage(page);
    //     try {
    //         if (router.query.type == "requests") {
    //             const response = await henceforthApi.Chat?.getRequestChatMessage(router.query.group_id as string, 0, 10)
    //             setchatResponse(response)
    //             if (typeof response?.data == 'string') {
    //                 let arrayOfData = response?.data?.length ? response.data : []
    //                 setMessages([])
    //             } else {
    //                 setMessages(response?.data)
    //             }
    //         }
    //         else {
    //             const response = await henceforthApi.Chat?.getChatMessage(router.query._id as string, 0, 10)
    //             setchatResponse(response)
    //             console.log("chat history", response)
    //             setLoading(false);
    //             if (typeof response?.data == 'string') {
    //                 let arrayOfData = response?.data?.length ? response.data : []
    //                 setMessages([])
    //             } else {
    //                 setMessages(response?.data)
    //             }
    //         }

    //     } catch (error) { }
    // }

    // const getSchedule = async (id: string) => {
    //     try {
    //         const apiRes = await henceforthApi.LiveStream.details(id)
    //         setScheduleData(apiRes?.data)
    //     } catch (error) {

    //     }
    // }
    // const joinPrivateGroups = (data) => {
    //     socketRef.current?.emit(henceofrthEnums.Socket.SEND_PRIVATE_REQ_JOIN_GROUP, data)
    //     NotificationToast.success({ title: "Request Sent For Joining Group", desc: "" })
    // }
    const disconnectSocket = () => {
        console.log(`Disconnecting   socketRef.current?...${socketRef.current}`);
    }
    // const handleError = (error: any) => {
    //     if (error?.response?.body?.error === "UNAUTHORIZED") {
    //         socketRef.current?.off()
    //     } else {
    //         // error((typeof error?.response?.body?.error_description === "string") ? error?.response?.body?.error_description : JSON.stringify(error?.response?.body?.error_description))
    //     }
    // }
    const handleScroll = async () => {
        const element = document.getElementById('chat_wrapper')
        try {
            if ((Number(element?.scrollTop)) === 0) {
                setPage((prevPage: any) => prevPage + 1);
            }
        } catch (error) {
            console.log('error', error)
        }
    };
    useEffect(() => {
        document.getElementById('chat_wrapper')?.addEventListener('scroll', handleScroll);
        return () => {
            document.getElementById('chat_wrapper')?.removeEventListener('scroll', handleScroll);
        };
    }, []);

    // useEffect(() => {
    //     if (router.query._id || router.query.group_id) {
    //         // getAllMessage(page)
    //     }
    // }, [router.query._id, router.query.group_id])
    useEffect(() => {
        if (socketRef?.current?.connected) {
            clearInterval(connectedRef?.current)
        }
        if (!userInfo?.access_token ) return
        else {
            if (socketRef?.current.connected) {
            socketConnect()
            // socketRef.current?.emit(henceofrthEnums.Socket.CHAT_HISTORY_UPDATE, { group_id: router.query._id })
            // getGroups()
            }
        }
        return () => {
                socketRef.current?.removeAllListeners()
        }

    }, [userInfo?.access_token, connected])
   
    // useEffect(() => {
    //     if (responseChat?.count === messages?.length) {
    //         return
    //     }
    //     else if (responseChat?.count != messages?.length && router.query._id) {
    //         // getAllMessage(page);
    //     }
    // }, [page])
    

    return (
        <ChatContext.Provider value={{ chat: connections, socketHitType, setSocketHitType, connected, socketRef,  setScheduleData,  scheduleData,   groups, videoExtensions, imageExtensions, audioExtensions, documentExtensions, loading, setLoading,  disconnectSocket,  connectionResponse, setconnectionResponse, messages, connections, ...props }}>
            {props.children}
        </ChatContext.Provider>
    )
}
export default ChatProvider