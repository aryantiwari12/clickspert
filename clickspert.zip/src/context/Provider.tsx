import React, { createContext, ReactNode, SetStateAction, useContext, useEffect, useState } from 'react'
import henceforthApi from 'src/utils/henceforthApi';
import { Router, useRouter } from 'next/router';
import { ConfigProvider, message, theme } from 'antd';
import { AuthInterface } from 'src/interfaces';
import { getAnalytics, logEvent } from 'firebase/analytics';
import  {getFirebaseMessageToken}  from 'src/utils/firebase';
import enUS from 'antd/locale/en_US';
import ar_EG from 'antd/locale/ar_EG';
import 'dayjs/locale/zh-cn';
import { COOKIES_USER_ACCESS_TOKEN, ERROR_UNAUTHORIZED } from './actionTypes';
import { destroyCookie } from 'nookies';
import { ChatContext } from './chatProvider';

type Function = () => Promise<void | string>;
type LoginFunction = (id: string) => void;
type ToastFunction = (msg: any) => void;
type downloadCsvFunction = (filename: string, data: Array<any>) => void;
type uploadCsvFunction = (file: any) => Promise<any>;

interface CommonContextType {
    loading: boolean;
    setLoading: React.Dispatch<SetStateAction<boolean>>;
    Toast: {
        error: ToastFunction,
        success: ToastFunction,
        warn: ToastFunction
    },
    userInfo: AuthInterface,
    count: number;
    maxDate:any,
    requestNotification:Function
    setCount: React.Dispatch<SetStateAction<any>>;
    setUserInfo: React.Dispatch<SetStateAction<AuthInterface>>
    logout: () => void,
    contentPages: Array<any>
    setContentPages: React.Dispatch<SetStateAction<Array<any>>>
    uploadCSV: uploadCsvFunction,
    // Capitalise:CapitaliseFunction,
    downloadCSV: downloadCsvFunction
    currency: any

}
export const GlobalContext = createContext({} as CommonContextType);
export const downloadFile = (file_path: String) => {
    var a: any = document.createElement('a') as HTMLElement;
    a.href = file_path;
    a.target = "_blank";
    a.download = file_path.substring(file_path.lastIndexOf('/') + 1);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

type GlobleContextProviderProps = {
    children: ReactNode;
    user_info: AuthInterface,
    theme: {
        colorPrimary: string,
        direction: string,
    }
}

const { defaultAlgorithm, darkAlgorithm } = theme;
function GlobalProvider(props: GlobleContextProviderProps) {
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [userInfo, setUserInfo] = useState(props.user_info)
    const [contentPages, setContentPages] = useState<Array<any>>([])
    const [count, setCount] = useState(0);
    const [maxDate ,setMaxDate]=useState()
    const [locale, setLocale] = React.useState(enUS)
    const [colorPrimary, setColorPrimary] = React.useState(props?.theme?.colorPrimary || '#ECC263')
    const [messageApi, contextHolder] = message.useMessage();
    const [isDarkMode, setIsDarkMode] = useState(true)
    const [currency, setcurrency] = useState<any>()
  const [pageLoad, setPage] = useState(false)
  if(userInfo?.access_token){
      henceforthApi.setToken(userInfo?.access_token)
  }

    const destroyErrorMessage = () => message.destroy('1')
    const destroySuccessMessage = () => message.destroy('2')
    const destroyWarnMessage = () => message.destroy('3')
const {socketHitType} =useContext(ChatContext)
    const logout = async () => {
        setUserInfo(null as any)
        destroyCookie(null, COOKIES_USER_ACCESS_TOKEN, {
            maxAge: 0,
            path: "/",
        });
        router.replace(`/login`)
    }
    const error = (error: any) => {
        let errorBody = error?.response?.body
        let error_type = errorBody?.error_type
        let error_message = errorBody?.error_message
        let message = errorBody?.message

        if (error_type == ERROR_UNAUTHORIZED) {
            logout()
        }
        destroyErrorMessage()
        messageApi.open({
            type: 'error',
            content: typeof message == "string" ? message : message ? JSON.stringify(message) : JSON.stringify(error),
            key: "1"
        });
    }
    const success = (success: string) => {
        destroySuccessMessage
        messageApi.open({
            type: 'success',
            content: success,
            key: "2"
        });
    };
    // const capitalise=(status:any)=>{
    //     const data =status?.slice(0,1)?.charAt(0)?.toUpperCase() + status?.slice(1,50)?.toLowerCase();
    //     return data
    // }
    const warn = (error: any) => {
        destroyWarnMessage()
        messageApi.open({
            type: 'warning',
            content: error,
            key: "3"
        });
        setTimeout(messageApi.destroy, 1000);
    }

    const Toast = {
        success,
        error,
        warn
    }
    Router.events.on('routeChangeComplete', () => setLoading(false));
    const createCsv = async (data: any) => {
        let keys = Object?.keys(data[0]);
        let result = '';
        result += keys.join(',');
        result += '\n';
        data?.forEach((element: any) => {
            let objectdata=(values:any)=>{
                if(values){
                    const data2= Object?.keys(values)
                    let result1 = '';
                    result += '\n';
                    result1 += data2.join(',');
                    data2.forEach((item:any)=>{
                        result1 +=`${["string","number","boolean"]?.includes(typeof values[item]) ?  values[item] : values[item]?._id}` + ","
                    })
                    return result1
                }
            }
            keys.forEach((key) => {
                result += `${["string","number","boolean"].includes(typeof element[key]) ? String(element[key]) : objectdata(element[key])}` + ',';
            })
            result += '\n';
        });
        return result;
    }
    
    const getCurrency = async () => {
        try {
            let apiRes = await henceforthApi.Currency.get()
            setcurrency(apiRes?.data[0])
        } catch (error:any) {
            if(error?.response?.body?.statusCode == 401){
                if(router.pathname.startsWith("/orders/")){
                }
                else{
                    router.replace("/login")
                }
            }
           
            
        }
    }
    const getOrderMaxDate = async () => {
        try {
            let apiRes = await henceforthApi.Order.maxOrderDate()
            setMaxDate(apiRes?.date)
        } catch (error:any) {
            
        }
    }
    
    
    useEffect(() => {
        getCurrency()
    }, [(router.pathname == "/login" || router.pathname.startsWith("/orders/"))  ?  "" :router.query ])
    const downloadCSV = async (name: string, array: any) => {
        console.log(array);
        if(!array?.length){
         return   Toast.warn("No data available to export")
        }
        if (array?.length > 0) {
            let csv = 'data:text/csv;charset=utf-8,' + await createCsv(array);
            let excel = encodeURI(csv);
            let link = document.createElement('a');
            link.setAttribute('href', excel);
            link.setAttribute('download', `${name}.csv`);
            link.click();
        }
        return
    }

    const uploadCSV = async (file: any) => {
        const reader = new FileReader();

        return await new Promise((resolve, reject) => {
            try {
                reader.onload = function (e: any) {
                    const text: string = e.target.result
                    
                    let textArr = text.replaceAll("\n'", '').replaceAll(",'", ',').replace("AlbumsName", "title").replace("TrackName", "title").replace("TrackFile", "file").split('\n')

                    let actualData: Array<any> = [];
                    if (textArr.length > 1) {
                        let keysArr = textArr[0].split(',').map((res) => res.charAt(0).toLowerCase() + res.slice(1))
                        console.log('keysArr', keysArr);
                        let keys = {}
                        keysArr.forEach(elementkeys => {
                            keys = { ...keys, [elementkeys]: elementkeys }
                        });
                        console.log('keys', keys);
                        textArr.forEach((element, index) => {
                            if (index > 0) {

                                let valueArr = element.split(',')
                                console.log('valueArr', valueArr);

                                let _tempData = {}
                                valueArr.forEach((elementValue, index2) => {
                                    if (elementValue) {
                                        _tempData = { ..._tempData, [keysArr[index2]]: elementValue }
                                    }
                                });
                                console.log('_tempData', _tempData);

                                if (Object.keys(_tempData).length !== 0) {
                                    actualData.push(_tempData)
                                }
                            }
                        });
                    }
                    resolve(actualData)
                }
                reader.readAsText(file);
            } catch (error) {
                reject(error)
            }
        })
    }

   

    const getNotificationCount = async () => {
        try {
            let apiRes = await henceforthApi.Notification.unreadCount()
            console.log("apiRes Notification counts unread", apiRes.count);
            setCount(apiRes.count)
        } catch (error) {
        }
    }
    const requestNotification = async () => {
        if (!("Notification" in window)) {
            console.log("This browser does not support desktop notification");
            return ""
        }
        else if (Notification.permission === "granted") {
            let { tokenId, error } = await getFirebaseMessageToken()

            if (error) {
                console.log("enableNotification error", error);
                return ""
            }
            return tokenId
        }
        else if (Notification.permission !== 'denied') {
            Notification.requestPermission(async (permission) => {
                if (permission === "granted") {
                    let { tokenId, error } = await getFirebaseMessageToken()
                    if (error) {
                        console.log("enableNotification error", error);
                        return ""
                    }
                    return tokenId

                } else {
                    console.log("permission", permission);
                    return ""
                }
            });
        } else {
            return ""
        }
    }

    useEffect(() => {
        if (userInfo?.access_token) {
            getNotificationCount()
        }
    }, [socketHitType ,router.query])
    React.useEffect(() => {
        setIsDarkMode(true)
        setTimeout(() => {
            setIsDarkMode(false)
        }, 100)
    }, [])
    React.useEffect(()=>{
        getOrderMaxDate()
    },[])
    return (
        <GlobalContext.Provider
            value={{ loading, Toast, count, setCount, maxDate, setLoading,requestNotification, userInfo, setUserInfo, logout, contentPages, setContentPages, uploadCSV, downloadCSV, ...props, currency }}>
            <ConfigProvider
                direction={locale == ar_EG ? 'rtl' : 'ltr'}
                locale={locale}

                theme={{
                    algorithm: !isDarkMode ? defaultAlgorithm : darkAlgorithm,
                    token: {
                        colorPrimary: colorPrimary,
                        borderRadius: 4,
                        colorBorderBg: "#f6f6f6",
                    },
                    components: {
                        Select: {
                            lineWidth: 1,
                            colorBgContainer: '#f6f6f6',
                        },
                        Collapse: {
                            colorBgLayout: 'red',
                            colorBgElevated: 'red',
                            colorPrimaryBg: 'red'
                        },
                        Input: {
                            lineWidth: 1,
                            colorBorder: '#CCCCCC',
                            colorBgContainer: '#f6f6f6',
                        },
                        Tag: {
                            colorBgContainer: 'red',
                            colorBgBase: 'red'
                        },
                        DatePicker: {
                            lineWidth: 1,
                            colorBgContainer: '#f6f6f6',
                        },
                        InputNumber: {
                            lineWidth: 2,
                            colorBgContainer: '#f6f6f6',
                        },

                        List: {
                            lineWidth: 2,
                        },
                        Card: {
                            borderRadiusLG: 16,
                            paddingContentHorizontal: 20,
                            colorBorderSecondary: "#E6E6E6",
                        },
                        Radio: {
                            colorPrimary: colorPrimary,
                        },
                        Button: {
                            boxShadow: "none",
                            lineWidth: 2,
                            fontWeightStrong: 700,
                            colorText: '#000000'
                        },

                        Tabs: {
                            colorPrimary: "#000000",
                            colorPrimaryHover: "#000000"
                        },
                        Pagination: {
                            borderRadius: 50,
                        },
                        Upload: {
                            margin: 20,
                        },


                    },
                }}>
                {props?.children}
            </ConfigProvider>
            {contextHolder}
        </GlobalContext.Provider>
    )
}

export default GlobalProvider