export interface SelectType {
    value: string,
    label: string
}