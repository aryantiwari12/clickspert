import type { ColumnsType } from 'antd/es/table';
import { Tooltip } from 'antd';
import { HomePageDetailsInterface, ProductInfoInterface } from '.';
import { ReactNode } from 'react';

interface DataType {
  key: React.Key,
  title:ReactNode

}
interface DataType1 {
  key: React.Key;
}
interface DataType2 {
  key: React.Key;
}
interface DataType12 {
  key: React.Key;
}
interface DataType11 {
  key: React.Key;
}

const allUserColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    // render: (name) => (
    //   <Tooltip placement="topLeft" title={name}>
    //     {name}
    //   </Tooltip>
    // ),
    width: 150,
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
    width: 200,
  },
  {
    title: 'Phone No.',
    dataIndex: 'phone',
    width: 200,
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 200,
    key: 'city',
  },

  {
    title: 'Area',
    dataIndex: 'Area',
    width: 200,
    key: 'Area',
  },
  {
    title: 'Operating System',
    dataIndex: 'OperatingSystem',
    width: 200,
    key: 'OperatingSystem',
  },
  {
    title: 'Action',
    dataIndex: 'actions',
    key: 'actions',
    fixed: 'right',
    width: 90,
  },
];

const userColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    width: 150,
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    width: 100
  },
  {
    title: 'Service Name',
    dataIndex: 'servicename',
    key: 'servicename',
    ellipsis: {
      showTitle: false,
    },
    width: 200,
  },
  // {
  //   title: 'Email',
  //   dataIndex: 'email',
  //   key: 'email',
  //   width: 150,
  // },
  // {
  //   title: 'Phone No',
  //   dataIndex: 'Phone',
  //   key: 'Phone No',
  //   width: 150,
  // },
  {
    title: 'City',
    dataIndex: 'city',
    key: 'city',
    width: 150,
  },
  {
    title: 'Area',
    dataIndex: 'area',
    key: 'area',
    width: 180,
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    key: 'date',
    width: 180,
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 100
  },
  {
    title: 'Promo Code',
    dataIndex: 'promoCode',
    width: 150
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    width: 100
  },
  // {
  //   title: 'Opearting System',
  //   dataIndex: 'opeartingSystem',
  //   key: 'opeartingSystem',
  //   width: 200,
  // },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 200,
  },
];
const userColumnsdetails: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'srn',
    key: 'srn',
    width: 100
  },
  {
    title: 'city',
    dataIndex: 'city',
    key: 'city',
    width: 100
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    key: 'orderid',
    width: 200,
  },
  {
    title: 'Service Name',
    dataIndex: 'Service_Name',
    key: 'Service_Name',
    ellipsis: {
      showTitle: false,
    },
    width: 200,
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    key: 'date',
    width: 200,
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    width: 200,
  },

  {
    title: 'Amount',
    dataIndex: 'Amount',
    key: 'Amount',
    width: 200,
  },
  {
    title: 'Recurring',
    dataIndex: 'Recurring',
    key: 'Recurring',
    width: 200,
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    fixed: 'right',
    width: 90,
  },
];

const userColumns1: ColumnsType<DataType1> = [
  {
    title: 'Sr.no.',
    dataIndex: 'srno',
    key: 'srno',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    width: 150,
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
    width: 150,
  },
  {
    title: 'Phone No.',
    dataIndex: 'phone',
    width: 200,
    key: 'phone',
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    fixed: 'right',
    width: 90,
  },
];

const userColumnspoint: ColumnsType<DataType12> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    key: 'orderid',
    width: 150,
  },

  {
    title: 'Service Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    width: 200,
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    key: 'date',
    width: 200,
  },
  {
    title: 'Points Credited',
    dataIndex: 'PointsCredited',
    key: 'PointsCredited',
    width: 150,
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
  },
];
const dataSourcepointtwo: ColumnsType<DataType11> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    key: 'orderid',
    width: 150,
  },

  // {
  //   title: 'User Name',
  //   dataIndex: 'name',
  //   key: 'name',
  //   ellipsis: {
  //     showTitle: false,
  //   },
  //   width: 150,
  // },
  {
    title: 'Service Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    width: 150,
  },
  {
    title: 'Transaction Id',
    dataIndex: 'TransactionId',
    key: 'TransactionId',
    width: 200,
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    key: 'date',
    width: 200,
  },
  {
    title: 'Type',
    dataIndex: 'Type',
    key: 'Type',
    width: 150,
  },
  {
    title: 'App Wallet',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
  },
];
const userColumns2: ColumnsType<DataType2> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
    width: 220,
  },
  {
    title: 'Phone No.',
    dataIndex: 'phone',
    width: 200,
    key: 'phone',
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 200,
    key: 'service',
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width:200,
  },
];
const productColumns: ColumnsType<ProductInfoInterface> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    render: (name) => (
      <Tooltip placement="topLeft" title={name}>
        {name}
      </Tooltip>
    ),
    width: 200
  },
  {
    title: 'Category',
    dataIndex: 'category',
    key: 'category',
    width: 100

  },
  {
    title: 'Price',
    dataIndex: 'price',
    key: 'price',
    width: 100
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
  }
]

const homepageColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Image',
    dataIndex: 'image',
    key: 'image',
    width: 100

  },
  {
    title: 'Title',
    dataIndex: 'title',
    key: 'title',
    ellipsis: {
      showTitle: false,
    },
    render: (title) => (
      <Tooltip placement="topLeft" title={title}>
        {title}
      </Tooltip>
    ),
    width: 100
  },
  {
    title: 'Sub Title',
    dataIndex: 'sub_title',
    key: 'sub_title',
    width: 100

  },

  // {
  //   title: 'Description',
  //   dataIndex: 'description',
  //   key: 'description',
  //   width: 100

  // },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
  }
]
const notificationColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 60,
    responsive: ['lg']
  },
  {
    title: 'User',
    dataIndex: 'User',
    width: 60
  },
  {
    title: 'Notification Type',
    dataIndex: 'notificationType',
    width: 150
  },
  {
    title: 'Category',
    dataIndex: 'Category',
    width: 100
  },
  {
    title: 'Subject',
    dataIndex: 'Subject',
    width: 100
  },
  {
    title: 'Message',
    dataIndex: 'message',
    width: 100
  },
];
const contactsUsColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 60,
    responsive: ['lg']
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 60
  },
  {
    title: 'Email',
    dataIndex: 'email',
    width: 150
  },
  // {
  //   title: 'Phone No.',
  //   dataIndex: 'phone',
  //   width: 100
  // },
  {
    title: 'Title',
    dataIndex: 'title',
    width: 100
  },
  {
    title: 'Message',
    dataIndex: 'message',
    width: 100
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  },
];

const languageColumns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Page',
    dataIndex: 'page',
    key: 'page',
    width: 200
  },
  {
    title: 'Action',
    dataIndex: 'action',
    key: 'action',
    width: 200
  }
];
const languageDetailsColumns: ColumnsType<DataType> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 150
  },
  {
    title: 'Key',
    dataIndex: 'name',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'en-US',
    dataIndex: 'en_us',
    width: 200
  },
  {
    title: 'Hindi',
    dataIndex: 'hi',
    width: 150
  },
  {
    title: 'Arabic',
    dataIndex: 'ar',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 150
  }
];

const serviceColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 80
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 150,
  },
  {
    title: 'Subservice',
    dataIndex: 'subservice',
    width: 300
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]

const apartmentColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Rooms',
    dataIndex: 'rooms',
    width: 150,
  },
  {
    title: 'Price (AED)',
    dataIndex: 'price',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]

const orderColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Vendor Name',
    dataIndex: 'vendorname',
    width: 150,
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    width: 150
  },
  {
    title: 'Service Name',
    dataIndex: 'service',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150
  },
  {
    title: 'Clickspert Points',
    dataIndex: 'clickspertPoint',
    width: 150
  },
  {
    title: 'Wallet',
    dataIndex: 'wallet',
    width: 150
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 150
  },
  {
    title: 'Promo Code',
    dataIndex: 'promoCode',
    width: 150
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]

const orderRequestColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    width: 150
  },
  {
    title: 'Service Name',
    dataIndex: 'service',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 150
  },
  {
    title: 'Promo Code',
    dataIndex: 'promocode',
    width: 150
  },
  {
    title: 'Clickspert Points',
    dataIndex: 'clickspertPoint',
    width: 150
  },
  {
    title: 'Wallet',
    dataIndex: 'wallet',
    width: 150
  },
  
  {
    title: 'Amount',
    dataIndex: 'amount',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 200
  }
]

const jobDetailColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'srno',
    width: 100
  },
  {
    title: 'Furniture',
    dataIndex: 'furniture',
    width: 150,
  },
  {
    title: 'Material',
    dataIndex: 'material',
    width: 150
  },
  {
    title: 'Size',
    dataIndex: 'size',
    width: 150
  },
  {
    title: 'Description',
    dataIndex: 'description',
    width: 150
  },
]

const feedbackColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'srno',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Vendor Name',
    dataIndex: 'vendorname',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Feedback',
    dataIndex: 'feedback',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]

const pagesColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Page',
    dataIndex: 'page',
    width: 100
  },
  {
    title: 'Description',
    dataIndex: 'description',
    width: 150
  },
  {
    title: 'Created On',
    dataIndex: 'createdon',
    width: 100
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const document: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 100
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 80
  }
]

const transactionColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Service Type',
    dataIndex: 'servicetype',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 150
  },
  {
    title: 'Transaction Type',
    dataIndex: 'transactionType',
    width: 150
  },
  {
    title: 'Transaction Id',
    dataIndex: 'transactionid',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150
  },
  {
    title: 'Order Price',
    dataIndex: 'price',
    width: 150
  },
  {
    title: 'Service Fee',
    dataIndex: 'servicefee',
    width: 150
  },
  {
    title: 'Total VAT ',
    dataIndex: 'vat',
    width: 150
  },
  {
    title: 'Total order price',
    dataIndex: 'totalprice',
    width: 150
  },
  {
    title: 'Admin earning',
    dataIndex: 'adminearning',
    width: 150
  },
  {
    title: 'Admin Service Fee',
    dataIndex: 'adminservicefee',
    width: 150
  },
  {
    title: 'Admin VAT',
    dataIndex: 'adminvat',
    width: 150
  },
  {
    title: 'Total admin earning  ',
    dataIndex: 'totaladminearning',
    width: 150
  },
  {
    title: 'Vendor earning',
    dataIndex: 'vendorearning',
    width: 150
  },
  {
    title: 'Vendor VAT',
    dataIndex: 'vendorvat',
    width: 150
  },
  {
    title: 'Total vendor earning ',
    dataIndex: 'totalvendorearning',
    width: 150
  },
  {
    title: 'Promo-code',
    dataIndex: 'promocode',
    width: 150
  },
  {
    title: ' Clickspert Point(Use) ',
    dataIndex: 'clickspertpointuse',
    width: 150
  },
  {
    title: 'Clickspert Point(Earn) ',
    dataIndex: 'clickspertpointe',
    width: 150
  },
  {
    title: 'App Wallet',
    dataIndex: 'appwallet',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const transactionPayoutColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Service Type',
    dataIndex: 'servicetype',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 150
  },
  {
    title: 'Transaction Type',
    dataIndex: 'transactionType',
    width: 150
  },
  {
    title: 'Transaction Id',
    dataIndex: 'transactionid',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150
  },
{
  title: 'Order Price',
  dataIndex: 'price',
  width: 150
},
{
  title: 'Service Fee',
  dataIndex: 'servicefee',
  width: 150
},
{
  title: 'Total VAT ',
  dataIndex: 'vat',
  width: 150
},
{
  title: 'Total order price',
  dataIndex: 'totalprice',
  width: 150
},
{
  title: 'Admin earning',
  dataIndex: 'adminearning',
  width: 150
},
{
  title: 'Admin VAT',
  dataIndex: 'adminvat',
  width: 150
},
{
  title: 'Total admin earning  ',
  dataIndex: 'totaladminearning',
  width: 150
},
{
  title: 'Vendor earning',
  dataIndex: 'vendorearning',
  width: 150
},
{
  title: 'Vendor VAT',
  dataIndex: 'vendorvat',
  width: 150
},
{
  title: 'Total vendor earning ',
  dataIndex: 'totalvendorearning',
  width: 150
},
{
  title: 'Promo-code',
  dataIndex: 'promocode',
  width: 150
},
{
  title: ' Clickspert Point(Use) ',
  dataIndex: 'clickspertpointuse',
  width: 150
},
{
  title: 'Clickspert Point(Earn) ',
  dataIndex: 'clickspertpointe',
  width: 150
},
{
  title: 'App Wallet',
  dataIndex: 'appwallet',
  width: 150
},
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const transactionclickspertColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Service Type',
    dataIndex: 'servicetype',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Recurring',
    dataIndex: 'recurring',
    width: 150
  },
  {
    title: 'Transaction Id',
    dataIndex: 'transactionid',
    width: 150
  },
  {
    title: 'Price',
    dataIndex: 'price',
    width: 150
  },
  {
    title: 'Clickspert Point',
    dataIndex: 'point',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const transactionappwalletColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Email',
    dataIndex: 'email',
    width: 150
  },
  {
    title: 'Phone No.',
    dataIndex: 'phone',
    width: 150
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 150
  },
  {
    title: 'App Wallet',
    dataIndex: 'wallet',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const commissionColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 200
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 300,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 80
  }
]
const SalonItemsColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 200
  },
  {
    title: 'Items',
    dataIndex: 'name',
    width: 300,
  },
  {
    title: 'Price',
    dataIndex: 'price',
    width: 300,
  },
  {
    title: 'Gender',
    dataIndex: 'gender',
    width: 300,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 80
  }
]
const SalonServicesColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 200
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 300,
  },
  {
    title: 'Services',
    dataIndex: 'items',
    width: 300,
  },
  {
    title: 'Price',
    dataIndex: 'price',
    width: 300,
  },
  {
    title: 'Discount',
    dataIndex: 'discount',
    width: 300,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 80
  }
]
const viewCommissionColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 200
  },
  {
    title: 'Sub Service',
    dataIndex: 'subservice',
    width: 300,
  },
  {
    title: 'Commission',
    dataIndex: 'commission',
    width: 300,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 80
  }
]

const clickspertColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 150,
  },
  {
    title: 'Points',
    dataIndex: 'points',
    width: 150,
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]

const promocodeColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 200,
  },
  {
    title: 'Discount',
    dataIndex: 'discount',
    width: 150,
  },
  {
    title: 'Max No. Users',
    dataIndex: 'maxusers',
    width: 100
  },
  {
    title: 'Creation Date',
    dataIndex: 'creationdate',
    width: 100
  },
  {
    title: 'Start Date - End Date',
    dataIndex: 'startdate',
    width: 100
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 100
  },
  {
    title: 'Action',
    dataIndex: 'action',
    key:"action",
    width: 100
  }
]
const complaintColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Vendor Name',
    dataIndex: 'vendorname',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Feedback Id',
    dataIndex: 'complaintid',
    width: 150
  },
  {
    title: 'Feedback Type',
    dataIndex: 'complainttype',
    width: 150
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    width: 150
  },
  {
    title: 'Date',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const locationColumns1: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'City',
    dataIndex: 'city',
    width: 150,
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 150,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const locationColumns2: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 50
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 350,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const faqColumns: ColumnsType<any> = [

  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 200
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 300,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const documentColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Document Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Document File',
    dataIndex: 'documentfile',
    width: 250,
  },
  // {
  //   title: 'Action',
  //   dataIndex: 'action',
  //   width: 100
  // }
]
const documentNewColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'Document Name',
    dataIndex: 'name',
    width: 150,
  },
  {
    title: 'Document File',
    dataIndex: 'documentfile',
    width: 250,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const vendorOrderColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Order Id',
    dataIndex: 'orderid',
    width: 150
  },
  {
    title: 'Service Name',
    dataIndex: 'service',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 100
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    width: 100
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100
  }
]
const vendorTransactionColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  {
    title: 'User Name',
    dataIndex: 'username',
    width: 150,
  },
  {
    title: 'Order',
    dataIndex: 'order',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Transaction Id',
    dataIndex: 'transactionid',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 100
  },
  {
    title: 'Price',
    dataIndex: 'price',
    width: 100
  },
  {
    title: 'Vendor Earning',
    dataIndex: 'earning',
    width: 100
  }
]

const vendorNewTransactionColumns: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    width: 100
  },
  // {
  //   title: 'User Name',
  //   dataIndex: 'username',
  //   width: 150,
  // },
  
  {
    title: 'Order Id',
    dataIndex: 'orderId',
    width: 150
  },
  {
    title: 'Service Type',
    dataIndex: 'serviceType',
    width: 150
  },
  {
    title: 'Genric',
    dataIndex: 'genric',
    width: 150
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    width: 150
  },
  {
    title: 'Transaction Id',
    dataIndex: 'transactionid',
    width: 150
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: 100
  },
  {
    title: 'Price',
    dataIndex: 'price',
    width: 100
  },
  {
    title: 'Service Fees',
    dataIndex: 'serviceFees',
    width: 100
  },
  {
    title: 'Commission',
    dataIndex: 'commission',
    width: 100
  },
  {
    title: 'Remarks',
    dataIndex: 'remarks',
    width: 100
  }
]


const vendorRequestService: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 150,
  },

  {
    title: 'Subservices',
    dataIndex: 'subservices',
    width: 200,
  },
];



const vendorRequestServiceChange: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 150,
  },
  {
    title: 'Subservices',
    dataIndex: 'subservice',
    width: 150,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100,
  },
];


const vendorRequestLocation: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Location',
    dataIndex: 'location',
    width: 100,
  },

  {
    title: 'Area',
    dataIndex: 'area',
    width: 100,
  },
];
const vendorRequestLocationChanged: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Changed Location',
    dataIndex: 'changedLocation',
    width: 150,
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 100,
  },
  // {
  //   title: 'Action',
  //   dataIndex: 'action',
  //   width: 100,
  // },
];

const vendorRequestServiceName: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 100,
  },

  {
    title: 'Location',
    dataIndex: 'location',
    width: 100,
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 100,
  },
];
const vendorRequestServiceNameChanged: ColumnsType<any> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100
  },
  {
    title: 'Service',
    dataIndex: 'service',
    width: 100,
  },

  {
    title: 'Location',
    dataIndex: 'location',
    width: 100,
  },
  {
    title: 'Area',
    dataIndex: 'area',
    width: 100,
  },
  {
    title: 'Action',
    dataIndex: 'action',
    width: 100,
  },
];

export default {
  userColumns1,
  userColumns2,
  userColumnspoint,
  dataSourcepointtwo,
  userColumns,
  notificationColumns,
  productColumns,
  homepageColumns,
  allUserColumns,
  userColumnsdetails,
  contactsUsColumns,
  languageColumns,
  languageDetailsColumns,
  document,
  serviceColumns,
  apartmentColumns,
  orderColumns,
  orderRequestColumns,
  feedbackColumns,
  jobDetailColumns,
  pagesColumns,
  transactionColumns,
  transactionPayoutColumns,
  transactionclickspertColumns,
  transactionappwalletColumns,
  vendorNewTransactionColumns,
  commissionColumns,
  viewCommissionColumns,
  SalonItemsColumns,
  SalonServicesColumns,
  clickspertColumns,
  promocodeColumns,
  complaintColumns,
  locationColumns1,
  locationColumns2,
  faqColumns,
  documentColumns,
  documentNewColumns,
  vendorOrderColumns,
  vendorTransactionColumns,
  vendorRequestService,
  vendorRequestServiceChange,
  vendorRequestLocation,
  vendorRequestLocationChanged,
  vendorRequestServiceName,
  vendorRequestServiceNameChanged,
}