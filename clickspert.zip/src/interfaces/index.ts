interface MongoId {
    _id: string
}
interface IdName extends MongoId {
    name: string
}
export interface AuthInterface {
    access_token: string,
    _id: string,
    profile_pic?: string,
    name?: string,
    first_name?: string,
    last_name?: string,
    email?: string,
    phone_verified?: string,
    phone_no?: string,
    image: string,
    country_code?: string,
    email_verified?: boolean,
    super_admin?: boolean,
    roles:Array<string>
}

export interface OrderInfoInterface {
    email?: string,
    name: string,
    area?:string,
    phone_no?: number,
    is_blocked:boolean
    operating_system?:string,
    country_code?: number,
    _id: any,
    special_instruction?:string,
    city?:string,
    sub_services?:any,
    work_quotation_vat?:any,
    device_type?:any,
    image?: any,
    work_quotation_commision_price?:any,
    promo_code_discount?:any,
    adminEarn?:number,
    total_before_tax?:any,
    admin_earning?:number,
    vendor_earning?:number,
    address?:{
    street_address?:any,
    area?:any,
    city?:any,
    house_no:string,
    postal_code:string ,
    country:string,
    state:string,
    address_type:string
    },
    users?:{
        name:string,
        image:any,
        _id:any,
    },
    vendor?:{
        name:string,
        image:any,
        _id:any
    },
    recording?:any,
    is_deactivated?:boolean,
    status?: any,
    grand_total?:number,
    vendorEarn?:number,
    additional_info?:any,
    time?:number,
    quotation_commission:any
    order_id?: any,
    description?:string,
    quotation_amount_currency_id?:any,
    quotation_total_amount?:any,
    work_quotation_description?:string,
    work_quotation_amount?:any,
    no_of_rooms?:number
    no_of_cleaners?:number,
    quotation_status?:string,
    recurring?:string,
    subtotal?:number,
    promo_code?:any,
    total_before_taxes?:number,
    service_fee?:number,
    total_amount?:number,
    vat?:number,
    price?:number,
    work_amount?:number
}
export interface vendorDetail{
    image?:any,
    name?:string,
    email?:any,
    country_code?:any,
    phone_no?:number,
    area?:string,
    is_blocked:boolean,
    city?:string,
    _id?:any,
    is_deactivated?:boolean                            
    description?:string,
    secondary_contacts?:{
        name?:string,
        phone_no?:number,
        email?:any,
        country_code?:number,
        area?:any
    },
    bank_account:[]
}

export interface ProductInfoInterface {
    _id: string,
    prodct_id: string,
    name: string,
    description: string,
    product_type: any,
    added_by: IdName,
    parcel_id?: string,
    brand_id: IdName,
    category_id: IdName,
    subcategory_id: IdName,
    sub_subcategory_id: any,
    images: Array<string>,
    quantity: number,
    sale_price: number,
    discount_percantage: number,
    discount: number,
    discount_price: number,
    total_reviews: number,
    total_ratings: number,
    average_rating: number,
    one_star_ratings: number,
    two_star_ratings: number,
    three_star_ratings: number,
    four_star_ratings: number,
    five_star_ratings: number,
    sold: boolean,
    ratings: Array<any>,
    product_highlights: Array<any>,
    is_blocked: boolean,
    is_deleted: boolean,
    updated_at: string,
    created_at: string
}

export interface ProductDetailsInterface {
    images: Array<any>,
    name: string,
    category_id: categoryDetails,
    description: string,
    sale_price: number
    regular_price: number,
    discount: number,
    is_deleted: boolean,
    is_visible: boolean
}

interface categoryDetails {
    name: string,
    _id: string
}

export interface StaffDetailInterface {
    is_blocked: boolean,
    email?: string,
    name?: string,
    profile_pic?: any,
    roles?: Array<any>,
    country_code?:number,
    phone_no?: number,
    _id: string
}

export interface FaqListingInterface {
    ans?: string,
    question?: string,
    is_deleted?: boolean,
    created_at?: number,
    _id: string
}

export interface ContentDetailInterface {
    page_url: string,
    image: string,
    title: string,
    description: string
}

export interface NotificationDetailsInterface {
    description: string,
    created_at: number,
    subject: string,
    email: string,
    message: string,
    phone_no: number,
    _id: string
}

export interface ContactUsDetailsInterface {
    _id: string,
    email?: string,
    name?: string,
    profile_pic?: string,
    phone_no?: number,
    message?: string,
    status?: string
}

export interface HomePageDetailsInterface {
    _id: string,
    description: string,
    image: string,
    sub_title: string,
    title: string
}
export interface Quotation{
    client?:string,
    address?:{
        street_address:any,
        house_no:string,
        city:string,
        postal_code:string,
        state:string,
        country:string,
        address_type:string
    },
    phone_no?:number,
    email?:any,
    date?:number,
    quotation_ref_no?:number,
    subject?:string,
    scope_of_work:any[],
    work_duration?:string,
    quotation_validity?:string,
    unit_price_currency?:any,
    amount_currency?:any,
    total_amount_currency?:any,
    vat_currency?:any,
    grand_total_currency?:any,
    terms_and_conditions:{
        description?:string,
        _id:any
    }

}
export interface LanguageInterface {
    name: string,
    _id: string
}
export interface VendorRequest{
    image?:any,
    name?:string,
    phone_no?:number,
    email?:any,
    country_code?:number,
    city?:any,
    _id?:any,
    area?:any,
    description?:string
}
export interface SubLanguageInterface {
    _id: string,
    mainkey_id: string,
    en_us: string,
    ar: string,
    hi: string,
    created_at: number,
}
export interface serviceDetails{
    image:any,
    name:any,
    sub_services:[]
    app_image:string
}
export interface DeepCleaningList{
    min_price:number
} 