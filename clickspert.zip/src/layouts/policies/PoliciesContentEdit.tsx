import banner from "@/assets/images/banner.png"
import { message, Upload, Form } from 'antd';
import type { UploadProps } from 'antd';
import dynamic from "next/dynamic";

const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Button, Card, Breadcrumb, Image } = {
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Breadcrumb: dynamic(() => import("antd").then(module => module.Breadcrumb), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}

const PoliciesContentEdit = (props: any) => {

    const onFinish = (values: any) => {
        console.log('Received values of form: ', values);
    };

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    const uploadProps: UploadProps = {
        name: 'file',
        action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
        headers: {
            authorization: 'authorization-text',
        },
        onChange(info) {
            if (info.file.status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (info.file.status === 'done') {
                message.success(`${info.file.name} file uploaded successfully`);
            } else if (info.file.status === 'error') {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
    };


    return <section>
        <Row gutter={[20, 20]}>
            <Col span={24}>
                <Card className='common-card'>
                    {props.children}
                    <div className='terms-conditions-form'>
                        {/* Image  */}
                        <div className="terms-conditions-wrapper-image mb-4">
                            <Image width="100%" height={350} src={banner.src} />
                        </div>
                        {/* form  */}
                        <div className="terms-conditions-wrapper-form">
                            <Form
                                name="basic"
                                initialValues={{ remember: true }}
                                onFinish={onFinish}
                                onFinishFailed={onFinishFailed}
                                autoComplete="off"
                                layout='vertical'>
                                {/* Upload Image  */}
                                <Form.Item name="text" rules={[{ required: true, message: 'Please input!' }]} hasFeedback label="Upload Image">
                                    <Upload {...uploadProps}>
                                        <Button type='primary' htmlType='button' size={'large'}>Upload Image</Button>
                                    </Upload>
                                </Form.Item>
                                {/* Description  */}
                                <Form.Item name="text" rules={[{ required: true, message: 'Please input!' }]} hasFeedback label="Description">
                                    <ReactQuill theme="snow" placeholder="Write description here..." />
                                </Form.Item>
                                {/* Button  */}
                                <Button type="primary" htmlType="submit" size={'large'}>
                                    Save Changes
                                </Button>
                            </Form>
                        </div>
                    </div>
                </Card>
            </Col>
        </Row>
    </section>
}
PoliciesContentEdit.displayName = "PoliciesContentEdit"
export default PoliciesContentEdit