import banner from "@/assets/images/banner.png"
import dynamic from "next/dynamic"
const { Image } = {
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}

const PoliciesContent = (props: any) => {

    return <div className='terms-conditions-wrapper'>
        <div className="terms-conditions-wrapper-image mb-4">
            <Image width="100%" height={350} src={props.image_url || banner.src} />
        </div>
        {/* listing  */}
        <div className="terms-conditions-wrapper-content">
            <div dangerouslySetInnerHTML={{ __html: props.description }} >
            </div>
        </div>
    </div>
}
PoliciesContent.displayName = "PoliciesContent"
export default PoliciesContent