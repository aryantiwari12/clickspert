
import { MenuOutlined, CloseOutlined } from '@ant-design/icons';
import { Badge, Grid, Layout, MenuProps } from 'antd';
import React, { useState, useEffect } from 'react';
import MenuBar from "@/components/common/MenuBar";
import Footer from '@/components/common/Footer';
import Link from 'next/link';
import { UsergroupAddOutlined, BellOutlined, UserOutlined } from '@ant-design/icons'
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import henceforthApi from '@/utils/henceforthApi';
import Script from 'next/script';

const { Button, Dropdown, Tooltip } = {
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
}

const { Header, Sider, Content } = Layout;

const MainLayout = ({ children }: any) => {
//    const []
    const { userInfo, setUserInfo, count, setCount, logout } = React.useContext(GlobalContext)
    const [collapsed, setCollapsed] = useState(false);
    const screens = Grid.useBreakpoint();
    useEffect(() => {
        window.addEventListener("scroll", () => {
            const header: any = document.querySelector('.ant-layout-header');
            if (window.scrollY >= 64) {
                header?.classList.add('sticky-top', 'z-3', 'transition-smooth')
            } else {
                header?.classList.remove('sticky-top', 'z-3', 'transition-smooth')
            }
        });
        window.addEventListener("resize", () => {
            if (window.innerWidth <= 991) {
                setCollapsed(true);
            }
            else {
                setCollapsed(false);
            }
        })
    });

    const items: MenuProps['items'] = [
        {
            key: '1',
            label: (
                <Link rel="noopener noreferrer" className="text-decoration-none fw-semibold" href="/profile">
                    Profile
                </Link>
            ),
        },
        {
            key: '2',
            label: (
                <Link rel="noopener noreferrer" className="text-decoration-none fw-semibold" href="/profile/password/change">
                    Change Password
                </Link>
            ),
        },
        {
            key: '3',
            label: (
                <button className="reset-all fw-semibold" type='button' onClick={logout}>
                    Log Out
                </button>
            ),
        },
    ];
    console.log(userInfo);
// React.useEffect(()=>{
//     const script = document.createElement('script');

//     script.src = "https://static.zdassets.com/ekr/snippet.js?key=a4ad6878-0383-44e3-95ff-016c73474280";
//     script.async = true;
//     script.id = 'ze-snippet';

//     document.body.appendChild(script);
    
//     return () => {
//         debugger
//         document.body.removeChild(script);
//     }
// },[])

    return (
        
        <Layout className="layout" hasSider>
             {/* <Script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=a4ad6878-0383-44e3-95ff-016c73474280"> </Script> */}
            <Sider trigger={null} collapsible collapsed={collapsed} theme="light" width={'250px'} breakpoint="lg" collapsedWidth="0"
                onBreakpoint={(broken) => {
                    console.log(broken);
                }} onCollapse={(collapsed, type) => {
                    console.log(collapsed, type);
                }}
                style={{
                    background: 'white',
                    overflow: 'auto',
                    height: screens.lg ? '100vh' : '100%',
                    position: 'fixed',
                    left: 0,
                    top: 0,
                    bottom: 0,
                    zIndex: 1 
                }}
            >

                <MenuBar collapsed={collapsed} setCollapsed={setCollapsed} />
            </Sider>
            <Layout className="site-layout" style={{ marginLeft: screens.lg ? collapsed ? '0px' : '250px' : '0', transition: "all 0.3s ease-in-out" }}>
                {/* Header  */}
                <Header style={{width:collapsed?'100%':'calc(100% - 250px)',transition: "all 0.3s ease-in-out"}} className="site-layout-background flex-center px-4 py-2" >
                    <div>
                        {React.createElement(collapsed ? MenuOutlined: CloseOutlined , {
                            className: 'trigger',
                            onClick: () => setCollapsed(!collapsed),
                        })}
                    </div>
                    <div className='d-inline-flex align-items-center'>
                        <Link href="/notification/listing/page/1" className="text-decoration-none">
                            <Button type="default" size={'large'} className="border-0 shadow-none bg-transparent py-0" htmlType='button'>
                                <Tooltip title="Notification">
                                    <Badge count={count} size='default'>
                                        <BellOutlined style={{ fontSize: "24px" }} />
                                    </Badge>
                                </Tooltip>
                            </Button>
                        </Link>
                        {userInfo?.super_admin && <Link href="/staff/page/1" className="text-decoration-none">
                            <Tooltip title="Staff">
                                <Button className='border-0 shadow-none bg-transparent py-0' size={'large'}>
                                    <UsergroupAddOutlined style={{ fontSize: "24px" }} />
                                </Button>
                            </Tooltip>
                        </Link>}
                        <Dropdown menu={{ items }} trigger={['click']} placement="bottomRight" arrow>
                            <Button className='shadow-none py-0 border-0 bg-transparent' htmlType='button'>
                                {userInfo?.image ? <img src={henceforthApi.FILES.imageSmall(userInfo?.image as any, '')} alt="img" className='profile-img ' /> : <UserOutlined  style={{ fontSize: "24px" }}/>}
                            </Button>
                        </Dropdown>
                    </div>
                </Header>
                {/* Content  */}
                <Content className="m-4">
                    {children}
                </Content>
                {/* Footer  */}
                <Footer />
            </Layout>
        </Layout >
    )
}

export default MainLayout;