
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Button, Card, Col, Divider, Form, Input, Image, Modal, Row, Select, Table, Typography } from 'antd';
import Link from 'next/link';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import HenceforthIcons from '@/components/HenceforthIcons';
import henceforthApi from '@/utils/henceforthApi';
import { GetServerSideProps } from 'next';
import placeholder from '@/assets/images/placeholder.png'
import dayjs, { Dayjs } from 'dayjs';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import ModalAssign from '@/components/common/ModalAssign';
import SearchPage from '@/components/common/SearchInput';
import henceofrthEnums from '@/utils/henceofrthEnums';
import { capitalize } from 'lodash';
const ViewOrderRequest = (props: any) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isModalOpenEdit, setIsModalOpenEdit] = useState(false);
    const [isModalOpenAssign, setIsModalOpenAssign] = useState(false);
    const [vendor, setVendor] = useState<any>('')
    const { userInfo, downloadCSV, Toast } = React.useContext(GlobalContext)
    const router = useRouter()
    const [state, setState] = useState(props.data)
    const [assignlist, setAssignList] = useState({
        data: []
    })
    const [service, setService] = useState({
        data: [],
    })
    const [subService, setSub_service] = useState({
        sub_services: []
    } as any)
    const [loading, setLoading] = useState({
        loading1: false,
        loading2: false,
        loading3: false,
    });
    const [form] = Form.useForm();

    console.log(state, "props");

    const showModal = () => {
        setIsModalOpen(true);
    };
    const showModalEdit = () => {
        setIsModalOpenEdit(true)
    }

    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleOkEDit = () => {
        setIsModalOpenEdit(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const handleCancelAssign = () => {
        setIsModalOpenAssign(false);
    };
    const handleCancelEdit = () => {
        setIsModalOpenEdit(false);
    };
    const  street_address=state?.address ? `${state?.address?.house_no ? `${state?.address?.house_no} , ` : " "}${state?.address?.city ? `${state?.address?.city} , ` : " "}${state?.address?.postal_code ? `${state?.address?.postal_code } , ` :  ""}${state?.address?.state ? `${state?.address?.state} , ` : " "}${state?.address?.country ? `${state?.address?.country} , ` : " "}${capitalize(state?.address?.address_type ? `${state?.address?.address_type} , ` : "")}` : "N/A"


    const CLICKSPERTPOINTS = state?.points_used_amount ? state?.payment_mode != "OTHER" ? ` & Clickspert Points` : ' Clickspert Points' : "";
    const WALLETPAYMENT = state?.wallets_used ? state?.payment_mode != "OTHER" ? ` & Wallet` : "Wallet" : "";
    const PAYMENTMODE = state?.payment_mode != "OTHER" ? capitalize(state?.payment_mode) : ""
    const subServiceName = state?.sub_services?.name
    const NoRecurring = (subServiceName === henceofrthEnums.Cleaning.WomenSaloonAndSpa ||
        subServiceName === henceofrthEnums.Cleaning.MenSaloonAndSpa || subServiceName === henceofrthEnums.Cleaning.PacksMove || subServiceName === henceofrthEnums.Cleaning.GroomingPackage || subServiceName === henceofrthEnums.Cleaning.smartInteriorAutomation || subServiceName === henceofrthEnums.Cleaning.windowCleaning || subServiceName === henceofrthEnums.Cleaning.smartInteriorAutomation || subServiceName === henceofrthEnums.Cleaning.AnnualMaintainceContract)
    const initialise = async () => {
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Order.listingVendor(urlSearchParam.toString())
            setAssignList(apiRes)
        } catch (error) {

        }
    }
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }
    const onChangeExtra = async (values: any) => {
        try {
            setLoading({
                ...loading,
                loading3: true
            })
            const info = {
                order_id: router.query._id,
                work_quotation_amount: +values.work_quotation_amount,
                quotation_commission: values.quotation_commission,
                quotation_total_amount: +values.quotation_total_amount,
                quotation_total_amount_currency_id: state.quotation_amount_currency_id
            }
            let apiRes = await henceforthApi.Order.extra(info)
            Toast.success(apiRes.message)
            setState((state: any) => {
                return {
                    ...state,
                    work_quotation_amount: +values.work_quotation_amount
                }
            })
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading({
                ...loading,
                loading3: false
            })
            setIsModalOpenEdit(false)
        }
    }
    const assignModal = () => {
        setIsModalOpenAssign(true)
    }
    const onChangeDecline = async (name: string) => {
        try {
            setLoading({
                ...loading,
                loading1: true
            })

            let apiRes = await henceforthApi.Order.decline(`order_id=${router.query._id}&is_quotation_status=${name}`)
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading({
                ...loading,
                loading1: false
            })
        }
    }
    const handlechange = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Vendor.getById(_id)
            setVendor(apiRes)
            setIsModalOpen(false)
        } catch (error) {

        }
    }
    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/order-request/${router.query._id}/view`, query: { service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/order-request/${router.query._id}/view`, query: { service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }
    const handleSelect = (_id: any) => {
        try {
            let sub_service = service?.data.find((res: any) => res._id == _id)
            setSub_service(sub_service)
            handleChange(null, _id)
        } catch (error) {
            Toast.error(error)
        }
    }
    useEffect(() => {
        serviceInitialse()
    }, [])

    useEffect(() => {
        form.setFieldValue("work_quotation_amount", state?.work_quotation_amount)
        form.setFieldValue("quotation_commission", state?.quotation_commission)
        form.setFieldValue("quotation_total_amount", state?.quotation_total_amount)
        initialise()
    }, [router.query.search, router.query.service_id,
    router.query.sub_service_id,])
    const dataSource = state?.furniture_data?.map((res: any, index: number) => {
        return {
            srno: index + 1,
            furniture: capitalize(res.material_type),
            material: res.material,
            size: res.size ? `${res.size} ` : '',
            description: res.description || "N/A"
        }
    })
    const columns = [
        {
            title: 'Sr.no.',
            dataIndex: 'srno',
            width: 200
        },
        {
            title: 'Furniture',
            dataIndex: 'furniture',
            width: 200
        },
        {
            title: 'Material',
            dataIndex: 'material',
            width: 200
        },
        {
            title: 'Size',
            dataIndex: 'size',
            width: 200
        },
        {
            title: 'Description',
            dataIndex: 'description',
            width: 200
        },
    ]
    const [isVendorAssignModalOpen, setIsVendorAssignModalOpen] = useState(false)
    const showVendorAssignModal = () => {
        setIsVendorAssignModalOpen(true);
        // setOrderId(_id)
    };
    const [serviceId, setServiceId] = useState('')
    const initialiseAssign = async (id: any) => {
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Order.listvendor(id)
            setAssignList(apiRes)
            setServiceId(id)
        } catch (error) {

        }
    }
    function success(pos: any) {
        console.log("successsssssssssssssss");
        const crd = pos.coords;
        router.push({
            pathname: '/address',
            query: {
                startLat: crd?.latitude,
                startlng: crd?.longitude,
                endLat: state?.address?.location?.coordinates[1],
                endLng: state?.address?.location?.coordinates[0],
            }
        })
    }
    return (
        <Fragment>
            <Row gutter={[20, 20]} className="mb-4">
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='mb-4'>
                            <Breadcrumb separator=">">
                                <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                                <Breadcrumb.Item><Link href="/order-request/page/1" className='text-decoration-none'>Orders</Link></Breadcrumb.Item>
                                <Breadcrumb.Item className='text-decoration-none'>Order details</Breadcrumb.Item>
                            </Breadcrumb>
                        </div>
                        {/* Title  */}
                        <div>
                            <Typography.Title level={3} className='mb-4 fw-bold'>Order Details</Typography.Title>
                        </div>

                        <div className='order-detail-img'>
                            <img src={henceforthApi.FILES.imageSmall(state?.sub_services?.image) || placeholder.src} alt='img' />
                        </div>
                        <div className='flex-center mt-3 mb-5'>
                            <div>
                                <Typography.Title level={4} className='mb-1 fw-bold'>{state?.sub_services?.name || 'N/A'}</Typography.Title>
                                <p className='m-0'><span className='text-gray'>Order Id:</span><span className='fw-600'> {state?.order_id ? `${state.order_id}` : "N/A"}</span></p>
                            </div>
                            {/* <div>
                                <Button size='large' type='primary' onClick={showModal}>Assign Vendor</Button>
                                <Button size='large' type='primary' onClick={()=>router.push(`/order-request/${state?._id}/quotation`)}>Send Quotation</Button>
                            </div> */}
                            <div>
                                {!state?.is_accepted ? <Button size='large' type='primary' onClick={showModal}>Assign Vendor</Button> : ""}
                                {(state?.is_quotation_based && state?.is_accepted && state?.quotation_status != 'USER_ACCEPTED_QUOTATION') ? <Button size='large' type='primary' onClick={() => router.push(`/order-request/${state?._id}/quotation`)}>Send Quotation</Button> : ""}
                            </div>
                        </div>
                        <Row justify={'space-between'}>
                            <Col span={24} md={12} xl={5}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Job details</Typography.Title>

                                {/* {state.is_quotation_based==true  ? <> */}
                                {/* <p><span className='text-gray'>No. of rooms in villa:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                <p><span className='text-gray'>No. of floors:</span><span className='fw-600 ms-2'>{state?.no_of_floors || 'N/A'}</span></p> */}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.HomeCleaning ?
                                    <>       <p><span className='text-gray'>No. of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                        <p><span className='text-gray'>No. of cleaners:</span><span className='fw-600 ms-2'>{state?.no_of_cleaners || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Need of Cleaning Materials:</span><span className='fw-600 ms-2'>{state?.normal_cleaning_price?.cleaning_material == false ? "No" : "Yes"}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.DeepCleaning ?
                                    <>
                                        <p><span className='text-gray'>Type:</span><span className='fw-600 ms-2'>{state?.type?.toLowerCase() || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Size of Yours Home:</span><span className='fw-600 ms-2'>{state?.no_of_rooms ? `${state?.no_of_rooms}BHK` : 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.FurnitureCleaning ?
                                    <>
                                        {/* <p><span className='text-gray'>Furniture Type:</span>{Array.isArray(state?.furniture_type) && state?.furniture_type?.length ? state?.furniture_type.map((res: any, index: any) => (<span className='fw-600 ms-2' key={index}>{(index !== 0 ? ', ' : '') + res?.toLowerCase()}</span>)) : "N/A"}</p>
                                        <p><span className='text-gray'>Number of Sofa:</span><span className='fw-600 ms-2'>{state?.no_of_sofa || 'N/A'}</span></p> */}
                                        {/* <Button>Job Details</Button> */}

                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.windowCleaning ?
                                    <>
                                        <p><span className='text-gray'>No. of rooms in villa:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'>No. of floors:</span><span className='fw-600 ms-2'>{state?.no_of_floors || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.AnnualMaintainceContract ?
                                    <>
                                        <p><span className='text-gray'>No. of rooms :</span><span className='fw-600 ms-2'>{state?.no_of_rooms ? state?.no_of_rooms + " BHK" : 'N/A'}</span></p>
                                        <p><span className='text-gray'>Home Type:</span><span className='fw-600 ms-2'>{capitalize(state?.type) || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Plan:</span><span className='fw-600 ms-2'>{capitalize(state?.plan_type) || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.petTriming ?
                                    <>
                                        <p><span className='text-gray'>Number of Cats:</span><span className='fw-600 ms-2'>{state?.no_of_cat || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Small Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_small_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Medium Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_medium_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Large Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_large_dog || 'N/A'}</span></p>

                                    </> : ""}
                                    {state?.sub_services?.name === henceofrthEnums.Cleaning.SwimmingPoolMaintenance ?
                                    <>
                                        <p><span className='text-gray'> description:</span><span className='fw-600 ms-2'>{state?.description || 'N/A'}</span></p>
                                    </> : ""}
                                    {state?.sub_services?.name === henceofrthEnums.Cleaning.SwimmingPoolCleaning ?
                                    <>
                                        <p><span className='text-gray'> Pool Size:</span><span className='fw-600 ms-2'>{state?.size || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PestControl ?
                                    <>
                                        <p><span className='text-gray'>Pest Type:</span><span className='fw-600 ms-2'>{state?.pest_type || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Cleaning Space:</span><span className='fw-600 ms-2'>{state?.cleaning_space || 'N/A'}</span></p>
                                    </>
                                    : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Disinfection ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </>
                                    : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.SaloonSpa ?
                                    <>
                                        <p><span className='text-gray'> Men Saloon:</span><span className='fw-600 ms-2'>{state?.men_saloon || 'N/A'}</span></p>
                                        {/* <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.same_emirates || 'N/A'}</span></p>
                                <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p> */}

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PacksMove ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.is_same_emirates == false ? 'NO' : "Yes"}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location from :</span><span className='fw-600 ms-2' title={state?.location_from}>{state?.location_from?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location to :</span><span className='fw-600 ms-2' title={state?.location_to}>{state?.location_to?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        {!state?.is_same_emirates && <>  <p><span className='text-gray'> Emirates from  :</span><span className='fw-600 ms-2' title={state?.from_emirates}>{state?.from_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                            <p><span className='text-gray'> Emirates to :</span><span className='fw-600 ms-2' title={state?.to_emirates}>{state?.to_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p></>}
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PacksPoints ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.is_same_emirates == false ? 'NO' : "Yes"}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Color :</span><span className='fw-600 ms-2' >{state?.color_id?.name || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location from :</span><span className='fw-600 ms-2' title={state?.location_from}>{state?.location_from?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location to :</span><span className='fw-600 ms-2' title={state?.location_to}>{state?.location_to?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        {!state?.is_same_emirates && <>  <p><span className='text-gray'> Emirates from  :</span><span className='fw-600 ms-2' title={state?.from_emirates}>{state?.from_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                            <p><span className='text-gray'> Emirates to :</span><span className='fw-600 ms-2' title={state?.to_emirates}>{state?.to_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p></>}
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.MoveOutInspection ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.smartInteriorAutomation ?
                                    <>
                                        <p><span className='text-gray'> Type:</span>{state?.sia.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>{(index !== 0 ? ', ' : '') + res.name}</span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.AcCleaning ?
                                    <>
                                        <p><span className='text-gray'> Duct Cleaning:</span><span className='fw-600 ms-2'>{state?.no_of_duct_cleaning || 'N/A'}</span></p>
                                        <p><span className='text-gray'> A/c Cleaning or filter cleaning:</span><span className='fw-600 ms-2'>{state?.no_of_ac_filter_cleaning || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Electrical ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Plumber ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Handyman ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Painting ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Landscaping ?
                                    <>
                                        <p><span className='text-gray'> Size of garden:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PetWashing ?
                                    <>
                                        <p><span className='text-gray'>Number of Cats:</span><span className='fw-600 ms-2'>{state?.no_of_cat || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Small Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_small_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Medium Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_medium_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Large Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_large_dog || 'N/A'}</span></p>

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.SwimmingPool ?
                                    <>
                                        <p><span className='text-gray'>Size:</span><span className='fw-600 ms-2'>{state?.swimming_pool?.size || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Type:</span><span className='fw-600 ms-2'>{capitalize(state?.swimming_pool?.type?.split("_")?.join(" ")) || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PetWashingTrimming ?
                                    <>
                                        <p><span className='text-gray'>Number of Cats:</span><span className='fw-600 ms-2'>{state?.no_of_cat || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Small Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_small_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Medium Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_medium_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Large Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_large_dog || 'N/A'}</span></p>

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.MenSaloonAndSpa ?
                                    <>
                                        <p><span className='text-gray'>Type of Saloon:</span>{state?.men_saloon_price.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>
                                            <p>{res?.item_name}</p>
                                            <p>No of Items:{res?.no_of_item}</p>
                                            <p>Type:{res?.type.toLowerCase()}</p>

                                        </span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.WomenSaloonAndSpa ?
                                    <>
                                        <p><span className='text-gray'>Type of Saloon:</span>{state?.women_saloon_price.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>
                                            <p>{res?.item_name}</p>
                                            <p>No of Items:{res?.no_of_item}</p>
                                            <p>Type:{res?.type.toLowerCase()}</p>

                                        </span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.GroomingPackage ?
                                    <>
                                        <p><span className='text-gray'>Number of Cats:</span><span className='fw-600 ms-2'>{state?.no_of_cat || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Small Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_small_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Medium Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_medium_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Large Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_large_dog || 'N/A'}</span></p>

                                    </> : ""}


                            </Col>
                            <Col span={24} md={12} xl={7}>
                                <div className='flex-between gap-2 mb-3'>

                                    <Typography.Title level={4} className='mb-0 fw-bold'>Address</Typography.Title>
                                    <Button onClick={() => navigator.geolocation.getCurrentPosition(success)} type="primary" htmlType='button' className='' ghost>
                                        Open Google Map
                                    </Button>
                                </div>
                                <p className='text-gray'>{state?.address ? street_address : 'N/A'}</p>
                            </Col>
                            <Col span={24} md={12} xl={6}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Date & Time</Typography.Title>
                                <p className='text-gray'>{dayjs(state?.time).format('ddd, MMM DD - hh:mm A')}</p>
                            </Col>
                            {NoRecurring ? "" : state?.sub_services?.name === henceofrthEnums.Cleaning.Disinfection || state?.sub_services?.name === henceofrthEnums.Cleaning.petTriming
                                || state?.sub_services?.name === henceofrthEnums.Cleaning.AcCleaning ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Electrical ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Plumber ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Handyman ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Painting ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.PetWashing ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.PetWashingTrimming ? '' :
                                <Col span={24} md={12} xl={4}>
                                    {state?.sub_services?.name === henceofrthEnums.Cleaning.WomenSaloonAndSpa ||
                                        state?.sub_services?.name === henceofrthEnums.Cleaning.MenSaloonAndSpa ? '' : <Typography.Title level={4} className='mb-3 fw-bold'>Recurring</Typography.Title>}
                                    {state?.recurring == "Multiple" ? <span>{Array.isArray(state?.cleaning_multiple_times) && state?.cleaning_multiple_times?.length ? state?.cleaning_multiple_times.map((res: any, index: number) => <span key={index}>{state?.cleaning_multiple_times?.length > index + 1 ? res + ", " : res}</span>) : "N/A"}</span> : <p className='text-gray'>{state?.recurring || 'N/A'}</p>}
                                    {state?.recurring == "Once" || state?.recurring == null ? "" : <>
                                        <p className='fw-700 mb-0'>Next Payment:- </p>{dayjs(state?.next_payment_date).format("DD/MMM/YYYY hh:mm A") || 'N/A'}</>}
                                </Col>}
                        </Row>
                    </Card>
                </Col>
                {/* <Col span={24}>
                    <Card className='common-card'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Job detail</Typography.Title>
                        {state?.sub_services?.name == henceofrthEnums.Cleaning.FurnitureCleaning ? 
                        <Table dataSource={dataSource} columns={ColumnsType.jobDetailColumns} pagination={false} scroll={{ x: '100%' }} />:""}
                    </Card>
                </Col> */}
                {state?.sub_services?.name == henceofrthEnums.Cleaning.FurnitureCleaning &&
                    <Col span={24}>
                        <Typography.Paragraph>Job Details</Typography.Paragraph>
                        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
                    </Col>}
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>User detail</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-profile user-detail'>
                                    <img src={henceforthApi.FILES.imageSmall(state?.users?.image) || placeholder.src} alt='img' />
                                </div>
                                <p className='m-0'>{state?.users?.name?.split("_")?.join(" ") || 'N/A'}</p>
                            </div>
                            {/* <div>
                                <Button icon={<HenceforthIcons.Download />} type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                    Download Invoice
                                </Button>
                            </div> */}
                        </div>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <div className="flex-between">
                            <Typography.Title level={5} className='mb-3 fw-bold'>Vendor details</Typography.Title>
                            <span>
                                {(state?.is_accepted) && <Button size='middle' type='primary' onClick={() => {
                                    showVendorAssignModal(); setTimeout(() => {
                                        initialiseAssign(state?.sub_services?._id)
                                    }, 100); showModal()
                                }}>Reassign Vendor</Button>}

                            </span>
                        </div>
                        <div className='flex-center flex-wrap gap-2'>

                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-detail d-flex align-items-center gap-2'>
                                    <div className='d-flex align-items-center gap-2'>

                                        <div className='user-profile user-detail'>
                                            <img src={henceforthApi.FILES.imageSmall(state?.vendor?.image) || placeholder.src} alt='img' />
                                        </div>
                                        {state?.vendor?.name ?
                                            <p className='m-0'>{state?.vendor?.name || 'N/A'}</p> : ""}

                                    </div>
                                </div>
                            </div>
                            {/* <div>
                                <Button icon={<HenceforthIcons.Download />} type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                    Download Invoice
                                </Button>
                            </div> */}
                        </div>

                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>{!state?.is_quotation_based ? `Payment Summary (${PAYMENTMODE}${CLICKSPERTPOINTS}${WALLETPAYMENT})` : state?.quotation_status == 'USER_ACCEPTED_QUOTATION' ? `Payment Summary (${PAYMENTMODE}${CLICKSPERTPOINTS}${WALLETPAYMENT})` : "Quotation"}</Typography.Title>
                        {/* {state?.is_quotation_based && */}
                        {(!state?.is_accepted || state?.quotation_status == "null" || state?.quotation_status == null)
                            ? !state?.is_quotation_based ? "" : <span>{state?.is_accepted ? <p>Please send quotation to user</p> : <p> No one accept this order and you have not assigned any vendor at this order </p>}</span> : <div className='payment-card'>
                                <ul>
                                    <li><span>Subtotal</span><span>{state?.subtotal ? `AED ${state?.subtotal?.toFixed(2)}` : "N/A"}</span></li>
                                    {state?.promo_code ?
                                        <li>
                                            <span>Promo Code ({state?.promo_code?.name ? `${state?.promo_code?.name}` : 'N/A'})</span><span>
                                                {state?.promo_code_discount ? `-AED  ${state?.promo_code_discount?.toFixed(2)}` : "N/A"}</span>
                                        </li> : ""}
                                    <Divider />

                                    {!state?.is_quotation_based && <li>
                                        <span>Total before taxes</span><span className='fw-bold'>{`AED ${state?.total_before_tax?.toFixed(2)}`}</span>
                                    </li>}
                                    {state?.service_fee && <li><span className='underline'>Service fee </span><span>{state?.service_fee ? `AED ${state?.service_fee?.toFixed(2)}` : "N/A"}</span></li>}
                                    {state?.commision && <li><span className='underline'>Commision </span><span>{state?.service_fee ? `AED ${state?.service_fee?.toFixed(2)}` : "N/A"}</span></li>}
                                    <li><span className='underline'>VAT(5%) </span><span>{state?.vat ? `AED ${state?.vat}` : "N/A"}</span></li>
                                    {state?.wallets_used ? <li><span>App Wallet</span><span className='fw-bold'>{state?.wallets_used ? `- AED ${state?.wallets_used?.toFixed(2)}` : 'N/A'}</span></li> : ""}
                                    {state?.points_used_amount ? <li><span className='underline'>Clickspert points  </span><span>{state?.points_used_amount ? `- AED ${state?.points_used_amount?.toFixed(2)} ` : "N/A"}</span></li> : ""}
                                    <li><span className='underline'>Total </span><span>{state?.total_amount ? `AED ${state?.total_amount?.toFixed(2)}` : "N/A"}</span></li>
                                    <Divider />
                                    <li><span>Vendor Subtotal</span><span>{state?.vendor_subtotal ? `AED ${state?.vendor_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>VAT(5%)</span><span>{state?.vendor_vat ? `AED ${state?.vendor_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>Vendor earns</span><span>{state?.vendor_earning ? `AED ${state?.vendor_earning?.toFixed(2)}` : 'N/A'}</span></li>
                                    <Divider />
                                    <li><span>Admin Subtotal</span><span>{state?.admin_subtotal ? `AED ${state?.admin_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                    {!state?.is_quotation_based && <li><span className='underline'>Service fee  </span><span>{state?.service_fee ? `AED ${state?.service_fee}` : 'N/A'}</span></li>}
                                    <li><span>VAT(5%)</span><span>{state?.admin_vat ? `AED ${state?.admin_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>Admin earns</span><span className='fw-bold'>{state?.admin_earning ? `AED ${state?.admin_earning.toFixed('2')}` : 'N/A'}</span></li>
                                </ul>
                            </div>}
                        {!state?.is_quotation_based &&
                            <div className='payment-card'>
                                <ul>
                                    <li><span>Subtotal</span><span>{state?.subtotal ? `AED ${state?.subtotal?.toFixed(2)}` : "N/A"}</span></li>
                                    {state?.promo_code ?
                                        <li>
                                            <span>Promo Code ({state?.promo_code?.name ? `${state?.promo_code?.name}` : 'N/A'})</span><span>
                                                {state?.promo_code_discount ? `-AED ${state?.promo_code_discount?.toFixed(2)}` : "N/A"}</span>
                                        </li> : ""}
                                    <Divider />

                                    {!state?.is_quotation_based && <li>
                                        <span>Total before taxes</span><span className='fw-bold'>{`AED ${state?.total_before_tax?.toFixed(2)}`}</span>
                                    </li>}
                                    {state?.service_fee && <li><span className='underline'>Service fee </span><span>{state?.service_fee ? `AED ${state?.service_fee?.toFixed(2)}` : "N/A"}</span></li>}
                                    {state?.commision && <li><span className='underline'>Commision </span><span>{state?.service_fee ? `AED ${state?.service_fee?.toFixed(2)}` : "N/A"}</span></li>}
                                    <li><span className='underline'>VAT(5%) </span><span>{state?.vat ? `AED ${state?.vat}` : "N/A"}</span></li>
                                    {state?.wallets_used ? <li><span>App Wallet</span><span className='fw-bold'>{state?.wallets_used ? `- AED ${state?.wallets_used?.toFixed(2)}` : 'N/A'}</span></li> : ""}
                                    {state?.points_used_amount ? <li><span className='underline'>Clickspert points  </span><span>{state?.points_used_amount ? `- AED${state?.points_used_amount?.toFixed(2)} ` : "N/A"}</span></li> : ""}
                                    <li><span className='underline'>Total </span><span>{`AED ${state?.total_amount?.toFixed(2)}` ?? "N/A"}</span></li>
                                    <Divider />
                                    <li><span>Vendor Subtotal</span><span>{state?.vendor_subtotal ? `AED ${state?.vendor_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>VAT(5%)</span><span>{state?.vendor_vat ? `AED ${state?.vendor_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>Vendor earns</span><span>{state?.vendor_earning ? `AED ${state?.vendor_earning?.toFixed(2)}` : 'N/A'}</span></li>
                                    <Divider />
                                    <li><span>Admin Subtotal</span><span>{state?.admin_subtotal ? `AED ${state?.admin_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                    {!state?.is_quotation_based && <li><span className='underline'>Service fee  </span><span>{state?.service_fee ? `AED ${state?.service_fee}` : 'N/A'}</span></li>}
                                    <li><span>VAT(5%)</span><span>{state?.admin_vat ? `AED ${state?.admin_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                    <li><span>Admin earns</span><span className='fw-bold'>{state?.admin_earning ? `AED ${state?.admin_earning.toFixed('2')}` : 'N/A'}</span></li>
                                </ul>
                            </div>}

                        {/* } */}
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Additional Info</Typography.Title>
                        {state?.special_instruction || state?.recording || state?.image ?
                            <div className="add-info">
                                <ul>
                                    {state?.special_instruction ?
                                        <li>
                                            <span>Notes:</span>
                                            <p>{state?.special_instruction || "N/A"}</p>
                                        </li> : ""}
                                    {state?.recording ?
                                        <li>
                                            <span>Recording:</span>
                                            <div className='recording'>
                                                <audio controls>
                                                    <source src={henceforthApi.FILES.audio(state?.recording)} type='audio/ogg' />
                                                </audio>
                                            </div>
                                        </li> : ""}
                                    {state?.image ?
                                        <li>
                                            <span>Images</span>
                                            <div className='add-info-img'>
                                                <Image
                                                    // id={`${index}`}
                                                    // width={150}
                                                    src={henceforthApi.FILES.imageOriginal(state?.image, placeholder.src)}
                                                />
                                                {/* <img src={henceforthApi.FILES.imageSmall(state?.image) || placeholder.src} alt='img' /> */}
                                            </div>
                                        </li> : ""}
                                </ul>
                            </div> : <div className='w-100 text-center '><HenceforthIcons.NoData /></div>}
                    </Card>
                </Col>
                {/* <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Extra Work Quotation</Typography.Title>
                        <div className="add-info">
                            <ul>
                                <li>
                                    <span>Vendor description:</span>
                                    <p>{state?.work_quotation_description || 'N/A'}</p>
                                </li>
                                <li className='mb-0'>
                                    <ul className='flex-center flex-wrap'>
                                        <li>
                                            <span>Amount</span>
                                            <p>{state?.work_quotation_amount ? `${state?.work_quotation_amount}AED` : "N/A"}</p>
                                        </li>
                                        <li>
                                            <span>Amount</span>
                                            <p>{state?.work_quotation_amount ? `${state?.work_quotation_amount}AED` : "N/A"}</p>
                                        </li>
                                        <li>
                                            <span>Amount</span>
                                            <p>{state?.work_quotation_amount ? `${state?.work_quotation_amount}AED` : "N/A"}</p>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <span>Status</span>
                                    <p>{state?.quotation_status || 'N/A'}</p>
                                </li>
                                <li className='mb-0'>
                                    <div className='d-flex align-items-center gap-2'>
                                        <Button type="primary" htmlType='button' className=' w-100' size='large' onClick={showModalEdit}><span className='text-dark' >Edit</span></Button>
                                        <Button type="primary" htmlType='button' className=' w-100 ' size='large' danger onClick={() => onChangeDecline("REJECTED")} loading={loading.loading1}><span className='text-white'>Decline</span></Button>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </Card>
                </Col> */}
                {/* <Col span={24}>
                    <Card className='common-card'>
                        <div className='feedback'>
                            <div className="flex-center">
                                <Typography.Title level={5} className='mb-3 fw-bold'>User Feedback</Typography.Title>
                                <Button type="primary" htmlType='button' size='large' className='px-4'><span className='text-dark'>Reply</span></Button>
                            </div>
                            <div className='d-flex align-items-center gap-1 mb-3'>
                                <Image src={Star} alt='img' />
                                <span className='text-theme fw-700'>{state?.reating || 'N/A'}</span>
                            </div>
                            <div>
                                <p className='text-gray mb-2'>Feedback message:</p>
                                <p>{state?.userFeedback || 'N/A'}</p>
                            </div>
                        </div>
                    </Card>
                </Col> */}
            </Row>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700  mt-2'>Assign Vendor</Typography.Title>
                    <Row gutter={[15, 15]}>
                        <Col span={24}>
                            <Form.Item>
                                <SearchPage placeholder="Search" pathname={`/order-request/${router.query._id}/view`} />
                            </Form.Item>
                        </Col>
                        {assignlist?.data.map((res: any, index: number) => {
                            return (
                                <Col span={24} md={12} key={index}>
                                    <ul className='modal-list'>
                                        <li onClick={() => {
                                            handlechange(res._id);
                                            setTimeout(() => {
                                                assignModal()
                                            }, 1000);
                                        }}>
                                            <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                                <div className="user-detail-img" role='button'>
                                                    <img src={henceforthApi.FILES.imageSmall(res.image) || placeholder.src} alt='img' />
                                                </div>
                                                <Typography.Text role='button' >{res.name || 'N/A'}</Typography.Text>
                                            </div>
                                        </li>

                                    </ul>
                                </Col>
                            )
                        })}
                    </Row>
                </div>
            </Modal>
            <ModalAssign isModalOpenAssign={isModalOpenAssign} setIsModalOpenAssign={setIsModalOpenAssign} handleCancelAssign={handleCancelAssign} vendor={vendor} />
            <Modal footer={null} centered={true} open={isModalOpenEdit} onOk={handleOkEDit} onCancel={handleCancelEdit}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Extra Work Quotation Amount</Typography.Title>
                    <Form size='large' form={form} onFinish={onChangeExtra} layout='vertical' className='mt-3'>
                        <Form.Item name="work_quotation_amount" label='Amount'>
                            <Input placeholder='Amount' className='border-0' />
                        </Form.Item>
                        <Form.Item name="quotation_commission" label='Commission' >
                            <Input placeholder='Commission' className='border-0' />
                        </Form.Item>
                        <Form.Item name="quotation_total_amount" label='Total' >
                            <Input placeholder='Total' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' loading={loading.loading3} htmlType='submit' block>Send Request</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}
export const getServerSideProps: GetServerSideProps = async (context) => {
    try {
        let apiRes = await henceforthApi.Order.getById(context.query._id as string)
        let data = apiRes
        return { props: { data } };
    } catch (error) {
        return {
            props: {}
        }
    }

}


ViewOrderRequest.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
export default ViewOrderRequest