import React, { useEffect, useState } from 'react'
import Header from '@/assets/images/quotation-header.svg'
import Footer from '@/assets/images/quotation-footer.png'
import Image from 'next/image'
import { Button, Col, DatePicker, DatePickerProps, Form, Input, Modal, Row, Tooltip, Typography } from 'antd'
import HenceforthIcons from '@/components/HenceforthIcons'
import henceforthApi from '@/utils/henceforthApi'
import { useRouter } from 'next/router'
import { Quotation } from '@/interfaces'
import dayjs from 'dayjs'
import { DeleteOutlined } from '@ant-design/icons'
import { GlobalContext } from '@/context/Provider'
import dynamic from 'next/dynamic'
import henceforthValidations from '@/utils/henceforthValidations'
import { capitalize } from 'lodash'
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const Quotation = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const { Toast, downloadCSV, uploadCSV } = React.useContext(GlobalContext)
    const [state, setState] = useState({} as Quotation)
    const [validityDate, setValidityDate] = useState('')
    const [loading, setLoading] = useState({
        loading1: false,
        loading2: false
    })
    const [currency, setcurrency] = useState<any>([])
    const router = useRouter()
    const [form] = Form.useForm();
    const [form1] = Form.useForm();
    let vat = 10
    const [rows, initRow] = useState<any>([]);
    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const addRowTable = () => {
        const data = {
            description: "",
            quantity: "",
            unit_price: "",
            amount: ""
        };
        initRow([...rows, data]);
    };
    const  street_address=state?.address ? `${state?.address?.house_no ? `${state?.address?.house_no} , ` : " "}${state?.address?.city ? `${state?.address?.city} , ` : " "}${state?.address?.postal_code ? `${state?.address?.postal_code } , ` :  ""}${state?.address?.state ? `${state?.address?.state} , ` : " "}${state?.address?.country ? `${state?.address?.country} , ` : " "}${capitalize(state?.address?.address_type ? `${state?.address?.address_type} , ` : "")}` : "N/A"


    const getCurrency = async () => {
        try {
            let apiRes = await henceforthApi.Currency.get()
            setcurrency(apiRes?.data[0])
        } catch (error) {

        }
    }
    // console.log(currency, "currrr");
    const VAT = Number(form.getFieldValue('quantity')) * Number(form.getFieldValue('unit_price') * 5 / 100)
    const TOTAL_AMOUNT = Number(form.getFieldValue('quantity')) * Number(form.getFieldValue('unit_price'))
    useEffect(() => {
        getCurrency()
    }, [])
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Order.getQuotation(router.query._id)
            setState(apiRes)
            form1.setFieldValue("term", apiRes?.terms_and_conditions?.description)
        } catch (error) {
            // console.log(error);

        }
    }
    const onChange: DatePickerProps['onChange'] = (date, dateString) => {
        // console.log(dateString);
        setValidityDate(dateString)
    };
    const getArray = (values: any) => {
        // console.log(values);

        const x = [] as any
        let total_amount = 0, grand_total = 0
        Array.isArray(values.quantity) && values.quantity.forEach((d: any, index: number) => {
            const amount = +values.unit_price[index] * (+values.quantity[index])
            // const total =amount
            const grand = amount + (amount * 5 / 100)
            const vat= amount *5/100
            const v = {
                amount: amount,
                description: values.description[index],
                quantity: +values.quantity[index],
                unit_price: values.unit_price[index],
                total_amount: amount,
                grand_total: grand,
                vat: vat,
                unit_price_currency: currency._id,
                amount_currency: currency._id,
                total_amount_currency: currency._id,
                vat_currency: currency._id,
                grand_total_currency: currency._id
            }
            // console.log(amount);

            if (amount && grand) {
                total_amount += amount
                grand_total += grand
            }
            x[index] = v
        })
        return { x, total_amount, grand_total }
    }
    const onchangeEdit = async (values: any) => {
        debugger
        // console.log(values, "valuessssssss");
        try {
            if (!values.term) return Toast.warn("Please Enter Description")
            setLoading({
                ...loading,
                loading2: true
            })
            let id = state?.terms_and_conditions?._id
            // console.log(id);
            const data = {
                description: values?.term
            }
            let apiRes = await henceforthApi.Order.editTerm(id, data)
            Toast.success(apiRes.message)
            initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setIsModalOpen(false)
            setLoading({
                ...loading,
                loading2: false
            })
        }
    }
    // console.log(state, "state");
    const create = async (values: any) => {
        if (!values.commisson) return Toast.warn("Please Enter Commission")
        if (!values.work_duration) return Toast.warn("Please Enter work duration")
        if (!validityDate) return Toast.warn("Please Select Date")
        if (!values.description) return Toast.warn("Please add scope of work")
        setLoading({
            ...loading,
            loading1: true
        })
        const { x } = getArray(values)
        const info = {
            order_id: router.query._id,
            scope_of_work: x,
            commisson: +values.commisson,
            quotation_validity: dayjs(validityDate).valueOf(),
            work_duration: values.work_duration,
        }
        try {
            let apiRes = await henceforthApi.Quotation.create(info)
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading({
                ...loading,
                loading1: false
            })

        }
    }

    const tableRowRemove = (index: number) => {
        const dataRow = [...rows];
        dataRow.splice(index, 1);
        initRow(dataRow);
    };
    useEffect(() => {
        initialise()

    }, [])
    const totalAmount = () => {
        const y = form.getFieldsValue()
        const { total_amount, grand_total } = getArray(y)
        console.log(total_amount ,"amountTotal");
        
        
        return {
            total_amount: total_amount || 0, grand_total: grand_total || 0 , vat:total_amount*5/100 , all_total :total_amount + total_amount*5/100
        }

    }

    return (
        <>
            <section className='container quotation'>
                <Row justify={'center'}>
                    <Col span={14}>
                        <div className="logo m-0">
                            <Image src={Header} alt='img' style={{ objectFit: 'fill' }} className='w-100' />
                        </div>
                        <Typography.Title level={3} className='fw-700 text-center my-4' underline>Quotation</Typography.Title>
                        <div className='table-responsive'>
                            <table className="table table-bordered">
                                {/* <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">First</th>
                                <th scope="col">Last</th>
                                <th scope="col">Handle</th>
                            </tr>
                        </thead> */}
                                <tbody>
                                    <tr>
                                        <td width={'50%'}>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='text-gray'>Client:</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>{state?.client || 'N/A'}</Typography.Paragraph>
                                            </div>
                                        </td>
                                        <td width={'50%'}>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='text-gray'>QTN REF No.:</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>{state?.quotation_ref_no || 'N/A'}</Typography.Paragraph>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width={'50%'}>
                                            <div className='flex-center gap-3 align-items-start'>
                                                <Typography.Paragraph className='text-gray'>Address:</Typography.Paragraph>
                                                <Tooltip title={street_address}>
                                                    <Typography.Paragraph className='fw-600' title={street_address}>{street_address?.slice(0, 30) + '...'}</Typography.Paragraph>
                                                </Tooltip>
                                            </div>
                                        </td>
                                        <td width={'50%'}>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='text-gray'>Date:</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>
                                                    {dayjs(state?.date).format("DD/MM/YYYY")}</Typography.Paragraph>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td width={'50%'}>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='text-gray'>Mobile No:</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>{state?.phone_no || 'N/A'}</Typography.Paragraph>
                                            </div>
                                        </td>
                                        <td width={'50%'}>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='text-gray'>Email::</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>{state?.email || 'N/A'}</Typography.Paragraph>
                                            </div>
                                        </td>
                                    </tr>
                                    {/* <tr>
                                        <td colSpan={2}>
                                            <div className='d-flex gap-2'>
                                                <Typography.Paragraph className='text-gray'>Subject:</Typography.Paragraph>
                                                <Typography.Paragraph className='fw-600'>{state?.subject || 'N/A'}</Typography.Paragraph>
                                            </div>
                                        </td>
                                    </tr> */}
                                </tbody>
                            </table>
                        </div>
                        <div className='flex-center'>
                            <Typography.Title level={4} className='fw-700 mt-2 mb-3'>Scope Of Work</Typography.Title>
                            <Button onClick={addRowTable} icon={<HenceforthIcons.Add />} className='border-0'></Button>
                        </div>
                        <Form layout='vertical' size='large' onFinish={create} form={form} className='mb-3'>
                            <div className='table-responsive'>
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">Sr.No.</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Qty</th>
                                            <th scope="col">Unit Price(AED)</th>
                                            <th scope="col">Amount(AED)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {rows.map((item: any, index: number) => {
                                            const { description, quantity, unit_price, amount } = item;
                                            return (
                                                <>
                                                    <tr key={index}>
                                                        <td>{index + 1}</td>
                                                        <td>
                                                            <Form.Item name={["description", index]} rules={[{ required: true, message: 'Enter your Description' }]}>
                                                                <Input name='description' placeholder='Enter your Description' />
                                                            </Form.Item>
                                                        </td>
                                                        <td>
                                                            <Form.Item name={["quantity", index]} rules={[{ required: true, message: 'Enter your quantity' }]}>
                                                                <Input placeholder='Enter your Quantity' onKeyPress={(e) => {
                                                                    if (!/[0-9]/.test(e.key)) {
                                                                        e.preventDefault();
                                                                    }
                                                                }} />
                                                            </Form.Item>
                                                        </td>
                                                        <td>
                                                            <Form.Item name={["unit_price", index]} rules={[{ required: true, message: 'Enter your unit price' }]}>
                                                                <Input placeholder='Enter your  unit price' onKeyPress={(e) => {
                                                                    if (!/[0-9]/.test(e.key)) {
                                                                        e.preventDefault();
                                                                    }
                                                                }} />
                                                            </Form.Item>
                                                        </td>
                                                        <td className='d-flex gap-2 align-items-baseline'>
                                                            <Form.Item shouldUpdate>
                                                                {({ getFieldValue }) => {

                                                                    return <Input name='amount' value={Array.isArray(getFieldValue("unit_price")) && Array.isArray(getFieldValue("quantity")) && getFieldValue("quantity")[index] && getFieldValue("unit_price")[index] ? +getFieldValue("quantity")[index] * +getFieldValue("unit_price")[index] : 0} placeholder='Enter your amount' disabled onKeyPress={(e) => {
                                                                        if (!/[0-9]/.test(e.key)) {
                                                                            e.preventDefault();
                                                                        }
                                                                    }} />

                                                                }}
                                                            </Form.Item>
                                                            <Button className='border-0' onClick={() => tableRowRemove(index)} danger><DeleteOutlined /></Button>
                                                        </td>
                                                        {/* <td>
                                                    </td> */}
                                                    </tr>
                                                </>
                                            )
                                        })}
                                        {rows.length ?
                                            <>
                                                <tr>
                                                    <td colSpan={4} className='text-end text-gray '>Total Amount</td>
                                                    <td>
                                                        <Form.Item shouldUpdate>
                                                            {({ getFieldValue }) => {
                                                                console.log(getFieldValue('unit_price'),"unitPrice");
                                                                
                                                                return getFieldValue('quantity')?.length && getFieldValue('unit_price')?.length ? totalAmount().total_amount : 0
                                                            }}
                                                        </Form.Item>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td colSpan={4} className='text-end text-gray'>VAT</td>
                                                    <td><Form.Item shouldUpdate>
                                                        {({ getFieldValue }) => {
                                                            return getFieldValue('quantity')?.length && getFieldValue('unit_price')?.length ? totalAmount().vat : 0
                                                        }}
                                                    </Form.Item></td>

                                                </tr>
                                                <tr>
                                                    <td colSpan={4} className='text-end text-gray fw-700'>Grand Total(Amount+VAT)</td>
                                                    <td className='fw-700'>

                                                        <Form.Item shouldUpdate>
                                                            {({ getFieldValue }) => {
                                                                return getFieldValue('quantity')?.length && getFieldValue('unit_price')?.length ?  totalAmount().all_total : 0
                                                            }}
                                                        </Form.Item>
                                                    </td>
                                                </tr>
                                            </> : ""}
                                    </tbody>
                                </table>
                            </div>

                            <Form.Item label='Commission(%)' name="commisson" >
                                <Input placeholder='Enter Your commisson' onKeyPress={(e) => {
                                    if (!/[0-9]/.test(e.key)) {
                                        e.preventDefault();
                                    }
                                }} />
                            </Form.Item>
                            <div className='d-flex align-items-center gap-2 mb-2'>
                                <Typography.Title level={4} className='fw-700'>Terms & Conditions</Typography.Title>
                                <Button className='border-0' onClick={showModal} icon={<HenceforthIcons.PencileIcon />}></Button>
                            </div>
                            {/* <ul> */}
                            <p className='text-break' dangerouslySetInnerHTML={{ __html: state?.terms_and_conditions?.description as any }} />

                            {/* </ul> */}

                            <div>
                                <Typography.Title level={4} className='fw-700 mt-3 mb-2'>Quotation Validity</Typography.Title>
                                <DatePicker className='w-100' onChange={onChange} disabledDate={henceforthValidations.disabledDate} />
                            </div>
                            <div>
                                <Typography.Title level={4} className='fw-700 mt-3 mb-2'>Work Duration</Typography.Title>
                                <Form.Item name="work_duration" rules={
                                    [
                                        () => ({
                                            validator(_, value) {
                                                if (!value) {
                                                    return Promise.reject("Please Enter Value");
                                                }
                                                else if (value <= 0) {
                                                    return Promise.reject("Please enter your value in greater than 1")
                                                }
                                                else {
                                                    return Promise.resolve();
                                                }
                                            },
                                        }),
                                    ]
                                }>
                                    <Input placeholder='Enter your Work Duration' onKeyPress={(e) => {
                                        if (!/\b([0-9]|[1-9][0-9])\b/.test(e.key)) {
                                            e.preventDefault();
                                        }
                                    }} />
                                </Form.Item>
                            </div>
                            <div className='my-3'>
                                <Button size='large' htmlType="submit" type='primary' loading={loading.loading1} block>Update</Button>
                            </div>
                            <div className="logo m-0">
                                <Image src={Footer} alt='img' style={{ objectFit: 'fill' }} className='w-100' />
                            </div>
                        </Form>
                    </Col>
                </Row>
                <Modal title="Basic Modal" footer={false} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <Form
                        layout='vertical'
                        size='large'
                        form={form1}
                        onFinish={onchangeEdit}
                    >
                        <Form.Item name="term" rules={[() => ({
                            validator(_, value) {
                                // console.log(value);

                                const remove_space = value.replace(/\s/g, "")
                                if (value) {
                                    if (value === '<p><br></p>' || remove_space === '<p></p>') return Toast.warn('Please enter description')
                                }
                                return Promise.resolve();
                            }

                        })]} label="Description">
                            <ReactQuill theme="snow" placeholder="Write description here..." />
                        </Form.Item>
                        <Button block type='primary' htmlType='submit' className='mt-3' loading={loading.loading2} >Save</Button>
                    </Form>
                </Modal>
            </section>
        </>
    )
}

export default Quotation