import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Select, DatePicker, Modal, Form, DatePickerProps } from 'antd';
import Link from 'next/link';
import { UploadOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import placeholder from '@/assets/images/placeholder.png'
import dayjs, { Dayjs } from 'dayjs';
import SearchPage from '@/components/common/SearchInput';
import ModalAssign from '@/components/common/ModalAssign';
import { ChatContext } from '@/context/chatProvider';
import { capitalize } from 'lodash';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const OrdersRequest: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const { socketHitType ,setSocketHitType } = React.useContext(ChatContext)
   
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [serviceId,setServiceId]=useState('')
    const [orderId, setOrderId] = useState('')
    const [assignlist, setAssignList] = useState({
        data: []
    })
    const [service, setService] = useState({
        data: [],
    })
    const [subService, setSub_service] = useState({
        sub_services: []
    } as any)
    const [isModalOpenAssign, setIsModalOpenAssign] = useState(false);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [vendor, setVendor] = useState<any>('')
    const [limit, setLimit] = useState(10)
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const handlePagination = (page: number, pageSize: number) => {
        setLimit(pageSize)
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const onChangeAssign = async (vendor_id: any, order_id: any) => {
        try {
            let apiRes = await henceforthApi.Order.assignVendor(`vendor_id=${vendor_id}&order_id=${order_id}`)
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        }
    }
    const showModal = (_id: any,sub_service:any) => {
        setOrderId(_id)
        setIsModalOpen(true);
    };
    const handleOk = () => {
        setIsModalOpen(false);
    };
console.log(state ,"order-request");

    const handleCancel = () => {
        setIsModalOpen(false);
        router.push({pathname:'/order-request/page/1',query:''})
    };
    const dataSource = state.data.map((res: any, index: number) => {
        const  street_address=res?.address ? `${res?.address?.house_no ? `${res?.address?.house_no} , ` : " "}${res?.address?.city ? `${res?.address?.city} , ` : " "}${res?.address?.postal_code ? `${res?.address?.postal_code } , ` :  ""}${res?.address?.state ? `${res?.address?.state} , ` : " "}${res?.address?.country ? `${res?.address?.country} , ` : " "}${capitalize(res?.address?.address_type ? `${res?.address?.address_type} , ` : "")}` : "N/A"


        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <div className="user-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.user_id?.image) || placeholder.src} alt='img' />
                </div>
                <Typography.Text>{res?.user_id?.name?.split("_")?.join(" ") || 'N/A'}</Typography.Text>
            </div>,
            orderid: res.order_id || 'N/A',
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.sub_service_id?.image) || placeholder.src} alt='img' />
                </div>
                <div>
                    <Typography.Text className='text-gray fw-700'>{res?.service_id?.name || 'N/A'}</Typography.Text><br />
                    <Typography.Paragraph className='mb-0'>{res?.sub_service_id?.name || 'N/A'}</Typography.Paragraph>
                </div>
            </div>,
            city: res?.address?.city || 'N/A',
            area: <span title={street_address}>{street_address?.slice(0, 23) || 'N/A'}</span>,
            date: dayjs(res.time).format('ddd, MMM DD - hh:mm A'),
            clickspertPoint:res?.points_used_amount ? `AED ${res?.points_used_amount}` : "N/A",
            wallet: res?.wallets_used_amount ? `AED ${res?.wallets_used_amount}` : "N/A",
            recurring: res?.recurring || 'N/A',
            promocode: res?.promo_id?.name || 'N/A',
            amount: <span>{res?.total_amount ? `AED ${res?.total_amount?.toFixed(2)}` : "N/A"}</span>,
            action:
                <span>
                    {(res?.is_quotation_based && res?.is_accepted ) ? <Button size='large' type='primary' onClick={() => router.push(`/order-request/${res?._id}/quotation`)}>Send Quotation</Button> : <Button size='large' type='primary' onClick={() => {showModal(res._id,res.sub_service_id._id) ;setTimeout(() => {
                        initialiseAssign(res.sub_service_id._id)
                    }, 100);}}>Assign Vendor</Button> }
                    <Link href={`/order-request/${res._id}/view`}><Button type='primary' className='bg-transparent' shape='circle'><HenceforthIcons.ViewTwo /></Button></Link>
                </span>
        }
    })
    const initialise = async () => {
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            } if (query.start_date) {
                urlSearchParam.set('start_date', String(router.query.start_date).toUpperCase() as string)
            } if (query.end_date) {
                urlSearchParam.set('end_date', String(router.query.end_date).toUpperCase() as string)
            }
            // debugger
            let apiRes = await henceforthApi.Order.orderRequest(urlSearchParam.toString(), limit)
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
            // setSocketHitType({
            //     order_request:""
            // })
            // socketHitType?.order_request
        }
    }
    const handleCancelAssign = () => {
        setIsModalOpenAssign(false);
    };
    const initialiseAssign = async (id:any) => {
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            }
           
            let apiRes = await henceforthApi.Order.listvendor(id , urlSearchParam?.toString() )
            setAssignList(apiRes)
            setServiceId(id)
        } catch (error) {

        }
    }
    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/order-request/page/${router.query.pagination}`, query: { service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/order-request/page/${router.query.pagination}`, query: { service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }

    const handleSelect = (_id: any) => {
        try {
            let sub_service = service?.data.find((res: any) => res._id == _id)
            setSub_service(sub_service)
            handleChange(null, _id)
        } catch (error) {
            Toast.error(error)
        }
    }

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }
    const onDateSelect: DatePickerProps['onChange'] = (dateString) => {
        if (router.query.end_date) {
            router.push({ pathname: `/order-request/page/${router.query.pagination}`, query: { start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } })
        } else {
            router.push({ pathname: `/order-request/page/${router.query.pagination}`, query: { start_date: dayjs(dateString).valueOf() } })
        }
    };
    const onDate = (dateString: any) => {
        router.push({ pathname: `/order-request/page/${router.query.pagination}`, query: { start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } }, undefined, { shallow: true })
    }
    const handlechange = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Vendor.getById(_id)
            setVendor(apiRes)
            setIsModalOpen(false)
        } catch (error) {

        }
    }
//     const r = /\d+/;
// const s = "efeff100";
// (window as any).alert (s.match(r))
    const assignModal = () => {
        setIsModalOpenAssign(true)
    }
    useEffect(() => {
        serviceInitialse()
    }, [])
  
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.service_id,
    router.query.sub_service_id, router.query.search, router.query.type, router.query.start_date, router.query.end_date , socketHitType])
    useEffect(() => {
        // if(assignlist?.data?.length){
            initialiseAssign(serviceId)
        // }
    }, [router.query.search])
    return (
        <Fragment>
            <Head>
                <title>Orders</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Order requests</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row  gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Order Requests</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[5, 15]} className='my-4'>
                                {/* Search  */}
                                <Col span={24}>
                                    <SearchPage placeholder="Search" pathname="/order-request/page/1" />
                                    {/* <Search size="large" placeholder="Search..." enterButton /> */}
                                </Col>
                                <Col span={24} md={12}>
                                    <Select
                                        showSearch
                                        size='large'
                                        className='w-100'
                                        placeholder="Select service"
                                        optionFilterProp="children"
                                        allowClear
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                        filterSort={(optionA, optionB) =>
                                            (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                        }
                                        onChange={handleSelect}
                                        options={service?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}

                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <Select
                                        size='large'
                                        showSearch
                                        className='w-100 bg-transparent'
                                        placeholder="Select sub service"
                                        optionFilterProp="children"
                                        allowClear
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        onChange={(e: any) => handleChange(e, String(router.query.service_id))}
                                        options={subService?.sub_services?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDateSelect}
                                        placeholder='From' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDate}
                                        placeholder='To' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                            </Row>

                            <div >
                                <Table dataSource={dataSource} columns={ColumnsType.orderRequestColumns} pagination={false} scroll={{ x: '100%' }} />
                            </div>

                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                    <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                        <div className='text-center'>
                            <Typography.Title level={3} className='fw-700  mt-2'>Assign Vendor</Typography.Title>
                            {/* <Form size='large' layout='vertical'> */}

                                <Row gutter={[12, 12]}>
                                    <Col span={24}>
                                        <Form.Item>
                                            <SearchPage placeholder="Search" pathname={`/order-request/page/${router.query.pagination}`} />
                                            {/* <Input placeholder="Search" className='border-0' size='large' prefix={<SearchOutlined />} /> */}
                                        </Form.Item>
                                    </Col>
                                    {/* <Col span={24} md={12}>
                                        <Form.Item className='mb-0'>
                                            <Select placeholder='Select services' className='text-start'>
                                                <Select.Option>a</Select.Option>
                                                <Select.Option>b</Select.Option>
                                                <Select.Option>c</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col span={24} md={12}>
                                        <Form.Item className='mb-0'>
                                            <Select placeholder='Select subservice' className='text-start'>
                                                <Select.Option>a</Select.Option>
                                                <Select.Option>b</Select.Option>
                                                <Select.Option>c</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </Col> */}
                                    {assignlist?.data.map((res: any, index: number) => {
                                        return (
                                            <Col span={24} md={12} key={index}>
                                                <ul className='modal-list'>
                                                    <li>
                                                     <Button className='h-100 border-0' size='large'>   <div className='user-detail d-inline-flex gap-2 align-items-center'>
                                                            <div className="user-detail-img" role='button'>
                                                                <img src={henceforthApi.FILES.imageSmall(res.image) || placeholder.src} alt='img' />
                                                            </div>
                                                            <Typography.Text role='button' onClick={() => {
                                                                handlechange(res._id);
                                                                setTimeout(() => {
                                                                    assignModal()
                                                                }, 1000);
                                                            }}>{res.name || 'N/A'}</Typography.Text>
                                                        </div></Button>
                                                    </li>

                                                </ul>
                                            </Col>
                                        )
                                    })}
                                </Row>
                            {/* </Form> */}
                        </div>
                    </Modal>
                    <ModalAssign isModalOpenAssign={isModalOpenAssign} setIsModalOpenAssign={setIsModalOpenAssign} handleCancelAssign={handleCancelAssign} vendor={vendor} orderId={orderId} initialise={initialise} />

                    {/* <ModalVendor isModalOpen={isModalOpen} onOk={handleOk} onCancel={handleCancel} assignlist={assignlist}/> */}
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Order Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Order.orderExport(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                User_Name:item?.user_id?.name ?? 'N/A',
                                order_id:item?.order_id?.replace("#" , " ") || "N/A",
                                date_time:dayjs(item?.time)?.format("DD MMM YYYY") ?? 'N/A',
                                recurring:item?.recurring ?? 'N/A',
                                promo_code:item?.promo_id?.name ?? 'N/A',
                                amount:item?.total_amount?.toFixed(2) ?? "N/A",
                                city:item?.address?.city?.split(",")?.join(" ") ?? "N/A",
                                area:item?.address?.street_address?.split(",")?.join(" ") ?? "N/A",
                                Service:item?.service_id?.name ?? "N/A",
                                subService:item?.sub_service_id?.name ?? "N/A"
                            }
                          })
                        downloadCSV("Order request", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

OrdersRequest.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default OrdersRequest
