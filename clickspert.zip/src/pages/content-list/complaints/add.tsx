import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Tabs, Typography, Select, Form } from 'antd';
import Link from 'next/link';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import placeholder from '@/assets/images/placeholder.png'
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import SearchPage from '@/components/common/SearchInput';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
let usersId = [] as any
const AddComplaint: Page = () => {
    const [form] = Form?.useForm()
    const ReactQuill = dynamic(import('react-quill'), { ssr: false })
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const [user, setUser] = React.useState({
        data: [] as any,
        count: 0
    })
    const [showUserList, setShowUserList] = useState(false)
    const [complaintTypeList, setComplaintTypeList] = useState({
        data: [] as any,
        count: 0
    })
    const [userOrderlist, setUserOrderList] = useState({
        data: [] as any,
        count: 0
    })
    const [selectedUser, setSelectedUser] = React.useState(
        [] as any
    )
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const getComplaintTypeList = async () => {
        try {
            const apiRes = await henceforthApi.Complaint.complaintType()
            setComplaintTypeList(apiRes)
            console.log(apiRes, "points");

        } catch (error) {

        }
    }

    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Complaint.userlist(urlSearchParam.toString())
            setUser(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    const handleChange = async () => {
        console.log(selectedUser);
        
        try {
            const apiRes = await henceforthApi.User.order(selectedUser[0]?._id, "COMPLETED")
            setUserOrderList(apiRes)
        } catch (error) {

        }
    }
    const handleDelete = (id:string ,index:number) => {
        const ind=selectedUser.findIndex((res:any)=>res?._id == id)
      const data=  selectedUser?.splice(ind ,1)
        setSelectedUser([...selectedUser])
        setUser({
            data:[...user.data,...data],
            count:user.count+1
        })
        console.log(user.data);
        console.log(selectedUser);
        
    }
    const handleUserChange = async(res: any, index: number) => {
        if(selectedUser?.length == 1){
          return Toast.warn("You can complaint only 1 user ")
        }
        else{
            setSelectedUser([...selectedUser, { image: res?.image, _id: res?._id, name: res?.name }])
            const apiRes = await henceforthApi.User.order(res?._id, "COMPLETED")
            setUserOrderList(apiRes)
            user.data?.splice(index, 1)
        }
        // handleChange()
        console.log(selectedUser);

    }
    const handleSubmit = async (values: any) => {
        if(!selectedUser?.length){
            Toast.warn("Please select User")
        }
        const data={
            ...values,
            user_id:selectedUser[0]?._id
        }
        try {
            setLoading(true)
            const apiRes = await henceforthApi.Complaint.add(data)
            Toast.success(apiRes?.message)
            router.replace(`/content-list/complaints/page/1`)
        } catch (error) {

        }
        finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search, router.query.type])

    React.useEffect(() => {
        getComplaintTypeList()
    }, [])


    return (
        <Fragment>
            <Head>
                <title>Feedback</title>
                <meta name="description" content="Users" />
            </Head>
            <section className='add-promo-code'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={14}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'><Link href={'/content-list/complaints/page/1'} className='text-decoration-none'>Feedbacks</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Add Feedback</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='fw-700 mb-4'>Add Feedback</Typography.Title>
                            </div>
                            <Form
                                layout='vertical'
                                size='large'
                                onFinish={handleSubmit}
                                form={form}
                            >
                                <Row gutter={[15, 0]}>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'User'}
                                            name="user_id"
                                            // rules={[{ required: true, message: 'Please select user name', whitespace: true }]}
                                        >
                                            <Select
                                                open={false}
                                                showSearch
                                                placeholder="Select user"
                                                allowClear
                                                onClick={() => setShowUserList(showUserList == true ? false : true)}
                                                className='border-0'
                                                // options={user?.data?.map((item: any) => {
                                                //     return <ul>
                                                //         <li>
                                                //             <div>
                                                //                 <img src="ui8i87o9o9oo8" alt='image' />
                                                //                 <span>{item?.name}</span>
                                                //             </div>
                                                //         </li>
                                                //     </ul>
                                                //     // { label: item?.name ?? "N/A", value: item?._id }
                                                // })}
                                                onChange={handleChange}
                                            />
                                            {showUserList == true ? <div className=' mt-4 mb-4'>
                                                {selectedUser?.map((item: any, index: number) => {
                                                    return (<span className='d-flex gap-2 align-items-center mb-3' key={index}>  <img src={henceforthApi.FILES.imageSmall(item?.image) || placeholder.src} height={50} className="rounded-pill " width={50} alt='image' />
                                                        <span>{item?.name}<span onClick={()=>handleDelete(item?._id ,index)}><HenceforthIcons.CrossIcon /></span></span></span>)
                                                })}
                                                <div className='mb-5'>
                                                <SearchPage placeholder="Search here ..." />
 
                                                </div>
                                                {user?.data?.map((item: any, index: number) => {
                                                    return <div key={item?._id} className='mt-2'>
                                                        <ul>
                                                            <li onClick={() => handleUserChange(item, index)}>
                                                                <div className='d-flex gap-2 align-items-center mb-3'>
                                                                    <img src={henceforthApi.FILES.imageSmall(item?.image) || placeholder.src} height={50} className="rounded-pill" width={50} alt='image' />
                                                                    <span>{item?.name}</span>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                })}</div> : ""}


                                            {/* </Select> */}
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'Order'}
                                            name="order_id"
                                            rules={[{ required: true, message: 'Please select order name', whitespace: true }]}
                                        >
                                            <Select
                                                placeholder="Select order"
                                                allowClear
                                                className='border-0'
                                                options={userOrderlist?.data?.map((item: any) => { return { label: item?.service_id?.name ?? "N/A", value: item?._id } })}
                                                // disabled={!form.getFieldValue("user_id")}
                                            />

                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'Title'}
                                            name="title_id"
                                            rules={[{ required: true, message: 'Please select title', whitespace: true }]}
                                        >
                                            <Select
                                                placeholder="Select title"
                                                allowClear
                                                className='border-0'
                                                options={complaintTypeList?.data?.map((item: any) => { return { label: item?.title ?? "N/A", value: item?._id } })}
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        {/* Description  */}
                                        <Form.Item name="description" hasFeedback label="Description" rules={[{ required: true, message: 'Please enter description', whitespace: true }]}>
                                            <ReactQuill theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Button htmlType='submit' type='primary' loading={loading}>Add Complaint</Button>
                                    </Col>

                                </Row>
                            </Form>
                        </Card>
                    </Col>
                </Row>
                {/* <ExportFile open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                    }
                }} /> */}

            </section>
        </Fragment>
    )
}

AddComplaint.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default AddComplaint
