import MainLayout from '@/layouts/MainLayout';
import { Avatar, Badge, Breadcrumb, Button, Card, Col, Divider, Dropdown, Form, Input, Modal, Row, Tooltip, Typography } from 'antd';
import Link from 'next/link';
import React, { Fragment, ReactNode, useState } from 'react'
import HenceforthIcons from '@/components/HenceforthIcons';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import dayjs from 'dayjs';
import user from "@/assets/images/placeholder.png"
import henceofrthEnums from '@/utils/henceofrthEnums';
import { GlobalContext } from '@/context/Provider';

const ViewComplaints = () => {
    const router = useRouter();
    const [form] = Form.useForm()
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [details, setDetails] = useState() as any
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const getComplaintDetails = async () => {
        try {
            const apiRes = await henceforthApi.Complaint.detail(router.query._id as string)
            setDetails(apiRes)
            console.log(apiRes, "points");
        } catch (error) {

        }
    }
    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const createReply = async (values: any) => {
        const data = {
            ...values,
            _id: router.query._id
        }
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Complaint.reply(data)
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            form.resetFields()
            setIsModalOpen(false)

        }
    }
    const handleStatus = async (id: string, status: string) => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Complaint.editStatus(id, status)
            Toast.success(apiRes.message)
            details.status = apiRes?.status
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }
    const capitalise = (status: string) => {
        const data = status?.slice(0, 1)?.charAt(0)?.toUpperCase() + status?.slice(1, 50)?.toLowerCase()
        return <span>{data}</span>
    }
    const StatusItem = () => {
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Complaint.resolved}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Complaint.resolved} />,
                        onClick: () => handleStatus(String(router.query._id), henceofrthEnums.Complaint.resolved),
                        disabled: details?.status == "RESOLVED" ? true : false
                    },
                    {
                        key: '12',
                        label: <Divider style={{ height: 2 }} plain className='m-0'></Divider>
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Complaint.open}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Complaint.open} />,
                        onClick: () => handleStatus(String(router.query._id), henceofrthEnums.Complaint.open),
                        disabled: details?.status == "OPEN" ? true : false
                    }
                ],
            }

        ]
    }
    React.useEffect(() => {
        getComplaintDetails()
    }, [])
    return (
        <Fragment>
            <Row gutter={[20, 20]} className="mb-4">
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='mb-4'>
                            <Breadcrumb separator=">">
                                <Breadcrumb.Item>Management</Breadcrumb.Item>
                                <Breadcrumb.Item><Link href="/user/page/1" className='text-decoration-none'>Feedbacks</Link></Breadcrumb.Item>
                                <Breadcrumb.Item className='text-decoration-none'>Feedback details</Breadcrumb.Item>
                            </Breadcrumb>
                        </div>
                        {/* Title  */}
                        <div className='flex-center mb-4'>
                            <Typography.Title level={3} className='fw-700'>Feedback Details</Typography.Title>
                            <Button type='primary' size='large' onClick={showModal}>Reply</Button>
                        </div>

                        <div className='order-detail-img'>
                            <img src={henceforthApi.FILES.imageOriginal(details?.sub_service?.image, user?.src)} alt='img' />
                        </div>
                        <div className='flex-center mt-3 mb-5'>
                            <div>
                                <Typography.Title level={4} className='mb-1 fw-bold'>{details?.sub_service?.name ?? "N/A"}</Typography.Title>
                                <p className='m-0'><span className='text-gray'>Order Id:</span><span className='fw-600'> {`${details?.unique_order_id}`}</span></p>
                            </div>
                            <div className='d-flex align-items-center '>
                                <div className={`upcoming ${details?.status == "OPEN" ?  'bg-theme' : 'bg-danger'}`}>
                                    {capitalise(details?.status) ?? "N/A"}
                                </div>
                                <Tooltip title="Actions">
                                    <Dropdown menu={{ items: StatusItem() }} trigger={['click']} placement="bottomRight">
                                        <a onClick={(e) => e.preventDefault()}>
                                            <Button shape='circle' className='border-0' htmlType='button'><HenceforthIcons.More /></Button>
                                        </a>
                                    </Dropdown>
                                </Tooltip>
                            </div>
                        </div>
                        <Row gutter={[0, 20]}>
                            <Col span={24}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Date & Time</Typography.Title>
                                <p className='text-gray'>{dayjs(details?.created_at).format("ddd, MMM DD - hh:mm a")}</p>

                            </Col>
                            <Col span={24}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Feedback</Typography.Title>
                                <div className='mb-4'>
                                    <p className='text-gray mb-2'>Feedback type</p>
                                    <p className='fw-600'>{details?.title?.title ?? "N/A"}</p>
                                </div>
                                <div>
                                    <p className='text-gray mb-2'>Description</p>
                                    <p className='fw-600' dangerouslySetInnerHTML={{ __html: details?.description ?? "N/A" }}></p>
                                </div>
                            </Col>
                        </Row>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>User details</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-profile user-detail'>
                                    <img src={henceforthApi.FILES.imageOriginal(details?.user?.image, user?.src)} alt='img' />
                                </div>
                                <p className='m-0'>{details?.user?.name ?? "N/A"}</p>
                            </div>
                            <div>
                                <Button icon={<HenceforthIcons.Download />} onClick={() => router.push(`/orders/${details?.order_id}/user/invoice`)} type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                    Download Invoice
                                </Button>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Vendor details</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-detail d-flex align-items-center gap-2'>
                                    <Avatar
                                        style={{ backgroundColor: '#ECC263' }}
                                        size={{ xs: 60, sm: 60, md: 60, lg: 80, xl: 80, xxl: 80 }}
                                    >
                                        {details?.vendor?.name ? details?.vendor?.name?.slice(0, 1)?.toUpperCase() : "N/A"}
                                    </Avatar>
                                    <p className='m-0'>{details?.vendor?.name ?? "N/A"}</p>

                                </div>
                            </div>
                            <div>
                                <Button icon={<HenceforthIcons.Download />} type="primary" onClick={() => router.push(`/orders/${details?.order_id}/vendor/invoice`)} htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                    Download Invoice
                                </Button>

                            </div>
                        </div>

                    </Card>
                </Col>
            </Row>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Reply</Typography.Title>
                    <Form size='large' form={form} layout='vertical' onFinish={createReply} className='mt-2'>
                        <Form.Item name="reply_message" label='Reply' rules={[{ required: true, message: "Please Enter Reply" }]} >
                            <Input placeholder='Enter your Reply' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' block loading={loading}><span className='text-white'>Submit</span></Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}



ViewComplaints.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
export default ViewComplaints