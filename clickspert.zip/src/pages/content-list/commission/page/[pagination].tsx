import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { UploadOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import SearchPage from '@/components/common/SearchInput';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Commission: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { downloadCSV, Toast } = React.useContext(GlobalContext)
    const {socketHitType}=React.useContext(ChatContext)
    const [commission, setCommission] = useState({
        data: [] as any,
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const onSearch = (value: string) => {
        console.log("onserach value", value);
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }

    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const TableData = () => <Row gutter={[20, 20]} >

    </Row>

    const items: TabsProps['items'] = [
        {
            key: '',
            label: 'All',
            children: <TableData />,
        },
        {
            key: '1',
            label: 'Upcoming',
            children: <TableData />,
        },
        {
            key: '2',
            label: 'Completed',
            children: <TableData />,
        },
    ];

    const getPromoList = async () => {
        let query = router.query
        let urlSearchParam = new URLSearchParams()
        try {
            if (query.search) {
                urlSearchParam.set('search', String(query.search))
            }
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
              }

            const apiRes = await henceforthApi.Commission.getlist(urlSearchParam?.toString())
            setCommission(apiRes)
            console.log(apiRes, "points");

        } catch (error) {

        }
    }

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    const dataSource = commission?.data?.map((item: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                {/* <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar> */}
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageOriginal(item?.image, user?.src)} alt='img' />
                </div>
                <Typography.Text>{item?.name ?? "N/A"}</Typography.Text></div>,
            subservice: 'Normal cleaning, Deep cleaning, Furniture cleaning, Window cleaning',
            action: <Link href={`/content-list/commission/${item?._id}/view`}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })

    useEffect(() => {
        getPromoList()
    }, [router.query.type, router.query.pagination,socketHitType, router.query.end_date, router.query.search, router.query.start_date, router.query.service_id])

    return (
        <Fragment>
            <Head>
                <title>Commission</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Commission</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Commission</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[15, 15]} className='my-4'>
                                <Col span={24}>
                                    {/* Search  */}
                                    <SearchPage placeholder="Search..." />
                                </Col>
                                {/* Table  */}
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.commissionColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Commission.export(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                // name:item?.name,
                                // email:item?.email,
                                // phone_no:item?.phone_no,
                                // money_earned:item?.vendor_earning,
                                // city:item?.city,
                                service:item?.name,
                                // service:item?.sub_services.map((res:any ,index:number)=>res?.name)?.toString()?.split(",")?.join(" "),
                            }
                          })
                          if(!exportData?.length){
                            return Toast.warn("No records found")
                          }
                        downloadCSV("commission", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Commission.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Commission
