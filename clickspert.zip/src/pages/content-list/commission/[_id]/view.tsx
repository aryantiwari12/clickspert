import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space, Modal, Form } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import Serviceimg from '../../../../assets/images/banner.png'
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import Image from 'next/image';
import SearchPage from '@/components/common/SearchInput';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ViewCommission: Page = () => {
    const router = useRouter()
    const { downloadCSV, Toast } = React.useContext(GlobalContext)
  
    const [form] = Form.useForm()
    const [details, setDetails] = useState({
        data: [] as any,
        count: 0,
        service_name:""
    })
    const [id, setId] = useState({
        _id:"",
        sub_service:""
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const getCommissionDetail = async () => {
        let query = router.query
        let urlSearchParam = new URLSearchParams()
        try {
            if (query.search) {
                urlSearchParam.set('search', String(query.search))
            }
            const apiRes = await henceforthApi.Commission.detail(String(router.query._id), urlSearchParam?.toString())
            setDetails(apiRes)
            console.log(apiRes, "points");

        } catch (error) {

        }
    }
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const handleFinish = async (values: any) => {
        const data = {
            commission: Number(values.commission)
        }
        try {
            setLoading(true)
            const apiRes = await henceforthApi.Commission.editCommission(id?._id as string, data)
            Toast.success(apiRes?.message)
            const newData = details?.data?.findIndex((item: any) => item?._id == id?._id)
            details.data[newData].commission = apiRes?.commission
            setIsModalOpen(false)
        } catch (error) {

        }
        finally{
            setLoading(false)
        }
    }

  
    const dataSource = details?.data?.map((item: any, index: number) => {
        return {
            key: index + 1,
            subservice: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageOriginal(item?.image, user?.src)} alt='img' />
                </div>
                <Typography.Text>{item?.name ?? "N/A"}</Typography.Text></div>,
            commission:item?.is_quotation_based ? "Quotation Based" : item?.commission == 0 ? "N/A" : item?.commission + "%",
            action:
            !item?.is_quotation_based &&     <Button onClick={() => { showModal(); setId({_id:item?._id , sub_service:item?.name}); form.setFieldValue("commission", item?.commission) }} type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.PencileIcon /></Button>
        }
    })

    useEffect(() => {
        getCommissionDetail()
    }, [router.query.search])
    return (
        <Fragment>
            <Head>
                <title>Commission</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'><Link href={'/content-list/commission/page/1'} className='text-decoration-none'>Commission </Link></Breadcrumb.Item>
                                    <Breadcrumb.Item>{details?.service_name}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='m-0 fw-bold'>Cleaning</Typography.Title>
                            </div>
                            <Row gutter={[5, 15]} className='my-4'>
                                <Col span={24}>
                                    {/* Search  */}
                                    <div className=' d-flex gap-4 align-items-center'>
                                        <div className='w-100'>
                                            <SearchPage placeholder="Search..." />
                                        </div>
                                    </div>
                                </Col>
                            </Row>

                            {/* Table  */}
                            <Row className="mt-4">
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.viewCommissionColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                {/* <ExportFile open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                    }
                }} /> */}
                <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Commission for {id?.sub_service}</Typography.Title>
                        <Form size='large' form={form} layout='vertical' className='mt-2' onFinish={handleFinish}>
                            <Form.Item label='Commission(%)' name="commission" rules={[{ required: true, message: 'Please enter commission', whitespace: true }]} >
                                <Input placeholder='Commission' onKeyPress={(e: any) => {
                                    if (!/[0-9]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                                        e.preventDefault();
                                    }
                                }} className='border-0' />
                            </Form.Item>
                            <Form.Item className='mb-2 mt-4'>
                                <Button type='primary' loading={loading} htmlType='submit' block><span className='text-white'>Save Changes</span></Button>
                            </Form.Item>
                        </Form>
                    </div>
                </Modal>
            </section>
        </Fragment>
    )
}

ViewCommission.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default ViewCommission
