import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import Serviceimg from '../../../../assets/images/banner.png'
import Image from 'next/image';
import { ColumnsType } from 'antd/es/table';
import { Dayjs } from 'dayjs';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Commission: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const [show, setShow] = useState(true);
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const onSearch = (value: string) => {
        console.log("onserach value", value);
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }

    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const commissionColumns: ColumnsType<any> = [

        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 200
        },
        {
            title: 'Minimum Service Fee',
            dataIndex: 'minimum_service_fee',
            width: 300,
        },
        {
            title: 'Maximum Service Fee',
            dataIndex: 'maximum_service_fee',
            width: 300,
        },
        {
            title: 'Service',
            dataIndex: 'service',
            width: 300,
        },
        {
            title: 'Vat(%)',
            dataIndex: 'vat',
            width: 300,
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 80
        }
    ]

    const initialise = async () => {
        try {
            setLoading(true)
            let apiRes = await henceforthApi.serviceFee.listing()
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    const dataSource = state?.data.map((res: any, index: number) => {
        return {
            key: 1,
            minimum_service_fee: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <Typography.Text>{res?.minimum_service_fee ? `AED ${res?.minimum_service_fee}` :'N/A' }</Typography.Text></div>,
            maximum_service_fee:<Typography.Text>{res?.maximum_service_fee ? res?.maximum_service_fee :'N/A'  }</Typography.Text>,
            service:<Typography.Text>{res?.service ? `AED ${res?.service}` :"n/a" }</Typography.Text>,
            vat: "50",
            action: <Link href={'/content-list/commission/1/view'}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })
    useEffect(() => {
        initialise()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>Commission</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Service Fee</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Service Fee</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' onClick={() => router.replace('/content-list/service-fee/add')}>Add</Button>
                                </div>
                            </div>
                            <Row gutter={[15, 15]} className='my-4'>
                                {/* Table  */}
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={commissionColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Commission.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Commission
