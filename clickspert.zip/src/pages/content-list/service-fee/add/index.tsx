import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Typography, Form } from 'antd';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ServiceFee: Page = () => {
    const { Toast } = React.useContext(GlobalContext)
    const [form] = Form.useForm();
    const [state, setState] = React.useState("") as any
    const [feeId , setFeeId]=React.useState("")
    const [loading, setLoading] = React.useState(false)
    const router = useRouter()
    // const serviceFee = async () => {
    //     try {
    //         const apiRes = henceforthApi.Service.getServiceFee();
    //         form.setFieldsValue(apiRes)
    //         setState(apiRes)
    //     } catch (error) {

    //     }
    // }
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.detail()
            form.setFieldValue("minimum_service_fee",String(apiRes?.minimum_service_fee))
            form.setFieldValue("maximum_service_fee",String(apiRes?.maximum_service_fee))
            form.setFieldValue("service_fee",apiRes?.service_fee)
            setState(apiRes)
        } catch (error) {
            console.log(error);

        }
    }
    const Update = async (values: any) => {
        try {
            setLoading(true)
            const info = {
                minimum_service_fee: +values.minimum_service_fee,
                maximum_service_fee: +values.maximum_service_fee,
                service_fee: values.service_fee
            } as any
            let apiRes;
            if (state?._id) {
              info._id=state?._id
                apiRes = await henceforthApi.Service.editServiceFee(info)
            }
            else {
                apiRes = await henceforthApi.Service.addServiceFee(info)
            }
            Toast.success(apiRes.message)
            initialise()
            // form.resetFields()
            // router.back()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }

    }

    const onFinish = async (values: any) => {
        await Update(values)
    }
    React.useEffect(() => {
        // serviceFee()
        initialise()
    }, [])
    return (
        <Fragment>
            <Head>
                <title>Service Fee</title>
                <meta name="description" content="Users" />
            </Head>
            <section className='add-promo-code'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={14}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Service Fee</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='fw-700 mb-3'>Service Fee</Typography.Title>
                            </div>
                            <Form
                                layout='vertical'
                                size='large'
                                form={form}
                                onFinish={onFinish}
                            >
                                <Row gutter={[15, 0]}>
                                    <Col span={24}>
                                        <Form.Item
                                            name={"minimum_service_fee"}
                                            label='Minimum Service Fee (AED)'
                                            rules={[{ required: true, message: 'Please Enter Minimum Service Fee ', whitespace: true }]}
                                        >
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            name="maximum_service_fee"
                                            label='Maximum Service Fee (AED)'
                                            rules={[{ required: true, message: 'Please Enter Maximum Service Fee', whitespace: true }]}

                                        >
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            name="service_fee"
                                            label={'Service Fee (%)'}
                                            rules={[{ required: true, message: 'Please Enter Service Fee', whitespace: true }]}

                                        >
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Button htmlType='submit' type='primary' className='mt-4' loading={loading}>Save Changes</Button>
                                    </Col>

                                </Row>
                            </Form>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}
ServiceFee.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default ServiceFee
