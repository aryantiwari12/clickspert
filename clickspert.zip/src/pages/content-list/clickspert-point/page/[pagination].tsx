import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space, Modal, Form, Dropdown, Divider } from 'antd';
import user from "@/assets/images/placeholder.png"
import { UploadOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import henceofrthEnums from '@/utils/henceofrthEnums';
import SearchPage from '@/components/common/SearchInput';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const ClickspertPoint: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const [form] = Form.useForm()
    const router = useRouter()
    const { downloadCSV, currency, Toast } = React.useContext(GlobalContext)
    const {socketHitType}=React.useContext(ChatContext)
    const [id, setId] = useState({
        _id: "",
        type: "",
        service:""
    })
    const [amountPoints, setAmountPoints] = useState({
        _id: "",
        amount: ""
    })
    const [points, setPoints] = useState({
        data: [] as any,
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const getPointsList = async () => {
        let query = router.query
        let urlSearchParam = new URLSearchParams()
        try {
            if (query.search) {
                urlSearchParam.set('search', String(query.search))
            }
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
              }
            const apiRes = await henceforthApi.ClickspertPoints.getlist(urlSearchParam?.toString())
            const apiResponse = await henceforthApi.ClickspertPoints.get()
            setAmountPoints(apiResponse)
            setPoints(apiRes)
        } catch (error) {

        }
    }
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const handleStatus = async (id: string, status: string) => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.ClickspertPoints.editPointStatus(id, { status: status })
            Toast.success(apiRes.messgae)
            const newData = points?.data?.findIndex((item: any) => item?._id == id)
            points.data[newData] = apiRes?.data
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }
    const capitalise = (status: string) => {
        const data = status?.slice(0, 1)?.charAt(0)?.toUpperCase() + status?.slice(1, 50)?.toLowerCase()
        return <span>{data}</span>
    }
    const StatusItem = (res: any, index: any) => {
        console.log(res, "res");
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Points.inactive}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Points.inactive} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.Points.inactive),
                        disabled: res?.status == "INACTIVE" ? true : false
                    },
                    {
                        key: '12',
                        label: <Divider style={{ height: 2 }} plain className='m-0'></Divider>
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Points.active}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Points.active} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.Points.active),
                        disabled: res?.status == "ACTIVE" ? true : false
                    }
                ],
            }
        ]
    }
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    const dataSource = points?.data?.map((item: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageOriginal(item?.image, user?.src)} alt='img' />
                </div>
                <Typography.Text>{item?.name}</Typography.Text></div>,
            points: item?.points,
            status: <div className={`upcoming ${item?.status == "INACTIVE" ? 'bg-danger' : 'bg-theme'} `}>{capitalise(item?.status) ?? "N/A"}</div>,
            action: <div className='d-flex'>
                <Button className='bg-transparent' type='primary' shape='circle' onClick={() => { showModal(); setId({ _id: item?._id, type: "point" ,service:item?.name }); form?.setFieldValue("points", item?.points) }}><HenceforthIcons.PencileIcon /></Button>
                <li>
                    <Tooltip title="Actions">
                        <Dropdown menu={{ items: StatusItem(item, index) }} trigger={['click']} placement="bottomRight">
                            <a onClick={(e) => e.preventDefault()}>
                                <Button shape='circle' className='border-0' htmlType='button'><HenceforthIcons.More /></Button>
                            </a>
                        </Dropdown>
                    </Tooltip>
                </li>
            </div>
        }
    })

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }

    const handleSubmit = async (values: any) => {
        let data
        
        debugger
       
        try {
            let apiRes;
            setLoading(true)
            if (id?.type == "point") {
                apiRes = await henceforthApi.ClickspertPoints.editPointStatus(id?._id, { points: Number(values?.points) })
                Toast.success(apiRes?.messgae)
                const newData = points?.data?.findIndex((item: any) => item?._id == id._id)
                points.data[newData] = apiRes?.data
            }
            else {
                data = {
                    amount: Number(values?.amount),
                    currency: currency?._id
                }
                apiRes = await henceforthApi.ClickspertPoints.editAmountPoint(amountPoints?._id, data)
                setAmountPoints(apiRes?.data)
                Toast.success(apiRes?.message)
            }
            
            setIsModalOpen(false)
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        getPointsList()
    }, [router.query.type, router.query.pagination, socketHitType, router.query.end_date, router.query.search, router.query.start_date, router.query.service_id, router.query.sub_service_id, router.query.page])
    return (
        <Fragment>
            <Head>
                <title>Clickspert points</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Clickspert points</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <div className='d-flex gap-3'>
                                    <Typography.Title level={3} className='m-0 fw-bold'>Clickspert points</Typography.Title>
                                    <div className='border rounded-2 px-2 py-1 d-flex align-items-center gap-2'>
                                        <Typography.Text className='text-gray'>1 clickspert point = {`${amountPoints?.amount + ' AED' ?? "N/A"}`}</Typography.Text>
                                        <span onClick={() => { showModal(); setId({_id:"",type:"" ,service:""}); form.setFieldValue("amount", amountPoints?.amount) }}> <HenceforthIcons.PencileIcon /></span>
                                    </div>
                                </div>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[15, 15]} className='my-4'>
                                <Col span={24}>
                                    <SearchPage placeholder="Search..." />
                                </Col>

                                {/* Table  */}
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.clickspertColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.ClickspertPoints.export(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                service:item?.sub_service_id?.name,
                                clickspert_points:item?.points,
                                status:capitalise(item?.status),
                              

                            }
                          })
                        downloadCSV("clickspert points", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />
                <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit {id?.type == "point" ? "Points" : "Amount"} For {`${ id?.type == "point" ? id?.service : `Clickspert Points`}`}</Typography.Title>
                        <Form size='large' form={form} layout='vertical' className='mt-2' onFinish={handleSubmit}>
                            <Form.Item label={id?.type == "point" ? 'Points' : "Amount"} name={id?.type == "point" ? 'points' : "amount"} rules={[{ required: true, message: 'Please enter points', whitespace: true }]}>
                                <Input placeholder='Points' className='border-0' />
                            </Form.Item>
                            <Button type='primary' htmlType='submit' block loading={loading}><span className='h-dark'>Save Changes</span></Button>
                        </Form>
                    </div>
                </Modal>
            </section>
        </Fragment>
    )
}

ClickspertPoint.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default ClickspertPoint
