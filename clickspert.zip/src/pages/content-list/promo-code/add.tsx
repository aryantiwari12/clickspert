import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Typography, Select, DatePicker, Form, Checkbox, Tooltip, Tag, Space } from 'antd';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dayjs from 'dayjs';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { RangePickerProps } from 'antd/es/date-picker';
import { CheckboxChangeEvent } from 'antd/es/checkbox';
import Link from 'next/link';
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: React.ReactNode) => React.ReactNode;
};
let array = [] as any
const AddPromoCode: Page = ({ data }: any) => {
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const router = useRouter()
    const [form] = Form.useForm()
    const [handleDiscount, setHandleDiscount] = React.useState("")
    const [loading, setLoading] = React.useState(false)
    const [selectedService, setSelectedService] = React.useState({
        data:[] as any
    }) as any
    const [selectedDate, setSelectedDate] = React.useState<any>()
    const [service, setService] = React.useState({
        data: [],
    })
    const [subService, setSub_service] = React.useState({
        sub_services: []
    } as any)

    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }
    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/content-list/promo-code/add`, query: { ...router.query, service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/content-list/promo-code/add`, query: { ...router.query, service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }
    const selectSubservice = (e: any) => {
        let subService = e?.split("_")
        const serviceName = subService[1]
        const serviceId = subService[0]
        const ind = selectedService.data?.findIndex((item: any) => item?.sub_service_id == serviceId)
        // debugger
        if (ind != -1) {
        }
        else {
            array.push({ sub_service_id: serviceId, name: serviceName })
            setSelectedService({
           data : [...selectedService.data ,{ sub_service_id: serviceId, name: serviceName }]
            })
        }
        console.log(array, "newwwwwwwwwwww");
    }

    const onChange = (e: CheckboxChangeEvent) => {
        console.log(`checked = ${e.target.checked}`);
        form.setFieldValue("is_new_user", e.target.checked)
    };
    // const handleSelect = (_id: any) => {
    //     try {
    //         let sub_service = service?.data.find((res: any) => res._id == _id)

    //         setSub_service({
    //             ...subService,
    //             sub_service
    //         })
    //         console.log(sub_service, "subService");
    //         setSub_service(sub_service)


    //         console.log(subService, "sub_services");
    //     } catch (error) {
    //         Toast.error(error)
    //     }
    // }
    const disabledDate: RangePickerProps['disabledDate'] = (current) => {
        return current < dayjs().startOf('day');
    };
    const disabledDateOut: RangePickerProps['disabledDate'] = (current) => {
        return current < (selectedDate || dayjs(dayjs()).add(1, 'd'));
    };
    const onFinish = async (values: any) => {
        console.log(values,"values");
        // return
        debugger
        console.log(handleDiscount);

        if (handleDiscount == "") {
            return Toast.warn("Please select Discount type")
        }
        const payload = values.services.map((res: any) => {
            console.log(res,"ress");
            const sub_service_id = res?.sub_service_id.map((resp: string) => JSON.parse(resp).value)
            return {
                service_id: res?.service_id,
                sub_service_id
            }
        });
        const data = {
            ...values,
            start_date: dayjs(values?.start_date).valueOf(),
            end_date: dayjs(values?.end_date).valueOf(),
            min_amount: Number(values?.min_amount),
            discount_type: handleDiscount,
            services:payload
        }
        if (values.discount_amount) {
            data.discount_amount = Number(values?.discount_amount)
        }
        if (!values.is_new_user) {
            data.is_new_user = false
        }
        // if (handleDiscount == "PERCENTAGE") {
        //     data.discount_percentage = String(values.min_amount),
        //         delete data.min_amount
        // }
        // else {
        //     data.min_amount = Number(values?.min_amount)
        // }
        try {
            setLoading(true)
            debugger
            const apiRes = await henceforthApi.Promo.add(data)
            Toast.success(apiRes?.message ?? "success")
            router.back()
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setLoading(false)
        }
    }
    // const add = () => {

    // }
    React.useEffect(() => {
        serviceInitialse()
    }, [])
    return (
        <React.Fragment>
            <Head>
                <title>Promo Code</title>
                <meta name="description" content="Users" />
            </Head>
            <section className='add-promo-code'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={14}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'><Link href={'/content-list/promo-code/page/1'} className='text-decoration-none'>Promo Code</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Add Promo Code</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='fw-700 mb-4'>Add Promo Code</Typography.Title>
                            </div>
                            <Form
                                layout='vertical'
                                size='large'
                                form={form}
                                onFinish={onFinish}
                                initialValues={{
                                    services: [{ service_id: null, area_id: null, areas: [] }]
                                }}
                            >
                                <Row gutter={[15, 0]}>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'Promo Code Name'}
                                            name='name'
                                            rules={[{ required: true, message: 'Please enter promo code name', whitespace: true }]}
                                        >
                                            <Input placeholder='Promocode name' className='border-0' name='name'
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'Maximum Number Usage per User'}
                                            name='max_use_per_user'
                                            rules={[{ required: true, message: 'Please select user count' }]}
                                        >
                                            <Select
                                                placeholder="Select no."
                                                allowClear
                                                className='border-0'
                                            >
                                                <Select.Option value={1}>1</Select.Option>
                                                <Select.Option value={2}>2</Select.Option>
                                                <Select.Option value={3}>3</Select.Option>
                                                <Select.Option value={4}>4</Select.Option>
                                                <Select.Option value={5}>5</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>

                                        <div className='d-flex flex-column gap-2 mb-2'>
                                            <Button className={`discount p-0 rounded-4 ${handleDiscount === 'FIXED' && 'discount-active'}`} onClick={() => setHandleDiscount('FIXED')}>Fixed Discount</Button>
                                            <Button className={`discount p-0 rounded-4 ${handleDiscount === 'PERCENTAGE' && 'discount-active'}`} onClick={() => setHandleDiscount('PERCENTAGE')}> Discount Percentage</Button>
                                        </div>

                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            label={'Minimum Order Amount'}
                                            name='min_amount'
                                            rules={[{ required: true, message: 'Please enter amount', whitespace: true }]}
                                        >
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} maxLength={5}
                                                placeholder='Enter amount' className='border-0'
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Form.Item
                                            label={`Discount ${handleDiscount == "FIXED" ? "Amount" : "Percentage"}`}
                                            name={`discount_${handleDiscount == "FIXED" ? "amount" : "percentage"}`}
                                            rules={[{ required: true, message: 'Please enter discount', whitespace: true }]}
                                        >
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} maxLength={5}
                                                placeholder={`Enter ${handleDiscount.toLocaleLowerCase()}`} className='border-0'
                                            />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24} md={12}>
                                        <Form.Item
                                            label={'Start Date'}
                                            name='start_date'
                                            rules={[{ required: true, message: 'Please enter start date' }]}
                                        >
                                            <DatePicker clearIcon={false} onChange={(e: any) => {
                                                setSelectedDate(e)
                                                if ((dayjs(e).valueOf()) >= dayjs(form.getFieldValue('end_date')).valueOf()) {
                                                    setTimeout(() => {
                                                        form.setFieldValue('end_date', dayjs(e).add(1, 'day'))
                                                    }, 500)
                                                }
                                            }} disabledDate={disabledDate} name='start_date' className='w-100 border-0' placeholder='Start date' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24} md={12}>
                                        <Form.Item
                                            label={'End Date'}
                                            name='end_date'
                                        // rules={[{ required: true, message: 'Please enter end date' }]}
                                        >
                                            <DatePicker clearIcon={false} disabledDate={disabledDateOut} name='end-date' className='w-100 border-0' placeholder='End date' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                        </Form.Item>
                                    </Col>
                                    {/* vikram */}
                                 <Col span={24}>
                                 <Form.List
                                    name="services"
                                    rules={[
                                        {
                                            validator: async (_, names) => {
                                                if (!names || names.length < 1) {
                                                    return Promise.reject(new Error('At least 2 passengers'));
                                                }
                                            },
                                        },
                                    ]}
                                >
                                    {(fields, { add, remove }, { errors }) => (
                                        <>
                                            {fields.map((field, index, restField) => {
                                                return <Form.Item
                                                    // {...(index === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                                    required={false}
                                                    key={field.key}
                                                >
                                                    <Form.Item className='mb-3'
                                                        {...restField}
                                                        name={[field.name, "service_id"]}
                                                    >
                                                        <Select placeholder='Select Service'
                                                            // defaultValue="Select City"
                                                            onChange={() => {
                                                                const x = form.getFieldValue("services")
                                                                let allFields = x[index]
                                                                allFields.sub_service_id = []
                                                                allFields.sub_service_ids = null
                                                                form.setFieldValue("services", x)
                                                            }}
                                                            options={service.data.filter((res: any) => !form.getFieldValue('services').some((resp: any, ind: number) => resp?.service_id === res._id && index !== ind)).map((res: any, inde: number) => { return { value: res._id, label: res.name } })}
                                                        />
                                                    </Form.Item>
                                                    <Form.Item className='mb-0' 
                                                    shouldUpdate={(prev, curr) => prev.services[index]?.service_id !== curr.services[index]?.service_id}>
                                                        {({ setFieldValue, getFieldValue }) => {
                                                            const selecteAreas = service.data.find((res: any) => res._id === form.getFieldValue('services')[index]?.service_id) as any
                                                            let areaLen = (selecteAreas?.sub_services || []).length
                                                            if (areaLen && selecteAreas.sub_services[0]?._id !== "All") {
                                                                selecteAreas.sub_services.unshift({ _id: "All", name: "All" })
                                                                areaLen = (selecteAreas?.sub_services || []).length
                                                            }
                                                            return <Form.Item className='mb-0' name={[field.name, "sub_service_ids"]}>
                                                                <Select placeholder='Select Sub Services'

                                                                    onChange={(v, op: any) => {
                                                                        console.log(op);

                                                                        const x = getFieldValue("services")
                                                                        let allFields = x[index]
                                                                        if (op.value === "All") {
                                                                            const selected = (allFields.area_id || []).length
                                                                            if (selected === (areaLen - 1)) {
                                                                                allFields.sub_service_id = []
                                                                            } else {
                                                                                const x = [] as any
                                                                                console.log(areaLen, selecteAreas?.sub_services);

                                                                                for (let i = 1; i < areaLen; i++) {
                                                                                    const element = selecteAreas.sub_services[i];
                                                                                    x.push(JSON.stringify({ value: element._id, label: element.name }))
                                                                                }
                                                                                allFields.sub_service_id = x
                                                                            }
                                                                        }
                                                                        else if (allFields.sub_service_id) {
                                                                            let arrInde = allFields.sub_service_id.findIndex((res: string) => JSON.parse(res).value === op.value)
                                                                            if (arrInde !== -1) {
                                                                                allFields.sub_service_id.splice(arrInde, 1)
                                                                            } else {
                                                                                allFields.sub_service_id.push(JSON.stringify(op))
                                                                            }
                                                                        } else {
                                                                            allFields.sub_service_id = [JSON.stringify(op)]
                                                                        }
                                                                        allFields.areas = null
                                                                        setFieldValue("services", x)
                                                                        // console.log(getFieldValue([field.name,"area_id"]));
                                                                    }}
                                                                    options={Array.isArray(selecteAreas?.sub_services) ? selecteAreas.sub_services.map((res: any, index: number) => { return { value: res._id, label: res.name } }) : []}
                                                                />

                                                            </Form.Item>
                                                        }}
                                                    </Form.Item>
                                                    {/* <Row gutter={[15, 15]}> */}
                                                    <Form.Item className='mb-0' shouldUpdate={(prev, curr) => prev.services[index]?.sub_service_ids !== curr.services[index]?.sub_service_ids}>
                                                        {({ getFieldValue }) => {
                                                            console.log(getFieldValue("services"));
                                                            return <>
                                                                <Form.Item className='d-none mb-0' name={[field.name, "sub_service_id"]}>
                                                                    <Select placeholder='Select Area'
                                                                        mode="multiple"
                                                                    />
                                                                </Form.Item>
                                                                <Row className='mt-3' gutter={[12, 12]}>
                                                                    {Array.isArray(getFieldValue("services")[index]?.sub_service_id) && getFieldValue("services")[index]?.sub_service_id?.map((resp: any, indexes: number) => {
                                                                        const res = JSON.parse(resp)
                                                                        return <Col span={12}
                                                                            key={index}>
                                                                            <Tag className='w-100 flex-between' color="#108ee9" bordered={false} closable onClose={() => {
                                                                                const x = form.getFieldValue("services")
                                                                                let allFields = x[index]
                                                                                allFields.sub_service_id.splice(indexes, 1)
                                                                                form.setFieldValue("services", x)
                                                                            }}><Tooltip title={res.label}>{res.label.slice(0, 25)}</Tooltip></Tag>
                                                                        </Col>
                                                                    })}
                                                                </Row>
                                                                {/* </Row> */}
                                                            </>
                                                        }}
                                                    </Form.Item>
                                                    {fields.length > 1 ? (
                                                        <Button type='primary' className='mt-3' danger block ghost onClick={() => remove(field.name)}>
                                                            <span className='text-danger'>Delete</span>
                                                        </Button>
                                                    ) : null}
                                                </Form.Item>
                                            }

                                            )}
                                            <Form.Item>
                                                <Button
                                                    type="dashed"
                                                    onClick={() => add()}
                                                    style={{ width: '100%' }}
                                                >
                                                    Add More Service
                                                </Button>

                                            </Form.Item>
                                        </>
                                    )}
                                </Form.List>
                                 </Col>
                                    <Col span={24}>
                                        <Form.Item name="is_new_user">
                                            <Checkbox onChange={onChange}>Only for new users</Checkbox>
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Button htmlType='submit' loading={loading} type='primary'>Add Promo Code</Button>
                                    </Col>
                                </Row>
                            </Form>
                        </Card>
                    </Col>
                </Row>
            </section>
        </React.Fragment>
    )
}

AddPromoCode.getLayout = (page: React.ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

// export const getServerSideProps: GetServerSideProps = async (context) => {
//     try {
//         // let apiRes = await henceforthApi.Service.getServices()
//         // return { props: { data: apiRes.data } };
//     } catch (error: any) {
//         return { props: { data: null } };
//     }
// }

export default AddPromoCode
