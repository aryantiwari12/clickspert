import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Badge, Select, DatePicker, Dropdown, Divider } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import { DatePickerProps, Modal, TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined, ExclamationCircleFilled, PlusOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import Serviceimg from '../../../../assets/images/banner.png'
import Image from 'next/image';
import dayjs, { Dayjs } from 'dayjs'
import SearchPage from '@/components/common/SearchInput';
import henceofrthEnums from '@/utils/henceofrthEnums';
import { ChatContext } from '@/context/chatProvider';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const PromoCode: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { downloadCSV, Toast } = React.useContext(GlobalContext)
    const { socketHitType } = React.useContext(ChatContext)
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);
    const [promoCode, setPromoCode] = useState({
        data: [] as any,
        count: 0
    })
    const [subService, setSub_service] = useState({
        sub_services: []
    } as any)
    const [service, setService] = useState({
        data: [],
    })
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const onDateSelect: DatePickerProps['onChange'] = (dateString) => {
        if (router.query.end_date) {
            router.push({ pathname: `/content-list/promo-code/page/1`, query: { ...router.query, start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } })
        } else {
            router.push({ pathname: `/content-list/promo-code/page/1`, query: { ...router.query, start_date: dayjs(dateString).valueOf() } })
        }
    }
    const onDate = (dateString: any) => {
        router.push({ pathname: `/content-list/promo-code/page/1`, query: { ...router.query, start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } }, undefined, { shallow: true })
    }

    const getPromoList = async () => {
        let query = router.query
        let urlSearchParam = new URLSearchParams()
        try {
            if (query.search) {
                urlSearchParam.set('search', String(query.search))
            }
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.start_date) {
                urlSearchParam.set('start_date', String(router.query.start_date))
            }
            if (query.type) {
                urlSearchParam.set('type', String(query.type)?.split("-")?.join("_").toUpperCase())
            }
            if (query.end_date) {
                urlSearchParam.set('end_date', String(query.end_date))
            }
            if (query.service_id) {
                urlSearchParam.set('service_id', String(query.service_id))
            }
            if (query.limit) {
                urlSearchParam.set('limit', String(query.limit))
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(query.sub_service_id))
            }
            const apiRes = await henceforthApi.Promo.getlist(urlSearchParam?.toString())
            setPromoCode(apiRes)
        } catch (error) {

        }
    }
    const onDelete = async (id: string, index: number) => {
        try {
            Modal.confirm({
                title: 'Delete',
                icon: <ExclamationCircleFilled />,
                content: 'Are you sure you want to delete?',
                okText: 'Delete',
                okType: 'danger',
                onOk: async () => {
                    setLoading(true)
                    let apiRes = await henceforthApi.Promo.delete(id)
                    const newData = promoCode?.data?.splice(index, 1)
                    console.log(newData, "newData");
                    console.log(promoCode, "newData");

                    setPromoCode({
                        data: promoCode.data,
                        count: promoCode?.count - 1
                    })
                    Toast.success(apiRes?.message)
                    setLoading(false)
                    // await initialise()
                    router.push({ query: { ...router.query, pagination: promoCode?.data?.length ? Number(router.query.pagination) : Number(router.query.pagination) - 1 } }, undefined, { shallow: true })
                },
                onCancel() { },
            } as any);
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    const handleStatus = async (id: string, status: string) => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Promo.editStatus(id)
            Toast.success(apiRes.message)
            const newData = promoCode?.data?.findIndex((item: any) => item?._id == id)
            promoCode.data[newData].is_active = apiRes?.is_active
            // await initialise()
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    const StatusItem = (res: any, index: any) => {
        console.log(res, "res");
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Promo.inactive}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Promo.inactive} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.Promo.inactive),
                        disabled: res?.is_active ? false : true
                    },
                    {
                        key: '12',
                        label: <Divider style={{ height: 2 }} plain className='m-0'></Divider>
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.Promo.active}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.Promo.active} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.Promo.active),
                        disabled: res?.is_active ? true : false
                    }
                ],
            },
            {
                key: '2',
                label: (
                    <Typography.Text >
                        Delete
                    </Typography.Text >
                ),
                onClick: () => onDelete(res._id, index),
            }
        ]
    }
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const dataSource = promoCode?.data?.map((item: any, index: number) => {
        // let app=item?.filter((res:any)=>res._id===index).map((itess:any)=>itess.services)
        // console.log(app,"app");
        let value = item.multiple_service[0]
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: item?.name ?? "N/A",
            service: <div className='service-detail d-flex gap-2 align-items-center'>
                {/* {item?.multiple_service.map((res: any,index:number) => {
                    return (
                        <div className="service-detail-img mb-1">
                            <div>
                          <img src={henceforthApi.FILES.imageOriginal(res?.image, user?.src)} alt='img' />
                            </div>
                            <div className='mb-1 p-2'>
                                <Typography.Text><Tooltip title>{(index !== 0 ? ', ' : '')+ res.name}</Tooltip></Typography.Text><br />
                            </div><br/>
                                <Typography.Text>{res?.subservices?.map((resss: any, index: number) =><span>{resss.name}</span>)}</Typography.Text>,
                        </div>
                    )
                })} */}

                <div className="service-detail-img mb-1">
                    <img src={henceforthApi.FILES.imageOriginal(value?.image, user?.src)} alt='img' />
                </div>
                <div className='mb-1 p-2'>
                    <Typography.Text><Tooltip title>{value.name?.slice(0, 5)}</Tooltip></Typography.Text><br />
                    <Typography.Text>{value?.subservices[0]?.name.slice(0, 10)}</Typography.Text>,
                </div>

            </div>,
            discount: item?.discount_type == "PERCENTAGE" ? `Discount Percentage (${item?.discount_percentage} %)` : `Fixed Discount (AED ${item?.discount_amount})`,
            maxusers: item?.max_use_per_user ?? "N/A",
            creationdate: dayjs(item?.created_at).format("ddd,MMM DD"),
            startdate: dayjs(item?.start_date).format("ddd,MMM DD") + " - " + dayjs(item?.end_date).format("ddd,MMM DD"),
            status: <div className={`upcoming ${item?.is_active ? "bg-theme" : "bg-danger"}`}>
                {item?.is_active ? "Active" : "Inactive"}
            </div>,
            action:
                <li>
                    <Button className='bg-transparent' type='primary' shape='circle'><Link href={`/content-list/promo-code/${item?._id}/edit`}><HenceforthIcons.PencileIcon /></Link></Button>
                    <Tooltip title="Actions">
                        <Dropdown menu={{ items: StatusItem(item, index) }} trigger={['click']} placement="bottomRight">
                            <a onClick={(e) => e.preventDefault()}>
                                <Button shape='circle' className='border-0' htmlType='button'><HenceforthIcons.More /></Button>
                            </a>
                        </Dropdown>
                    </Tooltip>
                </li>
        }
    })


    const TableData = () => <Row gutter={[20, 20]} >
        <Col span={24} >
            <Table dataSource={dataSource} columns={ColumnsType.promocodeColumns} pagination={false} scroll={{ x: '100%' }} />
        </Col>
    </Row>

    const items: TabsProps['items'] = [
        {
            key: 'all',
            label: 'All',
            children: <TableData />,
        },
        {
            key: 'active',
            label: 'Active',
            children: <TableData />,
        },
        {
            key: 'deactive',
            label: 'Inactive',
            children: <TableData />,
        },
        {
            key: 'new-user',
            label: 'New Users',
            children: <TableData />,
        }
    ];
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }
    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/content-list/promo-code/page/1`, query: { ...router.query, service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/content-list/promo-code/page/1`, query: { ...router.query, service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }
    const handleSelect = (_id: any) => {
        try {
            let sub_service = service?.data.find((res: any) => res._id == _id)
            setSub_service(sub_service)
            handleChange(null, _id)
        } catch (error) {
            Toast.error(error)
        }
    }

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    React.useEffect(() => {
        serviceInitialse()
    }, [])
    useEffect(() => {
        getPromoList()
    }, [router.query.type, router.query.pagination, socketHitType, router.query.end_date, router.query.search, router.query.start_date, router.query.service_id, router.query.sub_service_id, router.query.page])
    return (
        <Fragment>
            <Head>
                <title>Promo Code</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Promo Code</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Promo Code</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Link href={'/content-list/promo-code/add'}><Button type="primary" htmlType="button" size='large' icon={<PlusOutlined />} >Add Promo Code</Button></Link>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[15, 15]} className='my-4'>
                                {/* Search  */}
                                <Col span={24}>
                                    {/* <Search size="large" placeholder="Search..." enterButton /> */}
                                    <SearchPage placeholder="Search..." />
                                </Col>
                                <Col span={24} md={12}>
                                    <Select
                                        showSearch
                                        allowClear
                                        size='large'
                                        className='w-100 bg-transparent'
                                        placeholder="Select service"
                                        optionFilterProp="children"
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                        filterSort={(optionA, optionB) =>
                                            (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                        }
                                        onChange={handleSelect}
                                        options={service?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <Select
                                        size='large'
                                        showSearch
                                        allowClear
                                        className='w-100 bg-transparent'
                                        placeholder="Select sub service"
                                        optionFilterProp="children"
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        onChange={(e: any) => handleChange(e, String(router.query.service_id))}
                                        options={subService?.sub_services?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDateSelect}
                                        placeholder='From' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker onChange={onDate} placeholder='To' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                            </Row>

                            {/* Tabs  */}
                            <div className='tabs-wrapper '>
                                <Tabs activeKey={router.query.type as string} items={items} onChange={onChange} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={promoCode.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Promo.export(start_date, end_date)
                        const exportData = apiRes?.data?.map((item: any, index: number) => {
                            return {
                                // status:capitalise(item?.status),
                                name: item?.name,
                                // vendor_name:item?.vendor_id?.name,
                                service: item?.service?.name,
                                discount: item?.discount_type == "PERCENTAGE" ? `Discount Percentage (${item?.discount_percentage} %)` : `Fixed Discount (AED ${item?.discount_amount})`,
                                maxusers: item?.max_use_per_user ?? "N/A",
                                creationdate: dayjs(item?.created_at).format("ddd MMM DD"),
                                startdate_endDate: dayjs(item?.start_date).format("ddd MMM DD") + ' to ' + dayjs(item?.end_date).format("ddd MMM DD"),
                                status: item?.is_active ? "Active" : "Inactive"

                                // clickspert_points:item?.points,
                                // order_id:item?.order_id,
                                // service_type:item?.is_quotation_based ? 'Quotation' : "Order based",
                                // date_time:dayjs(item?.date)?.format('DD MMM YYYY'),
                                // city:item?.address?.city,
                                // area:item?.address?.street_address?.split(",")?.join(" "),
                                // recurring:item?.recurring,
                                // transaction_id:item?.transactions?.transaction_no,
                                // point:item?.points?.toFixed(2),
                                // service_fee:item?.service_fee?.toFixed(2),
                                // promo_code:item?.promo_id?.name,
                                // commision:item?.commission,
                                // vendor_earning:item?.vendor_earning,
                                // amount:item?.total_amount?.toFixed(2),
                                // Service:item?.service_id?.name,
                                // app_wallet:item?.wallet_amount

                            }
                        })
                        downloadCSV("user", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

PromoCode.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default PromoCode
