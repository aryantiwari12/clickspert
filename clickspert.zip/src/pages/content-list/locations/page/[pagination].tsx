import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useRef, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Switch, Modal, Form, Select, Tag, theme, Popconfirm } from 'antd';
import { UploadOutlined, PlusOutlined } from '@ant-design/icons'
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import { useRouter } from 'next/router';
import henceforthValidations from '@/utils/henceforthValidations';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Location: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const [tags, setTags] = useState([] as Array<any>);
    const [form] = Form.useForm()
    const [locationType, setLocationType] = useState("")
    const router = useRouter()
    const { downloadCSV, Toast } = React.useContext(GlobalContext)
    const { socketHitType } = React.useContext(ChatContext)
    const [state, setState] = React.useState({
        data: [],
        count: 0
    } as any);
    const [city, setCity] = useState("")
    const [limit, setLimit] = useState(10)
    const placeInputRef = React.useRef(null as any)
    const [viewarea, setViewArea] = useState({
        data: [],
        count: 0
    })
    const listenerRef = React.useRef(null) as any
    const listenerAutooCompleteRef = React.useRef(null) as any
    const dataSouce2Heading = useRef('')
    const [modalHeading, setModalHeading] = useState('Add')
    const [loading, setLoading] = React.useState({
        loading1: false,
        loading2: false,
        loading3: false,
        loading4: false
    })
    const resEdit = useRef(null as any)
    const [exportModal, setExportModal] = React.useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const showModal = () => {
        setIsModalOpen(true);
    };
    console.log(modalHeading, "modalHeading");

    function loadGoogleMapScript(callback: any) {
        if (
            typeof (window as any).google === "object" &&
            typeof (window as any).google.maps === "object"
        ) {
            callback();
        } else {
            const googleMapScript = document.createElement("script");
            googleMapScript.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDcjhHJd7Yx6Je19s8m3qH5hK2jdT9Kk8E&libraries=places`;
            window.document.body.appendChild(googleMapScript);
            googleMapScript.addEventListener("load", callback);
        }
    }

    const initPlaceAPI = () => {
        loadGoogleMapScript(() => {
            if (placeInputRef) {
                listenerAutooCompleteRef.current = new (window as any).google.maps.places.Autocomplete(
                    placeInputRef?.current?.input
                );
                listenerRef.current = new (window as any).google.maps.event.addListener(
                    listenerAutooCompleteRef.current,
                    "place_changed",
                    () => {
                        let place = listenerAutooCompleteRef.current.getPlace();
                        console.log(place, "place");
                        const formatAddress = place.formatted_address;
                        console.log(formatAddress, "form");
                        const address = place.address_components;
                        const lat = place.geometry?.location.lat();
                        const lng = place.geometry?.location.lng();
                        let items: any = {};
                        if (Array.isArray(address) && address.length > 0) {
                            let zipIndex = address.findIndex((res) =>
                                res.types.includes("postal_code")
                            );
                            let administrativeAreaIndex = address.findIndex((res) =>
                                res.types.includes("administrative_area_level_1", "political")
                            );
                            let localityIndex = address.findIndex((res) =>
                                res.types.includes("locality", "political")
                            );
                            let countryIndex = address.findIndex((res) =>
                                res.types.includes("country", "political")
                            );
                            let premiseIndex = address.findIndex((res) =>
                                res.types.includes("premise", "street_number")
                            );
                            if (zipIndex > -1) {
                                items.pin_code = address[zipIndex].long_name;
                            }
                            if (administrativeAreaIndex > -1) {
                                items.state = address[administrativeAreaIndex].long_name;
                            }
                            if (localityIndex > -1) {
                                items.city = address[localityIndex].long_name;
                            } if (localityIndex > -1) {
                                items.street = address[localityIndex].long_name;
                            }
                            if (countryIndex > -1) {
                                items.country = address[countryIndex].long_name;
                            } if (countryIndex > -1) {
                                items.shortCountryName = address[countryIndex].short_name;
                            }
                            if (premiseIndex > -1) {
                                items.apartment_number = address[premiseIndex].long_name;
                            }
                            if (!items.city) return Toast.error('Enter a valid area')
                            const CityName = items.city?.toLowerCase();
                            if (locationType == 'Area' && CityName != dataSouce2Heading?.current) {
                                form.setFieldValue("area", "");
                                return Toast.error(`This area not exist in ${dataSouce2Heading?.current}`)
                            }
                            if (locationType == "Area") {
                                setCity(items.city)
                            }

                            const areaData = {
                                state: items.state,
                                city: items.city,
                                country: items.country,
                                landmark: items.street,
                                address_line1: formatAddress,
                                address_line2: items.street,
                                pincode: +items.pin_code,
                                lng,
                                lat
                            }
                            console.log(address);
                            form.setFieldValue('area', '')
                            setTags((tags) => [...tags, areaData]);
                        }
                    }
                );
            }
        });
    };
    const handlePagination = (page: number, pageSize: number) => {
        setLimit(pageSize)
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleCancel = () => {
        setIsModalOpen(false);
        setTags([])
        new (window as any).google.maps.event.removeListener(listenerRef.current);
        new (window as any).google.maps.event.clearInstanceListeners(listenerAutooCompleteRef.current);
    };
    console.log(modalHeading, "modalHeading");

    const dataSource = state?.data?.map((res: any, index: any) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            city: <div className='d-flex align-items-center gap-2'>
                <Typography.Text >{henceforthValidations.uppercaseWords(res.city) || "N/A"}</Typography.Text>
                <Button role='button' className='btn-0 border-0 p-0' onClick={() => { onChangeViewArea(res._id); dataSouce2Heading.current = res.city; router.replace({ query: { ...router.query, aredId: res?._id } }, undefined, { shallow: true }) }}><HenceforthIcons.ViewTwo /></Button>
            </div>,
            status: <div>
                <Switch defaultChecked onChange={() => onChange(res._id)} loading={loading.loading1} />
            </div>,
            action: <div>
                <Popconfirm
                    title="Delete"
                    description="Are you sure you want to delete ?"
                    onConfirm={(event) => { event?.stopPropagation(); onChangeDelete(res._id, index) }}
                >
                    <Button type='primary' className='bg-transparent p-1'><HenceforthIcons.Trash /></Button>
                </Popconfirm>
            </div>
        }
    })

    const handleAddEdit = (type: string, values: string) => {
        setTags([])
        setModalHeading(type)
        form.setFieldValue('area', values)
        showModal()
    }

    const dataSource2 = viewarea?.data?.map((res: any, index: any) => {
        return {
            key: index + 1,
            area: <div className='text-wrap'>{res.address_line1}</div>,
            action: <div>
                <Button type='primary' onClick={() => { handleAddEdit('Edit', res.address_line1); resEdit.current = res; setLocationType("Area") }} shape='circle' className='bg-transparent'><HenceforthIcons.PencileIcon /></Button>
                <Popconfirm
                    title="Delete"
                    description="Are you sure you want to delete ?"
                    onConfirm={(event) => { event?.stopPropagation(); onChangeDeleteArea(res._id, index) }}
                >
                    <Button type='primary' className='bg-transparent p-1'><HenceforthIcons.Trash /></Button>
                </Popconfirm>
            </div >
        }
    })
    const onChangeViewArea = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Loction.view(_id)
            setViewArea(apiRes)
        } catch (error) {

        }
    }
    const initialise = async () => {
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.start_date) {
                urlSearchParam.set('start_date', String(router.query.start_date).toUpperCase() as string)
            } if (query.end_date) {
                urlSearchParam.set('end_date', String(router.query.end_date).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Loction.listing(urlSearchParam.toString(), limit)
            setState(apiRes)
        } catch (error) {

        }
    }
    const onChange = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Loction.checked(_id, "")
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        } finally {

        }
    };
    const onChangeDelete = async (_id: any, index: number) => {
        try {
            setLoading({
                ...loading,
                loading2: true
            })
            let apiRes = await henceforthApi.Loction.delete(_id)
            Toast.success(apiRes.message)
            state.data.splice(index, 1)
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading({
                ...loading,
                loading2: false
            })
        }
    }
    const onChangeDeleteArea = async (_id: any, index: number) => {
        debugger
        try {
            setLoading({
                ...loading,
                loading4: true
            })
            let apiRes = await henceforthApi.Loction.areadelete(_id)
            Toast.success(apiRes.message)
            let newAreaObj: any = [...viewarea.data]
            newAreaObj.splice(index, 1)
            setViewArea({ ...viewarea, data: newAreaObj })
        } catch (error) {
            Toast.error(error)
            setLoading({
                ...loading,
                loading4: true
            })
        }
    }
    const onChangeLocationEdit = async () => {
        debugger
        const lastItem = tags[tags.length - 1];
        try {
            setLoading({
                ...loading,
                loading3: true
            })
            let apiRes = await henceforthApi.Loction.editArea(resEdit.current._id, lastItem)
            Toast.success(apiRes.message)
            let newAreaObj: any = [...viewarea.data]
            let index = newAreaObj.findIndex((res: any) => res._id === resEdit.current._id)
            newAreaObj.splice(index, 1)
            newAreaObj.push(apiRes)
            setViewArea({ ...viewarea, data: newAreaObj })
        } catch (error) {
            Toast.error(error)
        } finally {
            setTimeout(() => {
                setIsModalOpen(false);
                setLoading({
                    ...loading,
                    loading3: false
                });
            }, 2000);
        }
    }
console.log(tags,"tagaa");

    const onChangeLocationAdd = async () => {
        debugger
        let chooseCity = city?.toLowerCase();
        if (locationType == 'Area' && !city) {
            return Toast.warn(`Please Select Area`)
        }
        if (city && locationType == 'Area') {
            if (dataSouce2Heading.current != chooseCity) {
                return Toast.warn(`This Area not exit in ${dataSouce2Heading?.current} city`)
            }
        }
        else {
            // return Toast.warn("Please Select Area")
        }
        if (modalHeading === 'Edit') {
            onChangeLocationEdit()
            return
        }
        try {
            setLoading({
                ...loading,
                loading3: true
            })
            if(!tags[0]) return Toast.warn("Please Enter Location")
            let apiRes = await henceforthApi.Loction.add({ area: tags })
            Toast.success(apiRes.message)
            initialise()
            handleCancel()
            if (router?.query?.aredId) {
                onChangeViewArea(router?.query?.aredId)
            }
            setIsModalOpen(false);
        } catch (error) {
            // if(locationType == 'Area'){
            //     Toast.error(error)
            // }
            if(locationType == 'City'){
                Toast.error("This city is already added") 
            }
            else{
                Toast.error(error)
            }
        } finally {
            setTimeout(() => {
                setLoading({
                    ...loading,
                    loading3: false
                });
            }, 2000);
            
        }
    }
    const handleClose = (removedTag: string) => {
        const newTags = tags.filter((tag) => tag !== removedTag);
        setTags(newTags);
    };
    useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit , socketHitType])
    useEffect(() => {
        if (isModalOpen) {
            setTimeout(() => { initPlaceAPI() }, 500)
        }
    }, [isModalOpen])

    const tagChild = React.useMemo(() => tags.map((tag: any) => {
        const tagElem = (
            <Tag
                closable
                onClose={(e) => {
                    e.preventDefault();
                    handleClose(tag);
                }}
                color="#ECC263"
            >
                {tag.address_line1.length > 30 ? <Tooltip title={tag.address_line1}>{tag.address_line1.slice(0, 30) + '...'}</Tooltip> : tag.address_line1}
            </Tag>
        );
        return (
            <span key={tag} style={{ display: 'inline-block' }}>
                {tagElem}
            </span>
        );
    }), [tags]);

    return (
        <Fragment>
            <Head>
                <title>Location</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Location</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3 mb-4'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Location</Typography.Title>
                                <div className='d-flex gap-2'>

                                    <Button onClick={() => { handleAddEdit('Add', ''); setLocationType("City") }} type="primary" htmlType="button" size='large' icon={<PlusOutlined />} >Add Location</Button>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[15, 15]}>
                                <Col span={24} md={12}>
                                    <div className="custom-card p-4">
                                        <div className='mb-3'>
                                            <Typography.Title level={4} className='fw-700'>City</Typography.Title>
                                        </div>
                                        <Table dataSource={dataSource} columns={ColumnsType.locationColumns1} pagination={false} scroll={{ x: '100%' }} />
                                        <div className='p-2'>
                                            <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} onChange={handlePagination} />
                                        </div>
                                    </div>
                                </Col>
                                <Col span={24} md={12}>
                                    <div className="custom-card p-4">
                                        <div className='flex-center mb-2'>
                                            {router?.query?.aredId && <><Typography.Title level={4} className='fw-700'>Area of {dataSouce2Heading.current}</Typography.Title>
                                                <Button className='px-2' onClick={() => { handleAddEdit('Add', ''); setLocationType("Area") }} type='primary'><PlusOutlined className='text-white' /></Button>
                                            </>}
                                        </div>
                                        <Table dataSource={dataSource2} columns={ColumnsType.locationColumns2} pagination={false} scroll={{ x: '100%' }} />
                                    </div>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue}  open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading({
                            ...loading,
                            loading1: true
                        })
                        let apiRes = await henceforthApi.Loction.export(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                area: item?.city, 
                            }
                          })
                        downloadCSV("Feedbacks", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading({
                            ...loading,
                            loading1: false
                        })
                        setValue(null)
                    }
                }} />

                <Modal footer={null} centered={true} maskClosable={false} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>{modalHeading} {locationType == 'City' ? 'Location' : "Area"}</Typography.Title>
                        <Form size='large' form={form} onKeyDown={(keyEvent: any) => {
                            if ((keyEvent.charCode || keyEvent.keyCode) === 13) {
                                keyEvent.preventDefault();
                            }
                        }} layout='vertical' className='mt-2'>
                            <Form.Item label={locationType} name="area" rules={[{ required: false, message: `Please Enter ${locationType}` }]}>
                                <Input
                                    ref={(ref) => placeInputRef.current = ref}
                                    type="text"
                                    size="small"
                                    placeholder={`Enter a ${locationType} name`}
                                    className='border-0 p-2'
                                />
                            </Form.Item>
                            {modalHeading === 'Add' ? <div className='mt-2 d-flex flex-wrap gap-2'>
                                {tagChild}
                            </div>
                                :
                                <div className='mt-2 d-flex flex-wrap gap-2'>
                                    {tagChild[tagChild.length - 1]}
                                </div>
                            }
                            <div className='d-flex flex-wrap'>
                                <span style={{ display: 'inline-flex' }}>
                                    {/* {tagElem} */}
                                </span>
                                <span style={{ display: 'inline-flex' }}>
                                    {/* {tagElem} */}
                                </span>
                            </div>
                            <Form.Item className='mb-2 mt-4'>
                                <Button type='primary' htmlType='submit' block loading={loading.loading3} onClick={onChangeLocationAdd}>{modalHeading} {locationType == 'City' ? 'Location' : "Area"}</Button>
                            </Form.Item>
                        </Form>
                    </div>
                </Modal>
                {/* <LocationModal isModalOpen={isModalOpen} handleOk={handleOk} handleCancel={handleCancel}/> */}
            </section>
        </Fragment >
    )
}

Location.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Location
