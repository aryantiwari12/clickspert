import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Form, Checkbox } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const EditRefer: Page = () => {

    const ReactQuill = dynamic(import('react-quill'), { ssr: false })
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV ,currency } = React.useContext(GlobalContext)
    const [form] = Form.useForm()

    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);


    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            let apiRes = await henceforthApi.Refer.list()
            form.setFieldValue('amount', apiRes?.amount)
        } catch (error) {

        } 
    }
    const handleSubmit = async (values: any) => {
        setLoading(true)
        try {
            const data = {
                amount: Number(values?.amount),
                currency: currency?._id
            }
            const apiRes = await henceforthApi.Refer.add(data)
            Toast.success(apiRes?.message)
            router.back()
        } catch (error) {

        }
        finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search, router.query.type])


    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }

    return (
        <Fragment>
            <Head>
                <title>Refer</title>
                <meta name="description" content="Users" />
            </Head>
            <section className='add-promo-code'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={12}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'><Link href={'/content-list/refer-friend'} className='text-decoration-none'> Refer a friend</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Edit Refer a Friend</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='fw-700 mb-4'> Edit Refer a Friend</Typography.Title>
                            </div>
                            <Form
                                layout='vertical'
                                size='large'
                                form={form}
                                onFinish={handleSubmit}
                            >
                                <Row>
                                    <Col span={24}>
                                        <Form.Item label={'Price for Refer a Friend'} name="amount" rules={[{ required: true, message: 'Please enter amount', whitespace: true }]}>
                                            <Input placeholder='Enter Price' />
                                        </Form.Item>
                                    </Col>
                                    <Col span={24}>
                                        <Button type='primary' htmlType='submit' loading={loading}>Save Changes</Button>
                                    </Col>
                                </Row>
                            </Form>

                        </Card>
                    </Col>
                </Row>
                {/* <ExportFile open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                    }
                }} /> */}

            </section>
        </Fragment>
    )
}

EditRefer.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default EditRefer
