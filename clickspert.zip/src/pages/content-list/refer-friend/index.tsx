import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Form, Checkbox } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import { Dayjs } from 'dayjs';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Refer: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const ReactQuill = dynamic(import('react-quill'), { ssr: false })
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const [state, setState] = React.useState({
        amount:0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Refer.list()
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [])
  
    return (
        <Fragment>
            <Head>
                <title>Refer</title>
                <meta name="description" content="Users" />
            </Head>
            <section className='add-promo-code'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={14}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'> Refer a friend</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='fw-700 mb-4'> Refer a friend</Typography.Title>
                            </div>
                            <Row>
                                <Col span={24} md={14}>
                                    <div className='refer d-flex flex-column justify-content-center align-items-center'>
                                        <p>Refer a Friend</p>
                                        <Typography.Title level={3} className='fw-700 mb-4'>{`AED ${state?.amount}`}</Typography.Title>
                                        <div className='edit-btn'>
                                           <Link href={'/content-list/refer-friend/edit'}><Button className='border-0 bg-transparent' shape='circle'><HenceforthIcons.Pencil2/></Button></Link>
                                        </div>
                                    </div>
                                </Col>
                            </Row>

                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Refer.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Refer
