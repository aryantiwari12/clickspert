import type { AppProps } from 'next/app'
import GlobalProvider from '@/context/Provider';
import Head from 'next/head';
import Script from 'next/script';
import { ReactNode } from 'react';
import { NextPage } from 'next';
import henceforthApi from 'src/utils/henceforthApi';
import { parseCookies } from "nookies"
import { COOKIES_USER_ACCESS_TOKEN } from 'src/context/actionTypes';
import { Router, useRouter } from 'next/router';
import NProgress from 'nprogress';
import { AuthInterface } from '@/interfaces';
import "@/styles/globals.scss"
import { Wix_Madefor_Display } from '@next/font/google'
import favicon from '../assets/favicon.ico'
import ChatProvider from '@/context/chatProvider';
const Wix = Wix_Madefor_Display({
  weight: [ '400', '500', '600', '700', '800'],
  style: ['normal',],
  subsets: ['latin'],
  preload: true,
  fallback: ['system-ui', 'arial']
})

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

type Props = AppProps & {
  Component: Page;
  user_info: AuthInterface,
  theme: {
    colorPrimary: string,
    direction: string,
  }
};
NProgress.configure({ showSpinner: false })
Router.events.on('routeChangeStart', () => NProgress.start());
Router.events.on('routeChangeComplete', () => NProgress.done());
Router.events.on('routeChangeError', () => NProgress.done());

const MyApp = ({ Component, pageProps, ...props }: Props) => {
  const getLayout = Component.getLayout ?? ((page: ReactNode) => page);
// const router=useRouter()
  return <><GlobalProvider {...props}>
    <style jsx global>{`
        * {
          font-family: ${Wix.style.fontFamily} !important; 
        }
      `}</style>
    <Head>
      <title>
        Admin
      </title>
      <meta name="viewport" content="initial-scale=1.0, width=device-width" />
      <meta name="description" content="Shared Admin" />
      <link rel="icon" href={favicon.src} />
    </Head>
   
    <Script src="https://apis.google.com/js/platform.js?onload=init" async defer></Script>
    {/* <Script id="my-script" strategy="lazyOnload" src={`https://www.googletagmanager.com/gtag/js?id=${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}`} />
    <Script id="my-script" strategy="lazyOnload">
      {`
                    window.dataLayer = window.dataLayer || [];
                    function gtag(){dataLayer.push(arguments);}
                    gtag('js', new Date());
                    gtag('config', '${process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS}', {
                    page_path: window.location.pathname,
                    });
                `}
    </Script> */}
    {/* <Script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=a4ad6878-0383-44e3-95ff-016c73474280"> </Script> */}
    <Script async defer src="https://connect.facebook.net/en_US/sdk.js"></Script>
    <ChatProvider {...props}>
    {getLayout(
      <Component {...pageProps} />
    )}
    </ChatProvider>
  </GlobalProvider >
  </>

}

MyApp.getInitialProps = async (context: any) => {
  const accessToken = parseCookies(context.ctx)[COOKIES_USER_ACCESS_TOKEN]
  try {
    if (accessToken) {
      henceforthApi.setToken(accessToken)
      let apiRes = await henceforthApi.Auth.profile()
      const user_info = apiRes
      console.log("user_info getInitialProps called******", user_info);
      return { user_info: { ...user_info, access_token: accessToken } }
    }
    return { user_info: null }

  } catch (error: any) {
    
    return { user_info: { access_token: accessToken } }
  }
}

export default MyApp
