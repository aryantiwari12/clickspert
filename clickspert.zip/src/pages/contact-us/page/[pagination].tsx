'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Divider, Form, Input, Modal, Select, Space, Table, Typography } from 'antd';
import { MoreOutlined, DownloadOutlined, ExclamationCircleFilled } from '@ant-design/icons'
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import henceofrthEnums from '@/utils/henceofrthEnums';
import dynamic from 'next/dynamic';
import ColumnsType from '@/interfaces/ColumnsType';
import { ContactUsDetailsInterface } from '@/interfaces';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import Serviceimg from '../../../assets/images/banner.png'
import Image from 'next/image';
import Link from 'next/link';
import CountryCode from '@/utils/CountryCode.json'
import Placeholder from '@/assets/images/placeholder.png'
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
const { Option } = Select
const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const { Search } = Input;
interface DataType {
    key: React.Key;
}
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const ContactPage: Page = (props: any) => {
    const { confirm } = Modal;
    const [value, setValue] = React.useState<RangeValue>(null)
    const [form] = Form.useForm()
    const router = useRouter()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const { socketHitType } = React.useContext(ChatContext)
    const [country, setCountry] = React.useState('')
    const [exportModal, setExportModal] = React.useState(false);
    const [state, setState] = React.useState({
        data: [{} as ContactUsDetailsInterface],
        count: 0
    })
    const [contactInfo, setContactInfo] = React.useState("") as any
    const [contactType, setContactType] = React.useState("")
    const onDelete = async (id: string) => {
        try {
            confirm({
                title: 'Delete',
                icon: <ExclamationCircleFilled />,
                content: 'Are you sure you want to delete?',
                okText: 'Delete',
                okType: 'danger',
                onOk: async () => {
                    setLoading(true)
                    let apiRes = await henceforthApi.ContactUs.delete(id)
                    Toast.success("User query deleted")
                    await initialise()
                },
                onCancel() { },
            });
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }
    const handleStatus = async (id: string, status: string) => {
        setLoading(true)
        try {
            let items = {
                status: status
            }
            let apiRes = await henceforthApi.ContactUs.edit(id, items)
            Toast.success(apiRes.message)
            await initialise()
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    const StatusItem = (res: any, index: any) => {
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.pending}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.pending} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.InquiryStatus.pending),
                        disabled: res?.status == 'PENDING' ? true : false
                    },
                    {
                        key: '12',
                        label: <Divider style={{ height: 2 }} plain className='m-0'></Divider>
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.resolved}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.resolved} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.InquiryStatus.resolved),
                        disabled: res?.status == 'RESOLVED' ? true : false
                    }
                ],
            },
            {
                key: '2',
                label: (
                    <Typography.Text >
                        Delete
                    </Typography.Text >
                ),
                onClick: () => onDelete(res._id),
            }
        ]
    }

    const prefixSelector = (
        <Form.Item noStyle>
            <Select
                prefixCls='country-code'
                showSearch
                value={country}
                defaultValue="+91"
                onChange={(e: any) => setCountry(e)} >
                {CountryCode.map((res: any) => <Option value={res.dial_code} key={res.dial_code}>{res.dial_code}</Option>)}
            </Select>
        </Form.Item>
    );

    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: <div className='user-detail d-inline-flex gap-2 align-items-center'>

                <Typography.Text><Link href={res?.vendor_id ? `/vendor/${res?.vendor_id}/view` : `/user/${res?.user_id}/view`} className='text-dark' style={{ textDecoration: "none", cursor: "pointer" }}>{res.name}</Link></Typography.Text>
            </div>,
            email: <Link href={res?.vendor_id ? `/vendor/${res?.vendor_id}/view` : `/user/${res?.user_id}/view`} className='text-dark' style={{ textDecoration: "none", cursor: "pointer" }}> {res?.email ?? "N/A"} </Link>,
            title: res?.subject ? res?.subject : "N/A",
            message: <p dangerouslySetInnerHTML={{ __html: res.description?.length ? res.description : "N/A" }} />,
            status:
                <div className={`${res.status === "PENDING" ? 'upcoming bg-theme' : 'upcoming bg-success'}`}>
                    <span>{res.status === henceofrthEnums.ContectUsStatus.pending ? 'Pending' : 'Resolved'}</span>
                </div>,
            action:
                <li>
                    <Tooltip title="Actions">
                        <Dropdown menu={{ items: StatusItem(res, index) }} trigger={['click']} placement="bottomRight">
                            <a onClick={(e) => e.preventDefault()}>
                                <Button shape='circle' className='border-0' htmlType='button'><HenceforthIcons.More /></Button>
                            </a>
                        </Dropdown>
                    </Tooltip>
                </li>
        }

    })

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }

    const onSearch = (value: string) => {
        onChangeRouter("search", String(value).trim())
    }
    const handlePagination = (page: number, pageSize: number) => {
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const handleCancelContactModal = () => {
        setIsModalOpen(false)
    }

    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.ContactUs.listing(urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }
    const getContact = async () => {
        try {
            let apiRes = await henceforthApi.ContactUs.getContactInfo()
            form.setFieldsValue(apiRes)
            setContactInfo(apiRes)
        } catch (error) {

        } finally {
        }
    }

    const editContact = async (values: any) => {
        try {
            setLoading(true)
            const data = {} as any
            if (contactType == 'Whatsapp') {
                data.whtsp_phone_no = +values?.whtsp_phone_no
                data.whtsp_country_code = + country
            }
            else {
                data.phone_no = +values.phone_no
                data.country_code = +country
            }
            const apiRes = await henceforthApi.ContactUs.editContactInfo(data)
            getContact()
            setIsModalOpen(false)
            setCountry("")
            Toast.success(apiRes.message)
        } catch (error) {

        }
        finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        getContact()
    }, [])
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.search, router.query.limit, socketHitType])
    console.log(contactInfo);

    const data = [
        {
            heading: 'Phone',
            text: `+${contactInfo?.country_code} ${contactInfo?.phone_no}`
        },
        {
            heading: 'Whatsapp',
            text: `+${contactInfo?.whtsp_country_code} ${contactInfo?.whtsp_phone_no}`
        }
    ]
    const [isModalOpen, setIsModalOpen] = useState(false);

    const showModal = (type: string) => {
        debugger
        setContactType(type)

        setIsModalOpen(true);
        if (type == 'Whatsapp') {
            setCountry(contactInfo?.whtsp_country_code)
        }
        else {
            setCountry(contactInfo?.country_code)
        }
        console.log(country);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <Fragment>
            <Head>
                <title>Contact</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Contact</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-between mb-3'>
                                <Typography.Title className='m-0 fw-bold' level={3}>Contact</Typography.Title>
                                <Button type="primary" htmlType="button" icon={<DownloadOutlined />} size={'large'} onClick={() => setExportModal(true)}>Export</Button>
                            </div>
                            <Row gutter={[15, 15]}>
                                {data.map((res, i) =>
                                    <Col key={i} span={24} md={12}>
                                        <div className="contact-card">
                                            <div className="flex-between">
                                                <Space direction='vertical' className='gap-1'>
                                                    <Typography.Text className='text-gray fw-bold'>{res.heading}</Typography.Text>
                                                    <Typography.Text className='fw-bold'>{res.text}</Typography.Text>
                                                </Space>
                                                <Button onClick={() => showModal(res?.heading)} className='bg-transparent border-0' shape='circle' icon={<HenceforthIcons.PencileIcon />}></Button>
                                            </div>
                                        </div>
                                    </Col>
                                )}
                            </Row>
                            {/* Search  */}
                            <div className='my-4'>
                                <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
                            </div>
                            {/* Table  */}
                            <div className='table-wrapper'>
                                <Table dataSource={dataSource} columns={ColumnsType.contactsUsColumns as any} pagination={false} scroll={{ x: '100%' }} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />

                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>

                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="ContactUs Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.ContactUs.export(start_date, end_date)
                        const exportData = apiRes?.data?.map((item: any, index: number) => {
                            return {
                                name: item.name,
                                email: item?.email ?? "N/A",
                                // message: <p dangerouslySetInnerHTML={{ __html: item.description?.length ? item.description?.split(",")?.join(" ") : "N/A" }} />,
                                status: item.status === henceofrthEnums.ContectUsStatus.pending ? 'Pending' : 'Resolved',
                            }
                        })
                        downloadCSV("ContactUs", exportData)
                        // Toast.success(apiRes.message)
                    } catch (error) {
                        // Toast.warn(error)
                    } finally {
                        setLoading(false)
                    }
                }} />

                <Modal footer={false} prefixCls='contact' centered={true} title={`Edit ${contactType == 'Whatsapp' ? 'Whatsapp' : 'Phone'}`} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <Form layout='vertical' size='large' form={form} onFinish={editContact}>
                        {/* <Form.Item className='my-3'>
                            <Input placeholder='Enter' />
                        </Form.Item> */}
                        <Form.Item
                            name={`${contactType == 'Whatsapp' ? 'whtsp_phone_no' : 'phone_no'}`}
                            label={`${contactType == 'Whatsapp' ? 'Whatsapp Number' : 'Phone Number'}`}
                            rules={
                                [
                                    () => ({
                                        validator(_, value) {
                                            // if (value) {
                                            if (isNaN(value)) {
                                                return Promise.reject("Phone has to be a number.");
                                            }
                                            // if (value.length > 12) {
                                            //   return Promise.reject("Please enter a valid number");
                                            // }
                                            if (value.length < 5) {
                                                return Promise.reject("Please enter a valid number");
                                            }
                                            if (!value) {
                                                return Promise.reject("Please enter a valid number");
                                            }
                                            else {
                                                return Promise.resolve();
                                            }
                                        },
                                    }),
                                ]
                            }
                        >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} maxLength={15} minLength={4} addonBefore={prefixSelector}
                                style={{ width: '100%' }} placeholder={`${contactType == 'Whatsapp' ? ' Enter whatsapp number' : 'Enter phone number'}`}
                                className='phone-input'
                            />
                        </Form.Item>
                        <Space className='justify-content-center w-100'>
                            <Button type='primary' loading={loading} htmlType='submit'>Save</Button>
                            <Button type='primary' ghost onClick={handleCancelContactModal}>Cancel</Button>
                        </Space>
                    </Form>
                </Modal>
            </section>

        </Fragment>
    )
}

ContactPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default ContactPage
