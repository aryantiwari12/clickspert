import { GlobalContext } from '@/context/Provider';
import MainLayout from '@/layouts/MainLayout';
import { PlusOutlined } from '@ant-design/icons';
// import { TweenOneGroup } from 'rc-tween-one';
import henceforthApi from '@/utils/henceforthApi';
import { Breadcrumb, Button, Card, Col, theme, Form, Input, Row, Select, Typography, notification, InputRef, Tag } from 'antd';
import React, { ReactNode, useContext, useState } from 'react'
import dynamic from 'next/dynamic';
import henceforthValidations from '@/utils/henceforthValidations';
const { TweenOneGroup } = {
  TweenOneGroup: dynamic(() => import("rc-tween-one").then(module => module.TweenOneGroup), { ssr: false }),
}

function Email() {
  const [form] = Form.useForm()
  const { loading, setLoading } = useContext(GlobalContext)
  const { Toast } = React.useContext(GlobalContext)
  const [emailNotification, setEmailNotification] = React.useState({
    data: [],
    count: 0
  })
  const getData = async () => {
    try {
      const apiRes = await henceforthApi.Notification.emailNotifications()
      setEmailNotification(apiRes)
      let items = {} as any
      apiRes.data.forEach((res: any) => {
        items[res._id] = res.email
      })
      form.setFieldsValue(items)
    } catch (error) {
     
    }
  }
  const handleSubmit = async (values: any) => {
    const data = []
    for (const key in values) {
      data.push({
        _id: key,
        admin_ids: values[key]
      })
    }
    try {
      setLoading(true)
      const apiRes = await henceforthApi.Notification.update({ notification: data })
      Toast.success(apiRes?.message)
    } catch (error) {
      Toast.error(error)
    }
    finally {
      setLoading(false)
    }
  }
  //  
  React.useEffect(() => {
    getData()
  }, [])
  React.useEffect(() => {
    // <script type="text/javascript">
 
    // </script>
  }, []);

 


  return (
    <>
      <section>
        <Row gutter={[20, 20]}>
          <Col span={24} sm={16} md={18} lg={18} xl={14} >
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Management</Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Email</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div className='flex-center mb-4'>
                <Typography.Title className='m-0 fw-700' level={3}>Email Notification</Typography.Title>
              </div>
              <Form size='large' form={form} onFinish={handleSubmit}>
                <Row justify={'space-between'}>
                  {emailNotification.data?.length ? emailNotification.data.map((item: any, index: number) =>
                    <React.Fragment key={item._id}>
                      <Col span={6}>
                        <Typography.Title level={4}>{item.day} </Typography.Title>
                      </Col>
                      <Col span={16}>
                        <Form.Item name={item._id}rules={[() => ({
                          validator(_, value) {
                            console.log(value,"valuesss");
                            const ind=value.findIndex((item:any)=>!henceforthValidations.email(item))
                            console.log(ind,"index");
                            if (value && ind != -1) {
                              if (!henceforthValidations.email(value[ind])) {
                                return Promise.reject("Please enter correct email");
                              }
                              return Promise.resolve();
                            }
                            else {
                              return Promise.resolve();
                            }
                          },
                        })]}>
                          <Select
                            mode="tags"
                            open={false}
                            style={{ width: '100%' }}
                            placeholder="Tags Mode"
                          />
                        </Form.Item>

                      </Col>
                    </React.Fragment>):""}
                </Row>
                <Button type='primary' htmlType="submit" loading={loading} block className='mt-4'>Update</Button>
              </Form>
            </Card>
          </Col>
        </Row>


      </section>
    </>
  )
}
Email.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);
export default Email