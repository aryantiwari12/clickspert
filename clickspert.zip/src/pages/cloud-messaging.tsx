import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Form, Radio, Typography } from 'antd';
import dynamic from "next/dynamic";
import DebounceSelect from '@/utils/components/DebounceSelect';
import henceofrthEnums from '@/utils/henceofrthEnums';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';

const { Row, Col, Card, Button, Image } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}


const { TextArea } = Input;

const ReactQuill = dynamic(import('react-quill'), { ssr: false })

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

interface UserValue {
    label: string;
    value: string;
}

const Notification: Page = (props: any) => {
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const router = useRouter()
    const [notificationTo, setNotificationTo] = React.useState(henceofrthEnums.Selects.all)
    const [notificationType, setNotificationType] = React.useState(henceofrthEnums.NotificationType.push)
    const [fieldvalue, setFieldValue] = useState<UserValue[]>([]);
    const [form] = Form.useForm();

    const onFinish = async (values: any) => {
        debugger
        console.log(values ,"values");
        return
        try {
            let items = {
                selects: values.to,
                notification_type: values.type,
                subject: String(values.subject).trim(),
                description: String(values.text).trim()
            } as any
            if (!items.subject) {
                return Toast.warn("Subject should not be empty")
            }
            if (!items.description) {
                return Toast.warn("Description should not be empty")
            }
            if (values.to == henceofrthEnums.Selects.selected) {
                items['send_to'] = values?.to_user.map((res: UserValue) => res.value)
            }
            setLoading(true)
            let apiRes = await henceforthApi.Notification.create(items)
            console.log('apiRes------: ', apiRes);
            Toast.success("Notification Sent")
            form.resetFields()
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setLoading(false)
        }

    };

    async function fetchUserList(username: string): Promise<UserValue[]> {
        let urlSearchParam = new URLSearchParams()
            urlSearchParam.set('search', username.trim())
            urlSearchParam.set('limit', '20')
            urlSearchParam.set('pagination', '0')
        let apiRes = await henceforthApi.User.listing(urlSearchParam.toString(),10)
        return apiRes.data.map((res: any) => {
            return {
                label: res.name,
                value: res.email
            }
        })
    }


    return (
        <Fragment>
            <Head>
                <title>Cloud Messaging</title>
                <meta name="description" content="Cloud Messaging" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item className='text-decoration-none'>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Cloud Messaging</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title className='m-0 fw-bold' level={3}>Cloud Messaging</Typography.Title>
                            </div>
                            <div className='accordion-wrapper'>
                                <Form name="notification_add" className="notification-form" form={form} initialValues={{ to: notificationTo, type: notificationType }} onFinish={onFinish} scrollToFirstError layout="vertical">
                                    {/* Select users by emails */}
                                    <Form.Item name="to" label="Send notification to :" rules={[{ required: true, message: 'Please user to' }]}>
                                        <Radio.Group onChange={(e) => setNotificationTo(e.target.value)} value={notificationTo}>
                                            <Radio value={henceofrthEnums.Selects.all}>All Users</Radio>
                                            <Radio value={henceofrthEnums.Selects.selected}>Only selected users</Radio>
                                        </Radio.Group>
                                    </Form.Item>
                                    {notificationTo == henceofrthEnums.Selects.selected &&
                                        <Form.Item name="to_user" label="Select users by their Email" rules={[{ required: true, message: 'Select at least one user to Send notification' }]}>
                                            <DebounceSelect
                                                mode="multiple"
                                                value={fieldvalue}
                                                placeholder="Search users"
                                                fetchOptions={fetchUserList}
                                                onChange={(newValue) => {
                                                    setFieldValue(newValue as UserValue[]);
                                                }}
                                                style={{ width: '100%' }}
                                            />
                                        </Form.Item>}
                                    {/* Select notification type */}
                                    <Form.Item name="type" label="Send notification via :" rules={[{ required: true, message: 'Please notify to' }]}>
                                        <Radio.Group onChange={(e) => setNotificationType(e.target.value)} value={notificationType} >
                                            <Radio value={henceofrthEnums.NotificationType.push}>Push</Radio>
                                            <Radio value={henceofrthEnums.NotificationType.email}>Email</Radio>
                                        </Radio.Group>
                                    </Form.Item>
                                    {/* Subject  */}
                                    <Form.Item name="subject" rules={[{ required: true, whitespace: true, message: 'Please enter subject' }]} label="Subject">
                                        <Input placeholder="Subject" />
                                    </Form.Item>
                                    {/* Description  */}
                                    <Form.Item name="text" rules={[{ required: true, whitespace: true, message: 'Please enter description' }]} label="Description">
                                        {notificationType == henceofrthEnums.NotificationType.email ?
                                            <ReactQuill theme="snow" placeholder="Write Description here..." /> :
                                            <TextArea rows={4} placeholder="Write Description here..." maxLength={120} showCount />}
                                    </Form.Item>
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit" size={'large'} loading={loading} disabled={loading}>
                                        Send Notification
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

Notification.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}


export default Notification
