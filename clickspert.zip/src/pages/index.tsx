import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useCallback, useContext, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Form, Modal, Select, Table, Typography, } from 'antd';
import HenceforthIcons from '@/components/HenceforthIcons';
import Graph from '@/components/Graph';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import { EyeOutlined, LoginOutlined, } from "@ant-design/icons"
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import { GlobalContext } from '@/context/Provider';
import henceofrthEnums from '@/utils/henceofrthEnums';
import DashboardUser from '@/components/common/DashboardUser';
import dayjs from 'dayjs';
import SearchPage from '@/components/common/SearchInput';
import ModalAssign from '@/components/common/ModalAssign';
import ChatProvider, { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip, Image } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
  // Select: dynamic(() => import("antd").then(module => module.Select), { ssr: false }),
  Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
interface DataType {
  key: string;
  srno: number;
  name: ReactNode;
  userid: ReactNode;
  Order_Id: ReactNode;
  Service_Name: ReactNode;
  Area: ReactNode;
  date: ReactNode;
  Recurring: ReactNode;
  PromoCode: ReactNode;
  Amount: ReactNode;
  actions: ReactNode;
  city: ReactNode,
  // phone: number;
  transaction: ReactNode;
  subscription: ReactNode;
}
interface DataType1 {
  key: string;
  srno: number;
  name: ReactNode;
  email: string;
  phone: any;
  actions: ReactNode;
}
let DashboardData = [] as any
const Home: Page = (props: any) => {
  console.log(props, "props");

  const router = useRouter()
  const { userInfo } = React.useContext(GlobalContext)
  const {socketHitType}=useContext(ChatContext)
  const [isModalOpenAssign, setIsModalOpenAssign] = useState(false);
  const [state, setState] = React.useState({
    data: [],
    vendor_count: 0,
    user_count: 0,
    ongoing_order_count: 0,
    success_order_count: 0
  })
  const [userList, setUserList] = useState({
    data: [],
    count: 0
  })
  const [graphState, setGraphState] = React.useState({
    data: [],
    total_count: 0,
    graph_difference: {
      percentage_change: ""
    }
  })
  const [subService, setsubService] = React.useState({
    data: [] as any,
    total_count: 0
  })
  const [data, setData] = useState({
    vendor: { data: props?.vendorRequest?.data as any, count: props?.vendorRequest?.count },
    order: { data: props?.orderRequest?.data as any, count: props?.orderRequest?.count },
  })

  const [loading, setLoading] = React.useState(false)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [card, setCard] = useState([]) as any
  const [assignlist, setAssignList] = useState({
    data: [] as any
  })
  const [vendor, setVendor] = useState<any>('')
  const [orderId, setOrderId] = useState('')
  const array = [henceofrthEnums.GraphType.Yearly, henceofrthEnums.GraphType.Monthly, henceofrthEnums.GraphType.Weekly, henceofrthEnums.GraphType.Daily]
  const [graphType, setGraphType] = React.useState(henceofrthEnums.GraphType.Yearly.toUpperCase() as string)
  const DashboardList = async () => {
    try {
      let apiRes = await henceforthApi.Dashboard.dashBoard()

      setState(apiRes)
    } catch (error) {
      console.log(error);

    }
  }
  const subServiceList = async () => {
    try {
      let apiRes = await henceforthApi.Dashboard.subServiceList()
      apiRes?.data?.unshift({ _id: "", name: "ALL" })
      setsubService(apiRes)
    } catch (error) {
      console.log(error);

    }
  }
  console.log(router);

  const handleCancelAssign = () => {
    setIsModalOpenAssign(false);
  };
  const capitalize = (status: string) => {
    const data = status?.slice(0, 1)?.charAt(0)?.toUpperCase() + status?.slice(1, 50)?.toLowerCase()
    return <span>{data}</span>
  }


  const showModal = (_id: any) => {
    console.log(_id, "anyy");
    setOrderId(_id)
    setIsModalOpen(true);
  };

  const dataSource: DataType[] = data?.order?.data?.map((item: any, index: number) => {
    const  street_address=item?.address ? `${item?.address?.house_no ? `${item?.address?.house_no} , ` : " "}${item?.address?.city ? `${item?.address?.city} , ` : " "}${item?.address?.postal_code ? `${item?.address?.postal_code } , ` :  ""}${item?.address?.state ? `${item?.address?.state} , ` : " "}${item?.address?.country ? `${item?.address?.country} , ` : " "}${capitalize(item?.address?.address_type ? `${item?.address?.address_type} , ` : "")}` : "N/A"
    return {
      key: index + 1,
      srno: index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center'>
        <div className="user-detail-img">
          <img src={henceforthApi.FILES.imageOriginal(item?.user_id?.image, user?.src)} alt='img' />
        </div> <Typography.Text>{item?.user_id?.name}</Typography.Text></div>,
      orderid: <span>{item?.order_id ? `${item?.order_id}` : "N/A"}</span>,
      servicename: <div className='service-detail d-inline-flex gap-2 align-items-center'>
        <div className="service-detail-img">
          <img src={henceforthApi.FILES.imageSmall(item?.sub_service_id?.image) || user.src} alt='img' />
        </div>
        <div>
          <Typography.Text className='text-gray fw-700'>{item?.service_id?.name || 'N/A'}</Typography.Text><br />
          <Typography.Paragraph className='mb-0'>{item?.sub_service_id?.name}</Typography.Paragraph>
        </div>
      </div>,
      city: item?.address?.city ?? "N/A",
      area: <Tooltip title={street_address}>{street_address?.slice(0, 20) + "..."}</Tooltip>,
      date: dayjs(item?.date).format('ddd, MMM DD - hh:mm a'),
      recurring: <span>{item?.recurring ?? "N/A"}</span>,
      promoCode: <span>{item?.promo_id ? + item?.promo_id : "N/A"}</span>,
      amount: <span>{item?.total_amount ? `AED ${item?.total_amount}` : "N/A"}</span>,
      actions: <span>
        {!item?.is_quotation_based || item?.is_quotation_status == "ACCEPTED" ? <Button size='large' type='primary' onClick={() => showModal(item._id)}>Assign Vendor</Button> : ""}
        {item?.is_quotation_based && item?.is_quotation_status === "null" ? <Button size='large' type='primary' onClick={() => router.push(`/order-request/${item?._id}/quotation`)}>Send Quotation</Button> : ""}
        {/* <Button type='primary'  className='me-2' onClick={() => showModal(item._id)}>Assign Vendor</Button> */}
        <Link href={`/order-request/${item._id}/view`}><Button type='primary' className='bg-transparent' shape='circle'><HenceforthIcons.ViewTwo /></Button></Link>
      </span>
    }
  })

  const DashboardCards = useCallback(() => {
    const Cards = [] as any
    if (state?.user_count) {
      Cards?.push({
        cardBackground: "#FFF5CC",
        iconBackground: " linear-gradient(135deg, rgba(255, 171, 0, 0) 0%, rgba(255, 171, 0, 0.24) 97.35%)",
        icon: <HenceforthIcons.Users />,
        textColor: "#B76E00",
        title: state?.user_count,
        count: "Users",
        link: "/user/page/1"
      })
    }
    if (state?.vendor_count) {
      Cards?.push({
        cardBackground: "#CAFDF5",
        iconBackground: "linear-gradient(135deg, rgba(0, 184, 217, 0) 0%, rgba(0, 184, 217, 0.24) 97.35%)",
        icon: <HenceforthIcons.Product />,
        textColor: "#006C9C",
        title: state.vendor_count,
        count: "Vendors",
        link: "vendor/page/1"
      })
    }
    if (state?.success_order_count) {
      Cards?.push({
        cardBackground: "#FFE9D5",
        iconBackground: "linear-gradient(135deg, rgba(255, 86, 48, 0) 0%, rgba(255, 86, 48, 0.24) 97.35%)",
        icon: <HenceforthIcons.Delete />,
        textColor: "#B71D18",
        // title: state.product_count,
        title: state?.success_order_count,
        count: "Success Orders"
      })
    }
    if (state?.ongoing_order_count) {
      Cards?.push({
        cardBackground: "#C8FACD",
        iconBackground: "linear-gradient(135deg, rgba(0, 171, 85, 0) 0%, rgba(0, 171, 85, 0.24) 97.35%)",
        icon: <HenceforthIcons.RedOrder />,
        textColor: "#007B55",
        title: state?.ongoing_order_count,
        count: "Ongoing Orders"
      })
    }
    return Cards
  }, [state ,socketHitType])
 
  const dataSource1: DataType1[] = userList?.data?.map((item: any, index: number) => {
    return {
      key: item?._id,
      srno: index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center'>
        <div className="user-detail-img">
          <img src={henceforthApi.FILES.imageOriginal(item?.image, user?.src)} alt='img' />
        </div> <Typography.Text>{item?.name || "N/A"}</Typography.Text></div>,
      phone: item?.phone_no ? '+' + item?.country_code + "-" + item?.phone_no : "N/A",
      email: item?.email ?? "N/A",
      actions: <ul className='m-0 list-unstyled d-flex'><li>
        <Link href={`/user/${item?._id}/view`}><Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button></Link></li>
        <Tooltip title="Login As User"><li>
          {/* <Link target="_blank" href={`${process.env.NEXT_PUBLIC_WEBSITE_URL}/login/1/${userInfo?.access_token}`}>
            <Button className='bg-transparent' type='primary' shape='circle'><HenceforthIcons.LeftArrow /></Button>
          </Link> */}
        </li>
        </Tooltip>
      </ul>
    }
  })
  
  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const initialise = async () => {
    try {
      setLoading(true)
      let apiRes = await henceforthApi.Dashboard.userListing(5)
      setUserList(apiRes)
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false)
    }
  }
  const handlechange = async (_id: any) => {
    console.log(_id, "_id");

    try {
      let apiRes = await henceforthApi.Vendor.getById(_id)
      setVendor(apiRes)
      setIsModalOpen(false)
    } catch (error) {

    }
  }
  const assignModal = () => {
    setIsModalOpenAssign(true)
  }
  const initialiseAssign = async () => {
    try {
      let query = router.query
      let urlSearchParam = new URLSearchParams()
      if (query.search) {
        urlSearchParam.set('search', router.query.search as string)
      }
      // if (query.service_id) {
      //   urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
      // }
      if (query.sub_service_id) {
        urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
      }
      let apiRes = await henceforthApi.Order.listingVendor(urlSearchParam.toString())
      setAssignList(apiRes)
    } catch (error) {

    }
  }
  const typeChange = async (type: string) => {
    onChangeRouter("type", type)
    console.log("typeChange", type)
    // if (type === graphType) return
    await handleProductGraph(type)
    setGraphType(type)
  }
  const filterService = (e: any) => {
    if (e) {
      router.replace({
        query: { ...router.query, ['sub_service_id']: e }
      })
    }
    else {
      delete router.query.sub_service_id
      router.replace({
        query: { ...router.query }
      })
    }
  }

  const onChangeRouter = (key: string, value: string) => {
    router.replace({
      query: { ...router.query, [key]: value }
    })
    console.log("router query", router.query);
  }

  const handleProductGraph = async (type: string) => {
    setLoading(true)
    try {
      const query = router.query;
      let urlSearchParam = new URLSearchParams()
      urlSearchParam.set('type', type)
      if (query.sub_service_id) {
        urlSearchParam.set('sub_service_id', String(router.query.sub_service_id))
      }
      let resApi = await henceforthApi.Graph.create(urlSearchParam.toString())
      console.log("resapi", resApi.data);
      setGraphState(resApi)
    } catch (error) {
      console.log(error)
    }
    finally {
      setLoading(false)
    }
  }
  React.useEffect(() => {
    DashboardList();
    subServiceList()
  }, [socketHitType])
  React.useEffect(() => {
    initialise()
  }, [router.query.pagination, router.query.limit ,socketHitType])

  React.useEffect(() => {
    handleProductGraph(router.query.type as string || henceofrthEnums.GraphType.Yearly?.toUpperCase())
  }, [router.query.type, router.query.sub_service_id])
  React.useEffect(() => {
    initialiseAssign()
  }, [router.query.search])
  return (
    <Fragment>
      <Head>
        <title>Dashboard</title>
        <meta name="description" content="Homepage desc" />
      </Head>
      <section>
        {/* <div className="container-fluid"> */}
        <Row gutter={[20, 20]} className="mb-4">
          {DashboardCards()?.map((data: any, index: number) => {
            console.log(data);

            return (
              <Col span={24} md={12} lg={8} xl={6} className="gutter-row" key={index} >
                <Link href={data?.link ? data?.link : '#'} className='text-decoration-none'>
                  <Card className='dashboard-widget-card text-cente h-100 border-0 py-4' style={{ background: data?.cardBackground }} >
                    <div className='d-flex align-items-center justify-content-start ms-3'>
                      <div className='dashboard-widget-card-icon rounded-circle d-flex align-items-center justify-content-center' style={{ background: data?.iconBackground }}>
                        {data?.icon}
                      </div>
                      <div className='dashboard-widget-card-content ms-4'>
                        <Typography.Title level={3} className='m-0 mb-1 fw-bold' style={{ color: data?.textColor }} >{data?.title}</Typography.Title>
                        <Typography.Paragraph className="m-0" style={{ color: data?.textColor }}>{data?.count}</Typography.Paragraph>
                      </div>

                    </div>
                  </Card>
                </Link>
              </Col>
            )
          })}
        </Row>

        {/* Graph  */}
        <Row gutter={[20, 20]} className='mb-3'>
          <Col span={24}>
            <Card className='common-card'>
              <div className='flex-center flex-column flex-md-row mb-3 mb-md-0'>
                <div className='mb-4'>
                  <Typography.Title level={3} className='m-0 mb-2 fw-bold'>Sales Graph</Typography.Title>
                  <Typography.Paragraph className='m-0'>{`(+${graphState?.graph_difference?.percentage_change}%)`} than last year</Typography.Paragraph>
                </div>
                <div className='d-flex flex-wrap gap-2'>
                  <div>
                    <Select
                      status='warning'
                      size="middle"
                      defaultValue="All"
                      onChange={(e: any) => filterService(e)}
                      style={{ width: 200 }}
                      options={subService?.data?.map((res: any) => {
                        return { value: res._id, label: res.name }
                      })}
                    />
                  </div>
                  <div>
                    <Select
                      status='warning'
                      size="middle"
                      defaultValue="Yearly"
                      onChange={(e: any) => typeChange(e)}
                      style={{ width: 120 }}
                      options={array.map((res) => {
                        return {
                          value: res.toUpperCase(), label: res.replace('_', ' ')
                        }
                      })}
                    />
                  </div>
                </div>

              </div>
              <div className='graph-wrapper'>
                <Graph data={graphState} />
              </div>
            </Card>
          </Col>
        </Row>

        {/* <Divider type="vertical" /> */}
        <Row gutter={[20, 20]} className="mb-3">
          <Col span={24}>
            <Card className='common-card'>
              <Typography.Title level={3} className='m-0 mb-4 fw-bold'>Recent Order Request</Typography.Title>
              <Table dataSource={dataSource} columns={ColumnsType.userColumns as any} pagination={false} scroll={{ x: '100%' }} />
              <div className='text-end mt-4'><a className="border-0 text-dark fw-semibold text-decoration-none text-dark"><Link href={"/order-request/page/1"} className="text-dark" style={{ textDecoration: "none" }}>View All<HenceforthIcons.LeftArrowArchive /></Link></a></div>
            </Card>
          </Col>
        </Row>
        <Row className="mb-3">
          <Col span={24}>
            <Card className='common-card'>
              <Typography.Title level={3} className='m-0 mb-4 fw-bold'>Recent Users</Typography.Title>
              <Table dataSource={dataSource1} columns={ColumnsType.userColumns1} pagination={false} scroll={{ x: '100%' }} />
              <div className='text-end mt-4'><a className="border-0 text-dark fw-semibold text-decoration-none"><Link href={`/user/page/1`} className='text-dark' style={{ textDecoration: "none" }}>{userList?.count > 5 && "View All"}</Link> <HenceforthIcons.LeftArrowArchive /></a></div>
            </Card>
          </Col>
        </Row>
        <Row gutter={[20, 20]} className="mb-3">
          <DashboardUser vendor={props?.vendorRequest} setdata={setData} />
        </Row>
        {/* </div> */}
      </section>
      <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
        <div className='text-center'>
          <Typography.Title level={3} className='fw-700  mt-2'>Assign Vendor</Typography.Title>
          <Form size='large' layout='vertical'>

            <Row gutter={[12, 12]}>
              <Col span={24}>
                <Form.Item>
                  <SearchPage placeholder="Search" />
                </Form.Item>
              </Col>
              {/* <Col span={24} md={12}>
                <Form.Item className='mb-0'>
                  <Select placeholder='Select services' className='text-start'>
                    <Select.Option>a</Select.Option>
                    <Select.Option>b</Select.Option>
                    <Select.Option>c</Select.Option>
                  </Select>
                </Form.Item>
              </Col>
              <Col span={24} md={12}>
                <Form.Item className='mb-0'>
                  <Select placeholder='Select subservice' className='text-start'>
                    <Select.Option>a</Select.Option>
                    <Select.Option>b</Select.Option>
                    <Select.Option>c</Select.Option>
                  </Select>
                </Form.Item>
              </Col> */}
              {assignlist?.data.map((res: any, index: number) => {
                return (
                  <Col span={24} md={12} key={index}>
                    <ul className='modal-list'>
                      <li onClick={() => {
                            handlechange(res._id);
                            setTimeout(() => {
                              assignModal()
                            }, 1000);
                          }}>
                        <div className='user-detail d-inline-flex gap-2 align-items-center'>
                          <div className="user-detail-img" role='button'>
                            <img src={henceforthApi.FILES.imageSmall(res.image) || user.src} alt='img' />
                          </div>
                          <Typography.Text role='button' >{res.name || 'N/A'}</Typography.Text>
                        </div>
                      </li>
                    </ul>
                  </Col>
                )
              })}
            </Row>
          </Form>
        </div>
      </Modal>
      <ModalAssign isModalOpenAssign={isModalOpenAssign} setIsModalOpenAssign={setIsModalOpenAssign} handleCancelAssign={handleCancelAssign} vendor={vendor} orderId={orderId} initialise={initialise} />
    </Fragment>
  )
}

Home.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export default Home;

export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    let apiRes = await henceforthApi.Dashboard.vendorListing(5)
    let apiResponse = await henceforthApi.Dashboard.orderListing(5)
    let data = apiRes
    return { props: { vendorRequest: { ...data }, orderRequest: { ...apiResponse } } };
  } catch (error) {
    return {
      props: {}
    }
  }

}
