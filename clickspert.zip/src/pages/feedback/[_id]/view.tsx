import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Button, Card, Col, Form, Input, Modal, Row, Typography } from 'antd';
import Link from 'next/link';
import React, { Fragment, ReactNode, useState } from 'react'
import OrderDetailImg from '../../../assets/images/order-detail-img.png'
import Image from 'next/image';
import Star from '../../../assets/svg/star.svg'
import Head from 'next/head';
import { GetServerSideProps } from 'next';
import placeholder from '@/assets/images/placeholder.png'
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
const ViewFeedback = (props: any) => {
    console.log(props, "props");
    const [state, setState] = useState(props.data)
    const router = useRouter()
    const [isModalOpen, setIsModalOpen] = useState(false);
    const {Toast,loading,setLoading } = React.useContext(GlobalContext)
    const [form] = Form.useForm();
    
    const createReply = async (values:any) => {
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Feedback.reply(`_id=${router.query._id}&reply_message=${values.reply_message}`)
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        }finally{
            setLoading(false)
            form.resetFields()
            setIsModalOpen(false)

        }
    }

    const showModal = () => {
        setIsModalOpen(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    return (
        <Fragment>
            <Head>
                <title>Review</title>
                <meta name="description" content="Users" />
            </Head>
            <Row gutter={[20, 20]} className="mb-4">
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='mb-4'>
                            <Breadcrumb separator=">">
                                <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                                <Breadcrumb.Item><Link href="/feedback/page/1" className='text-decoration-none'>Review</Link></Breadcrumb.Item>
                                <Breadcrumb.Item className='text-decoration-none'>Review details</Breadcrumb.Item>
                            </Breadcrumb>
                        </div>
                        {/* Title  */}
                        <div>
                            <Typography.Title level={3} className='mb-4 fw-bold'>Review Detail</Typography.Title>
                        </div>

                        <div className='order-detail-img'>
                            <img src={henceforthApi.FILES.imageSmall(state?.sub_service?.image) || placeholder.src} alt='img' />

                        </div>
                        <div className='flex-center mt-3 '>
                            <div>
                                <Typography.Title level={4} className='mb-1 fw-bold'>{state?.sub_service?.name ?? 'N/A'}</Typography.Title>
                                <p className='m-0'><span className='text-gray'>Order Id:</span><span className='fw-600'> {`${state?.order_unique_id}` ?? 'N/A'}</span></p>
                            </div>
                            <div>
                                <Button type='primary' size='large' onClick={() => router.push(`/orders/${router.query._id}/view`)}>View Order Details</Button>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>User details</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-profile user-detail'>
                                    <img src={henceforthApi.FILES.imageSmall(state?.user?.image) || placeholder.src} alt='img' />
                                </div>
                                <p className='m-0'>{state?.user?.name || 'N/A'}</p>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Vendor details</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-detail d-flex align-items-center gap-2'>
                                    <Avatar
                                        style={{ backgroundColor: '#ECC263' }}
                                        size={{ xs: 60, sm: 60, md: 60, lg: 80, xl: 80, xxl: 80 }}
                                        src={henceforthApi.FILES.imageSmall(state?.vendor?.image) || placeholder.src}
                                    >
                                    </Avatar>
                                    <p className='m-0'>{state?.vendor?.name ?? 'N/A'}</p>

                                </div>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='feedback'>
                            <div className="flex-center">
                                <Typography.Title level={5} className='mb-3 fw-bold'>User Review</Typography.Title>
                                <Button type="primary" htmlType='button' size='large' className='px-4' onClick={showModal}><span className='text-dark'>Reply</span></Button>
                            </div>
                            <div className='d-flex align-items-center gap-1 mb-3'>
                                <Image src={Star} alt='img' />
                                <span className='text-theme fw-700'>{state?.rating_number ?? 'N/A'}</span>
                            </div>
                            <div>
                                <p className='text-gray mb-2'>Review message:</p>
                                <p>{state?.description || 'N/A'}</p>
                            </div>
                        </div>
                    </Card>
                </Col>
                <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Reply</Typography.Title>
                        <Form size='large' form={form} layout='vertical' onFinish={createReply} className='mt-2'>
                            <Form.Item name="reply_message" label='Reply' rules={[{ required: true,message:"Please Enter Reply" }]} >
                                <Input placeholder='Enter your Reply' className='border-0' />
                            </Form.Item>
                            <Form.Item className='mb-2 mt-4'>
                                <Button type='primary' htmlType='submit' block loading={loading}><span className='text-white'>Submit</span></Button>
                            </Form.Item>
                        </Form>
                    </div>
                </Modal>
            </Row>
        </Fragment>
    )
}
ViewFeedback.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
export const getServerSideProps: GetServerSideProps = async (context) => {
    try {
        let apiRes = await henceforthApi.Feedback.getById(context.query._id as string)
        let data = apiRes
        return { props: { data } };
    } catch (error) {
        return {
            props: {}
        }
    }

}
export default ViewFeedback