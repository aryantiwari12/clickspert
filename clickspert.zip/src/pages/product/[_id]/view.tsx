import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Image, Modal, Space, Switch, Typography, Upload } from 'antd';
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons';
import { EditFilled, DeleteFilled, EyeOutlined } from '@ant-design/icons'
import type { RcFile, UploadChangeParam, UploadFile, UploadProps } from 'antd/es/upload/interface';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import { ProductDetailsInterface } from '@/interfaces';
const { Row, Col, Card, Button, Spin, Popconfirm } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Spin: dynamic(() => import("antd").then(module => module.Spin), { ssr: false }),
    Popconfirm: dynamic(() => import("antd").then(module => module.Popconfirm), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const uploadButton = (
    <div>
        <PlusOutlined />
        <div style={{ marginTop: 8 }}>Upload</div>
    </div>
);

const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    })

const Product: Page = (props: any) => {
    const router = useRouter()
    const { userInfo, Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [visibleData, setVisibleData] = React.useState(false);
    const [state, setState] = useState<ProductDetailsInterface>({
        images: [],
        name: "",
        category_id: {
            name: "",
            _id: ""
        },
        is_visible: false,
        description: "",
        regular_price: 0,
        sale_price:0,
        discount: 0,
        is_deleted: false,
    })
    const [imageUpload, setImageUpload] = React.useState(false)
    const [deleteLoading, setDeleteLoading] = React.useState(false);
    const [visibilityLoading, setVisibilityLoading] = React.useState(false);

    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');

    const onChangeToggle = async (event:any) => {
        console.log("onChangeToggle called", event);
        try {
            setVisibilityLoading(true)
            let apiRes = await henceforthApi.Products.visibility(String(router.query._id))
            setVisibleData(apiRes.is_visible)
            Toast.success(apiRes.is_visible == true ? "Visibility ON" : "Visibility OFF")
            console.log("visible called", apiRes);
        } catch (error) {
            console.log(error)
        }
        finally {
            setVisibilityLoading(false)
        }
    }


    const onHandleImageChange: UploadProps['onChange'] = async (info: UploadChangeParam<UploadFile>) => {
        console.log('info called');
        setImageUpload(true)
        try {
            let image: Array<any> = []
            await Promise.all((info.fileList.map(async (res) => {
                console.log('res ->', res);
                if (res.originFileObj) {
                    let { file_name } = await henceforthApi.Common.uploadFile('file', res.originFileObj)
                    console.log('if res originFileObj --->', res.originFileObj, ' size', image.length);
                    image.push(file_name)
                } else {
                    console.log('else res --->', res.uid, ' size', image.length);
                    image.push(res.uid)
                }
                console.log('end', ' size', image?.length);

                if (image?.length) {
                    let items = {
                        image: image
                    }
                    await henceforthApi.Products.edit(String(router.query._id), items)
                }
            })))
            setState({
                ...state,
                images: image
            })
        } catch (error) {
            console.log(error)
        } finally {
            setImageUpload(false)
        }
    };
    const handleCancel = () => setPreviewOpen(false);

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
    };

    const handleDelete = async () => {
        try {
            setDeleteLoading(true);
            let id = String(router.query._id)
            let apiRes = await henceforthApi.Products.delete(id)
            router.push('/product/page/1')
        } catch (error) {
            console.log(error)
        } finally {
            setDeleteLoading(false);
        }
    }

    const initialize = async (id: string) => {
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Products.getById(id)
            console.log("Product initialize", apiRes);
            setState(apiRes)
            setVisibleData(apiRes.is_visible)
        } catch (error) {
            console.log(error)
        }
        finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        let id = router.query._id
        if (id) {
            initialize(id as string)
        }
    }, [])

    return (
        <Fragment>
            <Head>
                <title>{props?.title}</title>
                <meta name="description" content="Product" />
            </Head>
            <section className='product-edit'>
                <Row gutter={[20, 20]} className="mb-3">
                    <Col span={24}>
                        <Card className='common-card-transparent border-0'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/product/page/1" className='text-decoration-none'>Products</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>{state?.name}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                        </Card>
                    </Col>
                </Row>
                <Row gutter={[20, 20]}>
                    <Col xs={24} xl={17} xxl={18}>
                        {/* Title  */}
                        <div className='flex-center mb-4'>
                            <Typography.Title level={3} className='m-0 fw-bold'>{state?.name}</Typography.Title>
                            <Space>
                                <Link href={`/product/${router.query._id}/edit`}><Button type="primary" className='p-0' icon={<EditFilled />}></Button></Link>
                                <Popconfirm
                                    title="Delete the product ?"
                                    description="Do you really want to delete this product ?"
                                    okText="Delete it!"
                                    cancelText="No"
                                    onConfirm={handleDelete}
                                    okButtonProps={{ loading: deleteLoading, danger: true }}
                                >
                                    <Button className='p-0' type='primary' icon={<DeleteFilled />} htmlType="button" danger disabled={deleteLoading}></Button>
                                </Popconfirm>
                            </Space>
                        </div>
                        <Card className='common-card border-0 mb-3'>
                            <Row gutter={[50, 20]}>
                                <Col xs={24} md={12} xxl={12}>
                                    <Image.PreviewGroup 
                                        // items={state.images.map((res) => henceforthApi.FILES.imageOriginal(res, PlusOutlined))}
                                        preview={{
                                            onChange: (current, prev) => console.log(`current index: ${current}, prev index: ${prev}`),
                                        }}
                                    >
                                        <Image width={'100%'} height={220} className="object-fit-cover rounded-3"
                                            src={state?.images ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${state.images[0]}` : ''}
                                        />
                                    </Image.PreviewGroup>
                                </Col>
                                <Col xs={24} md={12} xxl={12}>
                                    <Spin spinning={imageUpload}>
                                        <Upload
                                            listType="picture-card"
                                            fileList={state.images?.map((res) => { return { url: henceforthApi.FILES.imageMedium(res, PlusOutlined), uid: res, name: res, status: "done" } })}
                                            onChange={onHandleImageChange}
                                            onPreview={handlePreview}
                                            disabled={imageUpload}>
                                            {uploadButton}
                                            {state.images?.length ? state.images.length < 8 && '' : ''}
                                        </Upload>
                                    </Spin>
                                    <Modal open={previewOpen} footer={null} onCancel={handleCancel}>
                                        <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                    </Modal>
                                </Col>
                            </Row>
                        </Card>
                        <Card className='common-card border-0 mb-3'>
                            {/* Title and Button */}
                            <div className='mb-4'>
                                <Typography.Title level={4} className='m-0 fw-bold'>General Info</Typography.Title>
                            </div >
                            {/* Product name  */}
                            <div className='mb-3' >
                                <div className='d-flex gap-lg-5 gap-2 flex-column flex-lg-row'>
                                    <Typography>
                                        <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Product name</Typography.Paragraph>
                                        <Typography.Title level={5} className='m-0 fw-bold'>{state?.name}</Typography.Title>
                                    </Typography>
                                    <Typography>
                                        <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Category</Typography.Paragraph>
                                        <Typography.Title level={5} className='m-0 fw-bold'>Category 1</Typography.Title>
                                    </Typography>
                                </div>
                            </div>
                            {/* Description  */}
                            <div>
                                <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Description</Typography.Paragraph>
                                <span dangerouslySetInnerHTML={{ __html: state?.description }}>
                                </span>
                                {/* <Typography.Title level={5} className='m-0 fw-bold' dangerouslySetInnerHTML={{__html:state?.description}}></Typography.Title> */}
                            </div>
                        </Card >

                        {/* Pricing  */}
                        <Card className='common-card border-0'>
                            {/* Title and Button */}
                            <div className='mb-4'>
                                <Typography.Title level={4} className='m-0 fw-bold'>Pricing</Typography.Title>
                            </div>
                            {/* Product pricing  */}
                            <div className='d-flex gap-lg-5 gap-2 flex-column flex-lg-row'>
                                <div>
                                    <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Regular Price</Typography.Paragraph>
                                    <Typography.Title level={5} className='m-0 fw-bold'>{state?.regular_price ? `$${state?.regular_price}` : 'N/A'}</Typography.Title>
                                </div>
                                <div>
                                    <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Sale Price</Typography.Paragraph>
                                    <Typography.Title level={5} className='m-0 fw-bold'>{state?.sale_price ? `$${state?.sale_price}` : 'N/A'}</Typography.Title>
                                </div>
                                {/* Product name  */}
                                <div>
                                    <Typography.Paragraph className='mb-2 fw-semibold' type='secondary'>Discount</Typography.Paragraph>
                                    <Typography.Title level={5} className='m-0 fw-bold'>{state?.discount}%</Typography.Title>
                                </div>
                            </div>
                        </Card>
                    </Col >

                    <Col xs={24} xl={7} xxl={6}>
                        {/* Visibility */}
                        <Spin spinning={visibilityLoading}>
                            <Card className='common-card border-0 mb-3'>
                                <Typography.Title level={4} className='m-0 mb-1 fw-bold'>Visibility</Typography.Title>
                                <Typography.Paragraph type="secondary">Setup product visibility for the customers.</Typography.Paragraph>
                                <div className='product-enable-wrapper flex-center p-3'>
                                    <label htmlFor="toggle" className='fw-bold' role="button">
                                        <Button htmlType='button' type='primary' icon={<EyeOutlined />}></Button>
                                        <Typography.Text className='ms-1' type='success'>Visible</Typography.Text></label>
                                    <Switch onChange={(e)=>onChangeToggle(e)} size="small" checked={visibleData} id='toggle' />
                                </div>
                            </Card>
                        </Spin>

                        {/* Preview */}
                        <Card className='common-card border-0'>
                            <Typography.Title level={4} className='m-0 mb-1 fw-bold'>Preview</Typography.Title>
                            <Typography.Paragraph className='m-0 mb-3' type="secondary">See the preview of the product in the
                                same way, user will see the product in
                                market.</Typography.Paragraph>
                            <Link href="/product/preview" className='w-100 d-block'><Button type='primary' className="w-100" ghost size='large'>See Preview</Button></Link>
                        </Card>
                    </Col>
                </Row >

            </section >
        </Fragment >
    )
}

Product.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default Product
