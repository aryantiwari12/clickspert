import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Select, Table, Card, Typography, Upload, Image, Space, Avatar } from 'antd';
import Link from 'next/link';
import React from 'react';
import { EyeFilled, EditFilled, LoginOutlined, PlusOutlined, DownloadOutlined, UploadOutlined, AppstoreOutlined, MenuOutlined } from '@ant-design/icons';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import henceofrthEnums from '@/utils/henceofrthEnums';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { ProductInfoInterface } from '@/interfaces';
import ColumnsType from '@/interfaces/ColumnsType';
import { FALLBACK } from '@/context/actionTypes';
import { SelectType } from '@/interfaces/AntType';
import { Dayjs } from 'dayjs';
const { Row, Col, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Meta } = Card;
const { Search } = Input;
let timer:any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Product: Page = (props: any) => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { Toast, downloadCSV, uploadCSV } = React.useContext(GlobalContext)
    const [exportModal, setExportModal] = React.useState(false);

    const [layoutGrid, setLayoutGrid] = useState(true)
    const [loading, setLoading] = React.useState(false)
    const [state, setState] = React.useState({
        data: [] as any,
        count: 0
    })
    const [categoryData, setCategoryData] = useState([] as Array<SelectType>)

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }
    const handleChange = (key: string, value: string) => {
        console.log("handleChange called", key, value);
        onChangeRouter(key, value)
    }

    const onSearch = (value: string) => {
        if (timer) {
            clearTimeout(timer)
          }
          timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
          }, 2000);
       
    }
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const initialize = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.category_id) {
                urlSearchParam.set('category_id', router.query.category_id as string)
            }
            if (query.sale_price) {
                urlSearchParam.set('sale_price', router.query.sale_price as string)
            }
            // let resApi = await henceforthApi.Products.listing(Number(router.query.pagination), Number(router.query.limit), String(router.query?.search ? router.query?.search : ''))
            let resApi = await henceforthApi.Products.listing(urlSearchParam.toString())
            console.log("resapi", resApi.data);
            setState({
                ...state,
                data: resApi.data,
                count: resApi.count
            })

        } catch (error) {
            console.log(error)
        }
        finally {
            setLoading(false)
        }
    }

    const dataSource = state?.data?.map((data: ProductInfoInterface, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <div className='user-detail d-inline-flex gap-2 align-items-center'>
                    <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${data?.images[0]}`}>{data.name?.charAt(0)?.toUpperCase()}</Avatar>
                </div>
                <Typography.Text>{data.name}</Typography.Text>
            </div>,
            category: data?.category_id?.name || 'N/A',
            price: data.sale_price ? `$${data.sale_price}` : 'N/A',
            actions: <ul className='m-0 list-unstyled d-flex gap-2'><li>
                <Link href={`/product/${data._id}/view`}><Button type='primary' shape='circle'><EyeFilled /></Button></Link></li>
                <Link href={`/product/${data?._id}/edit`}><Button type='primary' shape='circle'><EditFilled /></Button></Link>
            </ul>
        }
    }
    );

    React.useEffect(() => {
        initialize()
    }, [router.query.limit, router.query.pagination, router.query?.search, router.query?.category_id, router.query.sale_price])

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                // data.map(async (res: any) => {
                //     let items = {
                //         image: res.images,
                //         name: res.name,
                //         category_id: '648702e813d321fa5e4aaf9c',
                //         description: res.description || "N/A",
                //         price: '10',
                //         discount: res.discount || '0'
                //     }
                //     let apiRes = await henceforthApi.Products.import(items)
                //     console.log("handleUploadCsvFile called apiRes", apiRes);
                // })
                let apiRes = await henceforthApi.Products.import(info.file.originFileObj)
                console.log("import product", apiRes);
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No product added" :`${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }

    const getCategory = async () => {
        try {
            let apiRes = await henceforthApi.Category.listing()
            console.log('apiRes', apiRes);

            setCategoryData(apiRes.data)
            console.log("getCategory called", apiRes);

        } catch (error) {
            console.log(error)
        }
    }
    useEffect(() => {
        getCategory()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>Product</title>
                <meta name="description" content="Product" />
            </Head>
            <section>

                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card-transparent border-0'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Product</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='d-lg-flex justify-content-md-between align-items-center mb-3 mb-lg-0 product-page'>
                                <Typography.Title level={3} className='m-0 mb-2 mb-lg-0 fw-bold'>Products</Typography.Title>
                                <div className='d-flex gap-3 flex-nowrap align-items-center overflow-auto'>
                                    <Link href={'/product/add'}><Button type="primary" icon={<PlusOutlined />} size={'large'}>New Product</Button></Link>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />}>Import</Button>
                                    </Upload>
                                    <Button type="primary" htmlType="button" icon={<DownloadOutlined />} size={'large'} onClick={() => setExportModal(true)}>Export</Button>
                                    <Space className='gap-0 m-0 p-0 align-items-start justify-content-start'>
                                        <Button onClick={() => setLayoutGrid(true)} type="primary" icon={<AppstoreOutlined />} htmlType="button" className='rounded-start rounded-0' size={'large'} ghost={layoutGrid === false ? true : false}></Button>
                                        <Button onClick={() => setLayoutGrid(false)} type="primary" icon={<MenuOutlined />} htmlType="button" className='rounded-end rounded-0' size={'large'} ghost={layoutGrid === true ? true : false}></Button>
                                    </Space>
                                </div >
                            </div >
                            {/* Search  */}
                            <div className='my-4 flex-center gap-3 flex-wrap flex-md-nowrap' >
                                <Search size="large" placeholder="Search by Product Name" onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
                                <Space>
                                    <Select
                                        size="large"
                                        placeholder="Category"
                                        onChange={(e)=>handleChange('category_id',e)}
                                        style={{ width: 120 }}
                                        options={[{ value: '', label: 'All Categories' },
                                        ...categoryData.map((res: any) => {
                                            return { value: res?._id, label: res?.name }
                                        })
                                        ]}
                                    />
                                    < Select
                                        size="large"
                                        placeholder="Price"
                                        style={{ width: 120 }}
                                        onChange={(e)=>handleChange('sale_price',e)}
                                        options={[
                                            { value: henceofrthEnums.PriceFilter.low_to_high, label: 'Low to High' },
                                            { value: henceofrthEnums.PriceFilter.high_to_low, label: 'High to Low' },
                                        ]}
                                    />
                                </Space>
                            </div >
                            {/* Card and Table Layout  */}
                            {
                                layoutGrid ?
                                    <div className='product-cards mb-5'>
                                        <Row gutter={[20, 20]}>
                                            {
                                                state?.data?.map((data: any, index: number) => {
                                                    return (
                                                        <Col span={4} xxl={4} xl={6} lg={8} md={8} sm={12} xs={24} key={index + 1}>
                                                            <Card hoverable loading={false}
                                                                className="w-100 p-3"
                                                                cover={
                                                                    <Image alt={data.name} src={`${henceforthApi.API_FILE_ROOT_SMALL}${data?.images[0]}`}
                                                                        fallback={FALLBACK}
                                                                    />
                                                                }
                                                                actions={[
                                                                    <Link key={"sr1"} href={`/product/${data?._id}/view`}><Button type='primary' className='w-100' icon={<EyeFilled />}>View</Button></Link>,
                                                                    <Link key={"sr2"} href={`/product/${data?._id}/edit`}><Button type='primary' className='w-100' icon={<EditFilled />} ghost>Edit</Button></Link>
                                                                ]}>
                                                                <Meta
                                                                    className='p-0'
                                                                    title={
                                                                        <Space direction='vertical'>
                                                                            <Typography.Title level={5} className='m-0 fw-bold'>{data.name || 'N/A'}</Typography.Title>
                                                                            <Typography.Title level={5} className='m-0 mb-1 fw-semibold' type='secondary'>{data?.category_id?.name || 'N/A'}</Typography.Title>
                                                                        </Space>
                                                                    }
                                                                    description={<Typography.Paragraph className='m-0 fw-bolder'>{data.sale_price ? `$${data.sale_price}` : 'N/A'}</Typography.Paragraph>}
                                                                />
                                                            </Card>
                                                        </Col>
                                                    )
                                                })
                                            }
                                        </Row>
                                    </div>
                                    :
                                    <div className='product-cards mb-5'>
                                        <Row gutter={[20, 20]}>
                                            <Col span={24}>
                                                <Table dataSource={dataSource} columns={ColumnsType.productColumns} pagination={false} scroll={{ x: '100%' }} />
                                            </Col>
                                        </Row>
                                    </div>
                            }
                            {/* Pagination  */}
                            <Row justify={'center'}>
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card >
                    </Col >
                </Row >

                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Products.export(start_date, end_date)
                        downloadCSV("Product", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section >
        </Fragment >
    )
}

Product.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {

    return { props: { params: 'all' } };
}


export default Product
