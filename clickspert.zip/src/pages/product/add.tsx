import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Form, Upload, message, InputNumber, Typography, Select, Image, Dropdown, Switch, Spin } from 'antd';
import Link from 'next/link';
import type { MenuProps } from 'antd';
import { InboxOutlined, EyeOutlined, DeleteFilled } from '@ant-design/icons'
import type { UploadProps } from 'antd/es/upload/interface';
import dynamic from "next/dynamic";
import React from 'react';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}
const { Dragger } = Upload;

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const AddProduct: Page = () => {
    const router = useRouter()
    const [categoryData, setCategoryData] = useState({
        data: [] as any
    })
    const [imageState, setImageState] = useState([] as any)
    const { Toast } = React.useContext(GlobalContext)
    const [loading, setLoading] = React.useState(false)
    const [visibilityLoading, setVisibilityLoading] = React.useState(false);
    const [visibleData, setVisibleData] = React.useState(false);

    const uploadPropsProps: UploadProps = {
        name: 'file',
        // action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
        async onChange(info) {
            console.log('uploadPropsProps info', info);

            const { status } = info.file;

            // if (status === 'done' || status === 'error') {
            let imgArray = []
            for (let index = 0; index < info.fileList.length; index++) {
                const element = info.fileList[index];
                console.log('ele', element);
                imgArray.push(element?.originFileObj)
            }
            setImageState([...imageState, ...imgArray])
            // }
        },
        onDrop(e) {
            // console.log('Dropped files', e.dataTransfer.files);
        },
    };

    const onChangeToggle = async (event: any) => {
        console.log("onChangeToggle called", event);
        try {
            setVisibilityLoading(true)
            setVisibleData(event)
        } catch (error) {
            console.log(error)
        }
        finally {
            setVisibilityLoading(false)
        }
    }

    const getCategory = async () => {
        try {
            let apiRes = await henceforthApi.Category.listing()
            setCategoryData(apiRes)
        } catch (error) {
        }
    }

    useEffect(() => {
        getCategory()
    }, [])

    const imagesUpload = async () => {
        let images: Array<string> = []
        try {
            await Promise.all(imageState?.map(async (res: any) => {
                let apiRes = await henceforthApi.Common.uploadFile('file', res)
                // arr.push(apiRes?.file_name)
                images.push(apiRes?.file_name)
            }))
        } catch (error) {
            console.log('imagesUpload error', error);
        }
        return images
    }

    const onFinish = async (values: any) => {
        console.log("onFinish values", values);
        console.log("visibleData", visibleData)
        setLoading(true)
        try {
            let items: any = {
                name: String(values?.name).trim(),
                category_id: values.category,
                description: String(values.description).trim(),
                regular_price: values.reguler_price,
                is_visible: visibleData,
                sale_price: values.sale_price
            }
            console.log("visibilty is===", items.is_visible)
            if (items.name == "") {
                return Toast.warn("Invalid Firstname")
            }
            if (items.regular_price == 0) {
                return Toast.warn("Regular price cannot be 0")
            }
            if (items.regular_price == "") {
                return Toast.warn("Regular price cannot be empty")
            }
            if (items.sale_price == 0) {
                return Toast.warn("Sale Price cannot be 0")
            }
            if (items.sale_price == "") {
                return Toast.warn("Sale Price cannot be empty")
            }
            if (items.regular_price < items.sale_price) {
                return Toast.warn('Sale price must be less than Regular price')
            }
            if (!values?.images) {
                return Toast.warn('Image not selected')
            }
            let multipleImgages = await imagesUpload()
            items['image'] = multipleImgages
            let apiRes = await henceforthApi.Products.create(items)
            console.log("Product onFinish apiRes", apiRes);
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false)
        }
    };

    const handleDeleteImage = (index: number) => {
        imageState.splice(index, 1)
        setImageState([...imageState])
    }

    return (
        <Fragment>
            <Head>
                <title>Add Product</title>
                <meta name="description" content="Product" />
            </Head>
            <section className='product-edit'>
                <Row gutter={[20, 20]} className="mb-3">
                    <Col span={24}>
                        <Card className='common-card-transparent border-0'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/product/page/1" className='text-decoration-none'>Products</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>New Product</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                        </Card>
                    </Col>
                </Row>
                <Row>
                    <Col span={24}>
                        {/* Title  */}
                        <div className='mb-4'>
                            <Typography.Title level={3} className='m-0 fw-bold'>New Product</Typography.Title>
                        </div>
                    </Col>
                </Row>
                <Form name="edit_pricing" className="add-staff-form" onFinish={onFinish} scrollToFirstError layout='vertical'>
                    <Row gutter={[20, 20]}>
                        <Col xs={24} md={16} xxl={18}>
                            <Card className='common-card border-0 mb-3'>
                                <Row gutter={[20, 20]}>
                                    <Col span={24}>
                                        {/* Product name  */}
                                        <Form.Item name="name" rules={[{ required: true, whitespace: true, message: 'Please enter product name' }]} label="Product name">
                                            <Input type='text' placeholder="Enter product name" size='large' />
                                        </Form.Item>
                                        {/* Category name  */}
                                        {/* <Form.Item name="category" rules={[{ required: true, message: 'Please input category' }]} label="Category">
                                            <Input type='text' placeholder="Enter Category" size='large' />
                                        </Form.Item> */}

                                        <Form.Item name="category" rules={[{ required: true, message: 'Please input category' }]} label="Category">
                                            <Select className='w-100'
                                                size="large"
                                                defaultValue="Select Category"
                                                style={{ width: 120 }}
                                                options={
                                                    categoryData.data.map((res: any) => {
                                                        return { value: res._id, label: res?.name }
                                                    })
                                                }
                                            />
                                        </Form.Item>

                                        {/* Description  */}
                                        <Form.Item name="description" rules={[{ required: true, whitespace: true, message: 'Please enter description' }]} hasFeedback label="Description">
                                            <ReactQuill theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        {/* Upload Image  */}
                                        {/* <Image.PreviewGroup
                                            items={imageState.map((res: any) => URL.createObjectURL(res))}
                                        >
                                            {
                                                imageState.length != 0 && <Image
                                                    width={200}
                                                    src={URL.createObjectURL(imageState[0])}
                                                />
                                            }

                                        </Image.PreviewGroup> */}



                                        <Form.Item name="images" label="Upload Images">
                                            <Dragger {...uploadPropsProps} showUploadList={false} multiple className='mb-3' fileList={[]} >
                                                <Typography.Paragraph className="ant-upload-drag-icon m-0">
                                                    <InboxOutlined />
                                                </Typography.Paragraph>
                                                <Typography.Paragraph className="ant-upload-text m-0 my-1">Click Or drop image in box</Typography.Paragraph>
                                                <Typography.Paragraph className="ant-upload-hint">
                                                    <strong className='fw-bold'>Supported formats:</strong> jpg, png.
                                                </Typography.Paragraph>
                                            </Dragger>
                                        </Form.Item>


                                        <Form.Item name="images">
                                            <Row gutter={[20, 20]}>
                                                {
                                                    imageState.map((res: any, index: number) => {
                                                        return (
                                                            <Col span={24} sm={12} xl={8} xxl={6} key={index}>
                                                                <Card bordered={true} className='product-image' size="small"
                                                                    cover={<Image
                                                                        height={200}
                                                                        className='w-100 object-fit-cover'
                                                                        src={URL.createObjectURL(res)}
                                                                        placeholder="el"
                                                                        preview={false}
                                                                    />}
                                                                >
                                                                    <div className='position-absolute top-0 end-0 me-2 mt-2'>
                                                                        <Button type='primary' shape='circle' size='small' danger key={index} icon={<DeleteFilled color='#ff0000' onClick={() => handleDeleteImage(index)} />}></Button>
                                                                    </div>
                                                                </Card>
                                                            </Col>
                                                        )
                                                    })
                                                }
                                            </Row>
                                        </Form.Item>
                                    </Col>
                                </Row>
                            </Card>
                        </Col>

                        <Col xs={24} md={8} xxl={6}>
                            {/* Price */}
                            <Card className='common-card border-0 mb-3'>
                                {/* Regular price */}
                                <Form.Item name="reguler_price" rules={[{ required: true, message: 'Please enter regular price' }]} label="Regular price">
                                    <InputNumber style={{ width: '100%' }} placeholder="0.0" size='large' formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                        parser={(value) => value!.replace(/\$\s?|(,*)/g, '')} />
                                </Form.Item>
                                {/* Sale price */}
                                <Form.Item name="sale_price" rules={[{ required: true, message: 'Please enter sale price' }]} label="Sale price">
                                    <InputNumber style={{ width: '100%' }} placeholder="0.0" size='large' formatter={(value) => `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                        parser={(value) => value!.replace(/\$\s?|(,*)/g, '')} />
                                </Form.Item>
                                {/* visibility */}
                                <div className='product-enable-wrapper flex-center p-3'>
                                    <label htmlFor="toggle" className='fw-bold' role="button">
                                        <Typography.Text className='ms-1'>Visible</Typography.Text ></label>
                                    <Switch onChange={(e) => onChangeToggle(e)} size="small" checked={visibleData} defaultChecked id='toggle' />
                                </div>
                                <br></br>
                                <Button type='primary' htmlType='submit' className='w-100' size='large' loading={loading} disabled={loading} >Add Product</Button>
                            </Card>
                        </Col>
                    </Row>
                </Form>
            </section>
        </Fragment >
    )
}

AddProduct.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {

    return { props: { params: 'all' } };
}


export default AddProduct
