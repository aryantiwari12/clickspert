import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Button, Card, Col, Row, Input, Breadcrumb, Form, Radio, Typography, Select, Space } from 'antd';
import dynamic from "next/dynamic";
import { ALL_USERS, EMAIL, SELECTED_USERS, PUSH } from '@/context/actionTypes';
import DebounceSelect from '@/utils/components/DebounceSelect';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import Link from 'next/link';
import TextEditor from '@/components/common/TextEditor';
import placeholder from '../../assets/images/placeholder.png'
import Debounce from '@/utils/components/DebounceSelect1';
const { TextArea } = Input;

const ReactQuill = dynamic(import('react-quill'), { ssr: false })

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

interface UserValue {
    label: string;
    value: string;
}

const NotificationPage: Page = () => {
    const router = useRouter()
    const [description, setDescription] = useState('')
    const { Toast } = React.useContext(GlobalContext)
    const [loading, setLoading] = React.useState(false)
    const [notificationTo, setNotificationTo] = React.useState(ALL_USERS)
    const [notificationType, setNotificationType] = React.useState(PUSH)
    const [value, setValue] = useState<UserValue[]>([]);
    const [form] = Form.useForm();

    const onFinish = async (values: any) => {
        setLoading(true)
        console.log('Received values of form: ', values);
        debugger
        console.log(router.query.search, "1111");
        try {
            let items = {
                notification_type: notificationType,
                selects: notificationTo,
                subject: values.subject,
                category: values.category,
                message: values.message
            } as any

            if (notificationType == "EMAIL") {
                items.message = description
            }
            if (notificationTo != "ALL") {
                items.send_to = Array.isArray(router.query.search) ? router.query.search :[router.query.search]
            }
            let apiRes = await henceforthApi.Notification.create(items)
            Toast.success(apiRes.message || apiRes.data)
            form.resetFields()
            console.log(description, "dess");
            delete router.query.search
            router.push({pathname : "/notification/send"} , undefined , {shallow:true})
            // router.back()
        } catch (error) {
            console.log('error', error);

            Toast.error(error)
        } finally {
            setLoading(false)
        }
    };
    const handleChange = (e: any) => {
        debugger
        if (e) {
            router.push({ query: { ...router.query, search: e } })
        }
    }
    // async function fetchUserList(search: string): Promise<UserValue[]> {
    //     let uRLSearchParams = new URLSearchParams()
    //     uRLSearchParams.set('search', search)
    //     if (search) {
    //         uRLSearchParams.set('search', String(search))
    //     }
    //     let apiRes = await henceforthApi.User.listing(uRLSearchParams.toString(), 100)
    //     let data = apiRes.data
    //     return data?.map((user: any) => {
    //         return {


    //             label: <div>
    //                 <Space>
    //                     <div className="notification-img">
    //                         <img src={user?.image ? henceforthApi.API_FILE_ROOT_SMALL + user?.image : placeholder.src} alt='img' className='border' />
    //                     </div>
    //                     <p className='m-0'>name : {user?.name ? user?.name : "N/A"},</p>
    //                     <p className='m-0'>email : {user?.email ? user?.email : "N/A"},</p>
    //                     <p className='m-0'>phone Number : {user?.phone_no ? user?.phone_no : "N/A"}</p>
    //                 </Space>
    //             </div>,
    //             value: user._id,
    //         }
    //         // name:user?.name,
    //         // phone:user.phone_no
    //     })
    // }
    const [searchSelect, setSelectSearch] = useState("")
    const onDebounceChange = (value: string) => {
        debugger
        let old = router.query
        setSelectSearch(value)
        router.replace({ pathname: '/notification/send', query: { search: value } })
    }
    const fetchList = async (search: string) => {
        try {
            if (search?.length) {
                let apiRes: any
                apiRes = await henceforthApi.User.listing(search, 100)
                let data = apiRes.data
                return data?.map((user: any) => {
                    return {


                        label: <div>
                            <Space>
                                <div className="notification-img">
                                    <img src={user?.image ? henceforthApi.API_FILE_ROOT_SMALL + user?.image : placeholder.src} alt='img' className='border' />
                                </div>
                                <p className='m-0'>name : {user?.name ? user?.name : "N/A"},</p>
                                <p className='m-0'>email : {user?.email ? user?.email : "N/A"},</p>
                                <p className='m-0'>phone Number : {user?.phone_no ? user?.phone_no : "N/A"}</p>
                            </Space>
                        </div>,
                        value: user._id,
                    }
                    // name:user?.name,
                    // phone:user.phone_no
                });
            }
            return []
        } catch (error) {
            console.error('Error fetching user list:', error);
            return []
        }
        // }
    }
    // const clearSearch = () => {
    //     let old = router.query
    //     delete old['search']
    //     router.replace({
    //         query: { ...old }
    //     })
    // }

    return (
        <Fragment>
            <Head>
                <title>Cloud Messaging | Admin</title>
                <meta name="description" content="Cloud Messaging" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Management</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Cloud Messaging</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title level={3} className="m-0">Cloud Messaging</Typography.Title>
                            </div>
                            <div className='accordion-wrapper'>
                                <Form size='large' name="notification_add" className="notification-form"
                                    form={form}
                                    initialValues={{ to: notificationTo, type: notificationType }}
                                    onFinish={onFinish}
                                    scrollToFirstError layout="vertical">
                                    {/* Select users by emails */}
                                    <Form.Item label="Select users by emails" rules={[{ required: false, message: 'Please select user' }]}>
                                        <Radio.Group onChange={(e) => setNotificationTo(e.target.value)} value={notificationTo}>
                                            <Radio value={ALL_USERS}>All Users</Radio>
                                            <Radio value={SELECTED_USERS}>Only Selcted Users</Radio>
                                        </Radio.Group>
                                    </Form.Item>
                                    {notificationTo == SELECTED_USERS &&
                                        <Form.Item name="user_ids" label="Select users by emails" rules={[{ required: true, message: 'Please select atlest one user' }]}>
                                            <div className='cloud-messaging'>
                                                {/* <DebounceSelect
                                                mode="multiple"
                                                size={'large'}
                                                placeholder="Select users"
                                                fetchOptions={fetchUserList}
                                                style={{ width: '100%' }}
                                            /> */}
                                                < Debounce size="large" value={router.query?.search} onChange={onDebounceChange} others={router.query?.search ? {} : { placeholder: "Search" }} debounceClass="text-start" searchCharacters={(search: string) => {
                                                    setSelectSearch("")
                                                    return fetchList(search)
                                                }} options={(results: any) => results} searchSelect={searchSelect} />
                                            </div>
                                        </Form.Item>}
                                    {/* Select notification type */}
                                    <Form.Item name="type" label="Select notification type" rules={[{ required: false, message: 'Please select notification type' }]}>
                                        <Radio.Group onChange={(e) => { setNotificationType(e.target.value); form.setFieldValue('text', '') }} value={notificationType} >
                                            <Radio value={PUSH}>Push</Radio>
                                            <Radio value={EMAIL}>Email</Radio>
                                        </Radio.Group>
                                    </Form.Item>
                                    {/* Subject  */}
                                    <Form.Item label="Category" name="category" className='w-100' rules={[{ required: true, message: 'Please enter category' }]}>
                                        <Select
                                            placeholder="Select Category"
                                            className='w-100'
                                            style={{ width: 120 }}
                                            options={[
                                                { value: 'General', label: 'General' },
                                                { value: 'Advertisement', label: 'Advertisement' },
                                                { value: 'Promo', label: 'Promo' },
                                                { value: 'Quotation', label: 'Quotation' },
                                            ]}
                                        />
                                    </Form.Item>
                                    <Form.Item name="subject" rules={[{ required: true, message: 'Please enter subject' }]} label="Subject">
                                        <Input placeholder="Subject" size={'large'} />
                                    </Form.Item>
                                    {/* Description  */}
                                    <Form.Item name="message" label="Description">
                                        {notificationType == "EMAIL" ?
                                            //    <ReactQuill theme="snow" placeholder="Write description here..." />
                                            <TextEditor state={setDescription} />
                                            :
                                            <TextArea placeholder="Write description here..." rows={5} />}
                                    </Form.Item >
                                    {/* Button  */}
                                    <Button className='mt-3' type="primary" htmlType="submit" size={'large'} loading={loading}>
                                        Send Notification
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}

NotificationPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default NotificationPage