'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Divider, Input, Modal, Table, Typography } from 'antd';
import { ExclamationCircleFilled } from '@ant-design/icons'
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import henceofrthEnums from '@/utils/henceofrthEnums';
import dynamic from 'next/dynamic';
import ColumnsType from '@/interfaces/ColumnsType';
import { ContactUsDetailsInterface } from '@/interfaces';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import Link from 'next/link';
import SearchPage from '@/components/common/SearchInput';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const { Search } = Input;
interface DataType {
    key: React.Key;
}
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Notification: Page = (props: any) => {
    const [value, setValue] = useState<RangeValue>(null)
    const { confirm } = Modal;
    const router = useRouter()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const { socketHitType} = React.useContext(ChatContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [state, setState] = React.useState({
        data: [] as any,
        count: 0
    })
    const onDelete = async (id: string) => {
        try {
            confirm({
                title: 'Delete',
                icon: <ExclamationCircleFilled />,
                content: 'Are you sure you want to delete?',
                okText: 'Delete',
                okType: 'danger',
                onOk: async () => {
                    setLoading(true)
                    let apiRes = await henceforthApi.ContactUs.delete(id)
                    Toast.success("User query deleted")
                    await initialise()
                },
                onCancel() { },
            });
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }
    const handleStatus = async (id: string, status: string) => {
        setLoading(true)
        try {
            let items = {
                status: status
            }
            let apiRes = await henceforthApi.ContactUs.edit(id, items)
            Toast.success(apiRes.message)
            await initialise()
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    const StatusItem = (res: any) => {
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.pending}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.pending} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.InquiryStatus.pending),
                        disabled: res?.status == 'PENDING' ? true : false
                    },
                    {
                        key: '12',
                        label: <Divider style={{ height: 2 }} plain className='m-0'></Divider>
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.resolved}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.resolved} />,
                        onClick: () => handleStatus(res._id, henceofrthEnums.InquiryStatus.resolved),
                        disabled: res?.status == 'RESOLVED' ? true : false
                    }
                ],
            },
            {
                key: '2',
                label: (
                    <Typography.Text >
                        Delete Inquiry
                    </Typography.Text >
                ),
                onClick: () => onDelete(res._id),
            }
        ]
    }


    const dataSource = state?.data?.map((item: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            User: item?.user_type ?? "N/A",
            notificationType: item?.notification_type ?? "N/A",
            Category: item?.category,
            Subject: item?.subject ?? "N/A",
            message: <p className='text-wrap' dangerouslySetInnerHTML={{ __html: item?.message ?? "N/A" }} />,
        }
    })


    const handlePagination = (page: number, pageSize: number) => {
        router.replace({
            query: { ...router.query, pagination: page }
        })
    }

    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.Notification.listing(urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit , router.query.search , socketHitType])
    return (
        <Fragment>
            <Head>
                <title>Notification</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Notification</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center'>
                                <Typography.Title className='m-0 fw-bold' level={3}>Notification</Typography.Title>
                                <div className='d-flex gap-3'>
                                    <Link href={'/notification/send'}><Button type="primary" htmlType="button" size={'large'} >Send Notification</Button></Link>
                                    <Button type="primary" htmlType="button" icon={<HenceforthIcons.Export />} size={'large'} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            {/* Search  */}
                            <div className='my-4'>
                                {/* <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton /> */}
                                <SearchPage placeholder="Search..." />
                            </div>
                            {/* Table  */}
                            <div className='table-wrapper'>
                                <Table dataSource={dataSource} columns={ColumnsType.notificationColumns as any} pagination={false} scroll={{ x: '100%' }} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="ContactUs Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Notification.export(start_date, end_date)
                        const exportData = apiRes?.data?.map((item: any, index: number) => {
                            return {
                                User: item?.user_type ?? "N/A",
                                notificationType: item?.notification_type ?? "N/A",
                                Category: item?.category,
                                Subject: item?.subject ?? "N/A",
                                // message: <p className='text-wrap' dangerouslySetInnerHTML={{ __html: item?.message ?? "N/A" }} />
                            }
                        })
                        downloadCSV("Notifications", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Notification.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default Notification
