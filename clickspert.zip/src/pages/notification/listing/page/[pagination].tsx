'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useContext, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Divider, Empty, Input, List, Modal, Space, Table, Typography } from 'antd';
import { ExclamationCircleFilled } from '@ant-design/icons'
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import henceofrthEnums from '@/utils/henceofrthEnums';
import dynamic from 'next/dynamic';
import { CloseOutlined } from "@ant-design/icons"
import { NotificationDetailsInterface } from '@/interfaces';
import henceforthValidations from '@/utils/henceforthValidations';
import Placeholder from '@/assets/images/placeholder.png'
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime'
import Link from 'next/link';
import { Spinner } from '@/components/common/BootstrapCompo';
import { ChatContext } from '@/context/chatProvider';
dayjs.extend(relativeTime)
// const dayjs = require('dayjs');

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const { Search } = Input;
interface DataType {
    key: React.Key;
}
const Notification: Page = (props: any) => {
    // const dateFormat = dayjs
    // dateFormat.extend(relativeTime)
    const { confirm } = Modal;
    const router = useRouter()
    const { Toast, loading, setCount ,setLoading } = React.useContext(GlobalContext)
    const {socketHitType}=useContext(ChatContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [state, setState] = React.useState({
        read_count: 0,
        unread_count: 0,
        read_notification: [] as Array<NotificationDetailsInterface>,
        unread_notification: [] as Array<NotificationDetailsInterface>,

    })

    const readAllNotication = async () => {
        try {
            let apiRes = await henceforthApi.Notification.allRead()
            Toast.success(apiRes.message)
            console.log("readAllNotication called", readAllNotication);
            await initialise();
        }
        catch (error) {
            console.log(error);
        }
    }
    const readSingleNotication = async (id: string) => {
        try {
            let apiRes = await henceforthApi.Notification.readById(id)
            Toast.success(apiRes.message)
            console.log("readAllNotication called", readAllNotication);
            await initialise();
        }
        catch (error) {
            console.log(error);
        }
    }
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        // setLimit(pageSize)
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            let apiRes = await henceforthApi.Notification.readUnreadList(urlSearchParam?.toString())
            setState(apiRes)
            setCount(apiRes?.unread_count)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination , socketHitType])
    return (
        <Fragment>
            <Head>
                <title>Notification</title>
                <meta name="description" content="Contact-us" />
            </Head>
            {loading ? <Spinner /> : <section className='notification-page'>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item className='text-decoration-none'>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Notifications</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='d-flex justify-content-between align-items-center mb-2'>
                                <Space className='mb-4 justify-content-between w-100'>
                                    <Typography.Title level={3} className='fw-bold text-center m-0'>Notifications</Typography.Title>
                                </Space>
                            </div>

                            <div className='accordion-wrapper'>
                                <Row>
                                    <Col span={24}>
                                        <Col span={24}>
                                            <Col span={24} lg={24}>
                                                <Space className='notification-heading justify-content-between w-100 mb-3'>
                                                    <Typography.Title level={4} className='fw-bold m-0'>Unread Notifications</Typography.Title>
                                                    <Button type='primary' ghost htmlType='button' onClick={() => readAllNotication()} className='p-0 text-end border-0 fs-16'>Mark as all read</Button>
                                                </Space>
                                            </Col>
                                            {state?.unread_notification?.length ? state?.unread_notification?.map((res: any, index: number) => {
                                                const VENDOR_DETAILS = ["NEW_VENDOR", "NEW_DOCUMENT", "MANAGE_VENDOR_LOCATION_REQUEST","VENDOR_LOCATIONS","MANAGE_SUBSERVIE_AREA_REQUEST", "MANAGE_SUBSERVIES_REQUEST", "UPDATE_SUBSERVIES_LOCATION_REQUEST", "UPDATE_SUBSERVIES_REQUEST"]?.includes(res?.type)
                                                const ORDER_REQUEST_DETAILS = ["ORDER_REQUEST", "VENDOR_ACCEPTED"]?.includes(res?.type)
                                                const ORDER_ACCEPT_REJECT = (["UPCOMING", "ACTIVE", "COMPLETED"]?.includes(res?.order_id?.status) && res?.order_id?.is_accepted) ? `/orders/${res?.order_id?._id}/view` : `/order-request/${res?.order_id?._id}/view`
                                                const ORDER_DETAILS = ["ORDER_RESCHEDULE", "EXTRA_WORK_QUOTATION", "QUOTATION", "ORDER_FINISH", "ORDER_START", "ORDER_CONFIRMED", "ORDER_CANCELLED"]?.includes(res?.type)
                                                const USER_DETAILS = ["NEW_USER"]?.includes(res?.type)
                                                const VENDOR_REQUEST_DETAILS = ["VENDOR_REQUEST"]?.includes(res?.type)
                                                console.log(res?.sent_by_vendor?.account_status, "qwerty");

                                                const VENDOR_ACCEPT_REJECT = res?.sent_by_vendor?.account_status == "ACCEPTED" ? `/vendor/${res?.sent_by_vendor?._id}/view` : `/vendor-request/${res?.sent_by_vendor?._id}/view`
                                                const REDIRECT_TO_PAGE = VENDOR_DETAILS ? VENDOR_ACCEPT_REJECT : ORDER_DETAILS ? `/orders/${res?.order_id?._id}/view` : VENDOR_REQUEST_DETAILS ? VENDOR_ACCEPT_REJECT : ORDER_REQUEST_DETAILS ? ORDER_ACCEPT_REJECT : USER_DETAILS ? `/user/${res?.sent_by}/view` : ""

                                                return (<Link href={REDIRECT_TO_PAGE} className='text-decoration-none' key={res?._id} >       <Card className='rounded-3 mb-4 new-notification' onClick={() => readSingleNotication(res?._id)}>
                                                    <List>
                                                        <List.Item className='flex-column align-items-start  flex-lg-row align-items-lg-center'  >
                                                            <Space size={'middle'}>
                                                                <div className="notification-img">
                                                                    <img src={henceforthApi.FILES.imageSmall(res?.sub_service_image) || Placeholder.src} alt="img" />
                                                                </div>
                                                                <div>
                                                                    <Typography.Title className='mb-0' level={4}>
                                                                        {henceforthValidations.capitalizeFirstLetter(res.title)}
                                                                        {/* Order request */}
                                                                    </Typography.Title>
                                                                    <div>
                                                                        <Typography.Text className='fs-16'>
                                                                            {res?.message}
                                                                        </Typography.Text>
                                                                    </div>
                                                                    <div>
                                                                        <Typography.Text className='text-gray fs-16'>
                                                                            {dayjs(res.created_at).format('DD,MMM-YYYY')}
                                                                            {/* 07,Nov-2023 */}
                                                                        </Typography.Text>
                                                                    </div>
                                                                </div>
                                                            </Space>
                                                            <div>
                                                                <Typography.Text className='fw-semibold fs-16'>
                                                                    {dayjs(res?.created_at)?.fromNow()}
                                                                </Typography.Text>
                                                            </div>
                                                        </List.Item>
                                                    </List>
                                                </Card>
                                                </Link>)
                                            }) : ""}
                                        </Col>
                                        <Col span={24}>
                                            <Col span={24} lg={24}>
                                                <Space className='notification-heading justify-content-between w-100 mb-3'>
                                                    <Typography.Title level={4} className='fw-bold m-0'>Previous Notifications</Typography.Title>
                                                </Space>
                                            </Col>

                                            {state?.read_notification?.length ? state?.read_notification?.map((res: any) => {
                                                const VENDOR_DETAILS = ["NEW_VENDOR", "VENDOR_REQUEST", "NEW_DOCUMENT", "MANAGE_VENDOR_LOCATION_REQUEST","VENDOR_LOCATIONS","MANAGE_SUBSERVIE_AREA_REQUEST", "MANAGE_SUBSERVIES_REQUEST", "UPDATE_SUBSERVIES_LOCATION_REQUEST", "UPDATE_SUBSERVIES_REQUEST"]?.includes(res?.type)
                                                const ORDER_REQUEST_DETAILS = ["ORDER_REQUEST", "VENDOR_ACCEPTED"]?.includes(res?.type)
                                                const ORDER_DETAILS = ["ORDER_RESCHEDULE", "EXTRA_WORK_QUOTATION", "QUOTATION", "ORDER_FINISH", "ORDER_START", "ORDER_CONFIRMED", "ORDER_CANCELLED"]?.includes(res?.type)
                                                const USER_DETAILS = ["NEW_USER"]?.includes(res?.type)
                                                const ORDER_ACCEPT_REJECT = (["UPCOMING", "ACTIVE", "COMPLETED"]?.includes(res?.order_id?.status) && res?.order_id?.is_accepted) ? `/orders/${res?.order_id?._id}/view` : `/order-request/${res?.order_id?._id}/view`
                                                const VENDOR_REQUEST_DETAILS = ["VENDOR_REQUEST"]?.includes(res?.type)
                                                const VENDOR_ACCEPT_REJECT = res?.sent_by_vendor?.account_status == "ACCEPTED" ? `/vendor/${res?.sent_by_vendor?._id}/view` : `/vendor-request/${res?.sent_by_vendor?._id}/view`
                                                const REDIRECT_TO_PAGE = VENDOR_DETAILS ? VENDOR_ACCEPT_REJECT : ORDER_DETAILS ? `/orders/${res?.order_id?._id}/view` : VENDOR_REQUEST_DETAILS ? VENDOR_ACCEPT_REJECT : ORDER_REQUEST_DETAILS ? ORDER_ACCEPT_REJECT : USER_DETAILS ? `/user/${res?.sent_by}/view` : ""
                                                console.log(res?.sent_by_vendor?.account_status, "qwerty");
                                                return <Link href={REDIRECT_TO_PAGE} className='text-decoration-none' key={res?._id} >       <Card className='rounded-3 mb-4 new-notification' key={res?._id}>
                                                    <List>
                                                        <List.Item className='flex-column align-items-start  flex-lg-row align-items-lg-center'  >
                                                            <Space size={'middle'}>
                                                                <div className="notification-img">
                                                                    <img src={henceforthApi.FILES.imageSmall(res?.sub_service_image) || Placeholder.src} alt="img" />
                                                                </div>
                                                                <div>
                                                                    <Typography.Title className='mb-0' level={4}>
                                                                        {henceforthValidations.capitalizeFirstLetter(res.title)}
                                                                    </Typography.Title>
                                                                    <div>
                                                                        <Typography.Text className='fs-16'>
                                                                            {res?.message}
                                                                        </Typography.Text>
                                                                    </div>
                                                                    <div>
                                                                        <Typography.Text className='text-gray fs-16'>
                                                                            {dayjs(res.created_at).format('DD,MMM-YYYY')}
                                                                        </Typography.Text>
                                                                    </div>
                                                                </div>
                                                            </Space>
                                                            <div>
                                                                <Typography.Text className='fw-semibold fs-16'>
                                                                    {dayjs(res?.created_at).fromNow()}
                                                                </Typography.Text>

                                                            </div>
                                                        </List.Item>
                                                    </List>
                                                </Card> </Link>
                                            }
                                            ) : ""}
                                        </Col>

                                        {/* Pagination  */}
                                        <Row justify={'center'} className="mt-4 mb-4">
                                            <Col span={24}>
                                                <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.read_count} hideOnSinglePage={true} onChange={handlePagination} disabled={loading} />
                                            </Col>
                                        </Row>

                                    </Col>
                                </Row>
                            </div>
                        </Card >
                    </Col >
                </Row >

            </section >}
        </Fragment >
    )
}

Notification.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default Notification
