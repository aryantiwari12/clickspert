import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useContext } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import user from "@/assets/images/profile.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined } from '@ant-design/icons'
import dynamic from 'next/dynamic';
import { GlobalContext } from '@/context/Provider';
const { Row, Col, Card, Button, Pagination, Tooltip, } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const onChange = (key: string) => {
  console.log(key);
};

const { Search } = Input;
interface DataType {
  key: React.Key;
}
const columns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'sr',
    key: 'sr',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    render: (name) => (
      <Tooltip placement="topLeft" title={name}>
        {name}
      </Tooltip>
    ),
    width: 150
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
    width: 200
  },
  {
    title: 'Phone No.',
    dataIndex: 'phone',
    key: 'phone',
    width: 200
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
    fixed: 'right'
  },
];

const dataSource = [
  {
    key: '1',
    sr: '1',
    name: <div className='user-detail d-inline-flex gap-2 align-items-center'> <img src={user.src} className="profile-img" alt="avataar" /><Typography.Text >Johny</Typography.Text ></div>,
    email: "johny123@gmail.com",
    phone: '+61-5236985214',
    actions: <ul className='m-0 list-unstyled d-flex gap-2'><li><Link href="/user/view"><Button type='primary' shape='circle'><EyeOutlined /></Button></Link></li>
      <Tooltip title="Login As User"><li>
        <Button type='primary' shape='circle'><LoginOutlined /></Button>
      </li></Tooltip>
    </ul>
  }
];

const items: TabsProps['items'] = [
  {
    key: '1',
    label: 'All',
    children: <Row gutter={[20, 20]} >
      <Col span={24} >
        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
      </Col>
    </Row>,
  },
  {
    key: '2',
    label: 'Active',
    children: <Row gutter={[20, 20]} >
      <Col span={24} >
        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
      </Col>
    </Row>,
  },
  {
    key: '3',
    label: 'Deactive',
    children: <Row gutter={[20, 20]} >
      <Col span={24} >
        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
      </Col>

    </Row>,
  },
  {
    key: '4',
    label: 'Block',
    children: <Row gutter={[20, 20]} >
      <Col span={24} >
        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
      </Col>
    </Row>,
  },
  {
    key: '5',
    label: 'Unblock',
    children: <Row gutter={[20, 20]} >
      <Col span={24} >
        <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
      </Col>
    </Row>,
  },
];

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

const onSearch = (value: string) => console.log(value);

const Users: Page = (props: any) => {
  const { userInfo } = useContext(GlobalContext)

  console.log('props', props);

  return (
    <Fragment>
      <Head>
        <title>Users</title>
        <meta name="description" content="Users" />
      </Head>
      <section>
        <Row gutter={[20, 20]}>
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>General</Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Users</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* title  */}
              <div className='flex-center'>
                <Typography.Title level={3} className='m-0 fw-bold'>Users</Typography.Title>
                <Button type="primary" htmlType="button" icon={<DownloadOutlined />}>Export</Button>
              </div>
              {/* Search  */}
              <div className='my-4'>
                <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
              </div>
              {/* Tabs  */}
              <div className='tabs-wrapper'>
                <Tabs defaultActiveKey="1" items={items} onChange={onChange} />
              </div>
              {/* Pagination  */}
              <Row justify={'center'} className="mt-4">
                <Col span={24}>
                  <Pagination defaultCurrent={1} total={30} />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
      </section>
    </Fragment>
  )
}

Users.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default Users
