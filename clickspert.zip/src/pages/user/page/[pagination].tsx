import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState, } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Skeleton, Spin } from 'antd';
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { DownloadOutlined, UploadOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import SearchPage from '@/components/common/SearchInput';
import placeholder from '@/assets/images/placeholder.png'
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
import { capitalize } from 'lodash';

const { Row, Col, Card, Button, Pagination, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
const TableData = ({ dataSource, loading }: any) => <Row gutter={[20, 20]} >
  <Col span={24} >
    <Table dataSource={dataSource} loading={loading} columns={ColumnsType.allUserColumns as any} pagination={false} scroll={{ x: '100%' }} />
  </Col>
</Row>
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Users: Page = () => {
  const [value, setValue] = useState<RangeValue>(null)
  const router = useRouter()
  const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
  const { socketHitType } = React.useContext(ChatContext)
  const [state, setState] = React.useState({
    data: [],
    count: 0
  })
  const [loading, setLoading] = React.useState(false)
  const [exportModal, setExportModal] = React.useState(false);
  const [limit, setLimit] = useState(10)
  const onChangeRouter = (key: string, value: string) => {
    router.replace({
      query: { ...router.query, [key]: value }
    })
    console.log("router query", router.query);
  }
  const onChange = (value: string) => {
    onChangeRouter("type", value)
  };
  const handlePagination = (page: number, pageSize: number) => {
    console.log('page: number, pageSize', page, pageSize);
    setLimit(pageSize as any)
    router.replace({
      query: { ...router.query, pagination: page }
    })
  }
  const data = {
    name: "aryan"
  }
  console.log(typeof data);

  const dataSource = state.data.map((res: any, index: any) => {
    const  street_address=res?.address ? `${res?.address?.house_no ? `${res?.address?.house_no} , ` : " "}${res?.address?.city ? `${res?.address?.city} , ` : " "}${res?.address?.postal_code ? `${res?.address?.postal_code } , ` :  ""}${res?.address?.state ? `${res?.address?.state} , ` : " "}${res?.address?.country ? `${res?.address?.country} , ` : " "}${capitalize(res?.address?.address_type ? `${res?.address?.address_type} , ` : "")}` : "N/A"

    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center'>
        {/* <Avatar size={40}></Avatar> */}
        <div className="user-detail-img">
          <img src={henceforthApi.FILES.imageSmall(res.image) || placeholder.src} alt='img' />
        </div>
        {/* </Badge> */}
        <Typography.Text className='text-capitalize'>{res.name || 'N/A'}</Typography.Text></div>,
      email: <Tooltip placement="topLeft" title={res?.email} arrow={true}>
        {res.email?.length > 20 ? res?.email?.slice(0, 20) + "..." : res?.email || "N/A"}
      </Tooltip>,
      phone: res.phone_no || 'N/A',
      city: res?.address?.city || 'N/A',
      Area: <Tooltip title={street_address}> {street_address?.length > 15 ? street_address.slice(0, 15) + '....' : street_address || "N/A"}</Tooltip>,
      OperatingSystem: res.device_type || "N/A",
      actions: <ul className='m-0 list-unstyled d-flex'><li>
        <Link href={`/user/${res._id}/view`}><Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button></Link></li>

      </ul>
    }
  })


  const items: TabsProps['items'] = [
    {
      key: 'all',
      label: 'All',
      children: <TableData dataSource={dataSource} loading={loading} />,
    },
    {
      key: 'Active',
      label: 'Active',
      children: <TableData dataSource={dataSource} loading={loading} />,
    },
    {
      key: 'DEACTIVE',
      label: 'Deactive',
      children: <TableData dataSource={dataSource} loading={loading} />,
    },
    {
      key: 'BLOCK',
      label: 'Block',
      children: <TableData dataSource={dataSource} loading={loading} />,
    }
  ];

  const initialise = async () => {
    console.log("latest router query", router.query);
    try {
      setLoading(true)
      let query = router.query
      let urlSearchParam = new URLSearchParams()
      if (query.pagination) {
        urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
      }
      if (query.search) {
        urlSearchParam.set('search', router.query.search as string)
      }
      if (query.limit) {
        urlSearchParam.set('limit', String(router.query.limit))
      }
      if (query.type) {
        urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
      }
      let apiRes = await henceforthApi.User.listing(urlSearchParam.toString(), limit)
      setState(apiRes)
    } catch (error) {

    } finally {
      setLoading(false)
    }
  }


  React.useEffect(() => {
    initialise()
  }, [router.query.pagination, router.query.limit, router.query.search, router.query.type, socketHitType])
  return (
    <Fragment>
      <Head>
        <title>Users</title>
        <meta name="description" content="Users" />
      </Head>
      <section>
        {/* <Spin spinning={loading}> */}
        <Row gutter={[20, 20]}>
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Users</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* title  */}
              <div className='flex-center flex-column flex-md-row gap-3'>
                <Typography.Title level={3} className='m-0 fw-bold'>Users</Typography.Title>
                <div className='d-flex gap-2'>
                  {/* <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                    <Button type="primary" htmlType="button" size='large' icon={<DownloadOutlined />} >Import</Button>
                  </Upload> */}
                  <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                </div>
              </div>
              {/* Search  */}
              <div className='my-4'>
                <SearchPage placeholder="Search..." pathname="/user/page/1" />
              </div>

              {/* Tabs  */}
              <div className='tabs-wrapper'>
                <Tabs activeKey={router.query.type as string} items={items} onChange={onChange} />
              </div>
              {/* Pagination  */}
              <Row justify={'center'} className="mt-4">
                <Col span={24}>
                  <Pagination current={Number(router.query.pagination) || 1} pageSize={limit} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
        {/* </Spin> */}
        <ExportFile open={exportModal} value={value} setValue={setValue} setOpen={setExportModal} title="Users Export" export={async (start_date?: any, end_date?: number) => {
          const start = new Date(start_date)
          start.setHours(0, 0, 0, 0)
          const new_start_date = new Date(start)?.getTime()
          console.log(new_start_date, "newDate");

          try {
            setLoading(true)
            let apiRes = await henceforthApi.User.export(new_start_date, end_date)
            const exportData = apiRes?.data?.map((item: any) => {
              const  street_address=`${item?.address?.house_no ? `${item?.address?.house_no} , ` : " "}${item?.address?.city ? `${item?.address?.city} , ` : " "}${item?.address?.postal_code ? `${item?.address?.postal_code } , ` :  ""}${item?.address?.state ? `${item?.address?.state} , ` : " "}${item?.address?.country ? `${item?.address?.country} , ` : " "}${capitalize(item?.address?.address_type ? `${item?.address?.address_type} , ` : "")}` 
              return {
                name: item?.name ?? "N/A",
                email: item?.email ?? "N/A",
                phone_no: item?.phone_no ?? "N/A",
                device_type: item?.device_type ?? "N/A",
                city: item?.address?.city?.split(",")?.join(" ") ?? "N/A",
                street_address: street_address?.split(",")?.join(" ") ?? "N/A"
              }
            })
            downloadCSV("user", exportData)
          } catch (error) {
            console.log(error)
          } finally {
            setValue(null)
            setLoading(false)
          }
        }} />

      </section>
    </Fragment>
  )
}

Users.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default Users
