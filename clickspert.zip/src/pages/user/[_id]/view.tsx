import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useContext, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Divider, Pagination, Table, Typography, Popconfirm, Input, Select, DatePicker, DatePickerProps, Tabs, TabsProps, TableColumnsType, Form, Modal, Alert } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined, DownOutlined } from '@ant-design/icons'
import Link from 'next/link';
import image_1 from "@/assets/images/product-1.png"
import { EyeFilled, EditFilled } from '@ant-design/icons';
import { useRouter } from 'next/router';
import type { ColumnsType } from 'antd/es/table';
import henceforthApi from '@/utils/henceforthApi';
import ColumnsTyped from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import { OrderInfoInterface } from '@/interfaces';
import { GlobalContext } from '@/context/Provider';
import user from '@/assets/images/placeholder.png'
import HenceforthIcons from '@/components/HenceforthIcons';
import uiSettings from '@/utils/uiSettings';
import UserAppWallet from '@/components/UserAppWallet';
import dayjs from 'dayjs';
import placeholder from "../../../assets/images/placeholder.png"
import Search from 'antd/es/input/Search';
import SearchPage from '@/components/common/SearchInput';
import { capitalize } from 'lodash';
import { ChatContext } from '@/context/chatProvider';
const onChange: DatePickerProps['onChange'] = (date, dateString) => {
  console.log(date, dateString);
};
const { Row, Col, Card, Button, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
interface DataType12 {
  key: React.Key;
  srno: ReactNode,
  date: ReactNode,
  orderid: ReactNode,
  PointsCredited: ReactNode,
  phone: ReactNode,
  email: ReactNode,
  service: ReactNode,
  name: ReactNode,
  actions: ReactNode,
}
interface DataType {
  srn: any;
  name: ReactNode,
  phone: ReactNode,
  orderid: ReactNode;
  email: string;
  // city: ReactNode;
  Area: ReactNode;
  date: ReactNode;
  status: ReactNode;
  Recurring: ReactNode;
  Amount: ReactNode,
  Service_Name: ReactNode;
  OperatingSystem: ReactNode;
  actions: ReactNode;
}
const userColumnsdetails: ColumnsType<DataType> = [
  {
    title: 'Sr.No',
    dataIndex: 'srn',
    key: 'srn',
    width: 100
  },

  {
    title: 'Order Id',
    dataIndex: 'orderid',
    key: 'orderid',
    width: 200,
  },
  {
    title: 'Service Name',
    dataIndex: 'Service_Name',
    key: 'Service_Name',
    ellipsis: {
      showTitle: false,
    },
    width: 150,
  },
  {
    title: 'Date & Time',
    dataIndex: 'date',
    key: 'date',
    width: 200,
  },
  {
    title: 'Status',
    dataIndex: 'status',
    key: 'status',
    width: 200,
  },

  {
    title: 'Amount',
    dataIndex: 'Amount',
    key: 'Amount',
    width: 200,
  },
  {
    title: 'Recurring',
    dataIndex: 'Recurring',
    key: 'Recurring',
    width: 200,
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
  },
];
const columns: TableColumnsType<DataType12> = [
  {
    title: 'Sr.no.',
    dataIndex: 'sr',
    key: 'sr',
    responsive: ['lg'],
    width: 150
  },
  {
    title: 'Product Name',
    dataIndex: 'name',
    key: 'name',
    width: 250
  },
  {
    title: 'Category',
    dataIndex: 'category',
    key: 'category',
    ellipsis: {
      showTitle: false,
    },
    render: (name) => (
      <Tooltip placement="topLeft" title={name}>
        {name}
      </Tooltip>
    ),
    width: 250
  },
  {
    title: 'Amount',
    dataIndex: 'amount',
    key: 'amount',
    width: 200

  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    fixed: 'right'
  }
]
const UserView: Page = (props: any) => {
  const { loading, setLoading, userInfo, Toast, setUserInfo } = React.useContext(GlobalContext)
  const {socketHitType}=useContext(ChatContext)

  const [form] = Form.useForm()
  const [userDetail, setUserDetail] = useState({
    data: [] as any,
    count: 0,
    total_amount: 0
  })
  const [service, setService] = useState({
    data: [],
  })
  const [state, setState] = useState(props.data as OrderInfoInterface)
  const [blockLoading, setBlockLoading] = React.useState(false)
  console.log(state, "stateee");

  const [point, setPoint] = useState({
    data: [] as any,
    count: 0,
    total_point: 0
  })
  const [wallet, setWallet] = React.useState({
    data: [] as any,
    count: 0,
    total_amount: 0
  })
  const [deactiveLoading, setDeactiveLoading] = React.useState(false)
  const [deleteLoading, setDeleteLoading] = React.useState(false)
  const [productState, setProductState] = React.useState({
    data: [] as any,
    count: 0
  })
  const [subService, setSub_service] = useState({
    sub_services: []
  } as any)
  const router = useRouter()
  const  street_address=state?.address ? `${state?.address?.house_no ? `${state?.address?.house_no} , ` : " "}${state?.address?.city ? `${state?.address?.city} , ` : " "}${state?.address?.postal_code ? `${state?.address?.postal_code } , ` :  ""}${state?.address?.state ? `${state?.address?.state} , ` : " "}${state?.address?.country ? `${state?.address?.country} , ` : " "}${capitalize(state?.address?.address_type ? `${state?.address?.address_type} , ` : "")}` : "N/A"

  const onChangeRouter = (key: string, value: string) => {
    router.replace({
      query: { ...router.query, [key]: value }
    })
  }



  const handlePagination = (page: number, pageSize: number) => {
    console.log('page: number, pageSize', page, pageSize);
    router.replace({
      query: { ...router.query, pagination: page, limit: pageSize }
    })
  }
  const points = async () => {
    try {
      const apiRes = await henceforthApi.User.getPoints(router?.query._id as string)
      setPoint(apiRes)
    } catch (error) {

    }
  }

  const getWallets = async () => {
    try {
      const apiRes = await henceforthApi.User.getWallet(router?.query._id as string)
      setWallet(apiRes)
    } catch (error) {

    }
  }

  const blockUser = async (is_blocked: any) => {
    setBlockLoading(true)
    try {
      let resApi = await henceforthApi.User.block(String(router.query._id), '')
      Toast.success(uiSettings.capitalizeFirstLetter(resApi.message))
      // initialise()
      setState({
        ...state,
        is_blocked,
      })
    } catch (error) {
      console.log(error);
    }
    finally {
      setTimeout(() => {
        setBlockLoading(false)
      }, 500)
    }
  }
  const getDetails = async () => {
    let query = router.query
    const urlSearchParam = new URLSearchParams()
    if (query.search) {
      urlSearchParam.set('search', router.query.search as string)
    }
    if (query.type) {
      urlSearchParam.set('type', String(router.query.type)?.toUpperCase() as string)
    }
    if (query.service_id) {
      urlSearchParam.set('service_id', String(router.query.service_id) as string)
      form.setFieldValue("service_id", router.query.service_id)
    }
    if (query.sub_service_id) {
      urlSearchParam.set('sub_service_id', String(router.query.sub_service_id) as string)
      form.setFieldValue("sub_service_id", router.query.sub_service_id)
    }
    if (query.start_date) {
      urlSearchParam.set('start_date', String(router.query.start_date) as string)
      form.setFieldValue("start_date", dayjs(Number(router.query.start_date)))
    }
    if (query.end_date) {
      urlSearchParam.set('end_date', String(router.query.end_date) as string)
      form.setFieldValue("end_date", dayjs(Number(router.query.end_date)))
    }
    try {
      const apiRes = await henceforthApi.User.order(String(router.query._id), urlSearchParam.toString())
      setUserDetail(apiRes)
      console.log(router.query.search, "router.query.search");

    } catch (error) {

    }
  }


  const deactivateUser = async (is_deactivated: any) => {
    setDeactiveLoading(true)
    try {
      let resApi = await henceforthApi.User.deactivate(String(router.query._id), "")
      Toast.success(resApi.message)
      setState({
        ...state,
        is_deactivated
      })
    } catch (error) {
      console.log(error);
    }
    finally {
      setTimeout(() => {
        setDeactiveLoading(false)
      }, 500)
    }
  }
  const deleteUser = async () => {
    setDeleteLoading(true)
    try {
      let resApi = await henceforthApi.User.delete(String(router.query._id), '')
      Toast.success(resApi.message)
      router.back()
    } catch (error) {
      console.log(error);
    }
    finally {
      setTimeout(() => {
        setDeleteLoading(false)
      }, 500)
    }
  }


  const productDataSource = productState?.data?.map((res: any, index: number) => {
    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      sr: index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center'>
        <Avatar size={40} shape="square" src={`${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}`}>{res.name?.charAt(0)?.toUpperCase()}</Avatar>
        <Typography.Text>{res.name}</Typography.Text>
      </div>,
      category: res.category_id?.name || 'N/A',
      amount: res.price || 'N/A',
      actions: <ul className='m-0 list-unstyled d-flex gap-2'><li>
        <Link href={`/product/${res._id}/view`}><Button type='primary' shape='circle'><EyeFilled /></Button></Link></li>
        <Tooltip title="Edit Product"><li><Button type='primary' shape='circle'><EditFilled /></Button></li></Tooltip>
      </ul>
    }
  }
  );
  const dataSource: DataType[] = userDetail?.data?.map((item: any, index: number) => {
    return {
      srn: index + 1,
      Amount: item?.total_amount != 0 ? `AED ${item?.total_amount}` : "N/A",
      Recurring: item?.recurring ? item?.recurring : "N/A",
      date: dayjs(item?.created_at).format("ddd, MMM DD - hh:mm A"),
      orderid: `${item?.order_id}`,
      Service_Name: <div className='user-detail d-inline-flex gap-2 align-items-center'> <Avatar size={40} shape="square" src={henceforthApi.FILES.imageSmall(item?.sub_service_id.image) || placeholder.src}></Avatar> {item?.service_id?.name} <br /></div>,
      status: <div className={`upcoming ${item?.status == "ACTIVE" ? 'bg-theme' : item?.status == "CANCELLED" ? 'bg-danger' : item?.status == "UPCOMING" ? 'bg-success' : 'bg-blue'}`}>{capitalize(item?.status)}</div>,
      actions: <ul className=' list-unstyled d-flex'><li>
        <Link href={`/orders/${item?._id}/view`}><Button type='primary' className='bg-transparent' shape='circle'><HenceforthIcons.ViewTwo /></Button></Link></li>
      </ul>
    }
  })


  const onChange = (value: string) => {
    onChangeRouter("type", value)
  };
  const TableData = () => <Row gutter={[20, 20]} >
    <Col span={24} >
      <Table dataSource={dataSource} columns={userColumnsdetails} pagination={false} scroll={{ x: '100%' }} />
    </Col>
  </Row>
  const items: TabsProps['items'] = [
    {
      key: 'all',
      label: 'All',
      children: <TableData />,
    },
    {
      key: 'Upcoming',
      label: 'Upcoming',
      children: <TableData />,
    },
    {
      key: 'Active',
      label: 'Active',
      children: <TableData />,
    },
    {
      key: 'Completed',
      label: 'Completed',
      children: <TableData />,
    },
    {
      key: 'Cancelled',
      label: 'Cancelled',
      children: <TableData />,
    }
  ];


  const dataSourcepoint: DataType12[] = point?.data?.slice(0, 10)?.map((item: any, index: number) => {
    return {
      key: index + 1,
      srno: index + 1,
      orderid: `${item?.order_id}`,
      date: dayjs(item?.date).format("ddd, MMM DD - hh:mm a"),
      name: <div className='user-detail d-inline-flex align-items-center gap-2'>
        <Avatar size={40} shape="square" src={henceforthApi.FILES.imageSmall(item?.sub_service_id.image) || placeholder.src}></Avatar>{item?.service_id?.name}</div>,
      PointsCredited: item?.points != 0 ? `${item?.points} points` : "N/A",
      // service: "Cleaning, Pet care",
      actions: <Link href={`/orders/${item?._id}/view`}><span className='d-flex align-items-center'><Button type='primary' className='bg-transparent' shape='circle'><HenceforthIcons.ViewTwo /></Button> </span></Link>
    }
  })

  const onDateSelect: DatePickerProps['onChange'] = (dateString) => {
    if (router.query.end_date) {
      router.push({ pathname: `/user/${router.query._id}/view`, query: { start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } })
    } else {
      router.push({ pathname: `/user/${router.query._id}/view`, query: { start_date: dayjs(dateString).valueOf() } })
    }
  }
  const handleChange = (sub_ser: any, id: string) => {
    try {
      if (sub_ser) {
        router.push({ pathname: `/user/${router.query._id}/view`, query: { service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
      } else {
        router.push({ pathname: `/user/${router.query._id}/view`, query: { service_id: id } }, undefined, { shallow: true })
      }
    } catch (error) {

    }
  }
  const onDate = (dateString: any) => {
    router.push({ pathname: `/user/${router.query._id}/view`, query: { start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } }, undefined, { shallow: true })
  }
  const handleSelect = (_id: any) => {
    try {
      let sub_service = service?.data.find((res: any) => res._id == _id)
      setSub_service(sub_service)
      handleChange(null, _id)
    } catch (error) {
      Toast.error(error)
    }
  }
  const serviceInitialse = async () => {
    try {
      let apiRes = await henceforthApi.Service.listing('')
      setService(apiRes)
    } catch (error) {
      Toast.error(error)
    }
  }
  useEffect(() => {
    getDetails()
  }, [router.query.type, router.query.search, router.query.sub_service_id, socketHitType, router.query.service_id, router.query.start_date, router.query.end_date])
  React.useEffect(() => {
    serviceInitialse()
  }, [])
  useEffect(() => {
    points()
  }, [socketHitType])
  useEffect(() => {
    getWallets()
  }, [socketHitType])
  return (
    <Fragment>
      <Head>
        <title>User Details</title>
        <meta name="description" content="User Details" />
      </Head>
      <section>
        <Row gutter={[20, 20]} className="mb-4">
          {/* <Col span={24}>
            <Alert message={<div className='flex-between'><Typography.Title level={4} className='m-0 fw-medium'>This user has changed this content</Typography.Title><Link href={'/user/1/changeContent'}><Button type='primary'>View</Button></Link></div>} type="warning" />
          </Col> */}
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/user/page/1" className='text-decoration-none'>Users</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>
                    User detail
                    {/* {state?.name || 'N/A'} */}
                  </Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div>
                <Typography.Title level={3} className='m-0 fw-600'>User Details</Typography.Title>
              </div>
              {/* Car Listing  */}
              <div className='card-listing'>
                <div className='card-listing-image my-4 text-center'>
                  <Avatar size={120} src={henceforthApi.FILES.imageOriginal(state?.image, user?.src)}></Avatar>
                </div>
                <Divider plain></Divider>
                <Row justify={'space-between'}>
                  <Col span={24} md={12}>
                    <div className='w-100 d-flex flex-column flex-lg-row justify-content-between gap-3'>
                      <ul className='list-unstyled mb-4 mb-md-0 flex-shrink-0'>
                        <li><Typography.Title level={4} className='fw-700'>Personal Info</Typography.Title></li>
                        <li className='mb-3'><Typography.Text>Name:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.name || 'N/A'}
                        </Typography.Text ></li>
                        <li className='mb-3'><Typography.Text>Email:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.email || 'N/A'}
                        </Typography.Text ></li>
                        <li className='mb-3'><Typography.Text>Phone no:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.country_code ? state?.country_code : ""} {state?.phone_no || 'N/A'}
                        </Typography.Text></li>
                        <li className='mb-3'><Typography.Text>Address:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.address?.street_address || "N/A"}

                        </Typography.Text></li>
                        <li className='mb-3'><Typography.Text>Area:</Typography.Text> <Typography.Text className='ms-1'>
                          {street_address}
                        </Typography.Text></li>
                        <li className='mb-3'><Typography.Text>City:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.address?.city || 'N/A'}
                        </Typography.Text></li>
                        <li><Typography.Text>Operating System:</Typography.Text> <Typography.Text className='ms-1'>
                          {state?.device_type || "N/A"}
                        </Typography.Text></li>

                      </ul>
                    </div>
                  </Col>
                  <Col span={24} md={10}>
                    {/* Button  */}
                    <div className='card-listing-button'>
                      <Typography.Title level={4} className='fw-700 mb-0'>Action</Typography.Title>
                      <div className='d-flex flex-column gap-2 mt-3'>
                        <div className='w-100 d-flex gap-2'>
                          <Popconfirm
                            title="Accept the User"
                            onConfirm={() => blockUser(!state?.is_blocked)}
                            description={`${`Are you sure to ${!state?.is_blocked ? 'Block' : 'UnBlock'} this User?`}`}
                            okText={!state?.is_blocked ? 'Block' : 'UnBlock'}
                            cancelText="No"
                          >
                            <Button type="primary" htmlType='button' className='flex-grow-1 w-100' disabled={blockLoading} size='large' > {!state?.is_blocked ? 'Block' : 'UnBlock'}</Button>
                          </Popconfirm>
                          <Popconfirm
                            title="Accept the User"
                            onConfirm={() => deactivateUser(!state?.is_deactivated)}
                            description={`${`Are you sure to ${!state?.is_deactivated ? 'Deactivate' : 'Activate'} this User?`}`}
                            okText={!state?.is_deactivated ? 'Deactivate' : 'Activate'}
                            cancelText="No"
                          >
                            <Button type="primary" htmlType='button' className='flex-grow-1 w-100' disabled={deactiveLoading} size='large' ghost >
                              {!state?.is_deactivated ? 'Deactivate' : 'Activate'}
                            </Button>
                          </Popconfirm>
                        </div>
                        {/* <Button type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' danger onClick={() => deleteUser()}>Delete</Button> */}
                        {/* <Button type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' danger>Delete</Button> */}
                        <Popconfirm
                          title="Delete"
                          description="Are you sure you want to delete ?"
                          onConfirm={(event) => { event?.stopPropagation(); deleteUser() }}
                          okButtonProps={{ loading: deleteLoading, danger: true }}
                        >
                          <Button type="primary" htmlType='button' className='flex-grow-1 w-100 ' size='large' disabled={deleteLoading} danger><span className='text-white'>Delete</span></Button>

                          {/* <Button type="text" danger htmlType='button' className='px-0' ><HenceforthIcons.Delete /></Button> */}
                        </Popconfirm>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>

            </Card>
            <Card className='common-card mt-4'>
              <Form form={form}>
                <div className='d-flex align-items-center'>
                  <Typography.Title level={3} className='m-0 me-4 fw-bold'>Orders</Typography.Title>
                  <p className='text-muted mb-0 border rounded-2 p-2'>Total Paid Amount: <span className='text-dark fw-semibold'>{userDetail.total_amount ? `AED ${userDetail.total_amount?.toFixed(2)}` : '0'}</span></p>
                </div>
                <div className='py-3'>
                  {/* <Input placeholder="Basic usage" size='large' prefix={<SearchOutlined />} /> */}
                  <SearchPage pathname={``} placeholder={"Search..."} />
                </div>
                <div className='d-flex gap-2'>
                  {/* <Form.Item name="service_id"> */}
                  <Select
                    showSearch
                    size='large'
                    allowClear
                    className='w-100 bg-transparent'
                    placeholder="Select service"
                    optionFilterProp="children"
                    suffixIcon={<HenceforthIcons.DownArrow />}
                    filterOption={(input, option) => (option?.label ?? '').includes(input)}
                    filterSort={(optionA, optionB) =>
                      (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                    }
                    onChange={handleSelect}
                    options={service?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}

                  />
                  {/* </Form.Item> */}
                  {/* <Form.Item name="sub_service_id"> */}
                  <Select
                    size='large'
                    showSearch
                    allowClear
                    className='w-100 bg-transparent'
                    placeholder="Select sub service"
                    optionFilterProp="children"
                    suffixIcon={<HenceforthIcons.DownArrow />}
                    onChange={(e: any) => handleChange(e, String(router.query.service_id))}
                    options={subService?.sub_services?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                  />
                  {/* </Form.Item> */}
                </div>

                <div className='d-flex gap-2 py-3'>
                  {/* <Form.Item name="start_date"> */}
                  <DatePicker
                    onChange={onDateSelect}
                    placeholder='From' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                  {/* </Form.Item> */}
                  {/* <Form.Item name="end_date"> */}
                  <DatePicker onChange={onDate} placeholder='To' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                  {/* </Form.Item> */}
                </div>
              </Form>
              <div className='mt-3'>
                <Tabs activeKey={router.query.type as string} items={items} onChange={onChange} />
              </div>
            </Card>
            <Card className='common-card mt-4'>
              <div className='d-flex align-items-center mb-3'>
                <Typography.Title level={3} className='m-0 me-4 fw-bold'>Clickspert Points</Typography.Title>
                <p className='text-muted mb-0 border p-2'>Total Clickspert Points: <span className='text-dark fw-semibold'>{point?.total_point ? `Points ${point?.total_point}` : "0"}</span></p>
              </div>
              <Table dataSource={dataSourcepoint} columns={ColumnsTyped.userColumnspoint} pagination={false} scroll={{ x: '100%' }} />
              {point?.data?.length > 10 && <div className='text-end mt-4'><Link href={`/transactions/clickspert-points/page/1`} className="border-0 text-dark fw-semibold text-decoration-none">View All <HenceforthIcons.LeftArrowArchive /></Link></div>}
            </Card>
            <UserAppWallet wallet={wallet} getWallets={getWallets} />
          </Col>
        </Row>
        <Row gutter={[20, 20]}>
          <Col span={24}>
            {
              productState.data.length ?
                <Card className='common-card'>
                  <div>
                    <Typography.Title level={3} className='m-0 mb-3 fw-bold'>Products</Typography.Title>
                    <Table dataSource={productDataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
                  </div>
                </Card>
                :
                <></>
            }
          </Col>
        </Row>
        {/* Pagination  */}
        <Row justify={'center'}>
          <Col span={24}>
            <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={productState.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
          </Col>
        </Row>
      </section>

    </Fragment>
  )
}
UserView.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    let apiRes = await henceforthApi.User.getById(context.query._id as string)
    let data = apiRes
    return { props: { data } };
  } catch (error) {
    return {
      props: {}
    }
  }

}


export default UserView
