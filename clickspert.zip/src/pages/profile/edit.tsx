import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Select, Input, SelectProps, Upload, Modal, message, Typography } from 'antd';
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons';
import type { RcFile, UploadProps } from 'antd/es/upload';
import type { UploadFile } from 'antd/es/upload/interface';
import CountryCode from '@/utils/CountryCode.json'
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import placeholder from '../../assets/images/placeholder.png'
import henceforthValidations from '@/utils/henceforthValidations';
const { Row, Col, Card, Button } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}
const { Option } = Select;
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

const beforeUpload = (file: RcFile) => {
  const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
  if (!isJpgOrPng) {
    message.error('You can only upload JPG/PNG file!');
  }
  const isLt2M = file.size / 1024 / 1024 < 2;
  if (!isLt2M) {
    message.error('Image must smaller than 2MB!');
  }
  return isJpgOrPng && isLt2M;
};





const options: SelectProps['options'] = [];
for (let i = 0; i < 10; i++) {
  options.push({
    value: i.toString(10) + i,
    label: i.toString(10) + i,
  });
}
const getBase64 = (file: RcFile): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });


const EditProfile: Page = () => {
  const { Toast, loading, setLoading, userInfo, setUserInfo } = React.useContext(GlobalContext)
  const router = useRouter()
  const [form] = Form.useForm();

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [previewTitle, setPreviewTitle] = useState('');
  const [file, setFile] = useState<any>()
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [country, setCountry] = React.useState('')




  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );

  const handleCancel = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleImageUpload: UploadProps['onChange'] = async ({ fileList: newFileList }) => {
    setFileList(newFileList);
    setFile(newFileList[0])
    console.log('newFileList', newFileList);
  }

  const prefixSelector = (
    <Form.Item name="country_code" noStyle>
      <Select
        prefixCls='country-code'
        showSearch
        value={country}
        defaultValue="+91"
        onChange={(e: any) => setCountry(e)} >
        {CountryCode.map((res: any) => <Option value={res.dial_code} key={res.dial_code}>{res.dial_code}</Option>)}
      </Select>
    </Form.Item>
  );

  const editProfile = async (values: any) => {
    if (!henceforthValidations.nameValidation(values.name)) {
      return Toast.error("Please enter valid name")
    }
    if (fileList.length === 0) {
      return Toast.warn("Please upload image")
    }
    try {
      setLoading(true)
      if (file) {
        let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0]?.originFileObj)
        values.image = apiImageRes?.file_name
      }
      values.phone_no = +values.phone_no
      values.country_code = +values.country_code
      let apiRes = await henceforthApi.Auth.edit(values)
      setUserInfo(apiRes)
      Toast.success(apiRes.message)
      router.back()
    } catch (error) {
      Toast.error(error)
    }
    finally {
      setLoading(false)
    }
  }


  React.useEffect(() => {
    console.log(userInfo);
    if (userInfo) {
      form.setFieldsValue(userInfo)
      setCountry(String(userInfo?.country_code))
      setFileList([{
        uid: '-1',
        name: '',
        status: 'done',
        url: henceforthApi.FILES.imageOriginal(userInfo?.image, placeholder.src),
      }])
    }
  }, [userInfo])

  return (
    <Fragment>
      <Head>
        <title>Edit Profile</title>
        <meta name="description" content="Edit Profile" />
      </Head>
      <section className='notification'>
        <Row gutter={[20, 20]}>
          <Col span={24} md={12}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/profile" className='text-decoration-none'>Profile</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Edit Profile</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div className='mb-4'>
                <Typography.Title level={3} className='m-0 fw-bold'>Edit Profile</Typography.Title>
              </div>
              {/* form  */}
              <div className='card-form-wrapper'>
                <Form size='large' name="edit_profile" className="edit-profile-form" onFinish={editProfile} scrollToFirstError layout='vertical' form={form} >
                  {/* Image  */}
                  <Form.Item name='image'>
                    {/* Image  */}
                    <Upload
                      listType="picture-circle"
                      fileList={fileList}
                      onPreview={handlePreview}
                      onChange={handleImageUpload}
                    >
                      {fileList.length >= 1 ? null : <div>
                        <PlusOutlined />
                        <div style={{ marginTop: 8 }}>Upload</div>
                      </div>}
                    </Upload>
                    <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                      <img alt="example" style={{ width: '100%' }} src={previewImage} />
                    </Modal>
                  </Form.Item>
                  <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                  </Modal>
                  {/* Name  */}
                  <Form.Item name="name" rules={[{ required: true, whitespace: true, message: 'Please Enter Your Name' }]} label="Name" >
                    <Input className='border-0' maxLength={25} placeholder="Name" />
                  </Form.Item>
                  {/* Email  */}
                  <Form.Item name="email" label="Email" rules={[{ required: true, whitespace: true, message: 'Please Enter Your Email' }]}>
                    <Input className='border-0' type='email' placeholder="Email" disabled />
                  </Form.Item>
                  {/* Phone  */}
                  <Form.Item
                    name="phone_no"
                    label="Phone Number"
                    rules={
                      [
                        () => ({
                          validator(_, value) {
                            // if (value) {
                            if (isNaN(value)) {
                              return Promise.reject("Phone has to be a number.");
                            }
                            // if (value.length > 12) {
                            //   return Promise.reject("Please enter a valid number");
                            // }
                            if (value.length < 5) {
                              return Promise.reject("Please enter a valid number");
                            }
                            if (!value) {
                              return Promise.reject("Please enter a valid number");
                            }
                            else {
                              return Promise.resolve();
                            }
                          },
                        }),
                      ]
                    }
                  >
                    <Input onKeyPress={(e) => {
                      if (!/[0-9]/.test(e.key)) {
                        e.preventDefault();
                      }
                    }} maxLength={15} minLength={4} addonBefore={prefixSelector}
                      style={{ width: '100%' }} placeholder='Enter phone number'
                      className='phone-input'
                    />
                  </Form.Item>
                  {/* Button  */}
                  <Button type="primary" htmlType="submit" className="login-form-button" loading={loading}>
                    Save Changes
                  </Button>
                </Form>
              </div>
            </Card>
          </Col>
        </Row>

      </section>
    </Fragment>
  )
}

EditProfile.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default EditProfile
