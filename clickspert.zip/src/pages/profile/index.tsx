import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Divider, Typography, theme } from 'antd';
import Link from 'next/link';
import { GlobalContext } from '@/context/Provider';
import { CheckCircleTwoTone, UserOutlined } from '@ant-design/icons';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}
const { useToken } = theme;

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const Profile: Page = () => {
    const { token } = useToken();
    const { userInfo } = React.useContext(GlobalContext)

    return (
        <Fragment>
            <Head>
                <title>Profile</title>
                <meta name="description" content="Profile" />
            </Head>
            <section>

                <Row gutter={[20, 20]}>
                    <Col sm={22} md={12} lg={11} xl={10} xxl={9}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Profile</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div>
                                <Typography.Title level={3} className='m-0 fw-700'>Profile</Typography.Title>
                            </div>
                            {/* Car Listing  */}
                            <div className='card-listing'>
                                {/* <div className='card-listing-image my-4 text-center'>
                                    <Avatar size={120} src={henceforthApi.FILES.imageSmall(userInfo?.image as any, '')}></Avatar>
                                </div> */}
                                <div className='card-listing-image my-4 text-center'>
                                    <img  src={henceforthApi.FILES.imageMedium(userInfo?.image,'')} alt="avataar"  width={500} height={500} className='profile-image user-image' />
                                </div>
                                <Divider plain></Divider>
                                <ul className='list-unstyled mb-4'>
                                    <li className='mb-3'><Typography.Text className='text-light'>Name:</Typography.Text ><Typography.Text className='ms-1 fw-500 text-capitalize'>
                                        {userInfo?.name} 
                                        </Typography.Text ></li>
                                    <li className='mb-3'><Typography.Text className='text-light'>Email:</Typography.Text > <Typography.Text className='ms-1 fw-500'>
                                        {userInfo?.email}
                                        </Typography.Text > {userInfo?.email_verified && <CheckCircleTwoTone twoToneColor={token.colorPrimary} />}</li>
                                    {/* {userInfo?.phone_no && */}
                                        <li><Typography.Text className='text-light' >Phone no:</Typography.Text > <Typography.Text className='ms-1 fw-500'>+{userInfo?.country_code}-
                                        {userInfo?.phone_no} 
                                        {userInfo?.phone_verified && <CheckCircleTwoTone twoToneColor={token.colorPrimary} />}</Typography.Text ></li>
                                        {/* } */}
                                </ul>
                                {/* Button  */}
                                <div className='card-listing-button d-inline-flex flex-wrap gap-3 w-100'>
                                    <Link href="/profile/edit" className='w-100'><Button type="primary" htmlType='button' className='flex-grow-1 w-100'>Edit</Button></Link>
                                </div>
                            </div>

                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

Profile.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {

    return { props: { params: 'all' } };
}


export default Profile
