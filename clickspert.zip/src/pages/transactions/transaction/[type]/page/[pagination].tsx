import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useContext, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { DatePickerProps, TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import Serviceimg from '../../../../assets/images/banner.png'
import Image from 'next/image';
import dayjs, { Dayjs } from "dayjs"
import SearchPage from '@/components/common/SearchInput';
import { capitalize } from 'lodash';
import ChatProvider, { ChatContext } from '@/context/chatProvider';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Transaction: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const {socketHitType}=useContext(ChatContext)
    const [subService, setSubservice] = React.useState({
        data: [],
        count: 0
    })
    const [transaction, setTransaction] = React.useState({
        data: [] as any,
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);


    const onDateSelect: DatePickerProps['onChange'] = (dateString) => {
        console.log(dateString, "dateString");

        if (router.query.end_date) {
            router.push({ pathname: `/transactions/transaction/${router.query.type}/page/1`, query: router.query.search ? { search: router.query.search, start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } : { start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } })
        } else {
            router.push({ pathname: `/transactions/transaction/${router.query.type}/page/1`, query: router.query.search ? { search: router.query.search, start_date: dayjs(dateString).valueOf() } : { start_date: dayjs(dateString).valueOf() } })
        }
    }
    const onDate = (dateString: any) => {
        router.push({ pathname: `/transactions/transaction/${router.query.type}/page/1`, query: router.query.search ? { search: router.query.search, start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } : { start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } }, undefined, { shallow: true })
    }
    console.log((router.query.limit) ? "5" : 10 ,"limit");
    
    const filterSubservice = (value: any) => {
        if(value){
            router.push({ pathname: `/transactions/transaction/${router.query.type}/page/1`, query: { sub_service_id: value } }, undefined, { shallow: true })
        }
        else{
            delete router.query.sub_service_id
            router.replace({
              query: { ...router.query }
            })
          }
    }
    const getTransaction = async () => {
        let query = router.query
        let urlSearchParam = new URLSearchParams()
        try {
            if (query.search) {
                urlSearchParam.set('search', String(query.search))
            }
            if (query.start_date) {
                urlSearchParam.set('start_date', String(router.query.start_date))
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id))
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type)?.toUpperCase())
            }
            if (query.limit) {
                urlSearchParam.set('limit', String(router.query.limit))
            }
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
              }
            if (query.end_date) {
                urlSearchParam.set('end_date', String(query.end_date))
                // form.setFieldValue("end_date" , dayjs(Number(router.query.end_date)))
            }
            const apiRes = await henceforthApi.Transaction.getTransactions(urlSearchParam?.toString() ,Number(router.query.limit) ?? 10)
            setTransaction(apiRes)
            console.log(apiRes, "points");

        } catch (error) {

        }
    }
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const subServiceList = async () => {
        try {
            const apiRes = await henceforthApi.Transaction.sub_Service()
            apiRes?.data?.unshift({_id:"" , name:"All"})
            setSubservice(apiRes)
        } catch (error) {

        }
    }

    const dataSource = transaction?.data?.map((item: any, index: number) => {
        const TRANSACTIONTYPE=item?.transactions?.type == "WORK_QUOTATION";
        const PAYMENTTYPE=item?.payment_type == "ORDER_REFUND" ? item?.work_quotation_points ? `${item?.work_quotation_points}` : "N/A": item?.work_quotation_points ? `- ${item?.work_quotation_points}` : "N/A"
        const PAYMENTTYPENORMAL=item?.payment_type == "ORDER_REFUND" ? item?.clickspert_points ? `${item?.clickspert_points}` : "N/A" : item?.clickspert_points ? `- ${item?.clickspert_points}` : "N/A"
        const PAYMENTTYPEWALLET=item?.payment_type == "ORDER_REFUND" ? item?.work_quotation_wallets_used ? `AED ${item?.work_quotation_wallets_used}` : "N/A": item?.work_quotation_wallets_used ? `- AED ${item?.work_quotation_wallets_used}` : "N/A"
        const PAYMENTTYWALLETPENORMAL=item?.payment_type == "ORDER_REFUND" ? item?.wallet_amount ? `AED ${item?.wallet_amount}` : "N/A" : item?.wallet_amount ? `- AED ${item?.wallet_amount}` : "N/A"
        const  street_address=item?.address ? `${item?.address?.house_no ? `${item?.address?.house_no} , ` : " "}${item?.address?.city ? `${item?.address?.city} , ` : " "}${item?.address?.postal_code ? `${item?.address?.postal_code } , ` :  ""}${item?.address?.state ? `${item?.address?.state} , ` : " "}${item?.address?.country ? `${item?.address?.country} , ` : " "}${capitalize(item?.address?.address_type ? `${item?.address?.address_type} , ` : "")}` : "N/A"
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <div className="user-detail-img">
                    <img src={henceforthApi.FILES.imageOriginal(item?.user_id?.image, user?.src)} alt='img' />
                </div>
                <Typography.Text>{item?.user_id?.name}</Typography.Text>
            </div>,
            order: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageOriginal(item?.sub_service_id?.image, user?.src)} alt='img' />
                </div>
                <div>
                    <Typography.Paragraph className='mb-0'>{item?.sub_service_id?.name}</Typography.Paragraph>
                    <Typography.Text className='text-gray'>{item?.unique_order_id ? `${item?.unique_order_id}` : "N/A"}</Typography.Text><br />
                </div>
            </div>,
            servicetype: item?.is_quotation_based ? 'Quotation' : "Order based",
            city: item?.address.city ?? "N/A",
            area: <Tooltip title={street_address}>{street_address?.slice(0, 20) + "..."}</Tooltip>,
            date: dayjs(item?.date).format('ddd, MMM DD - hh:mm a'),
            recurring: item?.recurring ?? "N/A",
            transactionType :capitalize(item?.transactions?.type?.split("_")?.join(" ")) || "N/A" ,
            transactionid: item?.transactions?.transaction_no ? item?.transactions?.transaction_no : "N/A",
            status: <div className={`upcoming ${item?.status == "UPCOMING" ? `bg-success` : item?.status == "COMPLETED" ? 'bg-blue' : 'bg-danger'}`}>{capitalize(item?.status)}</div>,
            price: TRANSACTIONTYPE ? `AED ${item?.work_quotation_amount}` : item?.total_before_tax ? `AED ${item?.total_before_tax?.toFixed(2)}` : `AED ${item.subtotal}`,
            servicefee: TRANSACTIONTYPE ? "N/A" :item?.service_fee ? `AED ${item?.service_fee}`  : "N/A",
            vat:TRANSACTIONTYPE ? `AED ${item?.work_quotation_vat}` : item?.vat ? `AED ${item?.vat}` : "N/A",
            totalprice:TRANSACTIONTYPE ? `AED ${item?.total_amount}` : item?.total_amount ? `AED ${item?.total_amount}` : "N/A",
            adminearning:TRANSACTIONTYPE ? `AED ${item?.admin_quotation_subtotal.toFixed('2')}` : item?.admin_subtotal ? `AED ${item?.admin_subtotal.toFixed('2')}` : "N/A",
            adminvat:TRANSACTIONTYPE ? `AED ${item?.admin_quotation_vat}` : item?.admin_vat ? `AED ${item?.admin_vat}` : "N/A",
            totaladminearning:TRANSACTIONTYPE ? `AED ${item?.admin_quotation_earns}` : item?.admin_earning ? `AED ${item?.admin_earning.toFixed(2)}` : "N/A",
            adminservicefee:TRANSACTIONTYPE ? `N/A` : item?.service_fee ? `AED ${item?.service_fee.toFixed(2)}` : "N/A",
            totalvendorearning:TRANSACTIONTYPE ? `AED ${item?.vendor_quotation_earns}` : item?.vendor_subtotal.toFixed('2') ? `AED ${item?.vendor_earning}` : "N/A",
            vendorvat:TRANSACTIONTYPE ? `AED ${item?.vendor_quotation_vat}` ? `AED ${item?.vendor_quotation_vat}` : "N/A": item?.vendor_vat ? `AED ${item?.vendor_vat?.toFixed(2)}` : "N/A",
            promocode: TRANSACTIONTYPE ? "N/A" :item?.promo_code?.name ? `${item?.promo_code?.name}`  : "N/A",
            vendorearning:TRANSACTIONTYPE ? `AED ${item?.vendor_quotation_subtotal}` ? `AED ${item?.vendor_quotation_subtotal.toFixed('2')}` : "N/A": item?.vendor_subtotal ? `${item?.vendor_subtotal?.toFixed(2)}` : "N/A",
            commission: `${item?.commission ? `AED ${item?.commission}` : "N/A"}`,
            clickspertpointuse:item.payment_type=="ORDER_REFUND" ? 'N/A': TRANSACTIONTYPE ? `${item?.clickspert_points}` ? `${item?.clickspert_points}` : "N/A": item?.clickspert_points? `${item?.clickspert_points?.toFixed(2)}` : "N/A",
            clickspertpointe: TRANSACTIONTYPE ? `${item?.point_earn}` ? `${item?.point_earn.toFixed(2)}` : "N/A": item?.point_earn ? `${item?.point_earn.toFixed(2)}` : "N/A",
            point:TRANSACTIONTYPE ? `${PAYMENTTYPE}` : PAYMENTTYPENORMAL,
            appwallet:TRANSACTIONTYPE ? PAYMENTTYPEWALLET : PAYMENTTYWALLETPENORMAL,
            action: <Link href={`/orders/${item?.order_id}/view`}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })

    const TableData = () => <Row gutter={[20, 20]} >
        <Col span={24} >
            <Table dataSource={dataSource} columns={ColumnsType.transactionColumns} pagination={false} scroll={{ x: '100%' }} />
        </Col>
    </Row>

    const items: TabsProps['items'] = [
        {
            key: 'all',
            label: 'All',
            children: <TableData />,
        },
        {
            key: 'upcoming',
            label: 'Upcoming',
            children: <TableData />,
        },
        {
            key: 'completed',
            label: 'Completed',
            children: <TableData />,
        },
    ];
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    useEffect(() => {
        subServiceList()
    }, [])
    useEffect(() => {
        getTransaction()
    }, [router.query.start_date, router.query.end_date, socketHitType, router.query.search, router.query.sub_service_id, router.query.type, router.query.pagination ,router.query.limit])
    return (
        <Fragment>
            <Head>
                <title>Transactions</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Transactions</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Transactions</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[10, 15]} className='my-4'>
                                <Col span={24}>
                                    {/* Search  */}
                                    <div className=' d-flex gap-2 align-items-center'>
                                        <div className='w-100'>
                                            <SearchPage placeholder="Search..." />
                                        </div>
                                        <Space>
                                            <Select
                                                // showSearch
                                                size="large"
                                                defaultValue="All"
                                                style={{ width: 280 }}
                                                options={subService?.data?.map((item: any) => { return { label: item?.name, value: item?._id } })}
                                                onChange={filterSubservice}
                                            />
                                        </Space>

                                    </div>
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDateSelect}
                                        placeholder='From' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker onChange={onDate} placeholder='To' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                            </Row>

                            {/* Tabs  */}
                            <div className='tabs-wrapper '>
                                {/* <TableData/> */}
                                <Tabs activeKey={router.query.type as string} items={items} onChange={onChange} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1}  pageSize={Number(router.query.limit) || 10} total={transaction.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                               
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Transaction.export(start_date, end_date, router.query.type as string)
                        const exportData = apiRes?.data?.map((item: any, index: number) => {
                            const  street_address=`${item?.address?.house_no ? `${item?.address?.house_no} , ` : " "}${item?.address?.city ? `${item?.address?.city} , ` : " "}${item?.address?.postal_code ? `${item?.address?.postal_code } , ` :  ""}${item?.address?.state ? `${item?.address?.state} , ` : " "}${item?.address?.country ? `${item?.address?.country} , ` : " "}${capitalize(item?.address?.address_type ? `${item?.address?.address_type} , ` : "")}` 
                            return {

                                User_Name: item?.user_id?.name,
                                // vendor_name:item?.vendor_id?.name,
                                order_id: item?.order_id,
                                service_type: item?.is_quotation_based ? 'Quotation' : "Order based",
                                date_time: item?.time,
                                recurring: item?.recurring,
                                status: item?.status,
                                transaction_id: item?.transactions?.transaction_no,
                                promo_code: item?.promo_code?.name,
                                service_fee: item?.service_fee,
                                commision: item?.commission,
                                vendor_earning: item?.vendor_earning,
                                clickspert_points: item?.clickspert_points,
                                amount: item?.total_amount?.toFixed(2),
                                city: item?.address?.city,
                                area: street_address?.split(",")?.join(" "),
                                Service: item?.service_id?.name,
                                service: item?.sub_service_id?.name,
                                app_wallet: item?.wallet_amount

                            }
                        })
                        downloadCSV("transaction", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Transaction.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Transaction
