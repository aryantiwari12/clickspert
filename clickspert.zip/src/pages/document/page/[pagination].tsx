import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Breadcrumb, Typography, Modal, Input, Form, Space, Popconfirm } from 'antd';
import { EditOutlined, PlusOutlined, DeleteOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import dayjs from 'dayjs';
import SearchPage from '@/components/common/SearchInput';
import { GlobalContext } from '@/context/Provider';
import HenceforthIcons from '@/components/HenceforthIcons';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const Document: Page = () => {
    const { Toast } = React.useContext(GlobalContext)
    const { socketHitType  } = React.useContext(ChatContext)
    const router = useRouter()
    const [isModalOpen, setIsModalOpen] = React.useState(false);
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [limit,setLimit]=useState(10)
    const [resID, setResID] = React.useState('')
    const [form] = Form.useForm();
    const [loading, setLoading] = React.useState(false)
       const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        setLimit(pageSize)
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
          })
    }
    const Edit = async (_id: any, name: any) => {
        console.log(_id, "ssdd");
        setResID(_id)
        console.log(name, "name");
        form.setFieldValue("name", name)
    }
    const showModal = () => {
        setIsModalOpen(true);
    };
    const dataSource = state?.data.map((res: any, index: any) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: res?.name || "N/A",
            createdon: dayjs(res.createdon).format('DD/MM/YYYY'),
            action: <Space align='center' className='gap-0'>
                {/* <Button type='primary' shape='circle' className='bg-transparent' onClick={()=>router.replace(`${`/document/${res?._id}/view`}`)}><HenceforthIcons.ViewIcon /></Button> */}
                <Button type='primary' onClick={() => { Edit(res._id, res.name); showModal() }} shape='circle' className='bg-transparent'><HenceforthIcons.PencileIcon /></Button>
                <Popconfirm
                    title="Delete"
                    description="Are you sure to delete Document?"
                    onConfirm={() => onDelete(res._id, index)}
                    okText="Yes"
                    cancelText="No">
                    <Button  htmlType='button' shape='circle' block className=' border-0'><HenceforthIcons.Trash/></Button>
                </Popconfirm>
            </Space>
        }
    })
    const create = async (values: any) => {
        try {
            let apiRes
            setLoading(true)
            const info = {
                name: values.name
            }
            if (resID) {
                apiRes = await henceforthApi.Documents.documentEdit(resID, values.name, '')
            } else {
                apiRes = await henceforthApi.Documents.create(info)
            }
            Toast.success(apiRes.message)
            initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setTimeout(() => {
                setLoading(false)
                setIsModalOpen(false)
            }, 1000);
            setResID('')
            form.resetFields()
        }
    }
    const onDelete = async (id: any, index: any) => {
        console.log(index);
        debugger
        try {
            let apiRes = await henceforthApi.Documents.delete(id)
            state?.data?.splice(index, 1)
            setState({
                ...state,
                data:state?.data,
                count: state?.count-1
            })
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        }
    }
    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Documents.listing(urlSearchParam.toString(), limit)
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    const handleCancel = () => {
        setIsModalOpen(false);
        setResID('')
        form.resetFields()
    };
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search, router.query.type ,socketHitType])
    return (
        <Fragment>
            <Head>
                <title>Documents</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Documents</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Documents</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Button type="primary" htmlType="button" size='large' icon={<PlusOutlined />} onClick={showModal}>Add Documents</Button>
                                </div>
                            </div>
                            <Row gutter={[5, 15]} className='my-4'>
                                {/* Search  */}
                                <Col span={24}>
                                    {/* <Search size="large" placeholder="Search..." enterButton /> */}
                                    <SearchPage />
                                </Col>
                            </Row>

                            <Row className="mt-4">
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.document} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={limit} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                    <Modal open={isModalOpen} onCancel={handleCancel} className='amenties-modal' footer={null} bodyStyle={{ padding: '20px' }} title={<Typography.Title level={4} className='text-center'>{resID ? 'Edit' : 'Add'} Documents</Typography.Title>}>
                        <div>
                            <Form name="name" form={form} onFinish={create} className='add-amenties'
                                scrollToFirstError layout="vertical">
                                {/* Name  */}
                                <Form.Item name="name" rules={[{ required: true, message: 'Please Enter Documents' }]} label="Documents">
                                    <Input placeholder="Documents" size={'large'} />
                                </Form.Item>
                                <Button type='primary' htmlType='submit' loading={loading} block>{resID ? "EDIT" : "ADD"}</Button>
                            </Form>
                        </div>
                    </Modal>
                </Row>
            </section>

        </Fragment>
    )
}
Document.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Document
