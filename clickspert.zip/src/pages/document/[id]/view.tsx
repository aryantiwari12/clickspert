import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Divider, Pagination, Table, Typography, TabsProps, TableColumnsType } from 'antd';
import Link from 'next/link';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import { GlobalContext } from '@/context/Provider';
import { OrderInfoInterface, vendorDetail } from '@/interfaces';

const { Row, Col, Card, Button, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
const VendorView: Page = (props: any) => {
  console.log(props,"props");
  const [state, setState] = useState<vendorDetail>(props.data)
  return (
    <Fragment>
      <Head>
        <title>Documents Details</title>
        <meta name="description" content="User Details" />
      </Head>
      <section>
        <Row gutter={[20, 20]} className="mb-4">
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/document/page/1" className='text-decoration-none'>Documents</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>
                    {/* {state?.name || 'N/A'} */}
                    Documents detail
                  </Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div>
                <Typography.Title level={3} className='m-0 fw-600'>Document Detail</Typography.Title>
              </div>
            </Card>
            <Row gutter={[15, 15]}>
              <Col span={24} md={12}>
                {/* ant table */}
                <Card className='common-card card-listing mt-4 h-100'>
                  <ul className='list-unstyled mb-4 mb-md-0 flex-shrink-0'>
                    <li className='mb-3'><Typography.Text className='text-gray'>Name:</Typography.Text> <Typography.Text className='ms-1'>
                      {state?.name || 'N/A'}
                    </Typography.Text ></li>
                  </ul>
                </Card>
              </Col>
            </Row>
          </Col>
        </Row>
      </section>
    </Fragment>
  )
}

VendorView.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    let apiRes = await henceforthApi.Documents.getbyId(context.query._id as string)
    let data = apiRes
    return { props: { ...data } };
  } catch (error) {
    return {
      props: {}
    }
  }

}


export default VendorView
