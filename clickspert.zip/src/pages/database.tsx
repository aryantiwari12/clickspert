import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useContext } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Typography } from 'antd';
import dynamic from 'next/dynamic';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';

const { Row, Col, Card, Button } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
const DbBackup: Page = (props: any) => {
  const { Toast, setLoading, loading } = useContext(GlobalContext)
  console.log('props', props);
  const downloadNow = async () => {
    try {
      setLoading(true)
      let apiRes = await henceforthApi.Common.dbBackup()
      console.log('downloadNow apiRes ', apiRes);
      downloadDB(apiRes?.name, apiRes?.file_url)
    } catch (error) {
      Toast.error(error)
      console.log(error)
    } finally {
      setLoading(false)
    }
  }

  const downloadDB = async (name: string, file: any) => {
    let fileName = `${henceforthApi.API_FILE_ROOT_DB_BACKUP}${file}`
    window.open(fileName)
    return
  }

  return (
    <Fragment>
      <Head>
        <title>DB Backup</title>
        <meta name="description" content="DB Backup" />
      </Head>
      <section>
        <Row gutter={[20, 20]}>
          <Col sm={22} md={12} lg={11} xl={10} xxl={9}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Others</Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>DB Backup</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              <div className='flex-center mb-4'>
                <Typography.Title level={3} className='m-0 fw-bold'>DB Backup</Typography.Title>
              </div>
              <div className='card-content-wrapper'>
                <Typography.Paragraph>If you click on Download, Database will be downloaded.</Typography.Paragraph>
                <Typography.Paragraph>Db MySql file: <Button type='primary' htmlType='button' size={'large'} loading={loading} disabled={loading} className="ms-1" onClick={downloadNow}>Download</Button></Typography.Paragraph>
              </div>
            </Card>
          </Col>
        </Row>
      </section>
    </Fragment>
  )
}

DbBackup.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default DbBackup
