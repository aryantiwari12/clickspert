import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Form, Typography } from 'antd';
import dynamic from "next/dynamic";
import Link from 'next/link';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { log } from 'console';
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const AddFAQs: Page = (props: any) => {
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const router = useRouter();
    const service_id=router?.query?._id
    const onFinish = async (values: any) => {
        setLoading(true)
        let question = String(values.question).trim()
        let answer =String(values.answer).trim()
        if (!question) {
            return Toast.warn("Question should not be empty")
        }
        if (!answer) {
            return Toast.warn("Answer should not be empty")
        }
        let items = {
            service_id,
            question,
            answer,
            type:"USER"
        }
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Faq.create(items)
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading(false)
        } 
    };
    const handleChange=(content:any)=>{
        console.log("hiiiiii");
        
        console.log(content,"rfergr");
        
    }

    return (
        <Fragment>
            <Head>
                <title>FAQs</title>
                <meta name="description" content="Add FAQs" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/faq/page/1" className='text-decoration-none'>FAQs</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Add FAQ</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Add FAQ</Typography.Title>
                            </div>
                            <div className='form-wrapper'>
                                <Form name="faq_add_form" size='large' className="faq-form" initialValues={{ remember: false }} onFinish={onFinish} scrollToFirstError layout='vertical'>
                                    {/* Question  */}
                                    <Form.Item name="question" rules={[{ required: true, whitespace: true, message: 'Please add Question' }]} label="Question">
                                        <Input placeholder="Enter question here" className='border-0' />
                                    </Form.Item>
                                    {/* Answer  */}
                                    <Form.Item name="answer" rules={[() => ({
                                                            validator(_, value) {
                                                                const remove_space = value.replace(/\s/g, "")
                                                                console.log(value);
                                                                
                                                                if (value) {
                                                                    if (value === '<p><br></p>' || remove_space === '<p></p>' ) return Toast.warn('Please enter answer')
                                                                }
                                                                return Promise.resolve();

                                                            },
                                                        })]}   label="Answer">
                                        <ReactQuill className='bg-light border-0' onChange={handleChange} theme="snow"  placeholder="Write description here..." />
                                    </Form.Item>
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit" size={'large'} loading={loading}>
                                    Add FAQ
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

AddFAQs.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}


export default AddFAQs
