import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Form, Typography } from 'antd';
import dynamic from "next/dynamic";
import Link from 'next/link';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { FaqListingInterface } from '@/interfaces';
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Image, Dropdown, Pagination, Badge, Tooltip, Space } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
    Space: dynamic(() => import("antd").then(module => module.Space), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


const EditFAQs: Page = (props: any) => {
    const router = useRouter();
    const [value, setValue] = useState('');
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [state, setState] = React.useState({} as FaqListingInterface)

    const [form] = Form.useForm()

    const initialise = async () => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Faq.getByID(String(router.query._id))
            console.log("faq listing get", apiRes);
            setState(apiRes)
            form.setFieldsValue(apiRes)
            setValue(apiRes.answer)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    const handleEditFaq = async (values: any) => {
        console.log(value, "values");
        debugger
        try {
            setLoading(true)
            let question = String(values.question).trim()
            let answer = String(value).trim()
            if (!question) {
                return Toast.warn("Question should not be empty")
            }
            if (!value) {
                return Toast.warn("Answer should not be empty")
            }
            let items: any
            if (state.question != question) {
                items = { ...items, ...{ question } }
            }
            if (state.ans != answer) {
                items = { ...items, ...{ answer } }
            }
            if (items) {
                setLoading(true)
                let apiRes = await henceforthApi.Faq.edit(String(router.query._id), items)
                Toast.success(apiRes.message)
                setState(apiRes)
                router.back()
            }
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)

        }

    }
    const onchange = (e: any) => {
        console.log(e);

        setValue(e)
    }

    useEffect(() => {
        initialise()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>FAQs</title>
                <meta name="description" content="Edit FAQs" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/faq-user/page/1" className='text-decoration-none'>FAQs</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Edit FAQs</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Edit FAQs</Typography.Title>
                            </div>
                            <div className='form-wrapper'>
                                <Form form={form} name="faq_edit-form" className="faq-form" initialValues={{ remember: false }} onFinish={handleEditFaq} scrollToFirstError layout='vertical'>
                                    {/* Question  */}
                                    <Form.Item name="question" rules={[{ required: true, whitespace: true, message: 'Please add Question' }]} label="Question">
                                        <Input placeholder="Enter question here" />
                                    </Form.Item>
                                    {/* Answer  */}
                                    <Form.Item name="answer" rules={[ () => ({
                                        validator(_, value) {
                                            const remove_space = value.replace(/\s/g, "")
                                            if (value) {
                                                if (value === '<p><br></p>'  || remove_space === '<p></p>') return Toast.warn('Please enter description') 
                                            }
                                                return Promise.resolve();
                                            
                                        },
                                    })]} hasFeedback label="Answer">
                                        <ReactQuill theme="snow" value={value} onChange={onchange} placeholder="Write description here..." />
                                    </Form.Item>
                                    {/* Button  */}
                                    <Form.Item>
                                        <Button type="primary" htmlType="submit" size={'large'} loading={loading}>
                                            Save Changes
                                        </Button>
                                    </Form.Item>

                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

EditFAQs.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}


export default EditFAQs
