import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Collapse, theme, Typography, Pagination, Popconfirm } from 'antd';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { FaqListingInterface } from '@/interfaces';
import SearchPage from '@/components/common/SearchInput';
import { ChatContext } from '@/context/chatProvider';

const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

const { Panel } = Collapse;
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ViewFAQsPage: Page = (props: any) => {
    const { token } = theme.useToken();
    const router = useRouter();
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const { socketHitType } = React.useContext(ChatContext)
    const [deleteLoading, setDeleteLoading] = React.useState(false)
    const [state, setState] = React.useState({
        data: [] as Array<FaqListingInterface>,
        count: 0,
        service_name:""
    })
    const service_id = router.query._id
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onSearch = (value: string) => {
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }

    const handlePagination = (page: number, pageSize: number) => {
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.Faq.listing(urlSearchParam.toString(), router.query._id , "USER")
            setState(apiRes)

        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.search , socketHitType])

    const handleDelete = async (_id: string) => {
        setDeleteLoading(true)
        try {
            debugger
            let apiRes = await henceforthApi.Faq.delete(_id)
            Toast.success(apiRes.message)
            const newData=state?.data?.findIndex((item:any)=>item?._id == _id)
            state?.data?.splice(newData,1)
            initialise()
            if(!state?.data?.length){
                router.back()
            }
        } catch (error) {
            console.log(error)
        } finally {
            setDeleteLoading(false)
        }

    }

    const panelStyle = {
        marginBottom: 24,
        background: token.colorFillAlter,
        borderRadius: token.borderRadiusLG,
        border: '1px solid #e6e6e6',
    };
    console.log('props', props);

    const genExtra = (res: any) => (<ul className='list-unstyled'>
        <li>
            <Link href={`/faq-user/${res?._id}/edit`} >
                <Button type="text" className='px-0 border-0 bg-transparent shadow-none'><HenceforthIcons.Edit /></Button>
            </Link>
            <Popconfirm
                    title="Delete"
                    description="Are you sure you want to delete ?"
                    onConfirm={(event) => { event?.stopPropagation(); handleDelete(res._id) }}
                >
                    <Button type='primary' className='bg-transparent p-1'  ><HenceforthIcons.Trash /></Button>
                </Popconfirm>
        </li>
    </ul>)
    return (
        <Fragment>
            <Head>
                <title>FAQs</title>
                <meta name="description" content="FAQs" />
            </Head>
            <section className='faq'>

                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'><Link href={'/faq-user/page/1'} className='text-decoration-none'>FAQs</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item >{state?.service_name}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center'>
                                <Typography.Title level={3} className='m-0 fw-bold'>FAQs</Typography.Title>
                                <Link href={`/faq-user/${service_id}/add`}><Button type="primary" htmlType="button" icon={<PlusOutlined />} size={'large'}>Add FAQ</Button></Link>
                            </div>
                            {/* Search  */}
                            <div className='my-4'>
                                {/* <Search size="large" placeholder="Search..." enterButton /> */}
                                <SearchPage placeholder="Search" pathname={`/faq/${router.query._id}/view`} />
                            </div>
                            {/* Accordion  */}
                            <div className='accordion-wrapper'>
                                <Collapse
                                    bordered={false}
                                    accordion
                                    expandIconPosition='right'

                                >
                                    {state.data.map((res: any, index: number) => {
                                        return (
                                            <>
                                                < Panel key={res._id} className='mb-3' header={res?.question} style={panelStyle} extra={genExtra(res)} >
                                                    <Typography.Paragraph className="m-0" ><span dangerouslySetInnerHTML={{ __html: res?.answer }}></span></Typography.Paragraph>
                                                </Panel>
                                            </>
                                        )
                                    })}

                                </Collapse>
                            </div>
                            {/* <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} /> */}
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment >
    )
}

ViewFAQsPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {

    return { props: { params: 'all' } };
}


export default ViewFAQsPage
