import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table,Breadcrumb,Typography, Upload } from 'antd';
import Link from 'next/link';
import {UploadOutlined} from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import placehlder from '@/assets/images/placeholder.png'
import SearchPage from '@/components/common/SearchInput';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const FAQs: Page = () => {
    const [value, setValue] = React.useState<RangeValue>(null)
    const router = useRouter()
    const {downloadCSV, Toast} = React.useContext(GlobalContext)
    const { socketHitType  } = React.useContext(ChatContext)
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);
    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Faq.faq(urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search, router.query.type ,socketHitType])
    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    const dataSource = state?.data?.sort((a:any,b:any)=> a?.name?.localeCompare(b?.name)).map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            city: <div className='d-flex gap-2'>
                <Typography.Text>Sharjah</Typography.Text>
                <HenceforthIcons.ViewTwo />
            </div>,
            service: <div>
                <div className='service-detail d-inline-flex gap-2 align-items-center'>
                    <div className="service-detail-img">
                        <img src={henceforthApi.FILES.imageSmall(res?.image, placehlder.src)} alt='img' />
                    </div>
                    <div>
                        <Typography.Text>{res?.name || 'N/A'}</Typography.Text>
                    </div>
                </div>
            </div>,
            action: <div>
                <Link href={`/faq-user/${res?._id}/view`}>
                    <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
                </Link>
            </div>
        }
    })
    return (
        <Fragment>
            <Head>
                <title>FAQs</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>FAQs</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>FAQs</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[5, 15]} className='my-4'>
                                <Col span={24}>
                                    {/* Search  */}
                                    <SearchPage placeholder="search" pathname="/faq/page/1"/>
                                </Col>
                            </Row>

                            {/* Table  */}
                            <Row className="mt-4">
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.faqColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue}  open={exportModal} setOpen={setExportModal} title="User Faq Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Faq.export(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                Service:item?.name,
                            }
                          })
                        downloadCSV("Faq", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}
FAQs.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default FAQs
