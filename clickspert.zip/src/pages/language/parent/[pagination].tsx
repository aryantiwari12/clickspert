import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Modal, Popconfirm, Space, Table, Typography } from 'antd';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import henceofrthEnums from '@/utils/henceofrthEnums';
import dynamic from 'next/dynamic';
import ColumnsType from '@/interfaces/ColumnsType';
import Link from 'next/link';
import image_1 from "@/assets/images/product-1.png"
import { EyeFilled, EyeOutlined, EditFilled, LoginOutlined, EditOutlined, DeleteFilled } from '@ant-design/icons';
import { LanguageInterface } from '@/interfaces';
import HenceforthIcons from '@/components/HenceforthIcons';


const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

let timer:any;
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const { Search } = Input;
interface DataType {
    key: React.Key;
}

const ParentPage: Page = (props: any) => {
    const router = useRouter()
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [deleteLoading, setDeleteLoading] = useState(false);

    const [state, setState] = React.useState({
        data: [{} as LanguageInterface],
        count: 0
    })

    const [modalData, setModalData] = React.useState(null as any);

    const showModal = (data: any) => {
        console.log('showModal data', data);
        setModalData(data);
    };

    const handleOk = async (res: any) => {
        setModalData(null);
        await updateData(res);
    };

    const handleCancel = () => {
        setModalData(null);
    };

    const updateData = async (values: any) => {
        console.log("values for updateData", values);
        try {
            let name = String(modalData.name).trim()
            if (!name) {
                return Toast.warn("Name should not be empty")
            }
            let items = {
                name
            }
            if (items) {
                setLoading(true)
                let apiRes = await henceforthApi.LanguageParent.edit(values._id, items)
                console.log("edit response", apiRes);
                setState(apiRes?.updated_data)
                await initialise()
                Toast.success("Language Updated")
            }
        } catch (error) {
            console.log(error)
        }
        finally {
            setLoading(false)
        }
    };

    const onDelete = async (id: string) => {
    }
    const handleStatus = async (id: string, status: string) => {
    }

    const StatusItem = (res: any) => {
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.pending}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.pending} />,
                        onClick: () => handleStatus(res.id, henceofrthEnums.InquiryStatus.pending),
                        disabled: !res?.resolved
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.resolved}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.resolved} />,
                        onClick: () => handleStatus(res.id, henceofrthEnums.InquiryStatus.resolved),
                        disabled: res?.resolved
                    }
                ],

            },
            {
                key: '2',
                label: (
                    <Typography.Text >
                        Delete Inquiry
                    </Typography.Text >
                ),
                onClick: () => onDelete(res.id),

            }

        ]
    }

    const handleDelete = async (id: string) => {
        try {
            setDeleteLoading(true)
            let apiRes = await henceforthApi.LanguageParent.delete(id)
            console.log("handleDelete called", apiRes);
            Toast.success(apiRes.message)
            initialise()
        } catch (error) {
            console.log(error)
        }
        finally {
            setDeleteLoading(false)
        }
    }


    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            page: res.name || 'N/A',
            action: <ul className='m-0 list-unstyled d-flex '>
                <li>
                    <Link href={`/language/parent/child/${res._id}/1`}>
                        <Button  shape='circle' className='border-0'><HenceforthIcons.ViewIcon/></Button>
                    </Link>
                </li>
                <li>
                    <Button shape='circle' className='border-0' onClick={() => showModal(res)}><HenceforthIcons.PencileIcon /></Button>
                </li>
                <li>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure you want to delete ?"
                        onConfirm={(event) => { event?.stopPropagation(); handleDelete(res._id) }}
                        okButtonProps={{ loading: deleteLoading, danger: true }}
                    >
                        <Button className='border-0' shape='circle' ><HenceforthIcons.Trash /></Button>
                    </Popconfirm>

                </li>
            </ul>
        }
    }
    );

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }

    const onSearch = (value: string) => {
        if(timer){
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }
    const handlePagination = (page: number, pageSize: number) => {
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.LanguageParent.listing(urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {
            console.log("get Language", error)

        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search])


    return (
        <Fragment>
            <Head>
                <title>Contact-us</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Language</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Language</Typography.Title>
                                {/* <Button type="primary" htmlType="button" size='large' icon={<DownloadOutlined />}>Export</Button> */}
                            </div>
                            {/* Search  */}
                            <div className='my-4'>
                                <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
                            </div>
                            {/* Table  */}
                            <div className='table-wrapper'>
                                <Table dataSource={dataSource}
                                    columns={ColumnsType.languageColumns as any}
                                    pagination={false} scroll={{ x: '100%' }} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal title="Edit Language" open={modalData != null} okText={'Save'} onOk={() => handleOk(modalData)} onCancel={handleCancel}>
                <Form
                    name="basic"
                    labelCol={{ span: 8 }}
                    wrapperCol={{ span: 16 }}
                    style={{ maxWidth: 600 }}
                    initialValues={{ remember: true }}
                    autoComplete="off"
                >
                    <Space> Name
                        <Input placeholder="Enter name here" defaultValue={modalData?.name} value={modalData?.name} onChange={(e) => setModalData({ ...modalData, 'name': e.target.value })} />
                    </Space>
                </Form>
            </Modal>

        </Fragment>
    )
}

ParentPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default ParentPage
