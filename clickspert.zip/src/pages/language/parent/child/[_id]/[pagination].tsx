import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Modal, Popconfirm, Space, Table, Typography } from 'antd';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import henceofrthEnums from '@/utils/henceofrthEnums';
import dynamic from 'next/dynamic';
import ColumnsType from '@/interfaces/ColumnsType';
import { DeleteFilled, EditOutlined } from '@ant-design/icons';
import Link from 'next/link';
import { SubLanguageInterface } from '@/interfaces';


const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}


type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const { Search } = Input;
interface DataType {
    key: React.Key;
}


const ChildPage: Page = (props: any) => {
    const router = useRouter()
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)

    const [state, setState] = React.useState({
        data: [{} as SubLanguageInterface],
        total_count: 0
    })
    const [deleteLoading, setDeleteLoading] = useState(false);

    const [modalData, setModalData] = React.useState(null as any);

    const showModal = (data: any) => {
        console.log('showModal data', data);
        setModalData(data);
    };

    const handleOk = async (res: any) => {
        setModalData(null);
        await updateData(res);
    };

    const handleCancel = () => {
        setModalData(null);
    };

    const onDelete = async (id: string) => {

    }
    const handleStatus = async (id: string, status: string) => {

    }

    const handleDelete = async (id: string) => {
        try {
            setDeleteLoading(true)
            let apiRes = await henceforthApi.LanguageChild.delete(id)
            console.log("handleDelete called", apiRes);
            Toast.success(apiRes.message)
            initialise()
        } catch (error) {
            console.log(error)
        }
        finally {
            setDeleteLoading(false)
        }
    }

    const StatusItem = (res: any) => {
        return [
            {
                key: '1',
                label: (
                    <Typography.Text >
                        Change Status
                    </Typography.Text >
                ),
                children: [
                    {
                        key: '11',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.pending}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.pending} />,
                        onClick: () => handleStatus(res.id, henceofrthEnums.InquiryStatus.pending),
                        disabled: !res?.resolved
                    },
                    {
                        key: '12',
                        label: (
                            <Typography.Text >
                                {henceofrthEnums.InquiryStatus.resolved}
                            </Typography.Text >
                        ),
                        icon: <Badge color={henceofrthEnums.InquiryColor.resolved} />,
                        onClick: () => handleStatus(res.id, henceofrthEnums.InquiryStatus.resolved),
                        disabled: res?.resolved
                    }
                ],
            },
            {
                key: '2',
                label: (
                    <Typography.Text >
                        Delete Inquiry
                    </Typography.Text >
                ),
                onClick: () => onDelete(res.id),
            }
        ]
    }

    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: res?.key,
            en_us: res?.en_us,
            hi: res?.hi,
            ar: res?.ar,
            action: <ul className='m-0 list-unstyled d-flex gap-2'>
                <li>
                    <Button type='primary' shape='circle' onClick={() => showModal(res)}><EditOutlined /></Button>
                </li>
                <li>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure you want to delete ?"
                        onConfirm={(event) => { event?.stopPropagation(); handleDelete(res._id) }}
                        okButtonProps={{ loading: deleteLoading, danger: true }}
                    >
                        <Button type='primary' danger shape='circle' ><DeleteFilled /></Button>
                    </Popconfirm>

                </li>
            </ul>
        }
    })

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }

    const onSearch = (value: string) => {
        onChangeRouter("search", value)
    }
    const handlePagination = (page: number, pageSize: number) => {
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.LanguageChild.listing(String(router.query._id), urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    const updateData = async (values: any) => {
        console.log("values for updateData", values);
        try {
            let en_us = String(modalData.en_us).trim()
            let hi = String(modalData.hi).trim()
            let ar = String(modalData.ar).trim()
            if (!en_us) {
                return Toast.warn("en_us should not be empty")
            }
            if (!hi) {
                return Toast.warn("hi should not be empty")
            }
            if (!ar) {
                return Toast.warn("ar should not be empty")
            }
            let items = {
                parent_id: String(router.query._id),
                en_us,
                hi,
                ar
            }
            if (items) {
                setLoading(true)
                let apiRes = await henceforthApi.LanguageChild.edit(values._id, items)
                console.log("edit response", apiRes);
                setState(apiRes?.updated_data)
                await initialise()
                Toast.success("Language Updated")
            }
        } catch (error) {
            console.log(error)
        }
        finally {
            setLoading(false)
        }
    };

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search])

    return (
        <Fragment>
            <Head>
                <title>Sub Language</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/language/parent/1" className='text-decoration-none'>Language</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Sub Language</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center flex-column flex-md-row gap-3 '>
                                <Typography.Title level={3} className='m-0 fw-bold'>Sub Language</Typography.Title>
                                {/* <Button type="primary" htmlType="button" size='large' icon={<DownloadOutlined />}>Export</Button> */}
                            </div>
                            {/* Search  */}
                            <div className='my-4'>
                                <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
                            </div>
                            {/* Table  */}
                            <div className='table-wrapper'>
                                <Table dataSource={dataSource} columns={ColumnsType.languageDetailsColumns as any} pagination={false} scroll={{ x: '100%' }} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.total_count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal title={modalData?.key} open={modalData != null} okText={'Save'} onOk={() => handleOk(modalData)} onCancel={handleCancel}>
                <Space direction="vertical" size="middle" style={{ display: 'flex' }}>
                    <Input placeholder="Enter in en-US" defaultValue={modalData?.en_us} value={modalData?.en_us} onChange={(e) => setModalData({ ...modalData, 'en_us': e.target.value })} />
                    <Input placeholder="Enter in Hindi" defaultValue={modalData?.hi} value={modalData?.hi} onChange={(e) => setModalData({ ...modalData, 'hi': e.target.value })} />
                    <Input placeholder="Enter in Arabic" defaultValue={modalData?.ar} value={modalData?.ar} onChange={(e) => setModalData({ ...modalData, 'ar': e.target.value })} />
                </Space>
            </Modal>

        </Fragment>
    )
}

ChildPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default ChildPage
