import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Space, Tag, Typography, Avatar, Dropdown, Select, Popconfirm, Modal, Form, Tabs, TabsProps, Alert } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import Link from 'next/link';
import { DownloadOutlined } from '@ant-design/icons';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { GlobalContext } from '@/context/Provider';
import { upperCase } from 'lodash';
import user from "@/assets/images/placeholder.png"
import HenceforthIcons from '@/components/HenceforthIcons';
import { Dayjs } from 'dayjs';
import { Router } from 'express';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
const { TextArea } = Input;





type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const VendorRequest: Page = () => {
  const [value, setValue] = useState<RangeValue>(null)
  const router = useRouter()
  const { Toast, downloadCSV, uploadCSV } = React.useContext(GlobalContext)
  const { socketHitType } = React.useContext(ChatContext)
  const [exportModal, setExportModal] = React.useState(false);
  const [loading, setLoading] = React.useState(false)
  const [servicelist, setService] = useState({
    data: [],
    count: 0
  })
  const [form] = Form.useForm();
  const [limit, setLimit] = useState(10)
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [vendor_id, setVendorId] = useState('')
  const [state, setState] = React.useState({
    data: [],
    count: 0
  })
  const items: TabsProps['items'] = [
    {
      key: 'pending',
      label: 'Pending',

    },
    {
      key: 'rejected',
      label: 'Rejected',

    }

  ];
  const columns: ColumnsType<any> = [
    {
      title: 'Sr.no.',
      dataIndex: 'key',
      key: 'key',
      width: 100,
    },
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      width: 150
    },
    {
      title: 'Email',
      dataIndex: 'email',
      key: 'email',
      width: 180
    },
    {
      title: 'Phone No.',
      dataIndex: 'PhoneNo',
      key: 'PhoneNo',
      width: 180
    },
    {
      title: 'Services',
      dataIndex: 'services',
      key: 'services',
      width: 180
    },
    {
      title: 'City',
      dataIndex: 'city',
      key: 'city',
      width: 150
    },
    {
      title: 'Area',
      dataIndex: 'area',
      key: 'area',
      width: 200
    },
    {
      title: 'Actions',
      dataIndex: 'actions',
      key: 'actions',
      width: 150,
    }
  ];
console.log(router);

  const showModal = (_id: any) => {
    setIsModalOpen(true);
    setVendorId(_id)
  };
  console.log(vendor_id, "vendor_id");
  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };
  const onChangeRouter = (key: string, value: string) => {
    
    if(value){
      router.replace({
        query: { ...router.query, [key]: value }
      })
    }
    else{
      delete router.query.service_id
      router.replace({query : { ...router.query}})
    }
  }
  const Managevendor = async (_id: any, name: any, value: any) => {
    debugger
    try {
      setLoading(true)
      const info = {
        vendor_id: _id,
        account_status: name,
        account_rejection_reason: value.account_rejection_reason
      }
      let apiRes = await henceforthApi.Vendor.manage(info)
      Toast.success(apiRes.message)
      initialise()
      // Toast.success(apiRes.message)
    } catch (error) {

    } finally {
      setIsModalOpen(false)
      form.resetFields()
      setLoading(false)
    }
  }

  const handleFilter = (value: any) => {
    console.log("handleFilter called", value);
    onChangeRouter("service_id", value)
  }

  const handlePagination = (page: number, pageSize: number) => {
    console.log('page: number, pageSize', page, pageSize);
    setLimit(pageSize as any)
    router.replace({
      query: { ...router.query, pagination: page ,limit:pageSize}
    })
  }
  const dataSource = state?.data.map((res: any, index: number) => {
    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center' key={1}>
        <Avatar size={40} src={user.src}></Avatar>
        <Typography.Text className='text-capitalize'>
          <Tooltip title={res.name}> {res.name.slice(0, 10) || 'N/A'}</Tooltip></Typography.Text></div>,
      email: <Tooltip title={res.email}>{res.email.slice(0, 19) || 'N/A'}</Tooltip>,
      PhoneNo: res.phone_no || 'N/A',
      services: <>{Array.isArray(res.services) && (res?.services?.length) ? res?.services.slice(0, 1).map((res: any, index: number) => <span key={res._id}><Tooltip className='text-break'>{(index !== 0 ? ', ' : '') + res + '...'}</Tooltip></span>) : "N/A"}</>,
      city: <Tooltip title={res?.city}>{res?.city?.slice(0, 15) + '...'}</Tooltip> || 'N/A',
      area: <Tooltip title={res?.area}>{res?.area?.slice(0, 25) || 'N/A'}</Tooltip>,
      actions: <ul className='m-0 list-unstyled d-flex gap-1'>
        <li>
          <Link href={`/vendor-request/${res._id}/view`}><Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button></Link></li>
        {router.query.status == "pending" && <div className='d-flex'>
          <li>
            <Popconfirm
              title="Accept the Vendor"
              onConfirm={() => Managevendor(res._id, "ACCEPT", '')}
              description="Are you sure to Accept this Vendor?"
              okText="Accept"
              cancelText="No"
            >
              <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button>
            </Popconfirm>
          </li>
          <li>
            {/* <Popconfirm
            title="Reject the Vendor"
            onConfirm={() => Managevendor(res._id, "REJECT")}
            description="Are you sure to Reject this Vendor?"
            okText="Reject"
            cancelText="No"
          > */}
            <Button type='primary' onClick={() => showModal(res?._id)} shape='circle' className='bg-transparent'><HenceforthIcons.No />
            </Button>
            {/* </Popconfirm> */}
          </li>
        </div>}
      </ul>
    }
  })
  const onSearch = (e: any) => {
    if (e.target.value.trim()) {
      router.replace({
        pathname: e.pathname, query: { ...router.query, search: e.target.value.trim() }
      })
    } else if (!e.target.value) {
      let query = { ...router.query }
      delete query['search']
      router.push({ query }, undefined, { shallow: true })
    }
  }
  let urlSearchParam = new URLSearchParams()
  const initialise = async () => {
    try {
      setLoading(true) 
      let query = router.query
      if (query.pagination) {
        urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
      }
      // if (query.limit) {
      //   urlSearchParam.set('limit', router.query.limit as string)
      // }
      if (query.service_id) {
        urlSearchParam.set(`service_id`, router.query.service_id as any)
      }
      if (query.search) {
        urlSearchParam.set('search', router.query.search as string)
      }
      if (query.status) {
        urlSearchParam.set('status', upperCase(router.query.status as string))
      }
      let apiRes = await henceforthApi.Vendor.vendorRequest(urlSearchParam.toString() ,limit ?? 10)
      setState(apiRes)

    } catch (error) {
      console.log(error)
    } finally {
      setLoading(false)
    }
  }
  const service = async () => {
    try {
      let apiRes = await henceforthApi.Vendor.get()
      apiRes?.data?.unshift({_id:'' , name:"All"})
      setService(apiRes)
    } catch (error) {

    }
  }
  useEffect(() => {
    service()
  }, [])
  React.useEffect(() => {
    initialise()
  }, [router.query.pagination, router.query.limit, limit , router.query.search, router.query.service_id, router.query.status ,socketHitType])

  return (
    <Fragment>
      <Head>
        <title>Vendor</title>
        <meta name="description" content="Vendor" />
      </Head>
      <section>
        <Row gutter={[20, 20]}>
          {/* <Col span={24}>
            <Alert message={<div className='flex-between'><Typography.Title level={4} className='m-0 fw-medium'>This user has changed this content</Typography.Title><Space className='gap-0'>  <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button> <Button type='primary'  shape='circle' className='bg-transparent'><HenceforthIcons.No />
            </Button></Space></div>} type="warning" />
          </Col> */}
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Main menu</Link></Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/vendor/page/1" className='text-decoration-none'>Vendors</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Vendor requests</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* title  */}
              <div className='flex-center'>
                <Typography.Title level={3} className='m-0 mb-3 mb-md-0 fw-bold'>Vendor Requests</Typography.Title>
                <div className='d-flex align-items-lg-stretch gap-3 overflow-auto flex-nowrap'>
                  <Button type="primary" htmlType="button" size='large' onClick={() => setExportModal(true)} icon={<HenceforthIcons.Export />}>Export</Button>
                </div>
              </div>
              {/* Search  */}
              <div className='my-4 d-flex gap-2 align-items-center'>
                {/* <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton /> */}
                <div className='w-100'>
                  <Search onChange={onSearch} size="large" placeholder="Search..." enterButton />
                </div>
                <Space className='vendor-request-select'>
                  < Select
                    size="large"
                    defaultValue="All"
                    style={{ width: 250 }}
                    onChange={handleFilter}
                    options={servicelist?.data.map((res: any, index: number) => { return { value: res._id, label: res.name } }) as any}
                  />
                </Space>

              </div>
              {/* Table  */}
              <div className='tabs-wrapper mt-2'>
                <Tabs activeKey={router.query.status as string} items={items} onChange={(value) => onChangeRouter("status", value)} />
              </div>
              <div className='tabs-wrapper'>
                <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} className="w-100" />

              </div>
              {/* Pagination  */}
              <Row justify={'center'} className="mt-4">
                <Col span={24}>
                  <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                </Col>

              </Row>
            </Card>
          </Col>
          <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
            <div className='text-center'>
              <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Enter Reason</Typography.Title>
              <Typography.Paragraph className='text-gray'>Please enter the reason for declining the vendor’s request</Typography.Paragraph>
              <Form
                size='large' form={form} onFinish={(name) => Managevendor(vendor_id, "REJECT", name)} layout='vertical'>
                <Form.Item name="account_rejection_reason" rules={[{ required: true, message: "Please Enter Reason" }]}>
                  <TextArea rows={4} className='border-0' placeholder="Enter reason here..." />
                </Form.Item>
                <Form.Item className='mb-2'>
                  <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                </Form.Item>
              </Form>
            </div>
          </Modal>
        </Row>
        <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
          try {
            setLoading(true)
            let apiRes = await henceforthApi.Vendor.export(start_date, end_date , router.query.status )
            const exportData = apiRes?.data?.map((item: any, index: number) => {
              return {
                name: item?.name ?? 'N/A',
                email: item?.email ?? 'N/A',
                phone_no: item?.phone_no ?? 'N/A',
                money_earned: item?.vendor_earning ?? 'N/A',
                city: item?.city?.split(",")?.join(" ")?? 'N/A',
                street_address: item?.area?.split(",")?.join(" ") ?? 'N/A',
                service: item?.services.map((res: any, index: number) => res)?.toString()?.split(",")?.join(" ") ?? 'N/A',
              }
            })
            downloadCSV("Vendor-Request", exportData)
          } catch (error) {
            console.log(error);
          } finally {
            setLoading(false)
            setValue(null)
          }
        }} />

      </section>

    </Fragment>
  )
}

VendorRequest.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default VendorRequest
