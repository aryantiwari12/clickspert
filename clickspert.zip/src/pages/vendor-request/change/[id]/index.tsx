import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useContext, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Typography } from 'antd';
import Link from 'next/link';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import henceforthValidations from '@/utils/henceforthValidations';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ChangePassword: Page = (props: any) => {
    const [form] = Form.useForm();
    const router = useRouter()
    const { Toast, loading, setLoading } = useContext(GlobalContext)
    const onFinish = async (values: any) => {
        try {
            setLoading(true)
            if (henceforthValidations.strongPassword(values.password) === false) return Toast.warn(`Password must contains 8 characters including combination of uppercase and lowercase letter and number`)
            if (values.confirmPassword !== values.password) return Toast.warn(`New password does not match to confirm password`)
            let items = {
                _id: router.query.id,
                password: values.password
            }
            let apiRes = await henceforthApi.Vendor.vendorChange(items)
            Toast.success(apiRes.message || "Change Password successfully");
            router.back()
        } catch (error: any) {
            Toast.error(error?.response?.body?.message)
        }
        finally {
            setLoading(false)
        }
    };

    return (
        <Fragment>
            <Head>
                <title>Change Password</title>
                <meta name="description" content="Change Password" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col sm={22} md={12} lg={11} xl={10} xxl={9}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                                    {/* <Breadcrumb.Item><Link href="/profile" className='text-decoration-none'>Profile</Link></Breadcrumb.Item> */}
                                    <Breadcrumb.Item className='text-decoration-none'>Change Password</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='mb-4'>
                                <Typography.Title level={3} className='m-0 fw-700'>Change Password</Typography.Title>
                            </div>
                            {/* form  */}
                            <div className='card-form-wrapper'>
                                <Form size='large' form={form} name="change_password" className="change-password-form" onFinish={onFinish} scrollToFirstError layout='vertical'>
                                    {/* New Password  */}
                                    <Form.Item name="password" rules={[{ required: true, message: 'Please Enter your password!' }, { pattern: henceforthValidations.strongPasswordRegEx, message: "Password must contains 8 characters including combination of uppercase and lowercase letter and number" }]} label="New Password">
                                        <Input.Password className='border-0' type='password' placeholder="New Password" />
                                    </Form.Item>
                                    {/* Confirm Password  */}
                                    <Form.Item name="confirmPassword" dependencies={['password']} rules={[{ required: true, message: 'Please confirm your password' }, ({ getFieldValue }) => ({
                                        validator(_, value) {
                                            if (!value || getFieldValue('password') === value) {
                                                return Promise.resolve();
                                            }
                                            return Promise.reject(new Error('The new password that you entered do not match'));
                                        },
                                    }),]} label="Confirm Password">
                                        <Input.Password className='border-0' type='password' placeholder="Confirm Password" />
                                    </Form.Item>
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit" className="login-form-button " loading={loading}>
                                        Update Password
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

ChangePassword.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default ChangePassword
