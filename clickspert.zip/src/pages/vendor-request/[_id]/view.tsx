import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Divider, Pagination, Table, Typography, Popconfirm, Input, TabsProps, TableColumnsType, Modal, Form, Alert, Space } from 'antd';
import User from "@/assets/images/placeholder.png"
import Link from 'next/link';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import { GlobalContext } from '@/context/Provider';
import uiSettings from '@/utils/uiSettings';
import { VendorRequest } from '@/interfaces';
import VendorService from '@/components/common/VendorService';
import VendorSecondary from '@/components/common/VendorSecondary';
// import VendorNewDocument from '@/components/common/VendorDocument';
import VendorDocument from '@/components/common/VendorDocument';
import VendorNewDocument from '@/components/common/vendorNewDocs';
import HenceforthIcons from '@/components/HenceforthIcons';
const { Row, Col, Card, Button, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
const { TextArea } = Input;
const VendorRequestView: Page = (props: any) => {
  const {userInfo, Toast, setUserInfo } = React.useContext(GlobalContext)
  const [state, setState] = useState<any>(props.data) 
  const [blockLoading, setBlockLoading] = React.useState(false)
  const [deactiveLoading, setDeactiveLoading] = React.useState(false)
  const [deleteLoading, setDeleteLoading] = React.useState(false)
  console.log(props, "props");
  const [productState, setProductState] = React.useState({
    data: [] as any,
    count: 0
  })
  const [form] = Form.useForm();
  const router = useRouter()
  const [loading,setLoading]=useState({
    loading1:false,
    loading2:false,
  })
  const handlePagination = (page: number, pageSize: number) => {
    console.log('page: number, pageSize', page, pageSize);
    router.replace({
      query: { ...router.query, pagination: page, limit: pageSize }
    })
  }
  const Managevendor = async (_id: any, name: any,value:any) => {
    try {
      setLoading({
        ...loading,
        loading1:true
      })
      const info = {
        vendor_id: _id,
        account_status: name,
        account_rejection_reason: value.account_rejection_reason
      }
      let apiRes = await henceforthApi.Vendor.manage(info)
      Toast.success(apiRes.message)
      router.back()
    } catch (error) {
      Toast.error(error)
    }finally{
        setIsModalOpen(false)
      form.resetFields()
      setLoading({
        ...loading,
        loading1:false
      })
    }
    
  }
  const deleteUser = async () => {
    setDeleteLoading(true)
    try {
      let resApi = await henceforthApi.Vendor.delete(String(router.query._id))
      Toast.success(resApi.message ?? 'Vendor Deleted' )
      router.back()
    } catch (error) {
      Toast.error(error);
    }
    finally {
      setTimeout(() => {
        setDeleteLoading(false)
      }, 500)
    }
  }
  const [isModalOpen, setIsModalOpen] = useState(false);
  const showModal = () => {
    setIsModalOpen(true);
  };

  const handleOk = () => {
    setIsModalOpen(false);
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };


  return (
    <Fragment>
      <Head>
        <title>Vendor Details</title>
        <meta name="description" content="User Details" />
      </Head>
      <section>

        <Row gutter={[20, 20]} className="mb-4">
        {/* <Col span={24}>
            <Alert message={<div className='flex-between'><Typography.Title level={4} className='m-0 fw-medium'>This user has changed this content</Typography.Title><Space className='gap-0'>  <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button> <Button type='primary'  shape='circle' className='bg-transparent'><HenceforthIcons.No />
            </Button></Space></div>} type="warning" />
          </Col>
          <Col span={24}>
            <Alert message={<div className='flex-between'><Typography.Title level={4} className='m-0 fw-medium'>This user has changed this content</Typography.Title><Space className='gap-0'>  <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.Yes /></Button> <Button type='primary'  shape='circle' className='bg-transparent'><HenceforthIcons.No />
            </Button></Space></div>} type="warning" />
          </Col> */}
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/vendor/page/1" className='text-decoration-none'>Vendor</Link></Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/vendor-request/page/1" className='text-decoration-none'>Vendor requests</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>
                    {state?.name || 'N/A'}
                  </Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div>
                <Typography.Title level={3} className='m-0 fw-600'>Vendor Detail</Typography.Title>
              </div>
              {/* Car Listing  */}
              <div className='card-listing'>
                <div className='card-listing-image my-4 text-center'>
                  <Avatar size={120} src={henceforthApi.FILES.imageOriginal(state?.image, User?.src)}></Avatar>
                </div>
                <Divider plain></Divider>
                <Row justify={'space-between'}>
                  <Col span={24} md={12}>
                    <ul className='list-unstyled mb-4 mb-md-0 flex-shrink-0'>
                      <li><Typography.Title level={4} className='fw-700 mb-4'>Personal Info</Typography.Title></li>
                      <li className='mb-3'><Typography.Text>Name:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.name || 'N/A'}
                      </Typography.Text ></li>
                      <li className='mb-3'><Typography.Text>Email:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.email || 'N/A'}
                      </Typography.Text >
                      </li>
                      {/* <li><Typography.Text>Phone no:</Typography.Text> <Typography.Text  className='ms-1'>+{state.country_code} - {state.phone_no}</Typography.Text ></li> */}
                      <li className='mb-3'><Typography.Text>Phone no:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.country_code ? state?.country_code : ""} {state?.phone_no || 'N/A'}
                      </Typography.Text></li>
                      <li className='mb-3'><Typography.Text>Address:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.city || 'N/A'}
                      </Typography.Text></li>
                      <li className='mb-3'><Typography.Text>Area:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.area || 'N/A'}
                      </Typography.Text></li>
                      <li className='mb-3'><Typography.Text>City:</Typography.Text> <Typography.Text className='ms-1'>
                        {state?.city || 'N/A'}
                      </Typography.Text></li>
                      <li><Typography.Text>Description:</Typography.Text> <Typography.Text className='ms-1'>
                        <p className='text-break' dangerouslySetInnerHTML={{ __html: state?.description as any }}></p>
                      </Typography.Text></li>
                    {state?.reason &&  <li><Typography.Text>Rejected Reason:</Typography.Text> <Typography.Text className='ms-1'>
                        <p className='text-break'>{state?.reason ? state?.reason : "N/A"}</p>
                      </Typography.Text></li>}

                    </ul>
                  </Col>
                  <Col span={24} md={10}>
                    {/* Button  */}
                    <div className='card-listing-button'>
                      <Typography.Title level={4} className='fw-700 mb-4'>Action</Typography.Title>
                      <div className='d-flex flex-column gap-2 mt-3'>
                        <div className='w-100 d-flex gap-2'>
                          <Popconfirm
                            title="Accept the Vendor"
                            onConfirm={() => Managevendor(router.query._id, "ACCEPT",'')}
                            description="Are you sure to Accept this Vendor?"
                            okText="Accept"
                            cancelText="No"
                          >
                            <Button type="primary" htmlType='button' className='flex-grow-1 w-100' loading={blockLoading} disabled={blockLoading} size='large'> Accept</Button>
                          </Popconfirm>
                          <Button onClick={showModal} type="primary" htmlType='button' danger className='flex-grow-1 w-100' loading={deactiveLoading} disabled={deactiveLoading} size='large' ghost >
                            <span className='text-danger'>Decline</span>
                          </Button>
                        </div>
                        <Popconfirm
                          title="Delete"
                          description="Are you sure you want to delete ?"
                          onConfirm={deleteUser}
                          okButtonProps={{ loading: deleteLoading, danger: true }}
                        >
                          <Button type="primary" htmlType='button' className='flex-grow-1 w-100 ' size='large' disabled={deleteLoading} danger><span className='text-white'>Delete</span></Button>
                        </Popconfirm>
                        <Button type="primary" htmlType='button' onClick={()=>router.push(`/vendor-request/change/${state._id}`)} className='flex-grow-1 w-100' size='large' ghost >
                          Change Password
                        </Button>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Card>
            <Row gutter={[15, 15]}>
              {/* --------------------Vendor Service------ */}
              <VendorService {...state} />

              {/* --------------------Vendor Secondary--------- */}
              <VendorSecondary {...state} />

              {/* ------------- Vendor New Documents --------------- */}
             {state?.new_docs?.length ? <VendorNewDocument {...state} /> : ""}

              {/* --------------Vendor Old Docs-------------------- */}
              <VendorDocument {...state} />
            </Row>
          </Col>
        </Row>
        {/* Pagination  */}
        <Row justify={'center'}>
          <Col span={24}>
            <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={productState.count} hideOnSinglePage={true}  onChange={handlePagination} />
          </Col>
        </Row>
        <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
          <div className='text-center'>
            <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Enter Reason</Typography.Title>
            <Typography.Paragraph className='text-gray'>Please enter the reason for declining the vendor’s request</Typography.Paragraph>
            <Form size='large' form={form} onFinish={(name)=>Managevendor(router.query._id, "REJECT",name)} layout='vertical'>
              <Form.Item name="account_rejection_reason" rules={[{ required: true,message:"Please Enter Reason" }]}>
                <TextArea rows={4} className='border-0' placeholder="Enter reason here..." />
              </Form.Item>
              <Form.Item className='mb-2'>
                <Button type='primary' htmlType='submit' loading={loading.loading1} block>Submit</Button>
              </Form.Item>
            </Form>
          </div>
        </Modal>
      </section>
    </Fragment>
  )
}

VendorRequestView.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    let apiRes = await henceforthApi.Vendor.getById(context.query._id as string)
    let data = apiRes
    return { props: { data } };
  } catch (error) {
    return {
      props: {}
    }
  }

}

export default VendorRequestView
