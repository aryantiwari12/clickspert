import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker, Space, Popconfirm, Switch, Modal, Form, Radio } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, DeleteFilled, UploadOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import { Dayjs } from 'dayjs';

interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const SalonServices: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const [show, setShow] = useState(true);
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);
    const [itemsModal, setItemsModal] = React.useState(false)
    const [deleteLoading, setDeleteLoadingl] = React.useState(false)
    const [submitLoading, setSubmitLoading] = React.useState(false)
    const [modalText, setModalText] = React.useState('Add')
    const [form] = Form.useForm();


    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const onSearch = (value: string) => {
        console.log("onserach value", value);
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }

    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    console.log(state, 'state');

    const handleEdit = (res: any) => {
        setModalText('Edit')
        form.setFieldsValue(res)
        setItemsModal(true)
    }

    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: <Typography.Text>{res.name}</Typography.Text>,
            price: res.price,
            gender: res.gender,
            action:
                <ul className='m-0 list-unstyled d-flex gap-2'>
                    <li>
                        <Button type='primary' shape='circle' className='bg-transparent' onClick={() => handleEdit(res)} ><HenceforthIcons.Edit /></Button>
                    </li>
                    <li>
                        <Popconfirm
                            title="Delete"
                            description="Are you sure you want to delete ?"
                            onConfirm={(event) => { event?.stopPropagation(); handleDelete(res._id) }}
                            okButtonProps={{ loading: deleteLoading, danger: true }}
                        >
                            <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.DeleteIcon /></Button>
                        </Popconfirm>
                    </li>
                </ul>
        }
    }
    );
    const handleDelete = async (_id: string) => {
        try {
            setDeleteLoadingl(true)
            let apiRes = await henceforthApi.Salon.deleteItem(_id)
            initialise()
            Toast.success(apiRes.message)
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setDeleteLoadingl(false)
        }
    }

    const EditItem = async (values: any) => {
        console.log(form.getFieldValue('_id'));
        try {
            setSubmitLoading(true)
            const { price } = values;
            const numericPrice = +price;
            let apiRes = await henceforthApi.Salon.editItem({ ...values, price: numericPrice, _id: form.getFieldValue('_id') })
            initialise()
            Toast.success(apiRes.message)
            form.resetFields()
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setItemsModal(false)
            setSubmitLoading(false)
        }
    }

    const onFinish = async (values: any) => {
        if (modalText === 'Edit') {
            return EditItem(values)
        }
        try {
            setSubmitLoading(true)
            const { price } = values;
            const numericPrice = +price;
            let apiRes = await henceforthApi.Salon.addItem({ ...values, price: numericPrice })
            initialise()
            Toast.success(apiRes.message)
            form.resetFields()
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setItemsModal(false)
            setSubmitLoading(false)
        }
    }

    const initialise = async () => {
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            // if (query.limit) {
            urlSearchParam.set('limit', String(10))
            // }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.Salon.getItems(urlSearchParam.toString())
            setState(apiRes)
        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search])

    return (
        <Fragment>
            <Head>
                <title>Salon Services</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Salon Items</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Salon Items</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <div className=" d-flex align-items-center">
                                        <Button type="primary" htmlType="button" size='large' icon={<PlusOutlined />} onClick={() => { setItemsModal(true); setModalText('Add'); form.resetFields() }}>Add Item</Button>
                                    </div>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[5, 15]} className='my-4'>
                                <Col span={24}>
                                    {/* Search  */}
                                    <div className=' d-flex gap-4 align-items-center'>
                                        {/* <Search size="large" placeholder="Search..." onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton /> */}
                                        <div className='w-100'>
                                            <Input placeholder="Search" className='border-0' size='large' onChange={(e) => onSearch(e.target.value)} prefix={<SearchOutlined />} />
                                        </div>
                                    </div>
                                </Col>
                            </Row>

                            {/* Table  */}
                            <Row className="mt-4">
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.SalonItemsColumns}
                                        pagination={false}
                                    />
                                </Col>
                            </Row>
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={false} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
            <Modal
                title={`${modalText} Item`}
                centered
                open={itemsModal}
                footer={null}
                onCancel={() => setItemsModal(false)}
            >
                <div className='card-content-wrapper'>
                    <Form name="add-items" size="large" form={form} className="add-items" initialValues={{ remember: false }} layout='vertical' onFinish={onFinish} scrollToFirstError>
                        {/* Name  */}
                        <Form.Item
                            name="name"
                            label="Name"
                            rules={[{ required: true, message: 'Please enter name', whitespace: true }]}
                        >
                            <Input size='large' name='name'
                                onKeyPress={(e: any) => {
                                    if (!/[a-zA-Z ]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                                        e.preventDefault();
                                    }
                                }}
                                maxLength={20} className='w-100' id='Name' placeholder="Name" />
                        </Form.Item>
                        {/* Price  */}
                        <Form.Item
                            name="price"
                            label="Price"
                            rules={
                                [
                                    // { required: true },
                                    () => ({
                                        validator(_, value) {
                                            if (isNaN(value)) {
                                                return Promise.reject("price has to be a number.");
                                            }
                                            if (!value) {
                                                return Promise.reject("Please enter a valid price");
                                            }
                                            else {
                                                return Promise.resolve();
                                            }
                                        },
                                    }),
                                ]
                            }
                        >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} maxLength={5}
                                style={{ width: '100%' }} placeholder='price'
                            />
                        </Form.Item>
                        <Form.Item
                            name="gender"
                            label="Gender"
                            rules={[{ required: true, message: 'Please Select gender' }]}
                        >
                            <Radio.Group >
                                <Radio value={'MALE'}>Male</Radio>
                                <Radio value={"FEMALE"}>Female</Radio>
                            </Radio.Group>
                        </Form.Item>
                        {/* Button  */}
                        <Button type="primary" htmlType="submit" className="login-form-button w-100" loading={submitLoading}>
                            {modalText} Item
                        </Button>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}

SalonServices.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default SalonServices
