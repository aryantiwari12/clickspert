'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb,Modal, Table, Typography } from 'antd';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import ColumnsType from '@/interfaces/ColumnsType';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import Link from 'next/link';
import SearchPage from '@/components/common/SearchInput';
import uiSettings from '@/utils/uiSettings';
import { Dayjs } from 'dayjs';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Services: Page = (props: any) => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [state, setState] = React.useState({
        data: [] as any,
        count: 0
    })
    const [limit,setLimit]=useState(10)
    const dataSource = state?.data?.map((res: any, index: any) => {
        return {
            key: uiSettings.serialNumber(router.query.pagination, index, router.query.limit),
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res.image)} alt='img'  />
                </div>
                <Typography.Text>{res.name || "N/A"}</Typography.Text></div>,
            subservice: <div>{res?.sub_services?.slice(0,3)?.map((res2: any, index: any) => <span  key={res2._id}>{(index!==0?', ':'')+res2.name} </span>)}</div>,
            action: <Link href={res?._id ? `/services/${res._id}/view` : res?.link}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }
    const onSearch = (value: string) => {
        onChangeRouter("search", String(value).trim())
    }
    const handlePagination = (page: number, pageSize: number) => {
        setLimit(pageSize)
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const initialise = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.Service.servicelisting(urlSearchParam?.toString(),10)
            // urlSearchParam.toString()
            setState(apiRes)
            // setState({
            //     data: [{
            //         name: "Saloon",
            //         subServices: ["Women haircut", "Men haircut"],
            //         link: `/services/salon/page/1`
            //     }, {
            //         name: "Cleaning",
            //         subServices: ["Deep cleaning", "Normal cleaning"],
            //         link: `/services/1/view`
            //     }],
            //     count: 1
            // })

        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.search])

    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Services</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='flex-center'>
                                <Typography.Title className='m-0 fw-700' level={3}>Services</Typography.Title>
                                <Button type="primary" htmlType="button" icon={<HenceforthIcons.Export />} size={'large'} onClick={() => setExportModal(true)}>Export</Button>
                            </div>
                            {/* Search  */}
                            <div className='my-4 '>
                                <SearchPage placeholder="Search" pathname="/services/page/1"/>
                            </div>
                            {/* Table  */}
                            <div className='table-wrapper'>
                                <Table dataSource={dataSource} columns={ColumnsType.serviceColumns} pagination={false} scroll={{ x: '100%' }} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />

                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>

                <ExportFile value={value}  setValue={setValue} open={exportModal} setOpen={setExportModal} title="ContactUs Export" export={async (start_date?: number, end_date?: number) => {
                    
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Service.export(start_date, end_date)
                        const exportData=apiRes?.data?.map((item:any,index:number)=>{
                            return {
                                // name:item?.name,
                                // email:item?.email,
                                // phone_no:item?.phone_no,
                                // money_earned:item?.vendor_earning,
                                // city:item?.city,
                                Service:item?.name,
                                service:item?.sub_services.map((res:any ,index:number)=>res?.name)?.toString()?.split(",")?.join(" "),
                            }
                          })
                        downloadCSV("Services", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>

        </Fragment>
    )
}

Services.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default Services
