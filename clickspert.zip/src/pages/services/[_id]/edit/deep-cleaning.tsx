'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Calendar, Checkbox, Divider, Form, Input, Modal, Popconfirm, Radio, Select, Switch, Table, TimePicker, TimePickerProps, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined } from '@ant-design/icons'
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
import Link from 'next/link';
import ColumnsType from '@/interfaces/ColumnsType';
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { DeepCleaningList } from '@/interfaces';
import VillaPage from '@/components/common/Villa';
import henceofrthEnums from '@/utils/henceofrthEnums';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });
const EditDeepCleaning: Page = (props: any) => {
    const { Toast, loading, downloadCSV, currency, setLoading } = React.useContext(GlobalContext)
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [addForm] = Form.useForm()
    const [editForm] = Form.useForm()
    const [state, setState] = useState<any>()
    const router = useRouter()
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [modalName, setModalName] = useState('')
    const [villa, setVilla] = useState({
        count: 0,
        data: [] as any
    })
    const [recurring, setRecurring] = useState<any>([])

    let recurringArray = [
        { key: henceofrthEnums.recurring.ONCE, value: 'Once' },
        { key: henceofrthEnums.recurring.EVERY_WEEK, value: 'Every_week' },
        { key: henceofrthEnums.recurring.EVERY_2_WEEK, value: 'Every_2_week' },
        { key: henceofrthEnums.recurring.MONTHLY, value: 'Monthly' },
    ]


    const onSelectReccuring = (values: any) => {
        setRecurring(values)
    }

    useEffect(() => {
        if (state?.recurring) {
            setRecurring([...state?.recurring])
        }
    }, [state])


    // const [fileList, setFileList] = useState<UploadFile[]>([
    //     {
    //       uid: '-1',
    //       name: 'image.png',
    //       status: 'done',
    //       url: userInfo.image ? henceforthApi.FILES.imageMedium(userInfo.image, '') : '',
    //     },
    //   ]);
    const [apartment, setApartment] = useState({
        count: 0,
        data: [] as any
    })
    const [payLoadItems, setPayLoadItems] = useState<any>()
const [index,setIndex]=React.useState(0) as any
    const ApartmentData = apartment?.data?.map((res: any, index: number) => {
        return {
            key: index + 1,
            rooms: res?.rooms,
            price: res?.price,
            action: <div className='d-flex align-items-center'>
                <Button type='primary' size='middle' onClick={() => { showEditModal('apartment', res);setIndex(index) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                <Popconfirm
                    title="Delete"
                    description="Are you sure to delete apartment"
                    onConfirm={() => onDelete(res._id, 'apartment')}
                    okText="Yes"
                    cancelText="No">
                    <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                </Popconfirm>
            </div>
        }
    })
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };
    const showModal = (name: string) => {
        addForm.resetFields()
        setIsModalOpen(true);
        setModalName(name)
    };
console.log(state);

    const showEditModal = (name: string, items: any) => {
        setEditModalOpen(true);
        setModalName(name)
        setPayLoadItems(items)
        editForm.setFieldsValue(items)

    }
    console.log(modalName, "modalName");

    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    const onAddRooms = async (values: any) => {
        setLoading(true)
        try {
            const info = {
                type: "DEEP_CLEANING",
                sub_service_id: router.query._id,
                rooms: values.rooms,
                price: +values.price,
                price_currency: currency?._id
            }
            if (modalName == "villa") {
                let apiRes = await henceforthApi.DeepCleaning.villaCreate(info)
                // setVilla({
                //     ...villa,
                //     data: [apiRes?.data ,...state?.villa_ids]

                // })
                initialiseVillia()
                Toast.success(apiRes.message)
            } else {
                let apiRes = await henceforthApi.DeepCleaning.Apartment(info)
                // setApartment({
                //     ...apartment,
                //     data: [apiRes?.data ,...state?.apartment_ids]
                // })
                initialiseApartment()
                Toast.success(apiRes.message)
            }

            // await initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setTimeout(() => {
                setLoading(false)
                setIsModalOpen(false)
            }, 2000);
            addForm.resetFields()
        }
    }
    const onDelete = async (_id: any, type: string) => {
        try {
            setLoading(true)
            if (type == 'villa') {
                let apiRes = await henceforthApi.DeepCleaning.delete(_id)
                // const 
                await initialiseVillia()
                Toast.success(apiRes?.message)
            } else {
                let apiRes = await henceforthApi.DeepCleaning.apartmentDelete(_id)
                await initialiseApartment()
                Toast.success(apiRes?.message)
            }
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }

    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)
            setState(apiRes)
            form.setFieldsValue(apiRes);
            setFileList([{
                uid: '-1',
                name: 'image.png',
                status: 'done',
                url: apiRes.image ? henceforthApi.FILES.imageMedium(apiRes.image, '') : '',
            }])

        } catch (error) {

        }
    }

    const editSubService = async (values: any) => {
        console.log(values,"values");
        // return
        setLoading(true)
        if (!values?.image) {
            return Toast.warn('Please Select Image')
        }
        if (!fileList.length) {
            return Toast.warn('Please Select Image')
        }
        let items: any = {
            _id: router?.query?._id,
            name: values?.name,
            min_price: +values?.min_price,
            min_price_currency: state?.min_price_currency?._id,
            description: values?.description,
            discount_every_month: values?.discount_every_month,
            discount_every_week: values?.discount_every_week,
            discount_for_every_2_week: values?.discount_for_every_2_week,
            discount_for_once: +values?.discount_for_once,
            recurring:values?.recurring

        }


        if (values?.image?.file?.originFileObj) {
            let apiRes = await henceforthApi.Common.uploadFile('file', values?.image?.file?.originFileObj)
            items['image'] = apiRes?.file_name
        }
        try {
            let apiRes = await henceforthApi.DeepCleaning.editSubService(items)
            router?.back()
            Toast.success(apiRes?.message)
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }

    const onEdit = async (values: any) => {
        let items = {
            _id: payLoadItems?._id,
            type: 'DEEP_CLEANING',
            sub_service_id: router?.query?._id,
            // rooms: values?.rooms,
            // price: +values?.price,
        } as any
        try {
            debugger
            setLoading(true)
            if (modalName == 'apartment') {
                if(apartment?.data[index].rooms != values.rooms){
                 items.rooms=values?.rooms
                }
                if(apartment?.data[index].price != +values.price){
                    items.price= +values?.price
                }
                let apiRes = await henceforthApi.DeepCleaning.EditListing('apartment', items)
                Toast.success(apiRes?.message ?? 'Edit successfully' )
                await initialiseApartment()

            } else {
                if(villa?.data[index].rooms != values.rooms){
                    items.rooms=values?.rooms
                   }
                   if(villa?.data[index].price != +values.price){
                       items.price= +values?.price
                   }
                let apiRes = henceforthApi.DeepCleaning.EditListing('villa', items)
                Toast.success(apiRes?.message ?? 'Edit successfully' )
                await initialiseVillia()
            }

        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setEditModalOpen(false)
        }
    }
    const initialiseApartment = async () => {
        try {
            let apiRes = await henceforthApi.DeepCleaning.listingVilla("apartment", "DEEP_CLEANING")
            setApartment(apiRes)
        } catch (error) {

        }
    }

    const initialiseVillia = async () => {
        try {
            let apiRes
            apiRes = await henceforthApi.DeepCleaning.listingVilla("villa", "DEEP_CLEANING")
            setVilla(apiRes)
        } catch (error) {

        }
    }

    const handleCancel = () => {
        setIsModalOpen(false);
        setEditModalOpen(false)
    };

    useEffect(() => {
        initialiseVillia()
        initialiseApartment()
        initialise()
    }, [])
    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href="/services/page/1" className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id}/view`} className='text-decoration-none'>Cleaning</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit Deep Cleaning</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit Deep Cleaning</Typography.Title>
                                    </div>

                                    <Form
                                        layout='vertical'
                                        size='large'
                                        form={form}
                                        onFinish={editSubService}
                                    >
                                        <Form.Item name='image' >
                                            <Upload name="image"
                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}
                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item name="name" label={'Subservice Name'}>
                                            <Input className='border-0' disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        {/* <Form.Item name="min_price" label={'Minimum Price (AED)'} rules={[{ required: true, message: 'Please Enter your min price' }]}>
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Minimum Price' />
                                        </Form.Item> */}
                                        <Form.Item>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Villa</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => showModal("villa")}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <VillaPage {...villa} onDelete={onDelete} setIndex={setIndex} showModal={showEditModal} onEdit={onEdit} />
                                            </div>
                                        </Form.Item>
                                        <Form.Item>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Apartment</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => showModal("Apartment")}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <Table dataSource={ApartmentData} columns={ColumnsType.apartmentColumns} pagination={false} scroll={{ x: '100%' }} />
                                            </div>
                                        </Form.Item>

                                        <Form.Item name="recurring" label="Recurring" rules={[{ required: true, message: 'Please select recurring' }]} >
                                            <Select placeholder='Select Recurring'
                                                mode="multiple"
                                                onChange={onSelectReccuring}
                                                options={recurringArray?.map((res: any, index: number) => { return { value: res?.key, label: res?.key } }) as any}
                                            />
                                        </Form.Item >
                                        {recurring?.includes(henceofrthEnums.recurring.ONCE) && <Form.Item label={`Discount for Once (%)`} name={'discount_for_once'} rules={[{ required: true, message: 'Please Enter your Discount' }]} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.EVERY_WEEK) && <Form.Item label={`Discount for every week (%)`} name={'discount_every_week'} rules={[{ required: true, message: 'Please enter Discount every week' }]} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.EVERY_2_WEEK) && <Form.Item label={`Discount for every 2 week (%)`} name={'discount_for_every_2_week'} rules={[{ required: true, message: 'Please enter Discount for Every 2 Week' }]} >
                                            <Input className='border-0' placeholder='Enter Discount' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.MONTHLY) && <Form.Item label={`Discount for  every Month (%)`} name={'discount_every_month'} rules={[{ required: true, message: 'Please enter Discount Every month' }]} >
                                            <Input className='border-0' placeholder='Enter Discount' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>}
                                        <Form.Item name="description" hasFeedback label="Description">
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type='primary' htmlType='submit' loading={loading}>Save Changes</Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Rooms in {modalName == "villa" ? "villa" : "Apartment"}</Typography.Title>
                    <Form size='large' form={addForm} layout='vertical' onFinish={onAddRooms}>
                        <Form.Item name="rooms" label='No of Rooms' rules={[{ required: true, message: 'Please Enter no of rooms' }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: 'Please Enter price' }]} >
                            <Input placeholder='Price' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Add Rooms</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>

            <Modal footer={null} centered={true} open={editModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Rooms in {modalName == "villa" ? "villa" : "Apartment"}</Typography.Title>
                    <Form size='large' form={editForm} layout='vertical' onFinish={onEdit}>
                        <Form.Item name="rooms" label='No of Rooms' rules={[{ required: true, message: 'Please Enter no of rooms' }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: 'Please Enter price' }]} >
                            <Input placeholder='Price' className='border-0' onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Edit Rooms</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment >
    )
}

EditDeepCleaning.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default EditDeepCleaning