'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Calendar, Checkbox, Divider, Form, Input, Modal, Popconfirm, Radio, Select, Switch, Table, TimePicker, TimePickerProps, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined } from '@ant-design/icons'
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
import Link from 'next/link';
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { DeepCleaningList } from '@/interfaces';
import VillaPage from '@/components/common/Villa';
import { ColumnsType } from 'antd/es/table';
import { VillaTable } from '@/components/common/VillaTable';
import { ApartmentTable } from '@/components/common/ApartmentTable';
import henceofrthEnums from '@/utils/henceofrthEnums';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });
const EditPestControl = (props: any) => {
    const { Toast, loading, currency, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [state, setState] = useState<any>()
    const router = useRouter()
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [modalName, setModalName] = useState('')
    const [villa, setVilla] = useState({
        count: 0,
        data: [] as any
    })
    const [addPayload, setAddPayload] = useState<any>()
    const [insectId, setInsectId] = useState<any>()

    // const [fileList, setFileList] = useState<UploadFile[]>([
    //     {
    //       uid: '-1',
    //       name: 'image.png',
    //       status: 'done',
    //       url: userInfo.image ? henceforthApi.FILES.imageMedium(userInfo.image, '') : '',
    //     },
    //   ]);
    const [apartment, setApartment] = useState({
        count: 0,
        data: [] as any
    })
    const [arrayRes, setArrayRes] = useState<any>()

    const [reccuring, setReccuring] = useState<any>()
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);
    // recurring
    // : 
    // ["Once", "Every month", "Every 2 month", "Every 6 month"]
    let recurringArray = [
        { key: henceofrthEnums.recurring.ONCE, value: 'Once' },
        { key: henceofrthEnums.recurring.EVERY_MONTH, value: 'Every_month' },
        { key: henceofrthEnums.recurring.EVERY_2_MONTH, value: 'Every_2_month' },
        { key: henceofrthEnums.recurring.EVERY_6_MONTH, value: 'Every_6_month' },
    ]

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };
    const showModal = (name: string, res: any) => {
        console.log(res, "resssssssss");

        setAddPayload(res)
        // form.resetFields()
        setIsModalOpen(true);
        setModalName(name)
    };
    const resetField = () => {
        form.setFieldValue("price", '')
        form.setFieldValue("rooms", '')
        form.setFieldValue("internal_external_price", '')
        form.setFieldValue("internal_price", '')
    }

    console.log(modalName, "modalName");

    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    console.log(addPayload, 'addPayload');

    const onAdd = async (values: any) => {
        setLoading(true)
        debugger
        let apiRes: any
        try {
            const info = modalName == 'apartment' ? {
                sub_service_id: router?.query?._id,
                insect_id: addPayload?._id,
                type: "PEST_CONTROL",
                rooms: values.rooms,
                price: +values.price,
                price_currency: currency?._id
            } : {
                type: "PEST_CONTROL",
                sub_service_id: router?.query?._id,
                insect_id: addPayload?._id,
                internal_price: +values?.internal_price,
                price: +values?.price,
                rooms: values.rooms,
                price_currency: currency?._id,
                internal_price_currency: currency?._id,
                internal_external_price: +values?.internal_external_price,
                internal_external_price_currency: currency?._id
            }
            if (modalName == "villa") {
                apiRes = await henceforthApi.DeepCleaning.villaCreate(info)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
                    x[findIndex]?.villas.unshift(apiRes?.data)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
            } else {
                apiRes = await henceforthApi.DeepCleaning.Apartment(info)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
                    x[findIndex]?.apartments.unshift(apiRes?.data)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })

            }
            Toast.success(apiRes.message)
            // initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setIsModalOpen(false)
            // form.resetFields()
        }
    }
    const onDelete = async (_id: any, type: string) => {
        debugger
        try {
            setLoading(true)
            if (type == 'villa') {
                let apiRes = await henceforthApi.DeepCleaning.delete(_id)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
                    let y = x[findIndex]?.villas?.findIndex((items: any) => items?._id == apiRes?.data._id)
                    x[findIndex]?.villas?.splice(y, 1)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message)
            } else {
                let apiRes = await henceforthApi.DeepCleaning.apartmentDelete(_id)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
                    let y = x[findIndex]?.apartments?.findIndex((items: any) => items?._id == apiRes?.data._id)
                    x[findIndex]?.apartments?.splice(y, 1)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message)
            }
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }
    const onSelectReccuring = (values: any) => {
        setReccuring(values)
    }


    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)
            setState(apiRes)
            form.setFieldsValue(apiRes);
            setFileList([{
                uid: '-1',
                name: 'image.png',
                status: 'done',
                url: apiRes.image ? henceforthApi.FILES.imageMedium(apiRes.image, '') : '',
            }])

        } catch (error) {

        }
    }

    const editSubService = async (values: any) => {
        debugger
        if (!values?.image) {
            return Toast.warn('Please Select Image')
        }
        if (!fileList.length) {
            return Toast.warn('Please Select Image')
        }
        let items: any = {
            _id: router?.query?._id,
            name: values?.name,
            description: values?.description,
            min_price: +values?.min_price,
            min_price_currency: currency?._id,
            recurring: values?.recurring,
            discount_for_once: +values?.discount_for_once,
            discount_every_2_month: +values?.discount_every_2_month,
            discount_every_month: +values?.discount_every_month,
            discount_every_6_month: +values?.discount_every_6_month
        }
        if (values?.image?.file?.originFileObj) {
            let apiRes = await henceforthApi.Common.uploadFile('file', values?.image?.file?.originFileObj)
            items['image'] = apiRes?.file_name
        }

        try {
            let apiRes = await henceforthApi.PestControl.editPestControl(items)
            router?.back()
            Toast.success(apiRes?.message)
        } catch (error) {
            Toast.error(error)
        }
    }

    const onEdit = async (values: any) => {
        console.log(modalName);
        
        debugger
        let items = modalName == 'villa' ? {
            type: "PEST_CONTROL",
            _id: arrayRes?._id,
            sub_service_id: router?.query?._id,
            insect_id: insectId,
            rooms: values?.rooms,
            internal_price: +values?.internal_price,
            internal_external_price: +values?.internal_external_price,
            price_currency: currency?._id
        } : {
            _id: arrayRes?._id,
            sub_service_id: router?.query?._id,
            insect_id: insectId,
            type: "PEST_CONTROL",
            rooms: values.rooms,
            price: +values.price,
            price_currency: currency?._id
        }
        try {
            setLoading(true)
            if (modalName == 'apartment') {
                let apiRes = await henceforthApi.DeepCleaning.EditListing('apartment', items)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
                    let y = x[findIndex]?.apartments.findIndex((items: any) => items?._id == apiRes?.data?._id)
                    x[findIndex]?.apartments?.splice(y, 1, apiRes?.data)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message ?? 'Success')
            } else {
                let apiRes =await henceforthApi.DeepCleaning.EditListing('villa', items)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.insect_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
                    let y = x[findIndex]?.villas.findIndex((items: any) => items?._id == apiRes?.data?._id)
                    x[findIndex]?.villas?.splice(y, 1, apiRes?.data)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message ?? 'Success')
            }
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setEditModalOpen(false)
        }
    }
 

    const handleCancel = () => {
        setPreviewOpen(false)
        setIsModalOpen(false);
        setEditModalOpen(false)
    };

    useEffect(() => {
        initialise()
    }, [])

    let apartmentTables = Array.isArray(state?.apartment_ids) ? state?.apartment_ids : [state?.apartment_ids]

    const showEditModal = (name: string, res: number, arrayId: string, insectId: string, item: any) => {
        setAddPayload(item)
        setEditModalOpen(true);
        setModalName(name)
        setArrayRes(res)
        setInsectId(insectId)
        form.setFieldsValue(res)
    }

    useEffect(() => {
        if (state) {
            setReccuring([...state?.recurring])
        }
    }, [state])

    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={"/services/page/1"} className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id ? state?.service_id?._id : state?.service_id}/view`} className='text-decoration-none'>{state?.service_id?.name ? state?.service_id?.name : "Pest control"}</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit {state?.name}</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit {state?.name}</Typography.Title>
                                    </div>

                                    <Form
                                        layout='vertical'
                                        size='large'
                                        form={form}
                                        onFinish={editSubService}
                                    >
                                        <Form.Item name='image' rules={[{ required: true, message: "Image Field is Required" }]}>
                                            <Upload name="image"
                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}
                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item name="name" label={'Subservice Name'} >
                                            <Input className='border-0' disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        {/* <Form.Item name="min_price" label={'Minimum Order Value'} rules={[{ required: true, message: "Min Price is Required" }]} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Minimum Order' />
                                        </Form.Item> */}
                                        {state?.villa_ids.map((res: any, index: number) => <Form.Item key={index}  >
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Villa for {res?.insect}</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => { resetField(); showModal('villa', res) }}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <VillaTable service_type={state?.service_type} showEditModal={showEditModal} onDelete={onDelete} {...res} />
                                                {/* <Table dataSource={res?.villas} columns={villaColumns} pagination={false} scroll={{ x: '100%' }} /> */}
                                            </div>
                                        </Form.Item>)}
                                        {apartmentTables?.map((res: any, index: number) => <Form.Item key={index}>
                                            <div className='flex-center' >
                                                <Typography.Paragraph className='fw-700'>Apartment for {res?.insect}</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => { resetField(); showModal("apartment", res) }}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <ApartmentTable service_type={state?.service_type} showEditModal={showEditModal} onDelete={onDelete} {...res} />
                                            </div>
                                        </Form.Item>
                                        )}
                                        <Form.Item name="recurring" label="Recurring" rules={[{ required: true, message: "Please Select Recurring" }]}>
                                            <Select placeholder='Select Recurring'
                                                mode="multiple"
                                                onChange={onSelectReccuring}
                                                options={recurringArray?.map((res: any, index: number) => { return { value: res?.key, label: res?.key } }) as any}
                                            />
                                        </Form.Item>
                                        {/* ["Once", "Every month", "Every 2 month", "Every 6 month"] */}
                                        {reccuring?.includes(henceofrthEnums.recurring.ONCE) && <Form.Item label={`Discount for Once `} rules={[{ required: true, message: "Discount for Once is Required" }]} name={'discount_for_once'} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {reccuring?.includes(henceofrthEnums.recurring.EVERY_MONTH) && <Form.Item label={`Discount for every Month `} rules={[{ required: true, message: "Discount for every week is Required" }]} name={'discount_every_month'} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {reccuring?.includes(henceofrthEnums.recurring.EVERY_2_MONTH) && <Form.Item label={`Discount for every 2 Month `} rules={[{ required: true, message: "Discount for every 2 week is Required" }]} name={'discount_every_2_month'} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {reccuring?.includes(henceofrthEnums.recurring.EVERY_6_MONTH) && <Form.Item label={`Discount for Every 6 Month `} rules={[{ required: true, message: "Discount for Every 6 Month is Required" }]} name={'discount_every_6_month'} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {/* <Form.Item label={'Discount for Every 2 Month'} name={'discount_every_2_month'}>
                                            <Input className='border-0' placeholder='Enter Discount' />
                                        </Form.Item> */}
                                        <Form.Item name="description" hasFeedback label="Description" rules={[{ required: true, message: 'Description is required ' }]} >
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type='primary' htmlType='submit'>Save Changes</Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Rooms in {modalName == "villa" ? 'Villa' : "Apartment"} {`for ${addPayload?.insect}`}</Typography.Title>
                    <Form size='large' form={form} layout='vertical' onFinish={onAdd}>
                        <Form.Item name="rooms" label='Rooms' rules={[{ required: true, message: "Enter your rooms" }]} >
                            <Input placeholder='Rooms' className='border-0' />
                        </Form.Item>
                        {modalName == 'apartment' ? <Form.Item name="price" label='Price' >
                            <Input placeholder='Price' className='border-0' />
                        </Form.Item> : <><Form.Item required name="internal_price" label='Internal Price' rules={[{ required: true, message: "Enter your Price" }]} >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} placeholder='Price' className='border-0' />
                        </Form.Item>
                            <Form.Item name="internal_external_price" label='Both (Internal & External) Price' rules={[{ required: true, message: "Enter your Price" }]}>
                                <Input onKeyPress={(e) => {
                                    if (!/[0-9]/.test(e.key)) {
                                        e.preventDefault();
                                    }
                                }} placeholder='Price' className='border-0' />
                            </Form.Item>
                        </>}
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>

            <Modal footer={null} centered={true} open={editModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Rooms in {modalName == "villa" ? 'Villa' : "Apartment"} {`for ${addPayload?.insect}`}</Typography.Title>
                    <Form size='large' form={form} layout='vertical' onFinish={onEdit}>
                        <Form.Item name="rooms" label='Rooms' rules={[{ required: true, message: "Enter your Rooms" }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        {modalName == 'apartment' ? <Form.Item name="price" label='Price' rules={[{ required: true, message: "Enter your Rooms" }]}>
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} placeholder='Price' className='border-0' />
                        </Form.Item> : <><Form.Item name="internal_price" label='Internal Price' rules={[{ required: true, message: "Enter your Price" }]}>
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} placeholder='Price' className='border-0' />
                        </Form.Item>
                            <Form.Item name="internal_external_price" label='Both (Internal & External) Price' rules={[{ required: true, message: "Enter your Price" }]}>
                                <Input onKeyPress={(e) => {
                                    if (!/[0-9]/.test(e.key)) {
                                        e.preventDefault();
                                    }
                                }} placeholder='Price' className='border-0' />
                            </Form.Item>
                        </>}
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}

EditPestControl.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default EditPestControl
