'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Modal, Select, Tag, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import { PlusOutlined } from '@ant-design/icons'
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import placeholder from '@/assets/images/placeholder.png'
import Link from 'next/link';

const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

// const { Meta } = Card;
const { Search } = Input;
interface DataType {
    key: React.Key;
}
const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });

const WindowCleaning: Page = (props: any) => {
    const [previewOpen, setPreviewOpen] = useState(false);
    const router = useRouter()
    const [previewImage, setPreviewImage] = useState('');
    const [state, setState] = useState<any>()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [recurring, setRecurring] = useState<any>([])

    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };
    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    const handleCancel = () => setPreviewOpen(false);
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)
            setState(apiRes)
            form.setFieldsValue(apiRes)
            setFileList([{
                uid: '-1',
                name: '',
                status: 'done',
                url: henceforthApi.FILES.imageOriginal(apiRes.image, placeholder.src),
            }])
        } catch (error) {

        }
    }
    const Update = async (values: any) => {
        debugger
        try {
            if (!values?.image) {
                return Toast.warn('Please Select Image')
            }
            if (!fileList.length) {
                return Toast.warn('Please Select Image')
            }
            const items: any = {
                _id:router?.query?._id,
                name:values?.name,
                description:values?.description
              }
            if (values?.image?.file?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', values?.image?.file?.originFileObj)
                console.log("file image", apiImageRes);
                items['image'] = apiImageRes.file_name
            }
            let apiRes = await henceforthApi.Cleaning.windowCleaning(items)
            Toast.success(apiRes?.message);
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading(false)
        }
    }
    const onSelectValue = (res: any) => {
        setRecurring(res)
        console.log(res, "name");
    }
    console.log(recurring, "sssdfdf");
    console.log(state, 'state');


    useEffect(() => {
        initialise()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href="/services/page/1" className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id}/view`} className='text-decoration-none'>Cleaning</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit Window cleaning</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit Window Cleaning</Typography.Title>
                                    </div>
                                    <Form
                                        layout='vertical'
                                        size='large'
                                        onFinish={Update}
                                        form={form}
                                    >
                                        <Form.Item name='image'>
                                            <Upload name="image"

                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}

                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item name='name' label={'Subservice Name'} required>
                                        <Input className='border-0' disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        <Form.Item name="description" hasFeedback label="Description" rules={[{required: true, message:'Description is Reqired'}]} >
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type="primary" htmlType="submit" className="login-form-button mt-4" >
                                                Save Changes
                                            </Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>

            </section>

        </Fragment>
    )
}

WindowCleaning.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default WindowCleaning
