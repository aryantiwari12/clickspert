'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Calendar, Checkbox, Divider, Form, Input, Modal, Popconfirm, Radio, Select, Switch, Table, TimePicker, TimePickerProps, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined } from '@ant-design/icons'
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
import Link from 'next/link';
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { DeepCleaningList } from '@/interfaces';
import VillaPage from '@/components/common/Villa';
import { ColumnsType } from 'antd/es/table';
import { VillaTable } from '@/components/common/VillaTable';
import { ApartmentTable } from '@/components/common/ApartmentTable';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });
const EditDisInfection = (props: any) => {
    const { Toast, loading, currency, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [form1] = Form.useForm();

    const [state, setState] = useState<any>()
    const router = useRouter()
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [modalName, setModalName] = useState('')
    const [villa, setVilla] = useState({
        count: 0,
        data: [] as any
    })
    const [addPayload, setAddPayload] = useState<any>()
    const [insectId, setInsectId] = useState<any>()

    // const [fileList, setFileList] = useState<UploadFile[]>([
    //     {
    //       uid: '-1',
    //       name: 'image.png',
    //       status: 'done',
    //       url: userInfo.image ? henceforthApi.FILES.imageMedium(userInfo.image, '') : '',
    //     },
    //   ]);
    const [apartment, setApartment] = useState({
        count: 0,
        data: [] as any
    })
    const [arrayRes, setArrayRes] = useState<any>()


    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };
    const showModal = (name: string, res: any) => {
        debugger
        setAddPayload(res)
        // form.resetFields()
        setIsModalOpen(true);
        setModalName(name)
    };

    console.log(modalName, "modalName");

    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    console.log(addPayload, 'addPayload');

    const onAdd = async (values: any) => {
        setLoading(true)
        debugger
        let apiRes
        try {
            const info = {
                sub_service_id: router?.query?._id,
                type: state?.service_type,
                rooms: values.rooms,
                price: +values.price,
                price_currency: currency?._id
            }
            if (modalName == "villa") {
                apiRes = await henceforthApi.DeepCleaning.villaCreate(info)
            } else {
                apiRes = await henceforthApi.DeepCleaning.Apartment(info)
            }
            Toast.success(apiRes.message)
            initialise()
            form.resetFields()
        } catch (error) {
            Toast.error(error)
        } finally {
            setTimeout(() => {
                setLoading(false)
                setIsModalOpen(false)
            }, 2000);
        }
    }
    const onDelete = async (_id: any, type: string) => {
        debugger
        try {
            setLoading(true)
            if (type == 'villa') {
                let apiRes = await henceforthApi.DeepCleaning.delete(_id)
                Toast.success(apiRes?.message)
            } else {
                let apiRes = await henceforthApi.DeepCleaning.apartmentDelete(_id)
                Toast.success(apiRes?.message)
            }
            initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }

    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)
            setState(apiRes)
            form.setFieldsValue(apiRes);
            setFileList([{
                uid: '-1',
                name: 'image.png',
                status: 'done',
                url: apiRes.image ? henceforthApi.FILES.imageMedium(apiRes.image, '') : '',
            }])

        } catch (error) {

        }
    }

    const editSubService = async (values: any) => {
        debugger
        if (!values?.image) {
            return Toast.warn('Please Select Image')
        }
        if (!fileList.length) {
            return Toast.warn('Please Select Image')
        }
        let items: any = {
            _id: router?.query?._id,
            name: values?.name,
            description: values?.description,
            min_price: +values?.min_price,
            min_price_currency: currency?._id,

        }
        if (values?.image?.file?.originFileObj) {
            let apiRes = await henceforthApi.Common.uploadFile('file', values?.image?.file?.originFileObj)
            items['image'] = apiRes?.file_name
        }
        try {
            let apiRes = await henceforthApi.PestControl.editDisinfection(items)
            router?.back()
            Toast.success(apiRes?.message)
        } catch (error) {
            Toast.error(error)
        }
    }
    console.log(arrayRes, 'payLoadItems');

    const onEdit = async (values: any) => {
        debugger
        let items = {
            _id: arrayRes?._id,
            sub_service_id: router?.query?._id,
            type: state?.service_type,
            rooms: values.rooms,
            price: +values.price,
            price_currency: currency?._id
        }
        try {
            setLoading(true)
            if (modalName == 'apartment') {
                let apiRes = henceforthApi.DeepCleaning.EditListing('apartment', items)
                Toast.success(apiRes?.message ?? 'Success')
                // initialiseApartment()

            } else {
                let apiRes = henceforthApi.DeepCleaning.EditListing('villa', items)
                Toast.success(apiRes?.message ?? 'Success')
            }
            await initialise()

        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setEditModalOpen(false)
        }
    }
    // const initialiseApartment = async () => {
    //     try {
    //         let apiRes = await henceforthApi.DeepCleaning.listingVilla("apartment", "PEST_CONTROL")
    //         setApartment(apiRes)
    //     } catch (error) {

    //     }
    // }

    // const initialiseVillia = async () => {
    //     try {
    //         let apiRes
    //         apiRes = await henceforthApi.DeepCleaning.listingVilla("villa", "PEST_CONTROL")
    //         setVilla(apiRes)
    //     } catch (error) {

    //     }
    // }

    const handleCancel = () => {
        setIsModalOpen(false);
        setEditModalOpen(false)
    };

    useEffect(() => {
        // initialiseVillia()
        // initialiseApartment()
        initialise()
    }, [])

    const villaColumns: ColumnsType<any> = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, object: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Rooms',
            dataIndex: 'rooms',
            width: 150,
        },
        {
            title: 'Price',
            dataIndex: 'price',
            width: 100
        },

        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { showEditModal('villa', res) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete Villa"
                        onConfirm={() => onDelete(res._id, 'villa')}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ]

    const ApartmentColumns: ColumnsType<any> = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100,
            render: (text: any, object: any, index: any) => { return (index + 1) }
        },
        {
            title: 'Rooms',
            dataIndex: 'rooms',
            width: 150,
        },
        {
            title: 'Price',
            dataIndex: 'price',
            width: 150
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100,
            render: (_: any, res: any, index) => (
                <div className='d-flex align-items-center'>
                    <Button type='primary' size='middle' onClick={() => { showEditModal('apartment', res) }} shape='circle' className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete apartment"
                        onConfirm={() => onDelete(res._id, 'apartment')}
                        okText="Yes"
                        cancelText="No">
                        <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                    </Popconfirm>
                </div>
            )
        }
    ]

    let apartmentTables = Array.isArray(state?.apartment_ids) ? state?.apartment_ids : [state?.apartment_ids]

    const showEditModal = (name: string, res: number) => {
        debugger
        setEditModalOpen(true);
        setModalName(name)
        setArrayRes(res)
        form1.setFieldsValue(res)

    }
    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={"/services/page/1"} className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id}/view`} className='text-decoration-none'>{state?.service_id?.name}</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit {state?.name}</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit {state?.name}</Typography.Title>
                                    </div>

                                    <Form
                                        layout='vertical'
                                        size='large'
                                        form={form}
                                        onFinish={editSubService}
                                        onFinishFailed={(e) => console.log(e)
                                        }
                                    >
                                        <Form.Item name='image' required >
                                            <Upload name="image"
                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}
                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item required name="name" label={'Subservice Name'}>
                                            <Input className='border-0' disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        {/* <Form.Item rules={[{ required: true, message: "Min Price Is required" }]} name="min_price" label={'Minimum Order Value'}>
                                            <Input onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} className='border-0' placeholder='Enter Minimum Order' />
                                        </Form.Item> */}
                                        <Form.Item >
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Villa</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => showModal('villa', "")}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <Table dataSource={state?.villa_ids} columns={villaColumns} pagination={false} scroll={{ x: '100%' }} />
                                            </div>
                                        </Form.Item>
                                        <Form.Item>
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Apartment</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => showModal('apartment', "")}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <Table dataSource={state?.apartment_ids} columns={ApartmentColumns} pagination={false} scroll={{ x: '100%' }} />
                                        </Form.Item>
                                        <Form.Item name="description" rules={[{ required: true, message: "Description is required" }]} hasFeedback label="Description">
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type='primary' htmlType='submit'>Save Changes</Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Rooms in {modalName == "villa" ? 'Villa' : "Apartment"}</Typography.Title>
                    <Form size='large' layout='vertical' onFinish={onAdd} form={form1}>
                        <Form.Item name="rooms" label='No of rooms' rules={[{ required: true, message: 'Rooms is requried' }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: 'Price is requried' }]}>
                            <Input placeholder='Price' onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>

            <Modal footer={null} centered={true} open={editModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Rooms in {modalName == "villa" ? 'Villa' : "Apartment"}</Typography.Title>
                    <Form size='large' form={form1} layout='vertical' onFinish={onEdit}>
                        <Form.Item name="rooms" label='No of rooms' rules={[{ required: true, message: 'Rooms is requried' }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: 'Price is requried' }]}>
                            <Input placeholder='Price' onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}

EditDisInfection.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default EditDisInfection
