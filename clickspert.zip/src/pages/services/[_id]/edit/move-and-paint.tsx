'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Calendar, Checkbox, Divider, Form, Input, Modal, Popconfirm, Radio, Select, Switch, Table, TimePicker, TimePickerProps, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined } from '@ant-design/icons'
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
import Link from 'next/link';
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { DeepCleaningList } from '@/interfaces';
import VillaPage from '@/components/common/Villa';
import { ColumnsType } from 'antd/es/table';
import { VillaTable } from '@/components/common/VillaTable';
import { ApartmentTable } from '@/components/common/ApartmentTable';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });
const EditMoveAndPaint = (props: any) => {
    const { Toast, loading, currency, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewImage, setPreviewImage] = useState('');
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [editform] = Form.useForm();
    const [state, setState] = useState({} as any)
    const router = useRouter()
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [modalName, setModalName] = useState('')
    const [villa, setVilla] = useState({
        count: 0,
        data: [] as any
    })
    const [addPayload, setAddPayload] = useState<any>()
    const [colorId, setcolorId] = useState<any>()

    // const [fileList, setFileList] = useState<UploadFile[]>([
    //     {
    //       uid: '-1',
    //       name: 'image.png',
    //       status: 'done',
    //       url: userInfo.image ? henceforthApi.FILES.imageMedium(userInfo.image, '') : '',
    //     },
    //   ]);
    const [apartment, setApartment] = useState({
        count: 0,
        data: [] as any
    })
    const [arrayRes, setArrayRes] = useState<any>()


    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editModalOpen, setEditModalOpen] = useState(false);
    const [colorType, setColorType] = useState("");

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };
    const showModal = (name: string, res: any) => {
        setAddPayload(res)
        setIsModalOpen(true);
        setModalName(name)
    };

    console.log(modalName, "modalName");

    const handleOk = () => {
        setIsModalOpen(false);
    };
    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    console.log(addPayload, 'addPayload');
    const [addForm] = Form.useForm()

    const onAdd = async (values: any) => {
        setLoading(true)
        let apiRes: any
        try {
            const info = {
                sub_service_id: router?.query?._id,
                color_id: addPayload?._id,
                type: state?.service_type,
                rooms: values.rooms,
                price: +values.price,
                price_currency: currency?._id
            }
            if (modalName == "villa") {
                apiRes = await henceforthApi.DeepCleaning.villaCreate(info)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
                    x[findIndex]?.villas.unshift(apiRes?.data)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
            } else {
                apiRes = await henceforthApi.DeepCleaning.Apartment(info)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
                    x[findIndex]?.apartments.unshift(apiRes?.data)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })
            }
            Toast.success(apiRes.message)
            // initialise()
            addForm.resetFields()
        } catch (error) {
            Toast.error(error)
        } finally {
            setTimeout(() => {
                setLoading(false)
                setIsModalOpen(false)
            }, 2000);
            // form.resetFields()
        }
    }
    console.log(state);

    const onDelete = async (_id: any, type: string) => {
        try {
            setLoading(true)
            if (type == 'villa') {
                let apiRes = await henceforthApi.DeepCleaning.delete(_id)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
              let y= x[findIndex]?.villas?.findIndex((items:any)=>items?._id == apiRes?.data._id)
              x[findIndex]?.villas?.splice(y , 1)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message)
            } else {
                let apiRes = await henceforthApi.DeepCleaning.apartmentDelete(_id)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
              let y= x[findIndex]?.apartments?.findIndex((items:any)=>items?._id == apiRes?.data._id)
              x[findIndex]?.apartments?.splice(y , 1)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message)
            }
            // initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }

    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)

            setState(apiRes)
            // setState({
            //     ...state
            // })
            console.log(typeof state?.apartment_ids);
            form.setFieldsValue(apiRes);
            setFileList([{
                uid: '-1',
                name: 'image.png',
                status: 'done',
                url: apiRes.image ? henceforthApi.FILES.imageMedium(apiRes.image, '') : '',
            }])

        } catch (error) {

        }
    }
    // console.log(...state ,"1111");

    const editSubService = async (values: any) => {
        if (!values?.image || !state.image) {
            return Toast.warn('Please Select Image')
        }
        // if (!fileList.length) {
        //     return Toast.warn('Please Select Image')
        // }
        let items: any = {
            _id: router?.query?._id,
            name: values?.name,
            description: values?.description,
            min_price: +values?.min_price,
            min_price_currency: currency?._id,
        }
        if (values?.image?.file?.originFileObj) {
            let apiRes = await henceforthApi.Common.uploadFile('file', values?.image?.file?.originFileObj)
            items['image'] = apiRes?.file_name
        }
        try {
            setLoading(true)
            let apiRes = await henceforthApi.editSubService.edit('move-and-paint', items)

            Toast.success(apiRes?.message)
            router.back()
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setLoading(false)
        }
    }
    console.log(arrayRes, 'payLoadItems');

    const onEdit = async (values: any) => {
        let items = {
            _id: arrayRes?._id,
            sub_service_id: router?.query?._id,
            color_id: colorId,
            type: state?.service_type,
            rooms: values.rooms,
            price: +values.price,
            price_currency: currency?._id
        }
        try {
            setLoading(true)
            if (modalName == 'apartment') {
                let apiRes =await henceforthApi.DeepCleaning.EditListing('apartment', items)
                const findIndex = state?.apartment_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.apartment_ids.map((res: any) => ({
                        ...res,
                        apartments: [...res.apartments]
                    }))
              let y= x[findIndex]?.apartments.findIndex((items:any)=>items?._id == apiRes?.data?._id)
              x[findIndex]?.apartments?.splice(y , 1 , apiRes?.data)
                    return {
                        ...state,
                        apartment_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message ?? 'Success')
            } else {
                let apiRes =await henceforthApi.DeepCleaning.EditListing('villa', items)
                const findIndex = state?.villa_ids?.findIndex((item: any) => item?._id == apiRes?.data?.color_id)
                setState((state: any) => {
                    const x = state?.villa_ids.map((res: any) => ({
                        ...res,
                        villas: [...res.villas]
                    }))
                    let y= x[findIndex]?.villas.findIndex((items:any)=>items?._id == apiRes?.data?._id)
                    x[findIndex]?.villas?.splice(y , 1 , apiRes?.data)
                    return {
                        ...state,
                        villa_ids: [...x]
                    }
                })
                Toast.success(apiRes?.message ?? 'Success')
            }

        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setEditModalOpen(false)
            editform.resetFields()
        }
    }
    const handleCancel = () => {
        setIsModalOpen(false);
        setEditModalOpen(false)
    };

    useEffect(() => {
       
        initialise()
    }, [])

    const showEditModal = (name: string, res: number, arrayId: string, insectId: string) => {
        setEditModalOpen(true);
        setModalName(name)
        setArrayRes(res)
        setcolorId(insectId)
        editform.setFieldsValue(res)

    }
    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={"/services/page/1"} className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id ? state?.service_id?._id : state?.service_id}/view`} className='text-decoration-none'>{state?.service_id?.name ? state?.service_id?.name : "Packers & movers"}</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit {state?.name}</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit {state?.name}</Typography.Title>
                                    </div>

                                    <Form
                                        layout='vertical'
                                        size='large'
                                        form={form}
                                        onFinish={editSubService}
                                    >
                                        <Form.Item name='image' >
                                            <Upload name="image"
                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}
                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item name="name" label={'Subservice Name'}>
                                            <Input className='border-0' disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        {/* <Form.Item name="min_price" rules={[{ required: true, message: "Min Price is required " }]} label={'Minimum Order Value'}>
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Minimum Order' />
                                        </Form.Item> */}
                                        {state?.villa_ids?.map((res: any, index: number) => <Form.Item key={index} >
                                            <div className='flex-center'>
                                                <Typography.Paragraph className='fw-700'>Villa with {res?.color}</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => { showModal('villa', res); setColorType(res?.color) }}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <VillaTable service_type={state?.service_type} showEditModal={showEditModal} onDelete={onDelete} {...res} />
                                                {/* <Table dataSource={res?.villas} columns={villaColumns} pagination={false} scroll={{ x: '100%' }} /> */}
                                            </div>
                                        </Form.Item>)}
                                        {Array.isArray(state?.apartment_ids) && state?.apartment_ids?.map((res: any, index: number) => <Form.Item key={index}>
                                            <div className='flex-center' >
                                                <Typography.Paragraph className='fw-700'>Apartment with {res?.color}</Typography.Paragraph>
                                                <Button className='bg-transparent border-0 px-0' onClick={() => { showModal("apartment", res); setColorType(res?.color) }}><HenceforthIcons.Add /></Button>
                                            </div>
                                            <div>
                                                <ApartmentTable showEditModal={showEditModal} onDelete={onDelete} {...res} />
                                            </div>
                                        </Form.Item>
                                        )}
                                        <Form.Item name="description" rules={[{ required: true, message: "Min Price is required " }]} hasFeedback label="Description">
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type='primary' loading={loading} htmlType='submit'>Save Changes</Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Rooms in {modalName == "villa" ? 'Villa' : "Apartment"} for {colorType}</Typography.Title>
                    <Form size='large' form={addForm} layout='vertical' onFinish={onAdd}>
                        <Form.Item name="rooms" label='No of rooms' rules={[{ required: true, message: "Please Enter No. of Rooms" }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: "Please Enter Price" }]}  >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} placeholder='Price' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>

            <Modal footer={null} centered={true} open={editModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Rooms in {modalName == "villa" ? 'Villa' : "Apartment"} for {colorType}</Typography.Title>
                    <Form size='large' form={editform} layout='vertical' onFinish={onEdit}>
                        <Form.Item name="rooms" label='No of rooms' rules={[{ required: true, message: "Please Enter No. of Rooms" }]}>
                            <Input placeholder='No of rooms' className='border-0' />
                        </Form.Item>
                        <Form.Item name="price" label='Price' rules={[{ required: true, message: "Please Enter Price" }]}  >
                            <Input onKeyPress={(e) => {
                                if (!/[0-9]/.test(e.key)) {
                                    e.preventDefault();
                                }
                            }} placeholder='Price' className='border-0' />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' htmlType='submit' loading={loading} block>Submit</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
        </Fragment>
    )
}

EditMoveAndPaint.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default EditMoveAndPaint
