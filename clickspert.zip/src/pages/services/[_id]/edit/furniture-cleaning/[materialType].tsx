'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Modal, Popconfirm, Table, Typography, UploadFile } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

// const { Meta } = Card;
const { Search } = Input;
interface DataType {
    key: React.Key;
}
type PickerType = 'time' | 'date';



const SofaMaterial: Page = (props: any) => {


    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const router = useRouter()
    const { Toast, loading, setLoading, currency } = React.useContext(GlobalContext)
    const [state, setState] = React.useState({
        data: [] as any,
        count: 0
    })
    const [modal, setModal] = useState(false);
    const [modalType, setModalType] = useState('')
    const [res, setRes] = useState<any>()
    const [form] = Form.useForm()


    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Cleaning.furnitureMaterialByType(String(router?.query?._id), String(router?.query?.materialType).toUpperCase())
            setState(apiRes)
        } catch (error) {

        }
    }
    console.log(state, "state");

    const handleModal = (modalType: string, res?: any) => {
        if (modalType == 'add') {
            setModal(true)
            setModalType(modalType)
            form.resetFields()
        } else {
            setModal(true)
            setModalType(modalType)
            form.setFieldsValue(res)
            setRes(res)
        }
    }

    const columns = [
        {
            title: 'Sr.no.',
            dataIndex: 'key',
            width: 100
        },
        {
            title: `${router.query.materialType != "sofa" ? "Size" : "Material Name"}`,
            dataIndex: 'material',
            width: 150,
        },
        {
            title: `Price per ${router.query.materialType == "sofa" ? "seat" : `piece`}`,
            dataIndex: 'price',
            width: 150
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100
        }
    ]


    const onDelete = async (_id: any) => {
        try {
            setLoading(true)
            let apiRes = await henceforthApi.Cleaning.deleteMaterial(_id)
            Toast.success(apiRes?.message)
            await initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
        }
    }
    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: index + 1,
            material: res?.material,
            price: `${res?.price} ${res?.price_currency?.symbol}`,
            action: <div className='d-flex align-items-center'>
                <Button type='primary' size='middle' shape='circle' onClick={() => handleModal('edit', res)} className='bg-transparent border-0'><HenceforthIcons.PencileIcon /></Button>
                <Popconfirm
                    title="Delete"
                    description="Are you sure to delete Material"
                    onConfirm={() => onDelete(res._id)}
                    okText="Yes"
                    cancelText="No">
                    <Button shape='circle' size='middle' className='border-0 bg-transparent'><HenceforthIcons.Trash /></Button>
                </Popconfirm>
            </div>
        }
    }
    )

    const onFinish = async (values: any) => {
        debugger
        let items = modalType == 'add' ? {
            material: values?.material,
            price: Number(values?.price),
            sub_service_id: router?.query?._id,
            material_type: String(router?.query?.materialType).toUpperCase(),
            price_currency: currency?._id
        } : {
            _id: res?._id,
            material: values?.material,
            price: Number(values?.price),
        }
        try {
            setLoading(true)
            if (modalType == 'add') {
                let apiRes = await henceforthApi.Cleaning.addMaterial(items)
                Toast.success(apiRes?.message ?? 'success')

            } else {
                let apiRes = await henceforthApi.Cleaning.editMaterial(items)
                Toast.success(apiRes?.message ?? 'success')
            }
            await initialise()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setModal(false)
        }
    }

    useEffect(() => {
        initialise()
    }, [router?.query?._id, router?.query?.materialType])

    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                    <Breadcrumb.Item ><Link href={"/services/page/1"} className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item ><Link href={`/services/${state?.data[0]?.service_id ? state?.data[0]?.service_id : ""}/view`} className='text-decoration-none'>Cleaning</Link></Breadcrumb.Item>
                                    {/* <Breadcrumb.Item >Edit {state?.name}</Breadcrumb.Item>
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item> */}
                                    {/* <Breadcrumb.Item >Services</Breadcrumb.Item> */}
                                    {/* <Breadcrumb.Item >Cleaning</Breadcrumb.Item> */}
                                    <Breadcrumb.Item ><Link href={`/services/${router.query._id}/edit/furniture-cleaning`} className='text-decoration-none'>Edit Furniture Cleaning </Link></Breadcrumb.Item>
                                    <Breadcrumb.Item  >Edit <span className='text-capitalize'> {router?.query?.materialType} </span> material & size</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='mb-4'>
                                <div className='flex-center'>
                                    <Typography.Title className='m-0 fw-600' level={3}>Edit <span className='text-capitalize'> {router?.query?.materialType} </span> Material</Typography.Title>
                                    <Button className='border-0 px-2' onClick={() => handleModal('add')} ><HenceforthIcons.Add /></Button>
                                </div>
                            </div>
                            <div>
                                <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
                            </div>
                        </Card>
                    </Col>
                </Row>

                <Modal footer={null} centered={true} open={modal} onCancel={() => setModal(false)}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2 text-capitalize' >{modalType == 'add' ? 'Add' : 'Edit'} Material for {router?.query?.materialType}</Typography.Title>
                        <Form size='large' form={form} layout='vertical' onFinish={onFinish}>
                            <Form.Item name="material" label={`${router.query.materialType != "sofa" ? "Size" : "Material Name"}`} rules={[{ required: true, message: `Please enter  ${router.query.materialType == "sofa" ? "material name" : "size"}`, whitespace: true }]}>
                                <Input placeholder={`${router.query.materialType != "sofa" ? "Size" : "Material Name"}`} className='border-0' />
                            </Form.Item>
                            <Form.Item name="price" label={`Price per ${router.query.materialType == "sofa" ? "seat" : `piece`}`} rules={[{ required: true, message: `Please Enter price per ${router.query.materialType == "sofa" ? "seat" : "piece"}` }]} >
                                <Input placeholder={`Price per ${router.query.materialType == "sofa" ? "seat" : `piece`}`} className='border-0' onKeyPress={(e) => {
                                    if (!/[0-9]/.test(e.key)) {
                                        e.preventDefault();
                                    }
                                }} />
                            </Form.Item>
                            <Form.Item className='mb-2 mt-4'>
                                <Button type='primary' htmlType='submit' loading={loading} block>Add Material</Button>
                            </Form.Item>
                        </Form>
                    </div>
                </Modal>
            </section>
        </Fragment>
    )
}

SofaMaterial.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default SofaMaterial