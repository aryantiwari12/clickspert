'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Input, Modal, Select, Tag, Typography, Upload, UploadFile, message } from 'antd';
import dynamic from 'next/dynamic';
import { PlusOutlined } from '@ant-design/icons'
import { RcFile, UploadProps } from 'antd/es/upload';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import placeholder from '@/assets/images/placeholder.png'
import henceofrthEnums from '@/utils/henceofrthEnums';
import Link from 'next/link';

const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

// const { Meta } = Card;
const { Search } = Input;
interface DataType {
    key: React.Key;
}
const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });

const EditService: Page = (props: any) => {
    const [previewOpen, setPreviewOpen] = useState(false);
    const router = useRouter()
    const [previewImage, setPreviewImage] = useState('');
    const [state, setState] = useState<any>()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [previewTitle, setPreviewTitle] = useState('');
    const [form] = Form.useForm();
    const [recurring, setRecurring] = useState<any>([])

    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const beforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        if (!isJpgOrPng) {
            message.error('You can only upload JPG/PNG file!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('Image must smaller than 2MB!');
        }
        return isJpgOrPng && isLt2M;
    };


    let recurringArray = [
        { key: henceofrthEnums.recurring.ONCE, value: 'Once' },
        { key: henceofrthEnums.recurring.EVERY_WEEK, value: 'Every_week' },
        { key: henceofrthEnums.recurring.EVERY_2_WEEK, value: 'Every_2_week' },
        { key: henceofrthEnums.recurring.MULTIPLE, value: 'Multiple' },
    ]


    const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
        setFileList(newFileList);
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );
    const handleCancel = () => setPreviewOpen(false);
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router.query._id)
            setState(apiRes)
            form.setFieldsValue(apiRes)
            form.setFieldValue("min_price", apiRes.min_price)
            form.setFieldValue("price_per_hour", apiRes.price_per_hour)
            form.setFieldValue("discount_for_once", apiRes.discount_for_once)
            form.setFieldValue("discount_for_every_2_week", apiRes.discount_for_every_2_week)

            setFileList([{
                uid: '-1',
                name: '',
                status: 'done',
                url: henceforthApi.FILES.imageOriginal(apiRes.image, placeholder.src),
            }])
        } catch (error) {

        }
    }
    const Update = async (values: any) => {
        try {
            let image = state?.image
            const items = {
                _id: router.query._id,
                name: values.name,
                image: image,
                min_price: +values.min_price,
                min_price_currency: state.min_price_currency._id,
                price_per_hour: +values.price_per_hour,
                price_per_hour_currency: state?.price_per_hour_currency?._id,
                cleaning_material_price_per_hour: +values.cleaning_material_price_per_hour,
                cleaning_material_price_currency: state?.cleaning_material_price_currency?._id,
                recurring:
                    recurring
                ,
                discount_for_once: +values.discount_for_once,
                discount_every_week: +values.discount_every_week,
                discount_for_every_2_week: +values.discount_for_every_2_week,
                discount_multiple: +values.discount_multiple,
                description: values.description
            }
            if (fileList[0]?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0]?.originFileObj)
                console.log("file image", apiImageRes);
                items['image'] = apiImageRes.file_name
            }
            let apiRes = await henceforthApi.Service.normal_cleaning(items)
            Toast.success(apiRes.message);
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading(false)
        }
    }
    const onSelectValue = (res: any) => {
        setRecurring(res)
        console.log(res, "name");
    }
    console.log(recurring, "sssdfdf");
    console.log(state, 'state');


    const onSelectReccuring = (values: any) => {
        setRecurring(values)
    }

    useEffect(() => {
        initialise()
    }, [])
    useEffect(() => {
        if (state) {
            setRecurring([...state?.recurring])
        }
    }, [state])
    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24} md={16}>
                        <Card className='common-card '>
                            <Row>
                                <Col span={24}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={"/services/page/1"} className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${state?.service_id?._id}/view`} className='text-decoration-none'>Cleaning</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >Edit Normal Cleaning</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Edit Normal Cleaning</Typography.Title>
                                    </div>

                                    <Form
                                        layout='vertical'
                                        size='large'
                                        onFinish={Update}
                                        form={form}
                                    >
                                        <Form.Item name='image' rules={[{ required: true, message: 'Please select image', }]}>
                                            <Upload name="image"
                                                listType="picture-card"
                                                fileList={fileList}
                                                onPreview={handlePreview}
                                                beforeUpload={beforeUpload}
                                                onChange={handleChange}
                                            >
                                                {fileList.length > 0 ? null : uploadButton}
                                            </Upload>
                                        </Form.Item>

                                        <Modal open={false} title={previewTitle} footer={null} onCancel={handleCancel}>
                                            <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                        </Modal>
                                        <Form.Item name='name' label={'Subservice Name'} rules={[{ required: true, message: 'Please Enter your Subservice', whitespace: true }]}>
                                            <Input className='border-0' onKeyPress={(e: any) => {
                                                if (!/[a-zA-Z ]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                                                    e.preventDefault();
                                                }
                                            }} disabled placeholder='Enter Subservice Name' />
                                        </Form.Item>
                                        {/* <Form.Item name='min_price' label={'Minimum Price (AED)'} rules={[{ required: true, message: 'Please Enter your min price' }]}>
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Minimum Price' />
                                        </Form.Item> */}
                                        <Form.Item name="price_per_hour" label={'Price per Hour (AED)'} rules={[{ required: true, message: 'Please Enter your price per hour' }]}>
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Price per Hour' />
                                        </Form.Item>
                                        {/* Price for Cleaning Material Per Hour */}
                                        <Form.Item name="cleaning_material_price_per_hour" label={'Price for Cleaning Material Per Hour (AED)'} rules={[{ required: true, message: 'Please Enter your price per hour' }]}>
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Price per Hour' />
                                        </Form.Item>
                                        <Form.Item name="recurring" label="Recurring" rules={[{ required: true, message: 'Please Selet Recurring' }]} >
                                            <Select placeholder='Please Selet Recurring'
                                                mode="multiple"
                                                onChange={onSelectReccuring}
                                                options={recurringArray?.map((res: any, index: number) => { return { value: res?.key, label: res?.key } }) as any}
                                            />
                                        </Form.Item>
                                        {/* <div className='d-flex flex-wrap gap-2'>
                                            {state?.recurring?.map((res: any) => <Tag color="#108ee9" key={res?._id} bordered={false} closable><Tooltip title={res}>{res?.slice(0, 15)}</Tooltip></Tag>)}
                                        </div> */}
                                        {recurring?.includes('Once') && <Form.Item label={`Discount for Once % `} name={'discount_for_once'} rules={[{ required: true, message: '' }]} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.EVERY_WEEK) && <Form.Item label={`Discount for every week `} name={'discount_every_week'} rules={[{ required: true, message: '' }]} >
                                            <Input className='border-0' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} placeholder='Enter Discount' />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.EVERY_2_WEEK) && <Form.Item label={`Discount for every 2 week %`} name={'discount_for_every_2_week'} rules={[{ required: true, message: '' }]} >
                                            <Input className='border-0' placeholder='Enter Discount' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>}
                                        {recurring?.includes(henceofrthEnums.recurring.MULTIPLE) && <Form.Item label={`Discount for multiple times a week % `} name={'discount_multiple'} rules={[{ required: true, message: '' }]} >
                                            <Input className='border-0' placeholder='Enter Discount' onKeyPress={(e) => {
                                                if (!/[0-9]/.test(e.key)) {
                                                    e.preventDefault();
                                                }
                                            }} />
                                        </Form.Item>}
                                        <Form.Item name="description" hasFeedback label="Description" rules={[{ required: true, message: 'Please Enter your Description', whitespace: true }]}>
                                            <ReactQuill className='bg-light border-0' theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item className='mb-0'>
                                            <Button type="primary" htmlType="submit" className="login-form-button mt-4" >
                                                Save Changes
                                            </Button>
                                        </Form.Item>
                                    </Form>
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}

EditService.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default EditService