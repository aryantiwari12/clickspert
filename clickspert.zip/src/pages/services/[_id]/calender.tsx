'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useContext, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, BadgeProps, Breadcrumb, Calendar, Checkbox, Divider, Form, Input, MenuProps, Modal, Popconfirm, Radio, Space, Switch, Table, TimePicker, TimePickerProps, Typography } from 'antd';
import dynamic from 'next/dynamic';
import HenceforthIcons from '@/components/HenceforthIcons';
import { PlusOutlined, CloseOutlined } from '@ant-design/icons'
import Link from 'next/link';
import Image from 'next/image';
import ServiceDetailImg from '../../../assets/images/service-detail.png'
import { DatePickerProps, DatePickerType } from 'antd/es/date-picker';
import dayjs from 'dayjs';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { GlobalContext } from '@/context/Provider';
import { useOnOutsideClickCheck } from '@/utils/components/commonFunction';
var weekday = require('dayjs/plugin/weekday')

const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 4 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 24 },
    },
};

const formItemLayoutWithOutLabel = {
    wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 24, offset: 0 },
    },
};

// // const { Meta } = Card;
// const { Search } = Input;
// interface DataType {
//     key: React.Key;
// }
// type PickerType = 'time' | 'date';
const daysArray = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
let daysArrayFixed = [
    {
        day: 'SUN',
    },
    {
        day: 'MON',
    },
    {
        day: 'TUE',
    },
    {
        day: 'WED',
    },
    {
        day: 'THU',
    },
    {
        day: 'FRI',
    },
    {
        day: 'SAT',
    },

]

const Calender: Page = (props: any) => {
    const [form] = Form.useForm()
    const [dayform] = Form.useForm()
    const [view, setView] = React.useState('view')
    const [loading, setLoading] = useState({
        loading1: false,
        loading2: false
    })
    const { Toast } = useContext(GlobalContext)
    const router = useRouter()
    const [sideBarState, setSideBarState] = useState<any>({
        date: false,
        day: false
    })
    const [data, setData] = useState<any>()
    const [dateData, setDateData] = useState({
        count: 0,
        data: [] as any
    })
    const [daysData, setDaysData] = useState({
        count: 0,
        data: [...daysArrayFixed] as any,
    })
    const [isModalOpen, setIsModalOpen] = useState<boolean>(false)
    const [addDateModalForm] = Form.useForm()
    const [slot_type, setSlot_type] = React.useState<"30 mins" | "1 hour">("30 mins")
    const [isDaysModalOpen, setIsDaysModalOpen] = useState<boolean>(false)
    const [addDaysModalForm] = Form.useForm()
    const [open, setOpen] = useState({} as any);
    const [isEditModalOpen, setIsEditModalOpen] = useState<boolean>(false)
    const [modalData, setModalData] = useState<any>()
    const [EditForm] = Form.useForm()
    const [detail, setDetails] = useState<any>({
        dates: {},
        days: {}
    })
    const [monthly, setMonthly] = useState({
        dates: [] as any,
        days: [] as any
    })
    const [daysDataModal, setDaysDataModal] = useState({}) as any
    // const [dropdownValue, setDropDownValue] = useState<any>([])
    const [addDayData, setAddDayData] = useState()

    const handleOpenChange = (flag: boolean, index: number) => {
        setOpen({
            ['daya' + index]: flag
        });
    };
    const handleQuary = (name: string, value: string) => {
        let quary = router?.query
        delete quary['sidebar']

        router?.replace({ pathname: `/services/${router?.query?._id}/calender`, query: { ...quary, [name]: value } })
    }
    function getMillisecondsFromDateString(dateString: any) {
        const [day, month, year] = dateString.split(':').map(Number);
        const dateObject = new Date(year, month - 1, day);
        const milliseconds = dateObject.getTime();
        return milliseconds;
    }

    const handleCalenderClick = (items: any) => {
        const date = dayjs(items?.date?.$d)?.format("DD:MM:YYYY")
        const selectedDate = getMillisecondsFromDateString(date)

        const s = new Date(selectedDate).setHours(5.5, 30, 0, 0)
        const newDate = s?.valueOf()
        router?.replace({ pathname: `/services/${router?.query?._id}/calender`, query: { ...router?.query, ...items, date: newDate } })
    }

    const dateCalenderData = async () => {
        try {
            let apiRes = await henceforthApi.Calender.getDateCalender(String(router?.query?._id))
            setDateData(apiRes)
        } catch (error) {

        }
    }

    const CalenderMonthlyData = async () => {
        try {
            let apiRes = await henceforthApi.Calender.getMonthlyCalender(String(router?.query?._id), router.query.date ? Number(router.query.date) : new Date()?.valueOf())

            setMonthly(apiRes)
        } catch (error) {

        }
    }
    // const [daysData, setDaysData] = useState({
    //     count: 0,
    //     data: [...days] as any,
    //     dropdownValue:[] as any
    // })
    const handleDropDown = (e: any, index: number) => {
        let arr = [...daysData?.data]
        if (!!arr[index]?.dropdownValue) {
            // let arr = daysData?.data
            const inde = arr[index].dropdownValue.indexOf(e.target.value)
            // let indexOfValue = arr?.indexOf(e.target.value)
            if (inde !== -1) {
                arr[index].dropdownValue.splice(inde, 1)
            } else {
                arr[index].dropdownValue.push(e.target.value)
            }
        } else {
            arr[index].dropdownValue = [e.target.value]
        }
        setDaysData({
            ...daysData,
            data: arr
        })

    }

    const handleState = (key: string, value: boolean, falseKey: string) => {
        setSideBarState({
            [key]: value,
            [falseKey]: false
        })
    }

    const handleListViewModal = (index: number, state: boolean) => {
        debugger
        let value: any = daysArray[index]
        setDaysDataModal(daysData.data[index])
        setAddDayData(value)
        setIsDaysModalOpen(state)
    }

    // const AddDaySlot = async (values: any) => {
    //     try {
    //         const startHours = values.start_time?.$H
    //         const startMinutes = values.start_time?.$m
    //         const endHours = values.end_time?.$H
    //         const endMinutes = values.end_time?.$m
    //         const startTime=startHours+(startMinutes===30?0.5:0)
    //         const endTime=endHours+(endMinutes===30?0.5:0)

    //         if (startHours === endHours && startMinutes === endMinutes) throw 'Please select different time'
    //         if (slot_type === "1 hour" && (startMinutes === 30 || endMinutes === 30)) throw 'Please maintain 1 hour difference';
    //         console.log(values);
    //         let sta = values.start_time.$m === 30 ? values.start_time?.$H + 0.5 : values.start_time?.$H
    //         let star = sta
    //         let en = values.end_time.$m === 30 ? values.end_time?.$H + 0.5 : values.end_time?.$H
    //         const x = []
    //         for (let index = star; index < en;) {
    //             const t = sta.toString().endsWith(".5")
    //             console.log(sta)
    //             x.push({
    //                 start_time: (sta) * 60,
    //                 end_time: (sta + (slot_type === "30 mins" ? 0.5 : 1)) * 60
    //             })
    //             sta += (slot_type === "30 mins" ? 0.5 : 1)
    //             index += (slot_type === "30 mins" ? 0.5 : 1)
    //         }
    //         console.log(x);
    //         setLoading({
    //             ...loading,
    //             loading1: true
    //         })
    //         let weekday = router?.query?.view == 'calender' ? dayjs(Number(router?.query?.date)).format('ddd') : addDayData;

    //         let items = {
    //             sub_service_id: router?.query?._id,
    //             days: [
    //                 {
    //                     day: weekday?.toUpperCase(),
    //                     slot_type,
    //                     time_slots: x
    //                 }
    //             ]
    //         }
    //         let apiRes = await henceforthApi.Calender.addDays(items)
    //         Toast.success(apiRes?.message)
    //         addDaysModalForm.resetFields()
    //         if (router?.query?.view == 'calender') {
    //             await getByDate()
    //             await dateCalenderData()
    //         }
    //         daysListing()
    //         setIsModalOpen(false)
    //         setIsDaysModalOpen(false)
    //     } catch (error) {
    //         Toast.error(error)

    //     } finally {
    //         setLoading({
    //             ...loading,
    //             loading1: false
    //         })
    //     }
    // }
    const AddDaySlot = async (values: any) => {
        debugger
        let weekday = router?.query?.view == 'calender' ? dayjs(Number(router?.query?.date)).format('ddd') : addDayData;

        let items = {
            sub_service_id: router?.query?._id,
            days: [
                {
                    day: weekday?.toUpperCase(),
                    time_slots: [
                        {
                            start_time: values.start_time?.$H * 60 + values?.start_time?.$m,
                            end_time: values.end_time?.$H * 60 + values?.end_time?.$m
                        }
                    ]
                }
            ]
        }
        try {
            let apiRes = await henceforthApi.Calender.addDays(items)
            Toast.success(apiRes?.message)
            addDaysModalForm.resetFields()
            if (router?.query?.view == 'calender') {
                await getByDate()
                await dateCalenderData()
            }
            daysListing()
            CalenderMonthlyData()
        } catch (error) {
            Toast.error(error)
        } finally {
            setIsModalOpen(false)
            setIsDaysModalOpen(false)

        }
    }
    const onDeleteSlot = async (days: any) => {
        try {
            let apiRes = await henceforthApi.Calender.slotDateDelete(days)
            Toast.success(apiRes.message)
            daysListing()
        } catch (error) {

        }
    }
    const { isOpen, setIsOpen, menuRef } = useOnOutsideClickCheck()

    const handleEditModal = (index: number, state: boolean) => {
        setIsEditModalOpen(state)
        let res = detail?.dates?.time_slots[index]
        setModalData(res)
        EditForm.setFieldsValue({
            start_time: timeChange(res?.start_time),
            end_time: timeChange(res?.end_time),
        })
    }

    const handleDateAvailable = async (value: boolean) => {
        let items = {
            _id: router?.query?._id,
            date: router?.query?.date,
            is_available: value
        }
        try {
            let res = await henceforthApi.Calender.dateStatus(items)
            getByDate()
            CalenderMonthlyData()
            Toast.success(res?.message)
        } catch (error) {
            Toast.error(error)
        }
    }

    const handleDayAvailable = async (value: boolean, day: string, index: any) => {
        let items = {
            _id: router?.query?._id,
            day: day,
            is_available: value
        }
        if (index) {
            daysData.data[index].is_available = value
        }
        try {
            let res = await henceforthApi.Calender.daysStatus(items)
            getByDate()
            CalenderMonthlyData()
            Toast.success(res?.message)
        } catch (error) {
            Toast.error(error)
        }
    }


    const handleAdd = async (values: any) => {
        debugger
        let items = {
            sub_service_id: router?.query?._id,
            dates: [
                {
                    date: Number(router?.query?.date),
                    time_slots: [
                        {
                            start_time: values.start_time?.$H * 60 + values?.start_time?.$m,
                            end_time: values.end_time?.$H * 60 + values?.end_time?.$m
                        }
                    ]
                }
            ]
        }
        try {
            setLoading({
                loading1: true
            } as any)
            let apiRes = await henceforthApi.Calender.addDateCalender(items)
            Toast.success(apiRes?.message)
            addDateModalForm.resetFields()
            await getByDate()
            await dateCalenderData()
            CalenderMonthlyData()
        } catch (error) {
            Toast.error(error)
        } finally {
            form.resetFields()
            setIsModalOpen(false)
            setLoading({
                loading1: false
            } as any)
        }
    }


    const toHoursAndMinutes = (totalMinutes: number) => {
        // debugger
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        let time = dayjs(`${hours}:${minutes}`, 'HH:mm')
        return dayjs(time).format('HH:mm') as any
    }

    const timeChange = (totalMinutes: number) => {
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        return dayjs(`${hours}:${minutes}`, 'HH:mm')
    }

    const cellRender = (value: any) => {
        const y = monthly.days?.map((item: any) => dayjs(+item?.date).format('DD/MM/YYYY'))
        const j = monthly.dates?.map((res: any, index: number) => {
            if (!y?.includes(dayjs(+res?.date).format('DD/MM/YYYY'))) {
                monthly?.days?.push(res)
            }
            else {
                const q = monthly?.days?.findIndex((item: any) => dayjs(+item?.date).format('DD/MM/YYYY') == dayjs(+res?.date).format('DD/MM/YYYY'))
                monthly?.days?.splice(q, 1, res)
            }
        })
        let data = monthly.days?.find((res: any, index: number) => dayjs(+res?.date).format('DD/MM/YYYY') == dayjs(value).format('DD/MM/YYYY'))
        if (!data) {
            return <li key={value.date()}  ></li>
        }
        return (
            <ul className="" onClick={() => { handleCalenderClick({ date: `${dayjs(value).startOf('date').valueOf()}`, 'sidebar': 'open', 'date_id': data?.date_id }); }} >
                <li   >
                    <div className="">

                        {data?.time_slots?.map((res: any, index: number) =>
                            <div key={index} className='d-flex'>
                                <div className="">

                                    {(toHoursAndMinutes(res?.start_time))}-
                                </div>
                                <div className="">
                                    {(toHoursAndMinutes(res?.end_time))}

                                </div>
                            </div>)}
                    </div>
                </li>
            </ul>
        );

        // let data = dateData?.data?.find((res: any, index: number) => dayjs(+res?.date).format('DD/MM/YYYY') == dayjs(value).format('DD/MM/YYYY'))
        // if (!data) {
        //     return <li key={value.date()}  ></li>
        // }
        // return (
        //     <ul className="" onClick={() => { handleCalenderClick({ date: `${dayjs(value).startOf('date').valueOf()}`, 'sidebar': 'open', 'date_id': data?.date_id }); }} >
        //         <li   >
        //             <div className="">

        //                 {data?.time_slots?.map((res: any, index: number) =>
        //                     <div key={index} className='d-flex'>
        //                         <div className="">

        //                             {(toHoursAndMinutes(res?.start_time))}-
        //                         </div>
        //                         <div className="">
        //                             {(toHoursAndMinutes(res?.end_time))}

        //                         </div>
        //                     </div>)}
        //             </div>
        //         </li>
        //     </ul>
        // );
    }

    const deleteSlotInDays = async (id: string) => {
        try {
            let apiRes = await henceforthApi.Calender.deleteDaySlot(id)
            Toast.success(apiRes?.message ?? "Success")
            if (router?.query?.view == 'calender') {
                await getByDate()
                await dateCalenderData()
            } else {

                await daysListing()
            }
        } catch (error) {
            Toast.error(error)

        }
    }



    const onDelete = async (id: string) => {
        try {
            let apiRes = await henceforthApi.Calender.deleteDateSlot(id)
            Toast.success(apiRes?.message ?? "Success")
            await getByDate()
            await dateCalenderData()
        } catch (error) {
            Toast.error(error)

        }
    }
    const daysListing = async () => {
        // debugger
        try {
            let apiRes = await henceforthApi.Calender.getDays(String(router?.query?._id))
            setDaysData((days) => {
                let x = days.data
                if (apiRes.data.length) {

                    x = x.map((element: any) => {
                        const ind = apiRes.data.find((res: any) => element?.day?.toLowerCase() === res?.day?.toLowerCase())
                        if (ind) {
                            element = { ...element, ...ind }
                        } else {
                            element = { day: element.day }
                        }
                        return element
                    });
                } else {
                    x = daysArrayFixed
                }
console.log('days.data',x);

                return {
                    count: apiRes?.count,
                    data: [...x]
                }
            })
        } catch (error) {

        }
    }
    const editDays = async (id: string, key: string, value: any) => {
        debugger
        let items = {
            _id: id,
            [key]: value?.$H * 60 + value?.$m,
        }
        try {
            let apiRes = await henceforthApi.Calender.editDays(items)

            Toast.success(apiRes?.message ?? "Success")
            CalenderMonthlyData()
            getByDate()
            daysListing()
        } catch (error) {
            Toast.error(error)
        }
    }
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Service.sub_service(router?.query?._id)
            setData(apiRes)
        } catch (error) {

        }
    }
    useEffect(() => {
        initialise()
    }, [router?.query?._id])
    const editDates = async (id: string, key: string, value: any, type: string) => {
        debugger
        let items = {
            _id: id,
            [key]: value?.$H * 60 + value?.$m,
        }
        let apiRes;
        try {
            if (type == "dates") {
                apiRes = await henceforthApi.Calender.editDateCalender(items)
            } else {
                apiRes = await henceforthApi.Calender.editDayCalender(items)
            }

            Toast.success(apiRes?.message ?? "Success")
            CalenderMonthlyData()
            getByDate()
            daysListing()
        } catch (error) {
            Toast.error(error)
        }
    }
    const [valueIndex, setValueIndex] = useState<any>()
    const copyDaysData = async () => {
        let value = daysData?.data[valueIndex]
        let items = {
            sub_service_id: router?.query?._id,
            day: value?.day,
            days: [...value?.dropdownValue]
        }
        try {
            let apiRes = await henceforthApi.Calender.copyDays(items)
            await daysListing()
            Toast.success(apiRes?.message)
            setOpen({})
        } catch (error) {
            console.log(error);
        }
    }
    const getByDate = async () => {
        try {
            const apiRes = await henceforthApi.Calender.getByDate(String(router?.query?._id), String(router?.query?.date))
            console.log(apiRes, "apiRessssssssss");
            setDetails(apiRes)
        } catch (error: any) {
            Toast.error(error)
        }
    }
    const disabledHours = (e: any) => {
        console.log(e?.$H, "eeeeeeeee");
        const todaymilliseconds = new Date()?.setHours(5.5, 30, 0, 0)
        const s = todaymilliseconds
        const hours = [];
        if (todaymilliseconds >= Number(router.query.date)) {
            const currentMinute = dayjs().minute();
            const currentHour = dayjs().hour();
            const Hours = e?.$H ? currentHour > e?.$H ? currentHour : e?.$H : currentHour
            const timepickerHoursShow = currentMinute > 30 ? Hours : Hours - 1;
            for (let i = 0; i <= timepickerHoursShow; i++) {
                hours.push(i);
            }
        }
        else {
            for (let i = 0; i <= e?.$H; i++) {
                hours.push(i)
            }
        }
        console.log(hours, "hourssssssssss");
        return hours;
    };
    const disabledMinutes = (selectedHour: any) => {
        const minutes = [];
        const currentMinute = dayjs().minute();
        if (selectedHour === dayjs().hour()) {
            for (let i = 0; i <= currentMinute; i++) {
                minutes.push(i);
            }
        }
        console.log(minutes, "minutes");

        return minutes;
    };
    useEffect(() => {
        getByDate()
    }, [router?.query?._id, router?.query?.date])
    useEffect(() => {
        dateCalenderData()
        daysListing()
    }, [router?.query?._id, router?.query?.view])
    useEffect(() => {
        CalenderMonthlyData()
    }, [router?.query?._id, router?.query?.date])

    const items =
        [...daysArray.map((res: any, index: number) => {
            return {
                key: res,
                label: <div>
                    <Checkbox disabled={daysData?.data[valueIndex]?.day == res} value={res} >{res}</Checkbox>
                </div>
            }
        }), {
            key: 'apply',
            label: <div>
                <Button onClick={copyDaysData} type='primary' block>Apply</Button>
            </div>
        },]
    const handleMenuClick: MenuProps['onClick'] | any = (e: any, index: number) => {
        if (daysArray.includes(e.key.toUpperCase())) {
            setOpen({
                ['days' + index]: true
            });
        }
    };
    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section className='calender-section'>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card pe-0'>
                            <Row>
                                <Col span={24}  xl={20}>
                                    <div className='mb-4'>
                                        <Breadcrumb separator=">">
                                            <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href="/services/page/1" className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item ><Link href={`/services/${data?.service_id?._id}/view`} className='text-decoration-none'>{data?.service_id?.name}</Link></Breadcrumb.Item>
                                            <Breadcrumb.Item >{data?.name}</Breadcrumb.Item>
                                        </Breadcrumb>
                                    </div>
                                    {/* Title  */}
                                    <div className='mb-4'>
                                        <Typography.Title className='m-0 fw-600' level={3}>Calendar Availability of {data?.name}</Typography.Title>
                                    </div>

                                    <div className='mt-4'>
                                        <div className="flex-center">
                                            <Typography.Title className='m-0 fw-bold' level={4}>Working Hours</Typography.Title>
                                            <div className='text-end pe-3'>
                                                <Radio.Group defaultValue={router?.query?.view ?? 'list'} buttonStyle="solid">
                                                    <Radio.Button value="list" onClick={() => handleQuary('view', 'list')} className='text-dark'><Space align='center'><span className='d-flex'><HenceforthIcons.ListOutline /></span>List View</Space></Radio.Button>
                                                    <Radio.Button value="calender" onClick={() => handleQuary('view', 'calender')} className='text-dark'><Space align='center'><span className='d-flex'><HenceforthIcons.CalenderOutline /></span>Calender View</Space></Radio.Button>
                                                </Radio.Group>
                                            </div>
                                        </div>
                                        {router?.query?.view === 'calender' ?
                                            <div style={{overflow:'hidden', overflowX:'scroll'}}>
                                                <Calendar disabledDate={(current) => {
                                                    return dayjs().add(-1, 'days') >= current ||
                                                        dayjs().add(1, 'month') <= current;
                                                }}
                                                    cellRender={cellRender}
                                                    onSelect={(date: any, value) => { handleCalenderClick({ date: date, 'sidebar': 'open' }) }}
                                                />
                                            </div>
                                            :
                                            <div className="list-view">
                                                <Form layout='vertical' size='large' form={dayform} >
                                                    <ul>
                                                        {daysData?.data?.map((res: any, index: number) =>
                                                            <li className='d-flex align-items-center' key={res._id}>
                                                                <div className="d-flex align-items-center gap-4">
                                                                    <Checkbox checked={res?.is_available} onChange={(value) => handleDayAvailable(!res?.is_available, res?.day, index)} ><span className='text-dark'>{res?.day}</span></Checkbox>
                                                                    <div>
                                                                        {res?.time_slots?.map((timeRes: any, index: number) =>
                                                                            <Row gutter={[10, 10]} align={'middle'} key={timeRes._id}>
                                                                                <Col span={24} md={10}>
                                                                                    <Form.Item label={'Start Time'} name={['start_time',res?.day+index]} className='mb-0'>
                                                                                        <TimePicker format={'HH:mm'} minuteStep={30} inputReadOnly clearIcon={false} disabledHours={() => disabledHours("")} disabledMinutes={(e: any) => disabledMinutes(e)} onOk={(value) => editDays(timeRes?._id, 'start_time', value)} defaultValue={timeChange(timeRes?.start_time)} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                                                    </Form.Item>
                                                                                </Col>
                                                                                <Col span={24} md={10}>
                                                                                    <Form.Item label={'End Time'} name={['end_time',res?.day+index]} className='mb-0'>
                                                                                        <TimePicker format={'HH:mm'} minuteStep={30} inputReadOnly clearIcon={false} disabledHours={() => disabledHours(addDateModalForm?.getFieldValue("start_date"))} disabledMinutes={(e: any) => disabledMinutes(e)} onOk={(value) => editDays(timeRes?._id, 'end_time', value)} placeholder='Time' defaultValue={timeChange(timeRes?.end_time)} suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                                                    </Form.Item>
                                                                                </Col>
                                                                                <Col span={24} md={4}>
                                                                                    <Popconfirm
                                                                                        title="Delete"
                                                                                        description="Are you sure to delete time slot"
                                                                                        onConfirm={() => deleteSlotInDays(timeRes?._id)}
                                                                                        okText="Yes"
                                                                                        cancelText="No">
                                                                                        <Button className='border-0 bg-transparent mt-4'><HenceforthIcons.DeleteIcon /></Button>
                                                                                    </Popconfirm>

                                                                                </Col>
                                                                            </Row>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                                <div className='d-flex align-items-center gap-3'>
                                                                    <Button className='border-0 bg-transparent px-0' onClick={() => { handleListViewModal(index, true); setSlot_type(res.slot_type || slot_type) }}><PlusOutlined /></Button>
                                                                    <Dropdown overlayStyle={{ width: 150 }} trigger={['click']} menu={{ items, multiple: true, onChange: (values) => handleDropDown(values, index), selectedKeys: res?.dropdownValue, onClick: (e) => handleMenuClick(e, index), }} placement="bottomRight" arrow onOpenChange={(e) => handleOpenChange(e, index)}
                                                                        open={open?.['days' + index]}>
                                                                        <Button onClick={(e) => setValueIndex(index)} className='border-0 bg-transparent px-0'  ><HenceforthIcons.Copy /></Button>
                                                                        {/* <Button>bottomRight</Button> */}
                                                                    </Dropdown>
                                                                </div>
                                                            </li>)}
                                                    </ul>
                                                </Form>
                                            </div>
                                        }
                                    </div>
                                </Col>

                                {router?.query?.sidebar == 'open' && <Col span={24} md={8} className='border-start'>
                                    <div className='mb-3'>
                                        <Button onClick={() => handleQuary('sidebar', 'close')} className='bg-transparent border-0'><HenceforthIcons.CrossIcon /></Button>
                                    </div>
                                    <div>
                                        <ul>
                                            <li onClick={() => handleState('date', !sideBarState.date, 'day')} ><span>Edit Date</span><HenceforthIcons.RightArrow /></li>
                                            {detail?.days && <li onClick={() => handleState('day', !sideBarState.day, 'date')} ><span>Edit {dayjs(Number(router?.query?.date)).format("dddd")}</span><HenceforthIcons.RightArrow /></li>}
                                        </ul>
                                    </div>
                                    <div className='available-hours'>
                                        <ul>
                                            <li>
                                                {sideBarState.date && <Typography.Title className='mb-3 fw-600' level={4}>  {dayjs((+detail?.dates?.date || Number(router?.query?.date))).format('DD-MMM-YYYY')}</Typography.Title>}
                                                {detail?.days ? (sideBarState.day && <Typography.Title className='mb-3 fw-600' level={4}> Edit {dayjs(Number(router?.query?.date)).format("dddd")}</Typography.Title>) : ""}
                                                {(sideBarState.day) && <div className='flex-center'>
                                                    <Typography.Text className='m-0 fw-600 text-gray'>Available</Typography.Text>
                                                    <Switch checked={detail?.days?.is_available} onChange={(value) => handleDayAvailable(value, detail.days?.day, "")} />
                                                </div>}
                                                {sideBarState.date && <div className='flex-center'>
                                                    <Typography.Text className='m-0 fw-600 text-gray'>Available</Typography.Text>
                                                    <Switch checked={detail.dates.is_available} onChange={handleDateAvailable} />
                                                </div>}
                                            </li>
                                            {(sideBarState.date) && <li>
                                                <div className='flex-center'>

                                                    <Typography.Paragraph className='m-0 fw-600'>What hours are you available?</Typography.Paragraph>
                                                    <Button className='border-0 bg-transparent  px-0' onClick={() => setIsModalOpen(true)} ><HenceforthIcons.Add /></Button>
                                                </div>

                                                {detail?.dates?.time_slots?.map((res: any, index: number) => <Form
                                                    layout='vertical'
                                                    size='large'
                                                    key={index}

                                                > <Row gutter={[10, 10]}>
                                                        <Col span={24} md={12}>
                                                            <Form.Item label={'Start Time'} name={'start_time'} className='mb-0'>
                                                                <TimePicker minuteStep={30} format={'HH:mm'} inputReadOnly clearIcon={false} disabledHours={() => disabledHours("")} disabledMinutes={(e: any) => disabledMinutes(e)} onOk={(value) => editDates(res?._id, 'start_time', value, "dates")} placeholder='Time' defaultValue={timeChange(res?.start_time)} suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                            </Form.Item>
                                                        </Col>
                                                        <Col span={24} md={12}>
                                                            <Form.Item label={'End Time'} name={'end_time'} className='mb-0'>
                                                                <TimePicker minuteStep={30} format={'HH:mm'} inputReadOnly clearIcon={false} disabledHours={() => disabledHours(addDateModalForm?.getFieldValue("start_date"))} disabledMinutes={(e: any) => disabledMinutes(e)} onOk={(value) => editDates(res?._id, 'end_time', value, "dates")} defaultValue={(timeChange(res?.end_time))} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                            </Form.Item>
                                                        </Col>
                                                        <Col span={24}>
                                                            <Popconfirm
                                                                title="Delete"
                                                                description="Are you sure to delete time slot"
                                                                onConfirm={() => onDelete(res?._id)}
                                                                okText="Yes"
                                                                cancelText="No">
                                                                <Button danger ghost block><span className='text-danger'>Delete</span></Button>
                                                            </Popconfirm>


                                                        </Col>
                                                    </Row>
                                                </Form>)}
                                            </li>}
                                            {(sideBarState?.day) && <li>
                                                <div className='flex-center'>

                                                    <Typography.Paragraph className='m-0 fw-600'>What hours are you available?</Typography.Paragraph>
                                                    <Button className='border-0 bg-transparent  px-0' onClick={() => handleListViewModal(0, true)}  ><HenceforthIcons.Add /></Button>
                                                </div>

                                                {detail?.days?.time_slots?.map((res: any, index: number) => <Form
                                                    layout='vertical'
                                                    size='large'
                                                    key={index}

                                                > <Row gutter={[10, 10]}>
                                                        <Col span={24} md={12}>
                                                            <Form.Item label={'Start Time'} name={'start_time'} className='mb-0'>
                                                                <TimePicker minuteStep={30} format={'HH:mm'} inputReadOnly disabledHours={() => disabledHours("")} disabledMinutes={(e: any) => disabledMinutes(e)} clearIcon={false} onOk={(value) => editDates(res?._id, 'start_time', value, "day")} placeholder='Time' defaultValue={timeChange(res?.start_time)} suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                            </Form.Item>
                                                        </Col>
                                                        <Col span={24} md={12}>
                                                            <Form.Item label={'End Time'} name={'end_time'} className='mb-0'>
                                                                <TimePicker minuteStep={30} format={'HH:mm'} inputReadOnly disabledHours={() => disabledHours(addDateModalForm?.getFieldValue("start_date"))} disabledMinutes={(e: any) => disabledMinutes(e)} clearIcon={false} onOk={(value) => editDates(res?._id, 'end_time', value, "day")} defaultValue={(timeChange(res?.end_time))} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                                            </Form.Item>
                                                        </Col>
                                                        <Col span={24}>
                                                            <Popconfirm
                                                                title="Delete"
                                                                description="Are you sure to delete time slot"
                                                                onConfirm={() => deleteSlotInDays(res?._id)}
                                                                okText="Yes"
                                                                cancelText="No">
                                                                <Button danger ghost block><span className='text-danger'>Delete</span></Button>
                                                            </Popconfirm>
                                                            {/* <Button danger onClick={() => onDelete(res?._id)} ghost block><span className='text-danger'>Delete</span></Button> */}

                                                        </Col>
                                                    </Row>
                                                </Form>)}
                                            </li>}
                                        </ul>
                                    </div>
                                </Col>}
                            </Row>
                        </Card >
                    </Col >
                </Row >

                <Modal footer={null} centered={true} open={isModalOpen} onCancel={() => { addDateModalForm.resetFields(); setIsModalOpen(false) }}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Time Slot</Typography.Title>
                        <Form
                            layout='vertical'
                            size='large'
                            form={addDateModalForm}
                            onFinish={handleAdd}
                        > <Row gutter={[10, 10]}>
                                <Col span={24} md={12}>
                                    <Form.Item label={'Start Time'} name={'start_time'} className='mb-0' rules={[{ required: true, message: "Start Time is Required" }]}>
                                        <TimePicker minuteStep={30} format={'HH:mm'} disabledHours={() => disabledHours("")} disabledMinutes={(e: any) => disabledMinutes(e)} inputReadOnly clearIcon={false} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                    </Form.Item>
                                </Col>
                                <Col span={24} md={12}>
                                    <Form.Item label={'End Time'} name={'end_time'} rules={[{ required: true, message: "End Time is Required" }]} className='mb-0'>
                                        <TimePicker minuteStep={30} format={'HH:mm'} disabledHours={() => disabledHours(addDateModalForm.getFieldValue('start_time'))} disabledMinutes={(e: any) => disabledMinutes(e)} inputReadOnly clearIcon={false} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                    </Form.Item>
                                </Col>

                                <Col span={24}>
                                    <Button htmlType='submit' block loading={loading.loading1}><span className='text-danger'>Add Time Slot</span></Button>
                                </Col>
                            </Row>
                        </Form>
                    </div>
                </Modal>

                <Modal footer={null} centered={true} open={isDaysModalOpen} onCancel={() => { addDaysModalForm.resetFields(); setIsDaysModalOpen(false) }}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Add Time Slot </Typography.Title>
                        <Form
                            form={addDaysModalForm}
                            layout='vertical'
                            size='large'
                            onFinish={AddDaySlot}
                        > <Row gutter={[10, 10]}>
                                <Col span={24} md={12}>
                                    <Form.Item label={'Start Time'} rules={[{ required: true, message: "Start Time is Required" }]} name={'start_time'} className='mb-0'>
                                        <TimePicker minuteStep={30} format={'HH:mm'} disabledHours={() => disabledHours("")} disabledMinutes={(e: any) => disabledMinutes(e)} inputReadOnly clearIcon={false} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                    </Form.Item>
                                </Col>
                                <Col span={24} md={12}>
                                    <Form.Item label={'End Time'} rules={[{ required: true, message: "End Time is Required" }]} name={'end_time'} className='mb-0'>
                                        <TimePicker minuteStep={30} format={'HH:mm'} disabledHours={() => disabledHours(addDateModalForm?.getFieldValue("start_date"))} disabledMinutes={(e: any) => disabledMinutes(e)} inputReadOnly clearIcon={false} placeholder='Time' suffixIcon={<HenceforthIcons.TimeIcon />} className='w-100' />
                                    </Form.Item>
                                </Col>
                                {/* <Col span={24} className='d-flex justify-content-center'>
                                    <div className='d-flex gap-1 bg-light p-1 rounded' style={{ width: "fit-content" }}>
                                        <Button onClick={() => { setSlot_type("30 mins"); addDaysModalForm.resetFields() }} type={slot_type === "30 mins" ? "primary" : "ghost"}>
                                            30 mins
                                        </Button>
                                        <Button onClick={() => { setSlot_type("1 hour"); addDaysModalForm.resetFields() }} type={slot_type === "1 hour" ? "primary" : "ghost"}>
                                            1 hour
                                        </Button>
                                    </div>

                                </Col> */}
                                <Col span={24}>
                                    <Button htmlType='submit' block loading={loading.loading1}><span className='text-danger'>Add Time Slot</span></Button>
                                </Col>
                            </Row>
                        </Form>
                    </div>
                </Modal>


            </section >

        </Fragment >
    )
}

Calender.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default Calender