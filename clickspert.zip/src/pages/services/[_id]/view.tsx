'use client';
import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Divider, Form, Input, Modal, Switch, Table, Typography, Upload, UploadFile } from 'antd';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import { ContactUsDetailsInterface, serviceDetails } from '@/interfaces';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons'
import { RcFile, UploadChangeParam, UploadProps } from 'antd/es/upload';
import henceofrthEnums from '@/utils/henceofrthEnums';
import { Spinner } from '@/components/common/BootstrapCompo';


const { Row, Col, Card, Button, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const ViewServices: Page = (props: any) => {
    const router = useRouter()
    const { Toast, loading, downloadCSV, setLoading } = React.useContext(GlobalContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [state, setState] = React.useState({} as serviceDetails)
    const [poolModal, setPoolModal] = useState<boolean>(false)
    const [poolData, setPoolData] = useState<any>({
        count: 0,
        data: [] as any
    })
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [editImage, setEditImage] = useState<string>('')
    const [editImageModal, setEditImageModal] = useState(false)

    const [previewImage, setPreviewImage] = useState<any>('');
    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        // setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handleImage: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
        console.log(info?.fileList);
        setFileList(info?.fileList)
    };


    const handleEdit = (type: string, modal: boolean, image: string) => {
        setEditImageModal(modal)
        setEditImage(type)
        setFileList([{
            uid: '-1',
            name: 'image.png',
            status: 'done',
            url: image ? henceforthApi.FILES.imageOriginal(image, '') : '',
        }])
    }

    const handlePoolModal = async (open: boolean, index: number) => {
        let details: any = state?.sub_services[index]

        let _id = details?._id
        let res = await henceforthApi.Swimming.get(_id)
        let arr = res?.data?.map((res: any, resindex: number) => {

            return { ...res, subServiceId: _id }
        })


        setPoolData({
            count: res?.count,
            data: arr
        })
        console.log(arr, 'arr');

        setPoolModal(open)
    }
    console.log(poolData, 'poolData');

    const serviceEdit = async (value: any) => {
        let items: any = {
            _id: router?.query?._id,
        }
        if(!fileList?.length){
            return Toast.warn("Please upload image")
        }  

        if (value?.image?.file?.originFileObj) {
            let apiRes = await henceforthApi.Common.uploadFile('file', value?.image?.file?.originFileObj)
            if (editImage == "IMAGE") {
                items['image'] = apiRes?.file_name
            }
            if (editImage == "ICON") {
                items['app_image'] = apiRes?.file_name
            }
        }
        try {
            let apiRes = await henceforthApi.Service.edit(items)
            setState({
                ...state,
                image: apiRes?.data?.image,
                app_image: apiRes?.data?.app_image
            })
            Toast.success(apiRes?.message)
        } catch (error) {
            Toast.error(error)
        } finally {
            setEditImageModal(false)
        }
    }

    const initialise = async () => {
        setLoading(true)
        try {

            let apiRes = await henceforthApi.Service.getById(router.query._id)
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    const handletoogle = async (value: any, index: number, _id: string) => {
        debugger
        try {
            let apiRes = await henceforthApi.Service.enableDisable(_id)
            let arr: any = state?.sub_services
            arr[index].is_enabled = value
            setState({
                ...state,
                sub_services: arr
            })
            Toast.success(apiRes?.message)
        } catch (error) {
            Toast.error(error)
        }
    }

    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );

    React.useEffect(() => {
        initialise()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>Services</title>
                <meta name="description" content="Contact-us" />
            </Head>
            <section>
                {loading ?  <div className='text-center mt-2'><Spinner/></div> :
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Main Menu</Breadcrumb.Item>
                                    <Breadcrumb.Item><Link href="/services/page/1" className='text-decoration-none'>Services</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item >{state.name}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* Title  */}
                            <div className='mb-4'>
                                <Typography.Title className='m-0 fw-700' level={3}>{state.name || 'N/A'}</Typography.Title>
                            </div>
                            <div className='service-detail-img mb-4'>
                                <img src={henceforthApi.FILES.imageOriginal(state.image, '')} alt='img' />
                                <div className="app-icon">
                                    {/* <HenceforthIcons.AppIcon /> */}
                                  {!state?.app_image ? <div className='text-center mt-2'><Spinner/></div> :  <img src={henceforthApi.FILES.imageSmall(state.app_image, '')} alt='img' />}
                                </div>
                            </div>
                            <div className='d-flex align-items-center gap-3'>
                                <Button type='primary' size='large' onClick={() => handleEdit('IMAGE', true, state?.image)}  >Change Image</Button>
                                <Button type='primary' size='large' onClick={() => handleEdit('ICON', true, state?.app_image)} ghost>Change Icon</Button>
                            </div>
                            {/* cards */}
                            <Row gutter={[15, 15]} className='mt-5'>
                                {state?.sub_services?.map((res: any, index: number) => {
                                    return (
                                        <Col key={res._id} span={24} md={12}>
                                            <Card className="service-card">
                                                <div className="service-card-img">
                                                    <img src={henceforthApi.FILES.imageOriginal(res.image, '')} alt='img' />
                                                    <div className='icons'>
                                                        <Link href={`/services/${res._id}/calender`}><Button className='bg-transparent border-0' shape='circle'><HenceforthIcons.Calender /></Button></Link>

                                                        {res?.service_type == 'SWIMMING_POOL' ? <Button className='bg-transparent border-0' onClick={() => handlePoolModal(true, index)} shape='circle'><HenceforthIcons.EditIcon /></Button>
                                                            :
                                                            <Link href={`/services/${res._id}/edit/${res?.service_type?.split("_").join("-").toLowerCase()}`}><Button className='bg-transparent border-0' shape='circle'><HenceforthIcons.EditIcon /></Button></Link>
                                                        }

                                                    </div>
                                                </div>
                                                <div className="service-card-content p-3">
                                                    <div className="flex-center mb-2">
                                                        <Typography.Title className='m-0 fw-600' level={4}>{res.name || 'N/A'}</Typography.Title>
                                                        <Switch checked={res?.is_enabled} onChange={(e) => handletoogle(e, index, res?._id)} />
                                                    </div>
                                                    {/* <Typography.Paragraph className='text-gray' dangerouslySetInnerHTML={{__html:res.description}}></Typography.Paragraph> */}
                                                    {/* <p className='text-gray text-break'  dangerouslySetInnerHTML={{ __html: res?.description ? res?.description?.length > 30 ? res?.description?.slice(0,30)+'...' :res?.description : ""}}></p> */}
                                                    {res.name===henceofrthEnums.Cleaning.windowCleaning || res.name===henceofrthEnums.Cleaning.smartInteriorAutomation  ? <Typography.Text className='text-gray'>Quotation based</Typography.Text>:<Typography.Text className='text-gray'> Minimum Price </Typography.Text>  }
                                                  {!res.is_quotation_based &&  <Typography.Title className='m-0 fw-700' level={4}>{res?.min_price} {res?.min_price_currency?.symbol}</Typography.Title>}
                                                </div>
                                            </Card>
                                        </Col>
                                    )
                                })}


                            </Row>
                        </Card>
                    </Col>
                </Row> }
                <Modal className='services-banner-modal' footer={null} centered={true} open={editImageModal} onCancel={() => setEditImageModal(false)}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Change {editImage == 'IMAGE' ? 'Image' : 'Icon'}</Typography.Title>
                    </div>
                    <div className='mt-4'>
                        <Form
                            onFinish={serviceEdit}
                            size='large'
                        >
                            <Form.Item name={'image'} >
                                <Upload
                                    className='w-100'
                                    listType="picture-card"
                                    fileList={fileList}
                                    onPreview={handlePreview}
                                    onChange={handleImage}
                                >
                                    {fileList.length >= 1 ? null : uploadButton}
                                </Upload>
                            </Form.Item>
                            <div className='d-flex justify-content-center gap-3'>
                                <Form.Item>
                                    <Button type='primary' block htmlType='submit' >
                                        Save Changes
                                    </Button>
                                </Form.Item>
                                <Form.Item>
                                    <Button ghost block onClick={() => setEditImageModal(false)} type='primary' >
                                        Cancel
                                    </Button>
                                </Form.Item>
                            </div>
                        </Form>
                    </div>
                </Modal>


                <Modal footer={null} centered={true} open={poolModal} onCancel={() => setPoolModal(false)}>
                    <div className='text-center'>
                        <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Swimming Pool</Typography.Title>
                    </div>
                    <Row gutter={[15, 15]} className='mt-4'>
                        {poolData?.data?.map((res: any, index: number) => <Col key={index} span={24}> <Link className='text-decoration-none' href={`/services/${res.subServiceId}/edit/${res?._id}/swimming-pool-${res?.service_type?.toLowerCase()}`}>
                            <div className="service-modal-card flex-center p-3">
                                <div>
                                    <Typography.Title level={4} className='fw-600 mb-0'>
                                        {res?.name}
                                    </Typography.Title>
                                    {res?.min_price && <Typography.Title level={5} className='fw-500 text-gray m-0'>
                                        starts from <Typography.Text className='text-theme fw-700'>{res?.min_price} {res?.min_price_currency?.symbol}</Typography.Text>
                                    </Typography.Title>}
                                </div>
                                <Button shape='circle' className='border-0'><HenceforthIcons.ArrowBtn /></Button>
                            </div>
                        </Link>
                        </Col>
                        )}
                    </Row>
                </Modal>

                {/* <ExportFile open={exportModal} setOpen={setExportModal} title="ContactUs Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.ContactUs.export(start_date, end_date)
                        downloadCSV("ContactUs downloadCSV", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                    }
                }} /> */}

            </section>

        </Fragment>
    )
}

ViewServices.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default ViewServices