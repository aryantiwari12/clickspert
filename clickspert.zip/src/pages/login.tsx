import loginImg from "@/assets/images/login-bg.png"
import logo from "@/assets/images/logo.png"
import React, { useContext } from 'react';
import {
    Form,
    Input,
} from 'antd';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { COOKIES_USER_ACCESS_TOKEN } from '@/context/actionTypes';
import { setCookie } from 'nookies';
import dynamic from 'next/dynamic';
import HenceforthIcons from "@/components/HenceforthIcons";
import { lowerCase } from "lodash";

const { Row, Col, Button } = {
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
}

const LoginPage = () => {
    const router = useRouter()
    const { loading, setLoading, Toast, requestNotification, setUserInfo } = React.useContext(GlobalContext)
    const [rememberMe, setRememberMe] = React.useState(false)

    const onFinish = async (values: any) => {
        console.log('Received values of form: ', values);
        if (values.email == "") {
            return Toast.error("Please enter valid E-mail")
        }
        // let items = {
        //     email: String(values.email).toLowerCase(),
        //     password: values.password
        // }
        try {
            debugger
            setLoading(true)
            let notificationToken = await requestNotification();
            console.log(notificationToken , "notificationssssssssss");
            
            if (notificationToken) {
                values["fcm_token"] = notificationToken;
            }
            let apiRes = await henceforthApi.Auth.login(values)
            let data = apiRes
            Toast.success(data.message)
            if (rememberMe) {
                setCookie(this, COOKIES_USER_ACCESS_TOKEN, data.access_token, {
                    maxAge: 60 * 60 * 24 * 30,
                    path: "/",
                });
            } else {
                setCookie(this, COOKIES_USER_ACCESS_TOKEN, data.access_token, {
                    path: "/",
                });
            }
            setUserInfo(data)
            if (router.asPath?.includes("redirect")) {
                router.replace(router?.query?.redirect ? router?.query?.redirect as string : '/')
            } else {
                router.replace('/')
            }

        } catch (error: any) {
            Toast.error(error)
            setLoading(false)
        }
    };
    // let notificationToken =  requestNotification();
    // console.log(notificationToken , "notificationssssssssss");
    return (
        <section className='auth-pages d-flex align-items-center h-100'>
            <div className="container">
                <Row justify="center">
                    <Col className="gutter-row d-none d-md-block" xs={0} sm={6} md={12} lg={10} xl={8}>
                        <div className='image-wrapper '>
                            <img src={loginImg.src} alt="login" style={{ width: "100%" }} />
                        </div>
                    </Col>
                    <Col className="gutter-row" xs={22} sm={18} md={12} lg={10} xl={8}>
                        <div className='form-wrapper d-flex justify-content-center align-items-center h-100 bg-white py-5 px-4'>
                            <div className="w-100">
                                <div className='logo-wrapper mb-4 text-center'>
                                    <img src={logo.src} alt="login" width={180} />
                                </div>
                                <Form name="normal_login" size="large" className="login-form " initialValues={{ remember: false }} onFinish={onFinish} scrollToFirstError>
                                    {/* Email  */}
                                    <Form.Item name="email" className="mb-3" rules={[{ required: true, whitespace: true, message: 'Please enter valid email' }]} >
                                        <Input prefix={<HenceforthIcons.Email />} className="border-0 fs-6" placeholder="Email" />
                                    </Form.Item>
                                    {/* Password  */}
                                    <Form.Item name="password" rules={[{ required: true, message: 'Please enter password' }]}>
                                        <Input.Password prefix={<HenceforthIcons.Password />} type="password" className="border-0 fs-6" placeholder="Password" />
                                    </Form.Item>
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit" className="login-form-button w-100" loading={loading}>
                                        Log in
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        </section>
    )
}

export default LoginPage;