import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, List, Typography } from 'antd';
import Image from 'next/image';
import user from "@/assets/images/placeholder.png"
import dynamic from 'next/dynamic';

const { Row, Col, Card, Button, Avatar } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Avatar: dynamic(() => import("antd").then(module => module.Avatar), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

interface UserValue {
  label: string;
  value: string;
}

const Detail: Page = (props: any) => {

  const data = [
    {
      title: 'Booking ID',
      description: "#123456",
    },
    {
      title: 'Listing Name',
      description: <div className='d-flex gap-3 align-items-center'><Image src={user.src} width={40} height={40} className="object-fit-cover rounded-2" alt="image" /> <Typography.Text >Listing One</Typography.Text ></div>,
    },
    {
      title: 'No. of Rooms',
      description: "2",
    },
    {
      title: 'Check In',
      description: "03/13/2023 from 7:30 PM",
    },
    {
      title: 'Check Out',
      description: "03/14/2023 from 3:30 PM",
    },
    {
      title: 'Price of Booking',
      description: "$20",
    },
    {
      title: 'Admin’s Earning',
      description: "$2",
    },
    {
      title: 'Partner’s Earning',
      description: "$16",
    },
    {
      title: 'Booking Status',
      description: "Pending",
    },
  ];


  async function fetchUserList(username: string): Promise<UserValue[]> {
    console.log('fetching user', username);

    return fetch('https://randomuser.me/api/?results=5')
      .then((response) => response.json())
      .then((body) =>
        body.results.map(
          (user: { name: { first: string; last: string }; login: { username: string } }) => ({
            label: `${user.name.first} ${user.name.last}`,
            value: user.login.username,
          }),
        ),
      );
  }


  return (
    <Fragment>
      <Head>
        <title>Admin | Detail</title>
        <meta name="description" content="Detail" />
      </Head>
      <section>
        <Row gutter={[20, 20]}>
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item className='text-decoration-none'>Home</Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Detail</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* title  */}
              <div className='flex-center mb-4'>
                <Typography.Title level={3} className='m-0 fw-bold'>Booking Details</Typography.Title>
              </div>
              <div className='accordion-wrapper overflow-auto'>
                <List

                  itemLayout="horizontal"
                  dataSource={data}
                  renderItem={(item, index) => (
                    <List.Item className='justify-content-start gap-3'>
                      <List.Item.Meta
                        style={{ maxWidth: "400px" }}
                        description={item.title}
                      />
                      <div>{item.description}</div>
                    </List.Item>
                  )}
                />
              </div>
            </Card>
          </Col>
        </Row>

      </section>
    </Fragment>
  )
}

Detail.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}


export default Detail
