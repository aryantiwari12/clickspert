import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import PoliciesContentEdit from '@/layouts/policies/PoliciesContentEdit';
import { Breadcrumb, Typography } from 'antd';
import Link from 'next/link';
import { COOKIES_USER_ACCESS_TOKEN } from '@/context/actionTypes';
import henceforthApi from '@/utils/henceforthApi';

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const EditTermsConditions: Page = (props: any) => {
    console.log('props', props);


    return (
        <Fragment>
            <Head>
                <title>Edit Terms &#38; Conditions</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <PoliciesContentEdit {...props}>
                <div className='mb-4'>
                    <Breadcrumb separator=">">
                        <Breadcrumb.Item className='text-decoration-none'>Policies</Breadcrumb.Item>
                        <Breadcrumb.Item ><Link href="/terms" className='text-decoration-none'>Privacy-Policy</Link></Breadcrumb.Item>
                        <Breadcrumb.Item className='text-decoration-none'>Edit</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                {/* title  */}
                <div>
                    <Typography.Title level={3} className='m-0 mb-4 fw-bold'>Edit Privacy-Policy</Typography.Title>
                </div>
            </PoliciesContentEdit>
        </Fragment>
    )
}

EditTermsConditions.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    let access_token = context.req.cookies[COOKIES_USER_ACCESS_TOKEN]
    try {
        henceforthApi.setToken(access_token)
        // let apiRes = await henceforthApi.Content.getByType("PRIVACY_POLICY")
        // return { props: { params: 'all', ...apiRes } };
        return { props: {params: 'all'}}
    } catch (error) {
        return { props: { params: 'all', error } };
    }
}


export default EditTermsConditions
