import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Typography } from 'antd';
import Link from 'next/link';
import PoliciesContent from '@/layouts/policies/PoliciesContent';
import { COOKIES_USER_ACCESS_TOKEN } from '@/context/actionTypes';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';

const { Row, Col, Card, Button } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const TermsConditions: Page = (props: any) => {
    console.log('props', props);
    return (
        <Fragment>
            <Head>
                <title>Privacy-Policy</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Policies</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Privacy-Policy</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Privacy-Policy</Typography.Title>
                                <Link href="/privacy/edit" className='text-decoration-none'>
                                    <Button type="primary" htmlType="button">Edit</Button>
                                </Link>
                            </div>
                            {/* content  */}
                            <PoliciesContent {...props} />
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

TermsConditions.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    let access_token = context.req.cookies[COOKIES_USER_ACCESS_TOKEN]
    try {
        henceforthApi.setToken(access_token)
        // let apiRes = await henceforthApi.Content.getByType("PRIVACY_POLICY")
        // return { props: { params: 'all', ...apiRes } };
        return { props: { params: 'all' } };

    } catch (error) {
        return { props: { params: 'all', error } };
    }
}

export default TermsConditions
