import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Avatar, Badge, Select, DatePicker } from 'antd';
import user from "@/assets/images/placeholder.png"
import Link from 'next/link';
import type { TabsProps } from 'antd';
import { EyeOutlined, LoginOutlined, DownloadOutlined, UploadOutlined, SearchOutlined, PlusOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { UserOutlined } from '@ant-design/icons';
import HenceforthIcons from '@/components/HenceforthIcons';
import dayjs, { Dayjs } from 'dayjs';
import SearchPage from '@/components/common/SearchInput';
interface DataType {
    Area: ReactNode,
    OperatingSystem: ReactNode,
}
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Content: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { userInfo, downloadCSV, Toast, uploadCSV } = React.useContext(GlobalContext)
    const [show, setShow] = useState(true);
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };

    const onSearch = (value: string) => {
        console.log("onserach value", value);
        if (timer) {
            clearTimeout(timer)
        }
        timer = setTimeout(() => {
            onChangeRouter("search", String(value).trim())
        }, 2000);
    }

    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }


    const dataSource = state.data.map((res: any, index: any) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            page: res?.page_url?.split('_')?.join(' '),
            description: <span className='text-wrap unstyle' dangerouslySetInnerHTML={{ __html: res?.description.slice(0,100) }}></span>,
            createdon: dayjs(res.createdon).format('DD/MM/YYYY'),
            action: <Link href={`/content/${res._id}/view`}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })

    const TableData = () => <Row gutter={[20, 20]} >

    </Row>

    const items: TabsProps['items'] = [
        {
            key: '',
            label: 'All',
            children: <TableData />,
        },
        {
            key: '1',
            label: 'Active',
            children: <TableData />,
        },
        {
            key: '2',
            label: 'De-Activated',
            children: <TableData />,
        },
        {
            key: '3',
            label: 'Blocked',
            children: <TableData />,
        }
    ];

    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Content.listing(urlSearchParam.toString(),10)
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search, router.query.type])


    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                // let data = await uploadCSV(info.file.originFileObj);
                // console.log('data', data);
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }

    return (
        <Fragment>
            <Head>
                <title>Pages</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Pages</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row  gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Pages</Typography.Title>
                                <div className='d-flex gap-2'>
                                    {/* <Link href={`/content/add`}><Button type="primary" htmlType="button" size='large' icon={<PlusOutlined />}>Add Page</Button></Link> */}

                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>

                                </div>
                            </div>
                            <Row gutter={[15, 15]} className='my-4'>
                                {/* Search  */}
                                <Col span={24}>
                                    <SearchPage  placeholder="Search..."  />
                                </Col>
                                {/* Pagination  */}
                                <Col span={24} >
                                    <Table dataSource={dataSource} columns={ColumnsType.pagesColumns} pagination={false} scroll={{ x: '100%' }} />
                                </Col>
                            </Row>
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.User.export(start_date, end_date)
                        downloadCSV("user", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Content.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Content
