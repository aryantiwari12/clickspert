import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { message, Upload, Breadcrumb, Form, Input, Typography, Modal } from 'antd';
import banner from "@/assets/images/banner.png"
import placeholder from "@/assets/images/placeholder.png"
import dynamic from "next/dynamic";
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons'
import type { UploadFile } from 'antd/es/upload/interface';
import type { RcFile, UploadProps } from 'antd/es/upload';
import type { UploadChangeParam } from 'antd/es/upload';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import { ContentDetailInterface } from '@/interfaces';


const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Image, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}

const props: UploadProps = {
    name: 'file',
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    headers: {
        authorization: 'authorization-text',
    },
    onChange(info) {
        if (info.file.status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
            message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
};

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const EditTermsConditions: Page = (props: any) => {
    const [form] = Form.useForm();
    const router = useRouter();
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [state, setState] = React.useState({} as ContentDetailInterface)
    const [description, setDesciption] = useState<string>("");
    const [previewImage, setPreviewImage] = useState<any>('');
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState<UploadFile[]>([]);

    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );

    const initialise = async () => {
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Content.getByID(String(router.query._id))
            console.log("Content listing get", apiRes);
            setState(apiRes)
            if (apiRes?.image) {
                setFileList([
                    {
                        uid: '-1',
                        name: 'image.png',
                        status: 'done',
                        url: henceforthApi.FILES.imageOriginal(apiRes.image, ""),
                    }
                ])
            }

            form.setFieldsValue(apiRes)
            form.setFieldValue("image", apiRes?.image)
            // form.setFieldValue("description", apiRes?.description)
            setDesciption(apiRes?.description)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    const handleCancel = () => setPreviewOpen(false);
    console.log(description, "vlaue");

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file?.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file?.url!.substring(file?.url!.lastIndexOf('/') + 1));
    };

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handleImage: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
        console.log(info?.fileList);
        setFileList(info?.fileList)
    };
    console.log(fileList, "filelist");
    const onchange = (content: any, delta: any, source: any, editor: any) => {
        // const text=editor?.getText(content)
        // console.log(text);

        setDesciption(content)
    }

    const updateData = async (values: any) => {
        setLoading(true)
console.log(values,"valuesssssssssssssssssssss");

        try {
            const { title, page_url } = values
            if (!title) {
                return Toast.warn("Title should not be empty")
            }
            if (!page_url) {
                return Toast.warn("Page URL should not be empty")
            }
            if (description.trim() == "") {
                return Toast.warn("Please Enter description")
            }
            // return

            let items = {
                ...values,
                title: title?.trim(),
                page_url: page_url?.trim(),
                description: description,
                image: fileList?.length ? state?.image : null,
            }
            if (values?.image?.file?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', values.image.file.originFileObj)
                items['image'] = apiImageRes?.file_name
            }
            // if (items) {
            setLoading(true)
            let apiRes = await henceforthApi.Content.edit(String(router.query._id), items)
            setState(apiRes)
            Toast.success(apiRes.message)

            router.back()
            // }
        } catch (error) {
            Toast.error(error)

        } finally {

            setLoading(false)
        }

    };

    const onFinish = async (values: any) => {
        debugger
        console.log('Received values of form ', values);
        // return
        await updateData(values)
    };

    useEffect(() => {
        initialise()
    }, [])

    return (
        <Fragment>
            <Head>
                <title>Edit About Us</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <section className='terms-conditions-wrapper'>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item className='text-decoration-none'>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item ><Link href="/content/page/1" className='text-decoration-none'>Pages</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Edit</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='m-0 mb-4 fw-bold'>{state?.title?.split('_')?.join(" ")}</Typography.Title>
                            </div>
                            {/* form  */}
                            <div className="terms-conditions-wrapper-form">
                                <Form form={form}
                                    name="basic"
                                    size='large'
                                    initialValues={{ remember: true }}
                                    onFinish={onFinish}
                                    onFinishFailed={onFinishFailed}
                                    autoComplete="off"
                                    layout='vertical'>
                                    {/* Upload Image  */}
                                    <Form.Item name="image" >
                                        <Upload
                                            supportServerRender={false}
                                            withCredentials={false}
                                            className='w-100'
                                            listType="picture-card"
                                            fileList={fileList}
                                            onPreview={handlePreview}
                                            onChange={handleImage}
                                            multiple={false}
                                            maxCount={1}>
                                            {fileList.length >= 1 ? null : uploadButton}
                                        </Upload>
                                    </Form.Item>
                                    <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                        <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                    </Modal>
                                    <Typography.Text><b className='me-1'>Note:</b> <span>Please upload .jpg or .png file</span></Typography.Text>
                                    <Form.Item name="title" rules={[{ required: true, whitespace: true, message: 'Please Enter Your Title' }]} label="Title">
                                        <Input placeholder="Enter title here" disabled={true} className='bg-transparent' />
                                    </Form.Item>
                                    <Form.Item name="page_url" rules={[{ required: true, whitespace: true, message: 'Please Enter Page Url' }]} label="Page URL" >
                                        <Input placeholder="Add URL" disabled={true} className='bg-transparent' prefix={'pages /'} />
                                    </Form.Item>
                                    {/* Description  */}
                                    <Form.Item name="description" rules={[() => ({
                                        validator(_, value) {
                                            const remove_space = value.replace(/\s/g, "")
                                            console.log(value);

                                            if (value) {
                                                if (value === '<p><br></p>' || remove_space === '<p></p>') return Toast.warn('Please enter answer')
                                            }
                                            return Promise.resolve();
                                        },
                                    })]} label="Description">
                                        <div className='p-2'>
                                            <ReactQuill theme="snow" value={description} onChange={onchange} placeholder="Write description here..." />
                                        </div>
                                    </Form.Item>
                                    {form.getFieldValue("page_url") == "ABOUT_US" && <div>
                                        <Form.Item name="mission" rules={[() => ({
                                            validator(_, value) {
                                                const remove_space = value.replace(/\s/g, "")
                                                console.log(value);

                                                if (value) {
                                                    if (value === '<p><br></p>' || remove_space === '<p></p>') return Toast.warn('Please enter mission')
                                                }
                                                return Promise.resolve();
                                            },
                                        })]} label="Mission">
                                                <ReactQuill theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item name="vision" rules={[() => ({
                                            validator(_, value) {
                                                const remove_space = value.replace(/\s/g, "")
                                                console.log(value);

                                                if (value) {
                                                    if (value === '<p><br></p>' || remove_space === '<p></p>') return Toast.warn('Please enter vision')
                                                }
                                                return Promise.resolve();
                                            },
                                        })]} label="Vision">
                                            <ReactQuill theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                        <Form.Item name="value" rules={[() => ({

                                            validator(_, value) {
                                                const remove_space = value.replace(/\s/g, "")
                                                console.log(value);

                                                if (value) {
                                                    if (value === '<p><br></p>' || remove_space === '<p></p>') return Toast.warn('Please enter value')
                                                }
                                                return Promise.resolve();
                                            },
                                        })]} label="Value">
                                            <ReactQuill theme="snow" placeholder="Write description here..." />
                                        </Form.Item>
                                    </div>}
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit" loading={loading} >
                                        Save Changes
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}

EditTermsConditions.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default EditTermsConditions
