import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Image, Popconfirm, Typography, } from 'antd';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';
import banner from "@/assets/images/banner.png"
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import { ContentDetailInterface } from '@/interfaces';
import user from "@/assets/images/placeholder.png"

const { Row, Col, Card, Button, Space, } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Space: dynamic(() => import("antd").then(module => module.Space), { ssr: false })
}

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ContentDetailsPage: Page = (props: any) => {
    const router = useRouter()
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [state,setState] = React.useState( {}as ContentDetailInterface)

    const handleDelete = async () => {
        try {
            let id = String(router.query._id)
            setLoading(true)
            let apiRes = await henceforthApi.Content.delete(id)
            Toast.success(apiRes.message)
                router.back()
        } catch (error) {
            console.log(error)
            setLoading(false)
        }
    }
    const initialise=async()=>{
        try {
            let apiRes = await henceforthApi.Content.getByID(router.query._id as string)  
            setState(apiRes)
        } catch (error) {
            console.log(error);
            
        }
    }
 console.log(state,"state");
 

    useEffect(()=>{
        initialise()
    },[])
    return (
        <Fragment>
            <Head>
                <title>{state?.title}</title>
                <meta name="description" content="About us" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4 flex-center'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item ><Link href="/content/page/1" className='text-decoration-none'>Pages</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>{state?.title?.split('_')?.join(' ')}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center mb-4'>
                                <Typography.Title level={3} className='m-0 fw-bold'>{state?.title?.split('_')?.join(' ') || "N/A"}</Typography.Title>
                                <Space>
                                    <Link href={`/content/${router.query._id}/edit`} className='text-decoration-none'>
                                        <Button type="primary" size='large' htmlType="button">Edit page</Button>
                                    </Link>
                                    {/* <Popconfirm
                                        title="Delete"
                                        description="Are you sure to Delete page"
                                        onConfirm={handleDelete}
                                        okText="Yes"
                                        cancelText="No">
                                        <Button type="primary" danger size='large' htmlType="button" loading={loading} ><span className='text-white'>Delete page</span></Button>
                                    </Popconfirm> */}
                                </Space>
                            </div>
                            {/* content  */}
                            <div className='terms-conditions-wrapper'>
                            {/* {state?.image &&  */}
                                <div className="terms-conditions-wrapper-image mb-4">
                                    {/* image  */}
                                   <img width="100%" height={350} src={henceforthApi.FILES.imageOriginal(state?.image, user.src) } />
                                </div>
                                {/* } */}
                                {/* listing  */}
                                <div className="terms-conditions-wrapper-content"
                                // dangerouslySetInnerHTML={{ __html: state?.description }}
                                >
                                    {/* {state.description } */}
                                    <Typography.Title level={4} className='m-0 mb-2 fw-bold'>{state?.title?.split('_')?.join(' ') || "N/A"}</Typography.Title>
                                    <Typography.Paragraph className='m-0 mb-2 fw-400'><span dangerouslySetInnerHTML={{ __html: state?.description }}></span></Typography.Paragraph>
                                </div>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

ContentDetailsPage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
// export const getServerSideProps: GetServerSideProps = async (context) => {
//     try {

//         let apiRes = await henceforthApi.Content.getByID(context.query._id as string)
//         let data = apiRes
//         return { props: { data } };
//     } catch (error) {
//         return { props: { data: {} } };
//     }
// }
export default ContentDetailsPage