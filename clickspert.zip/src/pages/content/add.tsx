import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { message, Upload, Breadcrumb, Form, Input, Typography, Modal, Spin } from 'antd';
import banner from "@/assets/images/banner.png"
import dynamic from "next/dynamic";
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons'
import type { UploadFile } from 'antd/es/upload/interface';
import { GlobalContext } from '@/context/Provider';
import henceofrthEnums from '@/utils/henceofrthEnums';
import henceforthApi from '@/utils/henceforthApi';
import type { UploadChangeParam } from 'antd/es/upload';
import type { RcFile, UploadProps } from 'antd/es/upload';
import Banner from "@/assets/images/banner.png"
import { useForm } from 'antd/es/form/Form';
import { useRouter } from 'next/router';
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Image, Dropdown, Pagination, Badge, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
    Dropdown: dynamic(() => import("antd").then(module => module.Dropdown), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Badge: dynamic(() => import("antd").then(module => module.Badge), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),

}

const props: UploadProps = {
    name: 'file',
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    headers: {
        authorization: 'authorization-text',
    },
    onChange(info) {
        if (info.file.status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
            message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
};


type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const AddTermsConditions: Page = (props: any) => {
    console.log('props', props);
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [form] = Form.useForm()
    const router = useRouter();

    const [previewImage, setPreviewImage] = useState<any>('');
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [value, setValue] = useState('');
    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };

    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>
    );

    const handleCancel = () => setPreviewOpen(false);

    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handleImage: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
        console.log(info?.fileList);
        setFileList(info?.fileList)
    };

    const updateData = async (values: any) => {
        setLoading(true)
        try {
            let title = String(values.title).trim()
            let page_url = String(values.page_url).trim()
            if (!title) {
                return Toast.warn("Title should not be empty")
            }
            if (!page_url) {
                return Toast.warn("Page URL should not be empty")
            }
            let items = {
                title,
                page_url,
                description: values.description
            } as any
            if (values?.image?.file?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', values.image.file.originFileObj)
                console.log("file image", apiImageRes);
                items['image'] = apiImageRes?.file_name
            }
            console.log('Received items content add ', items);
            let apiRes = await henceforthApi.Content.create(items)
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading(false)
        }
        
    };

    const onFinish = async (values: any) => {
        console.log('Received values of form ', values);
        await updateData(values)
    };

    return (
        <Fragment>
            <Head>
                <title>Add Content</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <section className='terms-conditions-wrapper notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item ><Link href="/content/page/1" className='text-decoration-none'>Pages</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Add Pages</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div>
                                <Typography.Title level={3} className='m-0 mb-4 fw-bold'>Add Content</Typography.Title>
                            </div>
                            {/* form  */}
                            <div className="terms-conditions-wrapper-form">
                                <Form form={form}
                                    name="basic"
                                    initialValues={{ remember: true }}
                                    onFinish={onFinish}
                                    onFinishFailed={onFinishFailed}
                                    autoComplete="off"
                                    size='large'
                                    layout='vertical'>
                                    {/* Upload Image  */}
                                    <Form.Item label={'images'} name="image">
                                        <Upload
                                            className='w-100'
                                            listType="picture-card"
                                            fileList={fileList}
                                            onPreview={handlePreview}
                                            onChange={handleImage}
                                        >
                                            {fileList.length >= 1 ? null : uploadButton}
                                        </Upload>
                                    </Form.Item>
                                    <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                        <img alt="example" style={{ width: '100%' }} src={previewImage} />

                                        {/* <img alt="example" style={{ width: '100%' }} src={henceforthApi.FILES.imageOriginal(previewImage, Banner.src)} /> */}
                                    </Modal>
                                    {/* Upload Image  */}
                                    {/* <Form.Item name="text" rules={[{ required: true, message: 'Please input!' }]} hasFeedback label="Upload Image">
                                            <Upload {...props}>
                                                <Button type='primary' htmlType='button' size={'large'}>Upload Image</Button>
                                            </Upload>
                                        </Form.Item> */}
                                    {/* Title  */}
                                    <Form.Item name="page_url" rules={[{ required: true, whitespace: true, message: 'Please Enter Page Url' }]} label="Page Url" >
                                        <Input placeholder="Page Url" className='' />
                                    </Form.Item>
                                    <Form.Item name="title" rules={[{ required: true, whitespace: true, message: 'Please Enter Page Title' }]} label="Page Title" >
                                        <Input placeholder="Page Title" className='' />
                                    </Form.Item>
                                    {/* Description  */}
                                    <Form.Item name="description" rules={[{ required: true, message: 'Please Enter Description' }]} hasFeedback label="Description">
                                        <ReactQuill theme="snow"  value={value} placeholder="Write description here..." />
                                    </Form.Item>
                                    {/* Button  */}
                                    <Button type="primary" htmlType="submit"  loading={loading} disabled={loading}>
                                    Add Page
                                    </Button>
                                </Form>
                            </div>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}

AddTermsConditions.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default AddTermsConditions
