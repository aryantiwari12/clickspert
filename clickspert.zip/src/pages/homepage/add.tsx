import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { message, Upload, Breadcrumb, Form, Typography, Modal, Radio, RadioChangeEvent, Select, Space } from 'antd';
import type { UploadChangeParam } from 'antd/es/upload';
import dynamic from 'next/dynamic';
import type { UploadFile } from 'antd/es/upload/interface';
import { useRouter } from 'next/router';
import type { RcFile, UploadProps } from 'antd/es/upload';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import HenceforthIcons from '@/components/HenceforthIcons';
import { Label } from 'recharts';
const { Title } = Typography;
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Image } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
const AddHomePage: Page = (props: any) => {
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const router = useRouter();
    const [previewImage, setPreviewImage] = useState<any>('');
    const [previewOpen, setPreviewOpen] = useState(false);
    const [previewTitle, setPreviewTitle] = useState('');
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [value, setValue] = useState(Number(router.query.banner_type));
    const [promo, setPromo] = useState({
        data: []
    })
    const [service, setService] = useState({
        data: [],
    })
    const [form] = Form.useForm()
    const [subService, setSub_service] = useState({
        sub_services: []
    } as any)
    const onFinishFailed = (errorInfo: any) => {
        console.log('Failed:', errorInfo);
    };
    const handleCancel = () => setPreviewOpen(false);
    console.log(router, "router");
    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
        setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };

    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handleImage: UploadProps['onChange'] = (info: UploadChangeParam<UploadFile>) => {
        console.log(info?.fileList);
        setFileList(info?.fileList)
    };

    const updateData = async (values: any) => {
        console.log(values, "valuess");
        // return
        try {
            debugger
            setLoading(true)
            if (!fileList[0]?.originFileObj) {
                return Toast.warn("Please Add Image")
            }
            let items = {
                banner_type: '',
                descritpion: values.descritpion
            } as any
            if (fileList[0]?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0].originFileObj)
                console.log("file image", apiImageRes);
                items['image'] = apiImageRes?.file_name
            }
            if (router.query.banner_type == "1") {
                items['banner_type'] = "null"
            }
            if (router.query.banner_type == "2") {
                items['banner_type'] = "SERVICE"
            }
            if (router.query.banner_type == "3") {
                items['banner_type'] = "PROMOCODE"
            }
            if (router.query.service_id) {
                items['service_id'] = router.query.service_id
            }
            if (router.query.sub_service_id) {
                items['sub_service_id'] = router.query.sub_service_id
            }
            if (router.query.promo_code_id) {
                items[`promo_code_id`] = router.query.promo_code_id
            }

            let apiRes = await henceforthApi.Homepage.create(items)
            Toast.success(apiRes.message ?? "Banner Add successfully")
            router.push(`/homepage/page/1`)
        } catch (error) {
            Toast.error(error)
        }
        finally {
            setLoading(false)
            form.resetFields()
        }
    };
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }

    const handleSelect = (_id: any) => {
        try {
            let sub_service = service?.data.find((res: any) => res._id == _id)
            setSub_service(sub_service)
            // handleChange(null, _id)
            if (_id) {
                router.push({ pathname: "/homepage/add", query: { banner_type: 2, service_id: _id } }, undefined, { shallow: true })
            }
            else {
                router.push({ pathname: "/homepage/add", query: { banner_type: 2 } }, undefined, { shallow: true })
            }
        } catch (error) {
            Toast.error(error)
        }
    }
    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/homepage/add`, query: { banner_type: 2, service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/homepage/add`, query: { ...router.query, service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }
    const onFinish = async (values: any) => {
        console.log('Received values of form ', values);
        await updateData(values)
    };
    const onChange = (e: RadioChangeEvent) => {
        console.log('radio checked', e.target.value);
        router.push({ pathname: `/homepage/add`, query: { banner_type: e.target.value } }, undefined, { shallow: true })
        setValue(e.target.value)
        console.log(value, "banne");

    };
    const onSelecetPromo = (_id: any) => {
        router.push({ pathname: "/homepage/add", query: { banner_type: 3, promo_code_id: _id } })
    }
    const promocode = async () => {
        try {
            let apiRes = await henceforthApi.Homepage.promocode()
            setPromo(apiRes)
        } catch (error) {
            console.log(error);
        }
    }
    React.useEffect(() => {
        promocode()
    }, [])
    React.useEffect(() => {
        serviceInitialse()
    }, [])
    return (
        <Fragment>
            <Head>
                <title>Home Page</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <section>

                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item>Home Page</Breadcrumb.Item>
                                    <Breadcrumb.Item className=''>Add banner</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            <Title level={3}>Add Banner</Title>
                            <div className='terms-conditions-wrapper'>
                                <div className="terms-conditions-wrapper-content">
                                    <div className="terms-conditions-wrapper-form">
                                        <Form
                                            name="basic"
                                            initialValues={{ remember: true }}
                                            onFinish={onFinish}
                                            onFinishFailed={onFinishFailed}
                                            autoComplete="off"
                                            size='large'
                                            layout='vertical'>
                                            {/* Upload Image  */}
                                            <Form.Item name="image" label={'Images'}>
                                                <Upload
                                                    className='w-100 position-relative'
                                                    listType="picture-card"
                                                    fileList={fileList}
                                                    onPreview={handlePreview}
                                                    onChange={handleImage}
                                                >
                                                    {fileList.length == 1 ? null :
                                                        <div className='position-absolute d-flex justify-content-around w-100'>
                                                            <div>
                                                                <Button type='primary'> <HenceforthIcons.PluseIcon /> Uplode File</Button>
                                                                <p className='text-muted mb-0 mt-2'>Or drop image in box</p>
                                                            </div>
                                                            <div className=''>
                                                                <p>Supported formats:</p>
                                                                <Space>
                                                                    <Button className='bg-transparent border'>jpg</Button>
                                                                    <Button className='bg-transparent border'>png</Button>
                                                                </Space>
                                                            </div>
                                                        </div>}
                                                </Upload>
                                                <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                                                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                                </Modal>

                                                {/* <Typography.Text><b className='me-1'>Note:</b> <span>Please upload .jpg or .png file</span></Typography.Text> */}
                                            </Form.Item>
                                            <Radio.Group onChange={onChange} value={value}>
                                                <Radio value={1}>Null</Radio>
                                                <Radio value={2}>Service</Radio>
                                                <Radio value={3}>Promo Code</Radio>
                                            </Radio.Group>
                                            {router.query.banner_type == '1' ? '' :
                                                <>
                                                    {router.query.banner_type == '2' &&
                                                        <>
                                                            <div className='p-1'>
                                                                <Form.Item name="service_id" label='Service' rules={[{ required: true, message: 'Please Select Service' }]}>
                                                                    <Select
                                                                        showSearch
                                                                        size='large'
                                                                        className='w-100'
                                                                        placeholder="Select service"
                                                                        optionFilterProp="children"
                                                                        allowClear
                                                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                                                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                                                        filterSort={(optionA, optionB) =>
                                                                            (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                                                        }
                                                                        onChange={handleSelect}
                                                                        options={service?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}

                                                                    />
                                                                </Form.Item>
                                                            </div>
                                                            <div>
                                                                <Form.Item name="sub_service_id" label='Sub Service' rules={[{ required: true, message: 'Please Select Sub Service' }]}>
                                                                    <Select
                                                                        size='large'
                                                                        disabled={!router.query.service_id}
                                                                        showSearch
                                                                        className='w-100 bg-transparent'
                                                                        placeholder="Select sub service"
                                                                        optionFilterProp="children"
                                                                        allowClear
                                                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                                                        onChange={(e: any) => handleChange(e, String(router.query.service_id))}
                                                                        options={subService?.sub_services?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                                                                    />
                                                                </Form.Item>
                                                            </div>
                                                        </>}
                                                    {router.query.banner_type == '2' ? `` :
                                                        <>
                                                            <Form.Item name="gender" label="Promo Code" rules={[{ required: true }]}>
                                                                <Select
                                                                    placeholder="Select Promo Code"
                                                                    onChange={onSelecetPromo}
                                                                    allowClear
                                                                    options={promo?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}
                                                                >
                                                                </Select>
                                                            </Form.Item>
                                                        </>}
                                                </>}

                                            {/* Description  */}
                                            <Form.Item className='my-2' name="descritpion" rules={[{}, () => ({
                                                validator(_, value) {
                                                    // const remove_space = value.replace(/\s/g, "")
                                                    console.log(value);

                                                    if (value) {
                                                        if (value === '<p><br></p>') return Toast.warn('Please enter description')
                                                    }
                                                    return Promise.resolve();

                                                },
                                            })]} hasFeedback label="Banner Text" >
                                                <ReactQuill theme="snow" placeholder="Write description here..." />
                                            </Form.Item>
                                            {/* Button  */}
                                            <Button type="primary" htmlType="submit" loading={loading} disabled={loading} className='mt-4'>
                                                Add Banner
                                            </Button>
                                        </Form>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    </Col>
                </Row>
            </section>
        </Fragment>
    )
}
AddHomePage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}


export default AddHomePage
