import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Input, Breadcrumb, Select, Table, Card, Typography, Upload, Space, Avatar, Switch, Modal, Form, Popconfirm, UploadFile } from 'antd';
import Link from 'next/link';
import React from 'react';
import { PlusOutlined, DeleteOutlined, UploadOutlined, AppstoreOutlined, MenuOutlined } from '@ant-design/icons';
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import { HomePageDetailsInterface, ProductInfoInterface } from '@/interfaces';
import { SelectType } from '@/interfaces/AntType';
import HenceforthIcons from '@/components/HenceforthIcons';
import Cardimg from '../../../assets/images/banner.png'
import Image from 'next/image';
import { RcFile, UploadProps } from 'antd/es/upload';
import { Dayjs } from 'dayjs';
import { ChatContext } from '@/context/chatProvider';
const { Row, Col, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Meta } = Card;
const { Search } = Input;

let timer: any
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};


type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Homepage: Page = (props: any) => {
    const {socketHitType} =React.useContext(ChatContext)
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { Toast, downloadCSV, uploadCSV } = React.useContext(GlobalContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [introduction, setIntroduction] = useState({
        data: [],
        count: 0
    })
    const [previewImage, setPreviewImage] = useState<any>('');
    const [previewOpen, setPreviewOpen] = useState(false);
    const [form] = Form.useForm()
    const [loading, setLoading] = React.useState(false)
    const [state, setState] = React.useState({
        data: [] as HomePageDetailsInterface[],
        count: 0
    })
    const [service, setService] = useState({
        data: [],
    })
    const [id, setId] = useState('')
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }
    const handleChange = (value: any) => {
        console.log("handleChange called", value);
        onChangeRouter("category_id", value)
    }
    const handlePreview = async (file: UploadFile) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj as RcFile);
        }
        setPreviewImage(file.url || (file.preview as string));
        setPreviewOpen(true);
    };
    const getBase64 = (file: RcFile): Promise<string> =>
        new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = (error) => reject(error);
        });

    const handleImage: UploadProps['onChange'] = async ({ fileList: newFileList }) => {
        setFileList(newFileList);
        console.log('newFileList', newFileList);
    }
    const onchangeDelete = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Homepage.delete(_id)
            Toast.success(apiRes.message ?? "Banner Deleted successfully")
            initialize()
        } catch (error) {

        }
    }
    const initialize = async () => {
        setLoading(true)
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.category_id) {
                urlSearchParam.set('category_id', router.query.category_id as string)
            }
            let resApi = await henceforthApi.Homepage.listing(urlSearchParam.toString())
            console.log("resapi", resApi.data);
            setState(resApi)

        } catch (error) {
            console.log(error)
        }
        finally {
            setLoading(false)
        }
    }
    React.useEffect(() => {
        initialize()
    }, [router.query.limit, router.query.pagination, socketHitType, router.query?.search, router.query?.category_id])
    const dataSource2 = introduction.data.map((res: any, index: number) => {
        return {
            screen: `Screen ${index + 1}`,
            image: <div className='introduction-img'>
                <img src={henceforthApi.FILES.imageSmall(res.image)} alt='img' />
            </div>,
            title: res?.heading || 'N/A',
            description: <div className='text-wrap' title={res?.descritpion}>
                {res?.descritpion?.length > 30 ? res?.descritpion?.slice(0,30) + "..." : res?.descritpion  || 'N/A'}
            </div>,
            action: <div>
                <Button shape='circle' className='border-0 px-0' onClick={() => {
                    introductiongetById(res._id); setTimeout(() => {
                        setIsModalOpen(true)
                    }, 1000);
                }}><HenceforthIcons.PencileIcon /></Button>
                {/* <Space role='button'>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure to delete Introduction"
                        onConfirm={() => onDeleteIntro(res._id)}
                        okText="Yes"
                        cancelText="No">
                        <Button className='border-0' >
                            <DeleteOutlined />
                        </Button>
                    </Popconfirm>
                </Space> */}
            </div>
        }
    })

    const columns = [
        {
            title: 'Screen',
            dataIndex: 'screen',
            width: 150
        },
        {
            title: 'Image',
            dataIndex: 'image',
            width: 100
        },
        {
            title: 'Title',
            dataIndex: 'title',
            width: 200
        },
        {
            title: 'Description',
            dataIndex: 'description',
            width: 500
        },
        {
            title: 'Action',
            dataIndex: 'action',
            width: 100
        },
    ];
    const isEnableManage = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Homepage.isEnable(_id, '')
            Toast.success(apiRes.message)
            serviceInitialse()
        } catch (error) {
            Toast.error(error)
        }
    }

    const columns2 = [
        {
            title: 'Sr no.',
            dataIndex: 'srno',
            render: (_: any, data: any, index: number) => index + 1,
            width: 100
        },
        {
            title: 'Sub Service',
            dataIndex: 'name',
            render: (_: any, data: any, index: number) => { return <span title={data?.name}>{data?.name?.length > 20 ? data?.name?.slice(0, 20) + "..." : data?.name}</span> },
            width: 150
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (_: any, data: any, index: number) => <Switch onChange={() => isEnableManage(data._id)} defaultChecked={data.is_homepage_service} />,
            width: 50
        },
    ];
    const { TextArea } = Input;
    const onDelete = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Homepage.delete(_id)
            Toast.success(apiRes.message ?? "Banner Deleted successfully")
            initialize()
        } catch (error) {
            Toast.error(error)
        }
    }
    const onDeleteIntro = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Homepage.delIntr(_id)
            Toast.success(apiRes.message)
            introductionInitialse()
        } catch (error) {
            console.log(error);

        }
    }
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div style={{ marginTop: 8 }}>Upload</div>
        </div>)
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
            console.log(apiRes ,"servicccc");
            
        } catch (error) {
            Toast.error(error)
        }
    }
    const handleCancel = () => setPreviewOpen(false);
    const introductionInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Homepage.introduction()
            setIntroduction(apiRes)
        } catch (error) {
            console.log(error);
        }
    }
    const introductiongetById = async (_id: any) => {
        setId(_id)
        try {
            let apiRes = await henceforthApi.Homepage.introductionId(_id)
            setFileList([
                {
                    uid: '-1',
                    name: 'image.png',
                    status: 'done',
                    url: henceforthApi.FILES.imageOriginal(apiRes.image, ''),
                }
            ])
            form.setFieldsValue(apiRes)
            form.setFieldValue('heading', apiRes.heading)
            form.setFieldValue('descritpion', apiRes.descritpion)
        } catch (error) {

        }
    }
    const onFinish = async (values: any) => {
        if (!fileList?.length) {
            return  Toast.warn("Please select image")
        }
        try {
            setLoading(true)
            const items = {
                _id: id,
                heading: values.heading,
                descritpion: values.descritpion
            } as any
            if (fileList[0]?.originFileObj) {
                let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0].originFileObj)
                console.log("file image", apiImageRes);
                items['image'] = apiImageRes?.file_name
            }
            let apiRes = await henceforthApi.Homepage.EditInt(items)
            Toast.success(apiRes.message)
            introductionInitialse()
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading(false)
            setIsModalOpen(false)
        }
    }


    useEffect(() => {
        introductionInitialse()
    }, [])
    useEffect(() => {
        serviceInitialse()
    }, [socketHitType])
    return (
        <Fragment>
            <Head>
                <title>Admin</title>
                <meta name="description" content="Product" />
            </Head>
            <section className='notification'>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>General</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Home Page</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            <div className='product-page'>
                                <div className='mb-4'>
                                    <Typography.Title level={3} className='m-0 fw-700'>Introduction</Typography.Title>
                                </div>
                                <div>
                                    <Table pagination={false} dataSource={dataSource2} columns={columns} />
                                </div>
                            </div>
                        </Card >
                    </Col>

                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='product-cards product-page mb-3'>
                                <div className='flex-center mb-3 '>
                                    <Typography.Title level={3} className='m-0 fw-700'>Home Page</Typography.Title>
                                    <div className='d-flex gap-3 flex-nowrap align-items-center overflow-auto'>
                                        <Button type="primary" icon={<PlusOutlined />} size={'large'} onClick={() => router.push(`/homepage/add?banner_type=1`)}>Add Banner</Button>
                                        <Space>
                                            <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                        </Space>
                                    </div>
                                </div >
                                <Row gutter={[20, 20]}>
                                    {state?.data.map((res: any, index: number) => {
                                        return (
                                            <>
                                                <Col span={24} lg={12}>
                                                    <div className='flex-colum p-4 custom-card'>
                                                        <div className='flex-center mb-3'>
                                                            <Typography.Title level={5} className='m-0 fw-bold'>Banner {index + 1}</Typography.Title>
                                                            <div className=''>
                                                                <Link href={`/homepage/${res._id}/edit?banner_type=${res.banner_type.toLowerCase()}`}>
                                                                    <HenceforthIcons.PencileIcon />
                                                                </Link>
                                                                <Popconfirm
                                                                    title="Delete"
                                                                    description="Are you sure to delete Banner"
                                                                    onConfirm={() => onDelete(res._id)}
                                                                    okText="Yes"
                                                                    cancelText="No">
                                                                    <Button className='border-0' >
                                                                        <DeleteOutlined />
                                                                    </Button>
                                                                </Popconfirm>
                                                            </div>
                                                        </div>
                                                        <div className="custom-card-img">
                                                            <img alt='img' src={henceforthApi.FILES.imageSmall(res.image)} />
                                                            <div>
                                                                <div className="custom-card-content">
                                                                    {/* {res.banner_type == "null" ? '' :
                                                                        <>
                                                                            <Typography.Title level={4} className='fw-bold text-white'>20% Off</Typography.Title>
                                                                            <p>Today’s Special!</p>
                                                                        </>} */}
                                                                    <span dangerouslySetInnerHTML={{ __html: res.descritpion }}></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </Col>
                                            </>
                                        )
                                    })}
                                </Row>
                            </div>
                        </Card>
                    </Col>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-3 mb-lg-0 product-page'>
                                <div className='flex-center mb-3'>
                                    <Typography.Title level={3} className='fw-700 m-0'>Services</Typography.Title>
                                    {/* <Button onClick={() => setIsModalOpen('Services')} type='primary' icon={<PlusOutlined />}>Add</Button> */}
                                </div>
                                <Row gutter={[20, 20]}>
                                    {service?.data.map((res: any, index: number) => {
                                        return (
                                            <>
                                                <Col span={24} lg={12}>
                                                    <div className="custom-card p-3">
                                                        <div className='flex-center mb-3'>
                                                            <Typography.Title level={4} className='fw-700 m-0'>{res.name || 'N/A'}</Typography.Title>
                                                        </div>
                                                        <Table pagination={false} dataSource={res.sub_services} columns={columns2} />
                                                    </div>
                                                </Col>
                                            </>
                                        )
                                    })}

                                </Row>
                            </div >
                        </Card >
                    </Col >
                </Row >

                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Products.export(start_date, end_date)
                        downloadCSV("Product", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

                <Modal className='notification' centered={true} title={"Edit Introduction"} open={!!isModalOpen} onCancel={() => setIsModalOpen(false)} footer={false}>
                    <Form size='large' onFinish={onFinish} form={form} layout='vertical' className='mt-3' >
                        <Form.Item name="image" className='text-center  introduction-image'>
                            <Upload
                                className='w-100'
                                listType="picture-card"
                                fileList={fileList}
                                supportServerRender={false}
                                onPreview={handlePreview}
                                onChange={handleImage}
                            >
                                {fileList.length >= 1 ? null : uploadButton}
                                {/* <Image className='object-fit-cover w-100 h-100' src={state?.image ? `${henceforthApi.API_FILE_ROOT_SMALL}${state.image}` : ""} alt="avatar" /> */}
                                {/* {fileList.length >= 1 ? <img className='object-fit-cover w-100 h-100' src={state?.image ? `${henceforthApi.API_FILE_ROOT_SMALL}${state.image}` : ""} alt="avatar" /> : uploadButton} */}
                            </Upload>
                            <Modal open={previewOpen} footer={null} onCancel={handleCancel}>
                                <div className="introduction-img">
                                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                                </div>
                            </Modal>
                        </Form.Item>
                        <Form.Item name='heading' rules={[{ required: true, message: "Please enter title" }]} label="Title" >
                            <Input placeholder='Enter Title (maximum 30 words)' />
                        </Form.Item>
                        <Form.Item name="descritpion" rules={[{ required: true, message: "Please enter description" }]} label='Description'>

                            <TextArea rows={4} placeholder='Enter Description (maximum 150 words)' />
                        </Form.Item>
                        <Button type='primary' htmlType='submit' loading={loading} className='mt-3' block>Save</Button>
                    </Form>
                </Modal>
                {/* <HomepageModal isModalOpen={isModalOpen} setIsModalOpen={setIsModalOpen} /> */}

            </section >
        </Fragment >
    )
}

Homepage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {

    return { props: { params: 'all' } };
}


export default Homepage
