import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { message, Upload, Breadcrumb, Form, Typography, Input, Modal } from 'antd';
import banner from "@/assets/images/banner.png"
import type { UploadChangeParam } from 'antd/es/upload';
import dynamic from 'next/dynamic';
import { PlusOutlined } from '@ant-design/icons'
import type { UploadFile } from 'antd/es/upload/interface';
import Link from 'next/link';
import { useRouter } from 'next/router';
import type { RcFile, UploadProps } from 'antd/es/upload';
import { GlobalContext } from '@/context/Provider';
import henceforthApi from '@/utils/henceforthApi';
import { HomePageDetailsInterface } from '@/interfaces';
const ReactQuill = dynamic(import('react-quill'), { ssr: false })
const { Row, Col, Card, Button, Image } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Image: dynamic(() => import("antd").then(module => module.Image), { ssr: false }),
}

const props: UploadProps = {
    name: 'file',
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    headers: {
        authorization: 'authorization-text',
    },
    onChange(info) {
        if (info.file.status !== 'uploading') {
            console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
            message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
            message.error(`${info.file.name} file upload failed.`);
        }
    },
};

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

const ViewHomePage: Page = (props: any) => {
    const { Toast, loading, setLoading } = React.useContext(GlobalContext)
    const [form] = Form.useForm()
    const router = useRouter();
    const [state, setState] = React.useState({} as HomePageDetailsInterface)
    const [value, setValue] = useState('');

    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Homepage.getByID(String(router.query.id))
            console.log('apiRes', apiRes);
            form.setFieldsValue(apiRes)
            setState(apiRes)
        } catch (error) {
        }
    }

    React.useEffect(() => {
        initialise()
    }, [])


    return (
        <Fragment>
            <Head>
                <title>Home Page</title>
                <meta name="description" content="Terms Conditions" />
            </Head>
            <section>

                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Management</Breadcrumb.Item>
                                    <Breadcrumb.Item > <Link href="/homepage/page/1" className='text-decoration-none'>Home Page </Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>{state?.title || 'N/A'}</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            <div className='flex-center flex-column flex-md-row gap-3 mb-4'>
                                <Typography.Title level={3} className='m-0  fw-bold'>{state?.title || 'N/A'}</Typography.Title>
                                {/* <Link href={`homepage/${router.query._id}/edit`}>
                                    <Button type="primary" htmlType="button" size={'large'}>
                                        Edit
                                    </Button>
                                </Link> */}
                            </div>
                            <div className='terms-conditions-wrapper'>
                                <div className="terms-conditions-wrapper-content">
                                    <div className="terms-conditions-wrapper-form">
                                        <Form
                                            form={form}
                                            name="basic"
                                            initialValues={{ remember: true }}
                                            autoComplete="off"
                                            layout='vertical'>
                                            {/* Upload Image  */}
                                            <Form.Item name="image" >
                                                <Image width="100%" height={350} src={state?.image ? `${henceforthApi.API_FILE_ROOT_ORIGINAL}${state?.image}` : banner.src} />
                                            </Form.Item>
                                            {/* Title  */}
                                            <Form.Item name="title" rules={[{ required: true, message: 'Please enter page title' }]} label="Title" >
                                                <Input placeholder="Title" />
                                            </Form.Item>
                                            {/* SubTitle  */}
                                            <Form.Item name="sub_title" rules={[{ required: true, message: 'Please enter page sub title' }]} label="Sub Title" >
                                                <Input placeholder="Sub Title" />
                                            </Form.Item>
                                            {/* Description  */}
                                            <Form.Item name="description" rules={[{ required: true, message: 'Please enter page description' }]} hasFeedback label="Description" >
                                                <ReactQuill theme="snow" value={value} placeholder="Write description here..." />

                                            </Form.Item>
                                            {/* Button  */}
                                            {/* <Button type="primary" htmlType="submit" size={'large'}>
                                                Save
                                            </Button> */}
                                        </Form>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    </Col>
                </Row>

            </section>
        </Fragment>
    )
}

ViewHomePage.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}


export default ViewHomePage
