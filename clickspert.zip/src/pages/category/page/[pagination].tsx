import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Space, Tag, Typography, Avatar, Dropdown, Upload, Select, Modal, Form, Popconfirm } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import Link from 'next/link';
import { PlusOutlined, EyeFilled, DownloadOutlined, DeleteFilled, EditFilled, UploadOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import EmployeeRoles from '@/utils/EmployeeRoles.json'
import ExportFile from '@/components/ExportFile';
import type { MenuProps } from 'antd';
import { GlobalContext } from '@/context/Provider';
import { upperCase } from 'lodash';
import user from "@/assets/images/placeholder.png"
import HenceforthIcons from '@/components/HenceforthIcons';
import { Dayjs } from 'dayjs';



const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
const { Search } = Input;
interface DataType {
    key: React.Key;
}

const columns: ColumnsType<DataType> = [
    {
        title: 'Sr.no.',
        dataIndex: 'key',
        key: 'key',
        width: 100,
        responsive: ['lg']
    },
    {
        title: 'Name',
        dataIndex: 'name',
        key: 'name',
        ellipsis: {
            showTitle: false,
        },
        render: (name) => (
            <Tooltip placement="topLeft" title={name}>
                {name}
            </Tooltip>
        ),
        width: 100
    },
    {
        title: 'Actions',
        dataIndex: 'actions',
        key: 'actions',
        width: 100,
        fixed: 'right'
    },
];

type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const CategoryListing: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const [addForm] = Form.useForm()
    const [editForm] = Form.useForm()
    const [ellipsis, setEllipsis] = useState(true);
    const router = useRouter()
    const { Toast, downloadCSV, uploadCSV } = React.useContext(GlobalContext)
    const [exportModal, setExportModal] = React.useState(false);
    const [loading, setLoading] = React.useState(false)
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [deleteLoading, setDeleteLoading] = React.useState(false)
    const [addLoading, setAddLoading] = React.useState(false)
    const [editLoading, setEditLoading] = React.useState(false)

    const [modalOpen, setModalOpen] = useState(false);
    const [editCategoryResponse, setEditCategoryResponse] = useState(null as any)

    const addCategory = async (values: any) => {
        setAddLoading(true)
        try {
            let items = {
                name: String(values.addCategory).trim()
            }
            let apiRes = await henceforthApi.Category.create(items)
            setModalOpen(false)
            Toast.success("Category added")
            console.log("addCategory called", apiRes);
            addForm.resetFields()
            await initialise()
        } catch (error) {
            setModalOpen(false)

        } finally {
            setAddLoading(false)
        }
    }

    const editCategory = async (values: any) => {
        setEditLoading(true)
        try {
            let items = {
                name: String(values.editCategory).trim()
            }
            let apiRes = await henceforthApi.Category.edit(editCategoryResponse._id, items)
            Toast.success("Category Edited")
            setEditCategoryResponse(null)
            console.log("editCategory called", apiRes);
            await initialise()
        } catch (error) {
        }
        finally {
            setEditLoading(false)
        }
    }

    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
    }

    const onSearch = (value: string) => {
        onChangeRouter("search", String(value).trim())
    }

    const handleFilter = (value: any) => {
        console.log("handleFilter called", value);
        onChangeRouter("filter", value)
    }

    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }

    const handleDelete = async (id: string) => {
        try {
            setDeleteLoading(true)
            let apiRes = await henceforthApi.Category.delete(id)
            console.log("apiRes", apiRes);
            Toast.success("Category Deleted")
            initialise()
        } catch (error) {
            console.log(error)
        } finally {
            setDeleteLoading(false)
        }
    }

    const dataSource = state?.data?.map((res: any, index: number) => {
        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
            name: <Typography.Text>{res.name || 'N/A'}</Typography.Text>,
            actions: <ul className='m-0 list-unstyled d-flex gap-2'>
                <li>
                    <Button type="primary" shape='circle' onClick={() => setEditCategoryResponse(res)}><EditFilled /></Button>
                </li>
                <li>
                    <Popconfirm
                        title="Delete"
                        description="Are you sure you want to delete ?"
                        onConfirm={(event) => { event?.stopPropagation(); handleDelete(res._id) }}
                        okButtonProps={{ loading: deleteLoading, danger: true }}
                    >
                        <Button type='primary' danger shape='circle' ><DeleteFilled /></Button>
                    </Popconfirm>
                </li>
            </ul>
        }
    }
    );

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done') {
            try {
                let data = await uploadCSV(info.file.originFileObj);
                console.log('data', data);
                data.map(async (res: any) => {
                    let items = {
                        image: res.images,
                        name: res.name,
                        category_id: '648702e813d321fa5e4aaf9c',
                        description: res.description || "N/A",
                        price: '10',
                        discount: res.discount || '0'
                    }
                    let apiRes = await henceforthApi.Products.create(items)
                    console.log("handleUploadCsvFile called apiRes", apiRes);
                })
                console.log("loop ended");
                Toast.success('sucessfully')

            } catch (error) {
                console.log(error);
            }
            setLoading(false)
        } else if (info.file.status === 'error') {
            Toast.error(`${info.file.name} file upload failed.`);
        }
    }

    const initialise = async () => {
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.limit) {
                urlSearchParam.set('limit', router.query.limit as string)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            let apiRes = await henceforthApi.Category.listing(urlSearchParam.toString())
            setState(apiRes)

        } catch (error) {
            console.log(error)
        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        if (editCategoryResponse) {
            editForm.setFieldValue("editCategory", editCategoryResponse.name)
        }
    }, [editCategoryResponse])

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit, router.query.search])

    return (
        <Fragment>
            <Head>
                <title>All Categories</title>
                <meta name="description" content="List All Pages" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Category</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>

                            {/* Title  */}
                            <div>
                                <Typography.Title level={3} className='m-0 mb-3 fw-bold'>All Categories</Typography.Title>
                                <div className='d-lg-flex justify-content-md-between align-items-center gap-4 mb-3 mb-lg-0'>
                                    <Search size="large" placeholder="Search" onSearch={onSearch} onChange={(e) => onSearch(e.target.value)} enterButton />
                                    <div>
                                        <Button type="primary" icon={<PlusOutlined />} size={'large'} onClick={() => setModalOpen(true)}>
                                            Add
                                        </Button>
                                        {/* <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />}>Import</Button>
                                    </Upload>
                                    <Button type="primary" htmlType="button" icon={<DownloadOutlined />} size={'large'} onClick={() => setExportModal(true)}>Export</Button> */}
                                    </div >
                                </div >
                            </div>

                            {/* Table  */}
                            <div className='tabs-wrapper'>
                                <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} className="w-100" />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Products.export(start_date, end_date)
                        downloadCSV("Product", apiRes?.data)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />
            </section>

            {/* Modal Of Add Categry */}
            <Modal
                title={<Typography.Title level={4} className='mb-4'>Add Category</Typography.Title>}
                centered
                footer={false}
                open={modalOpen}
                onCancel={() => setModalOpen(false)}
            >
                <Form
                    name="basic"
                    initialValues={{ remember: true }}
                    onFinish={addCategory}
                    autoComplete="off"
                    layout='vertical'
                    form={addForm}
                >
                    <Form.Item
                        name="addCategory"
                        rules={[{ required: true, whitespace: true, message: 'Please Enter valid category name' }]}
                    >
                        <Input placeholder="Add Category" />
                    </Form.Item>
                    <Button type='primary' htmlType='submit' block loading={addLoading} disabled={addLoading}>Add</Button>
                </Form>

            </Modal>


            {/* Modal Of Edit Categry */}
            <Modal
                title={<Typography.Title level={4} className='mb-4'>Edit Category</Typography.Title>}
                centered
                footer={false}
                open={editCategoryResponse != null}
                onCancel={() => setEditCategoryResponse(null)}
            >
                <Form
                    name="basic"
                    initialValues={{ remember: true }}
                    onFinish={editCategory}
                    autoComplete="off"
                    layout='vertical'
                    form={editForm}
                >
                    <Form.Item
                        name="editCategory"
                        rules={[{ required: true, whitespace: true, message: 'Please Enter valid category name' }]}
                    >
                        <Input placeholder="Edit Category" />
                    </Form.Item>
                    <Button type='primary' htmlType='submit' block loading={editLoading} disabled={editLoading}>Edit</Button>
                </Form>

            </Modal>
        </Fragment>
    )
}

CategoryListing.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export default CategoryListing
