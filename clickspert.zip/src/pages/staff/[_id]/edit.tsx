import type { NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Select, Input, Upload, Modal, Spin, Typography, SelectProps } from 'antd';
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons';
import type { RcFile, UploadProps } from 'antd/es/upload';
import type { UploadFile } from 'antd/es/upload/interface';
import EmployeeRoles from '@/utils/EmployeeRoles.json'
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import CountryCode from '@/utils/CountryCode.json'
import henceforthValidations from '@/utils/henceforthValidations';
import placeholder from '../../../assets/images/placeholder.png'


const { Row, Col, Card, Button } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

const { Option } = Select;
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};


const EditStaff: Page = () => {

  const router = useRouter()
  const [form] = Form.useForm();
  const { loading, setLoading, Toast } = React.useContext(GlobalContext)
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [previewTitle, setPreviewTitle] = useState('');
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [file, setFile] = useState<any>()
  const [country, setCountry] = React.useState('')


  const options: SelectProps['options'] = [];
  for (let i = 0; i < 10; i++) {
    options.push({
      value: i.toString(10) + i,
      label: i.toString(10) + i,
    });
  }

  const onFinish = async (values: any) => {
    console.log('Received values of form: ', values);
    if (values.password === undefined) {
      delete values.password;
    }
    await updateProfile(values)
  };

  const getBase64 = (file: RcFile): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    })

  const handleCancel = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleImageUpload: UploadProps['onChange'] = async ({ fileList: newFileList }) => {
    setFileList(newFileList);
    setFile(newFileList[0])
    console.log('newFileList', newFileList);
  }

  const updateProfile = async (values: any) => {
    // debugger
    console.log(fileList);
    // return
    let name = String(values.name).trim()
    if (!name) {
      return Toast.warn("Please enter valid Name")
    }
    // if (!fileList[0]) {
    //   return Toast.warn("Please Add Image")
    // }
    // if (fileList.length === 0) {
    //   return Toast.warn("Please upload image")
    // }
    try {
      setLoading(true)
      if (file) {
        let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0]?.originFileObj)
        values.image = apiImageRes?.file_name
      }
     if(!fileList?.length){
      values.image=null
     }
      delete values['email']
      values.country_code = +values.country_code
      values.phone_no = +values.phone_no
      let apiRes = await henceforthApi.Staff.edit(String(router.query._id), values)
      Toast.success(apiRes.message)
      router.back()
    } catch (error: any) {
      Toast.error(error)
    } finally {
      setLoading(false)
    }
  }

  const prefixSelector = (
    <Form.Item name="country_code" noStyle>
      <Select
        prefixCls='edit-staff'
        showSearch
        value={country}
        defaultValue="+91"
        onChange={(e: any) => setCountry(e)} >
        {CountryCode.map((res: any) => <Option value={res.dial_code} key={res.dial_code}>{res.dial_code}</Option>)}
      </Select>
    </Form.Item>
  );


  const initialise = async () => {
    let _id = router.query._id as string
    try {
      let apiRes = await henceforthApi.Staff.getById(_id)
      console.log('apiRes edit data', apiRes);
      form.setFieldsValue(apiRes)
      setCountry(String(apiRes?.country_code))
      console.log(apiRes.image , 'apiRes.image');
      if(apiRes.image){
        setFileList([{
          uid: '-1',
          name: '',
          status: 'done',
          url:  henceforthApi.FILES.imageOriginal(apiRes.image , null),
        }])

      }
    } catch (error) {
      console.log(error)
    }
  }

  
  useEffect(() => {
    initialise()
  }, [])

  return (
    <Fragment>
      <Head>
        <title>Edit Staff</title>
        <meta name="description" content="Edit Staff" />
      </Head>
      <section>
        <Spin spinning={loading}>
          <Row gutter={[20, 20]}>
            <Col sm={22} md={12} lg={11} xl={10} xxl={9}>
              <Card className='common-card'>
                <div className='mb-4'>
                  <Breadcrumb separator=">">
                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                    <Breadcrumb.Item><Link href="/staff/page/1" className='text-decoration-none'>Staff</Link></Breadcrumb.Item>
                    <Breadcrumb.Item><Link href={`/staff/${router.query._id}/view`} className='text-decoration-none'>{form.getFieldValue("name") || router.query._id}</Link></Breadcrumb.Item>
                    <Breadcrumb.Item className='text-decoration-none'>Edit</Breadcrumb.Item>
                  </Breadcrumb>
                </div>
                {/* Title  */}
                <div className='mb-4'>
                  <Typography.Title level={3} className='m-0 fw-bold'>Edit Staff</Typography.Title>
                </div>
                {/* form  */}
                <div className='card-form-wrapper'>
                  <Form name="edit_staff"
                    size='large'
                    form={form}
                    className="add-staff-form"
                    onFinish={onFinish}
                    scrollToFirstError
                    layout='vertical'
                  >
                    {/* Image  */}
                    <Upload
                      listType="picture-circle"
                      fileList={fileList}
                      onPreview={handlePreview}
                      onChange={handleImageUpload}
                    >
                      {fileList.length >= 1 ? null : <div>
                        <PlusOutlined />
                        <div style={{ marginTop: 8 }}>Upload</div>
                      </div>}
                    </Upload>
                    <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                      <img alt="example" style={{ width: '100%' }} src={previewImage} />
                    </Modal>
                    {/* Name  */}
                    <Form.Item
                      name="name"
                      label="Name"
                      rules={[{ required: true, message: 'Please enter name', whitespace: true }]}
                    >
                      <Input size='large' name='name'
                        onKeyPress={(e: any) => {
                          if (!/[a-zA-Z ]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                            e.preventDefault();
                          }
                        }}
                        maxLength={20} className='border-0' id='Name' placeholder="Name" />
                    </Form.Item>
                    {/* Email  */}
                    <Form.Item
                      name="email"
                      label="Email"
                      className='mb-3'
                      rules={[{ required: true, message: 'Please enter email' },
                      ({ getFieldValue }) => ({
                        validator(_, value) {
                          if (value && !henceforthValidations.email(getFieldValue('email'))) {
                            return Promise.reject(new Error(`Please enter a valid email`));
                          } else {
                            return Promise.resolve();
                          }
                        },
                      }),
                      ]}
                    >
                      <Input className='border-0' type='email' placeholder="Email" disabled />
                    </Form.Item>
                    <Form.Item
                      name="phone_no"
                      label="Phone Number"
                      rules={
                        [
                          () => ({
                            validator(_, value) {
                              // if (value) {
                              if (isNaN(value)) {
                                return Promise.reject("Phone has to be a number.");
                              }
                              if (value.length > 12) {
                                return Promise.reject("Please enter a valid number");
                              }
                              if (value.length < 9) {
                                return Promise.reject("Please enter a valid number");
                              }
                              if (!value) {
                                return Promise.reject("Please enter a valid number");
                              }
                              else {
                                return Promise.resolve();
                              }
                            },
                          }),
                        ]
                      }
                    >
                      <Input onKeyPress={(e) => {
                        if (!/[0-9]/.test(e.key)) {
                          e.preventDefault();
                        }
                      }} maxLength={12} addonBefore={prefixSelector}
                        style={{ width: '100%' }} placeholder='Enter phone number'
                        className='phone-input'
                      />
                    </Form.Item>
                    {/* Password  */}
                    {/* Roles  */}
                    <Form.Item name="roles" label="Roles" rules={[{ required: true, message: 'Please Select Roles!' }]}>
                      <Select
                        mode="tags"
                        size={'large'}
                        placeholder="Please select"
                        style={{ width: '100%' }}
                        options={EmployeeRoles.map((res) => {
                          return {
                            label:res.name,
                            value: res.rol
                          }
                        })}
                      />
                    </Form.Item>
                    {/* Button  */}
                    <Button type="primary" loading={loading} htmlType="submit" className="login-form-button mt-4" block>
                      Save Changes
                    </Button>
                  </Form>
                </div>
              </Card>
            </Col>
          </Row>
        </Spin>
      </section>
    </Fragment>
  )
}

EditStaff.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export default EditStaff
