import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Spin, Tag, Typography, theme } from 'antd';
import User from "@/assets/images/placeholder.png"
import Link from 'next/link';
import henceforthApi from '@/utils/henceforthApi';
import { useRouter } from 'next/router';
import dynamic from 'next/dynamic';
import EmployeeRoles from '@/utils/EmployeeRoles.json'
import { GlobalContext } from '@/context/Provider';
const { Row, Col, Card, Button, Space, Popconfirm } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Space: dynamic(() => import("antd").then(module => module.Space), { ssr: false }),
  Popconfirm: dynamic(() => import("antd").then(module => module.Popconfirm), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};
const ViewStaff: Page = (props: any) => {
  console.log(props, "props");
  const router = useRouter()
  const { Toast, setUserInfo } = React.useContext(GlobalContext)
  const [state, setState] = React.useState(props?.data)
  const [loading, setLoading] = useState({
    loading1: false,
    loading2: false

  })

  const deleteStaffById = async () => {
    try {
      setLoading({
        ...loading,
        loading1: true
      })
      let resApi = await henceforthApi.Staff.staff_delete_by_id(String(router.query._id))
      Toast.success(resApi.message)
      router.push('/staff/page/1')
    } catch (error) {
      console.log(error);
      setLoading({
        ...loading,
        loading1: false
      })
    }
  }
  const manage = async (is_blocked: any) => {
    setLoading({
      ...loading,
      loading2: true
    })
    try {
      const item = {
        _id: state._id
      }
      let apiRes = await henceforthApi.Staff.block_delete(state?._id, item)
      setState({
        ...state,
        is_blocked
      })
      Toast.success(apiRes.message)
    } catch (error) {
      Toast.error(error)
    } finally {
      setLoading({
        ...loading,
        loading2: false
      })
    }
  }
  // const intialize = async () => {
  //   try {
  //     let apiRes = await henceforthApi.Staff.getById(router.query._id as string)
  //     console.log(apiRes);

  //   } catch (error) {

  //   }
  // }

  // React.useEffect(() => {
  //   intialize()
  // }, [])

  return (
    <Fragment>
      <Head>
        <title>Staff Details</title>
        <meta name="description" content="Staff Details" />
      </Head>
      <section>
        <Spin spinning={loading.loading1}>
          <Row gutter={[20, 20]}>
            <Col sm={22} md={12} lg={11} xl={10} xxl={9}>
              <Card className='common-card'>
                <div className='mb-4'>
                  <Breadcrumb separator=">">
                    <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                    <Breadcrumb.Item><Link href="/staff/page/1" className='text-decoration-none'>Staff</Link></Breadcrumb.Item>
                    <Breadcrumb.Item className='text-decoration-none'>View Staff</Breadcrumb.Item>
                  </Breadcrumb>
                </div>
                {/* Title  */}
                <div>
                  <Typography.Title level={3} className='m-0 fw-700'>View Staff</Typography.Title>
                </div>
                {/* Car Listing  */}
                <div className='card-listing'>
                  <div className='card-listing-image my-4 text-center'>
                    <Avatar size={120} src={henceforthApi.FILES.imageMedium(state?.image, User.src)}></Avatar>
                  </div>
                  {/* <Divider plain></Divider> */}
                  {/* Detail  */}
                  <ul className='list-unstyled mb-4'>
                    <li className='mb-3'><Typography.Text className='text-light'>Name:</Typography.Text > <Typography.Text className='ms-1 fw-500 text-capitalize'>{state?.name || 'N/A'}</Typography.Text ></li>
                    <li className='mb-3'><Typography.Text className='text-light'>Email:</Typography.Text > <Typography.Text className='ms-1 fw-500'>{state?.email || "N/A"}</Typography.Text ></li>
                    <li className='mb-3'><Typography.Text className='text-light'>Phone no:</Typography.Text > <Typography.Text className='ms-10 fw-500'>
                      {state?.phone_no ? `+${String(state?.country_code).replace("+", "")} ${state?.phone_no}` : 'N/A'}
                    </Typography.Text ></li>
                    <li className='d-flex'>
                      <Typography.Text className='text-nowrap text-light'>Roles:</Typography.Text >
                      <Typography>
                        <Space size={[0, 8]} wrap className='ms-1'>
                          {state?.roles?.map((resRole: any) =>
                            <Tag key={resRole}>
                              {(EmployeeRoles.find((resJson) => resJson.rol === resRole))?.name}
                            </Tag>
                          )}
                        </Space>
                      </Typography>
                    </li>
                  </ul>
                  {/* Button  */}
                  <div className='card-listing-button d-inline-flex flex-wrap gap-3 w-100'>
                    <Link href={`/staff/${router.query._id}/edit`} className='text-decoration-none text-white flex-grow-1'>
                      <Button type="primary" size='large' htmlType='button' block>
                        Edit
                      </Button>
                    </Link>
                    <Popconfirm
                      title={`${state?.is_blocked ? 'Unblock' : 'Block'} the staff`}
                      onConfirm={() => manage(!state?.is_blocked)}
                      description={`Are you sure to ${state?.is_blocked ? 'unblock' : 'block'} this staff?`}
                      okText={state?.is_blocked ? 'UnBlock' : 'Block'}
                      cancelText="No"
                      okButtonProps={{ type: 'primary', ghost: true }}
                    >
                      <Button type="primary" size='large' htmlType='button' className='flex-grow-1' ghost>{state?.is_blocked === true ? 'UnBlock' : 'Block'}</Button>
                    </Popconfirm>
                    <Link href={`/staff/change-password?id=${state?._id}`} className='w-100'>
                      <Button type="primary" htmlType='button' size='large' block>Change Password</Button></Link>
                    <Popconfirm
                      title="Delete the staff"
                      onConfirm={deleteStaffById}
                      description="Are you sure to delete this staff?"
                      okText="Delete it!"
                      cancelText="No"
                      okButtonProps={{ type: 'primary', danger: true }}
                    >
                      <Button type="primary" htmlType='button' size='large' block danger loading={loading.loading1}><span className='text-white'>Delete</span></Button>
                    </Popconfirm>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>
        </Spin>
      </section>
    </Fragment>
  )
}

ViewStaff.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);
export const getServerSideProps: GetServerSideProps = async (context) => {
  try {
    let apiRes = await henceforthApi.Staff.getById(context.query._id as string)
    let data = apiRes
    return { props: { data } };
  } catch (error) {
    return {
      props: {}
    }
  }

}
export default ViewStaff
