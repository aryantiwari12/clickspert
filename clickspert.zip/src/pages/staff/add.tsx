import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Breadcrumb, Form, Select, Input, Upload, Modal, message, Typography, SelectProps } from 'antd';
import Link from 'next/link';
import { PlusOutlined } from '@ant-design/icons';
import type { RcFile, UploadProps } from 'antd/es/upload';
import type { UploadFile } from 'antd/es/upload/interface';
import EmployeeRoles from '@/utils/EmployeeRoles.json'
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import dynamic from 'next/dynamic';
import { useRouter } from 'next/router';
import henceforthValidations from '@/utils/henceforthValidations';
import CountryCode from '@/utils/CountryCode.json'
const { Row, Col, Card, Button } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
}

const { Option } = Select;
type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

const getBase64 = (file: RcFile): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

const AddStaff: Page = () => {
  const router = useRouter()
  const { Toast, loading, setLoading, userInfo, setUserInfo } = React.useContext(GlobalContext)
  const [form] = Form.useForm();
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState('');
  const [previewTitle, setPreviewTitle] = useState('');
  const [fileList, setFileList] = useState<UploadFile[]>([]);
  const [country, setCountry] = React.useState('')


  const beforeUpload = (file: RcFile) => {
    const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
    if (!isJpgOrPng) {
      message.error('You can only upload JPG/PNG file!');
    }
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      message.error('Image must smaller than 2MB!');
    }
    return isJpgOrPng && isLt2M;
  };

  const handleCancel = () => setPreviewOpen(false);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as RcFile);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
    setPreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
  };

  const handleChange: UploadProps['onChange'] = ({ fileList: newFileList }) =>
    setFileList(newFileList);

  const uploadButton = (
    <div>
      <PlusOutlined />
      <div style={{ marginTop: 8 }}>Upload</div>
    </div>
  );

  const prefixSelector = (
    <Form.Item name="country_code" noStyle>
      <Select
      className=''
        prefixCls='country-code'
        showSearch
        value={country}
        defaultValue="+971"
        onChange={(e: any) => setCountry(e)} >
        {CountryCode.map((res: any) => <Option value={res.dial_code} key={res.dial_code}>{res.dial_code}</Option>)}
      </Select>
    </Form.Item>
  );

  const options: SelectProps['options'] = [];
  for (let i = 0; i < 10; i++) {
    options.push({
      value: i.toString(10) + i,
      label: i.toString(10) + i,
    });
  }

  const onFinish = async (values: any) => {
    console.log(values);
    // return
    debugger
    let items = {
      name: String(values.name).trim(),
      email: String(values.email).trim(),
      password: String(values.password).trim(),
      country_code: +values.country_code || +91,
      phone_no: +values.phone_no,
      roles: values.roles
    } as any
    if (!items.name) {
      return Toast.warn("Please enter valid Name")
    }
    if (!henceforthValidations.email(items.email)) {
      return Toast.warn("Please enter valid E-mail")
    }
    // if (!values?.profile_pic?.fileList[0].originFileObj) {
    //   return Toast.warn("Please Add Image")
    // }
    try {
      setLoading(true)
      if(values?.profile_pic?.fileList[0].originFileObj){
        let apiImageRes = await henceforthApi.Common.uploadFile('file', fileList[0]?.originFileObj)
        console.log("file image", apiImageRes);
        items['image'] = apiImageRes.file_name
      }
      let apiRes = await henceforthApi.Staff.create(items)
      form.resetFields()
      Toast.success(apiRes.message);
      router.replace(`/staff/${apiRes._id}/view`)
    } catch (error: any) {
      Toast.error(error)
      console.log(error);
    } finally {
      setLoading(false)
    }
  };

  return (
    <Fragment>
      <Head>
        <title>Add Staff</title>
        <meta name="description" content="Add Staff" />
      </Head>
      <section className='notification'>
        <Row gutter={[20, 20]}>
          <Col span={24} md={12}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                  <Breadcrumb.Item><Link href="/staff/page/1" className='text-decoration-none'>Staff</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Add Staff</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* Title  */}
              <div className='mb-4'>
                <Typography.Title level={3} className='m-0 fw-bold'>Add Staff</Typography.Title>
              </div>

              {/* form  */}
              <div className='card-form-wrapper'>
                <Form size='large' form={form} name="add_staff" className="add-staff-form" onFinish={onFinish} scrollToFirstError layout='vertical'>
                  {/* Image  */}

                  <Form.Item name='profile_pic'>
                    <Upload name="profile"
                      listType="picture-circle"
                      fileList={fileList}
                      onPreview={handlePreview}
                      beforeUpload={beforeUpload}
                      onChange={handleChange}
                    >
                      {fileList.length > 0 ? null : uploadButton}
                    </Upload>
                  </Form.Item>

                  <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                  </Modal>

                  {/* <Modal open={previewOpen} title={previewTitle} footer={null} onCancel={handleCancel}>
                    <img alt="example" style={{ width: '100%' }} src={previewImage} />
                  </Modal> */}
                  {/* Name  */}
                  <Form.Item
                    name="name"
                    label="Name"
                    rules={[{ required: true, message: 'Please enter name', whitespace: true }]}
                  >
                    <Input size='large' name='name'
                      onKeyPress={(e: any) => {
                        if (!/[a-zA-Z ]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                          e.preventDefault();
                        }
                      }}
                      maxLength={20} className='w-100' id='Name' placeholder="Name" />
                  </Form.Item>
                  <Form.Item
                    name="email"
                    label="Email"
                    className='mb-3'
                    rules={[{ required: true, message: 'Please enter email' },
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        if (value && !henceforthValidations.email(getFieldValue('email'))) {
                          return Promise.reject(new Error(`Please enter a valid email`));
                        } else {
                          return Promise.resolve();
                        }
                      },
                    }),
                    ]}
                  >
                    <Input className='border-0' type='email' placeholder="Email" />
                  </Form.Item>
                  {/* phone*/}
                  <Form.Item
                    name="phone_no"
                    label="Phone Number"
                    rules={
                      [
                        () => ({
                          validator(_, value) {
                            // if (value) {
                            if (isNaN(value)) {
                              return Promise.reject("Phone has to be a number.");
                            }
                            // if (value.length > 12) {
                            //   return Promise.reject("Please enter a valid number");
                            // }
                            if (value.length < 5) {
                              return Promise.reject("Please enter a valid number");
                            }
                            if (!value) {
                              return Promise.reject("Please enter a valid number");
                            }
                            else {
                              return Promise.resolve();
                            }
                          },
                        }),
                      ]
                    }
                  >
                    <Input onKeyPress={(e) => {
                      if (!/[0-9]/.test(e.key)) {
                        e.preventDefault();
                      }
                    }} maxLength={15} minLength={5} addonBefore={prefixSelector}
                      style={{ width: '100%' }} placeholder='Enter phone number'
                      className='phone-input'
                    /> 
                  </Form.Item>
                  {/* Password  */}
                  <Form.Item name="password"
                    rules={[{ required: true, message: 'Please enter your Password' },
                    ({ getFieldValue }) => ({
                      validator(_, value) {
                        console.log(_, value, 'p');
                        if (value && !henceforthValidations.strongPassword(getFieldValue('password'))) {
                          return Promise.reject(new Error("Password must has at least 8 characters that include at least 1 (lowercase , uppercase , number, and special ) character in (!@#$%^&*)"));
                        } else {
                          return Promise.resolve();
                        }
                      },
                    }),
                    ]}
                    label="Password">
                    <Input.Password className='border-0' type="password" placeholder="Password" />
                  </Form.Item>
                  {/* Phone No  */}
                  {/* <Form.Item name="phone_no" rules={[{ required: true, whitespace: true, message: 'Please enter phone no' }]} label="Phone No">
                    <Input type="text" addonBefore={prefixSelector} minLength={10} maxLength={10} placeholder="Phone No" />
                  </Form.Item> */}
                  {/* Roles  */}
                  <Form.Item name="roles" label="Roles" rules={[{ required: true, message: 'Please Select Roles' }]}>
                    <Select
                      mode="multiple"
                      placeholder="Please select"
                      style={{ width: '100%' }}
                      showSearch={true}
                      options={EmployeeRoles.map((res) => {
                        return {
                          value: res.rol,
                          label: res.name
                        }
                      })}
                    />
                  </Form.Item>
                  {/* Button  */}
                  <Button type="primary" htmlType="submit" className="login-form-button mt-4" loading={loading}>
                    Add Staff
                  </Button>
                </Form>
              </div>
            </Card>
          </Col>
        </Row>

      </section>
    </Fragment >
  )
}

AddStaff.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default AddStaff