import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Space, Tag, Typography, Avatar } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import Link from 'next/link';
import { PlusOutlined, SearchOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import dynamic from 'next/dynamic';
import EmployeeRoles from '@/utils/EmployeeRoles.json'
import ExportFile from '@/components/ExportFile';
import { GlobalContext } from '@/context/Provider';
import { upperCase } from 'lodash';
import user from "@/assets/images/placeholder.png"
import HenceforthIcons from '@/components/HenceforthIcons';
import SearchPage from '@/components/common/SearchInput';
import { Dayjs } from 'dayjs';

const { Row, Col, Card, Button, Pagination, Tooltip } = {
  Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
  Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
  Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
  Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
  Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
  Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
let timer: any
const { Search } = Input;
interface DataType {
  key: React.Key;
}

const columns: ColumnsType<DataType> = [
  {
    title: 'Sr.no.',
    dataIndex: 'key',
    key: 'key',
    width: 100,
    responsive: ['lg']
  },
  {
    title: 'Name',
    dataIndex: 'name',
    key: 'name',
    ellipsis: {
      showTitle: false,
    },
    // render: (name) => (
    //   <Tooltip placement="topLeft" title={name}>
    //     {name}
    //   </Tooltip>
    // ),
    width: 150
  },
  {
    title: 'Email',
    dataIndex: 'email',
    key: 'email',
    width: 200
  },
  {
    title: 'Roles',
    dataIndex: 'roles',
    key: 'roles',
    width: 200
  },
  {
    title: 'Actions',
    dataIndex: 'actions',
    key: 'actions',
    width: 100,
    fixed: 'right'
  },
];

type Page<P = {}> = NextPage<P> & {
  getLayout?: (page: ReactNode) => ReactNode;
};

type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Staff: Page = () => {
  const [value, setValue] = React.useState<RangeValue>(null)
  const router = useRouter()
  const { Toast, downloadCSV, userInfo } = React.useContext(GlobalContext)
  const [exportModal, setExportModal] = React.useState(false);
  const [loading, setLoading] = React.useState(false)
  const [limit, setlimit] = React.useState(10)
  const [state, setState] = React.useState({
    staff: [],
    count: 0
  })

  const onChangeRouter = (key: string, value: string) => {
    router.replace({
      query: { ...router.query, [key]: value }
    })
  }
  const handlePagination = (page: number, pageSize: number) => {
    console.log('page: number, pageSize', page, pageSize);
    setlimit(pageSize)
    router.replace({
      query: { ...router.query, pagination: page, limit: pageSize }
    })
  }
  const dataSource = state?.staff?.map((res: any, index: number) => {
    return {
      key: router.query.pagination ? (Number(router.query.pagination) - 1) * Number(router.query.limit || 10) + (index + 1) : index + 1,
      name: <div className='user-detail d-inline-flex gap-2 align-items-center' key={res._id}>
        <Avatar size={40} src={res?.image ? `${henceforthApi.FILES.imageSmall(res?.image)}` : user.src}></Avatar>
        <Typography.Text className='text-capitalize' title={res.name}>{res.name || 'N/A'}</Typography.Text></div>,
      email: res.email,
      roles: <Space size={[0, 'small']} wrap>
        {res.roles.slice(0, 3).map((resRole: any) =>
          <Tag key={resRole?.id} >
            {(EmployeeRoles.find((resJson) => resJson.rol === resRole))?.name}
          </Tag>)}{res.roles.length > 3 ? `+ ${res.roles.length - 3} more` : ''}
      </Space>,
      actions: <ul className='m-0 list-unstyled d-flex gap-2'>
        <li>
          <Link href={`/staff/${res._id}/view`}><Button type='primary' className='bg-transparent' shape='circle'><HenceforthIcons.ViewTwo /></Button></Link></li>
      </ul>
    }
  }
  );
  const initialise = async () => {
    try {
      setLoading(true)
      let query = router.query
      let urlSearchParam = new URLSearchParams()
      if (query.pagination) {
        urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
      }
      if (query.limit) {
        urlSearchParam.set('limit', router.query.limit as string)
      }
      if (query.search) {
        urlSearchParam.set('search', router.query.search as string)
      }
      if (query.filter) {
        urlSearchParam.set('filter', upperCase(router.query.filter as string))
      }
      let apiRes = await henceforthApi.Staff.listing(urlSearchParam.toString(), limit)
      setState(apiRes)
    } catch (error) {
      console.log(error)
    } finally {
      setLoading(false)
    }
  }
  React.useEffect(() => {
    initialise()
  }, [router.query.pagination, router.query.limit, router.query.search])
  console.log(userInfo);

  return (
    <Fragment>
      <Head>
        <title>Staff</title>
        <meta name="description" content="Staff" />
      </Head>
      <section>
        <Row gutter={[20, 20]}>
          <Col span={24}>
            <Card className='common-card'>
              <div className='mb-4'>
                <Breadcrumb separator=">">
                  <Breadcrumb.Item><Link href="/" className='text-decoration-none'>Home</Link></Breadcrumb.Item>
                  <Breadcrumb.Item className='text-decoration-none'>Staff</Breadcrumb.Item>
                </Breadcrumb>
              </div>
              {/* title  */}
              {userInfo?.super_admin && <div className='flex-center'>
                <Typography.Title level={3} className='m-0 mb-3 mb-md-0 fw-bold'>Staff</Typography.Title>
                <div className='d-flex align-items-center gap-3'>
                  <Link href='/staff/add'><Button type="primary" size='large' htmlType="button" icon={<PlusOutlined />}>Add Staff</Button></Link>
                  <Button type="primary" htmlType="button" size='large' onClick={() => setExportModal(true)} icon={<HenceforthIcons.Export />}>Export</Button>
                </div>
              </div>}
              {/* Search  */}
              <div className='my-4'>
                {/* <Search size="large" placeholder="Search..." enterButton /> */}
                <SearchPage placeholder="Search" pathname="/staff/page/1" />
              </div>
              {/* Table  */}
              <div className='tabs-wrapper'>
                <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} className="w-100" />
              </div>
              {/* Pagination  */}
              <Row justify={'center'} className="mt-4">
                <Col span={24}>
                  <Pagination current={Number(router.query.pagination) || 1} pageSize={Number(router.query.limit) || 10} total={state?.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                </Col>
              </Row>
            </Card>
          </Col>
        </Row>
        <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Users Export" export={async (start_date?: number, end_date?: number) => {
          try {
            setLoading(true)
            let apiRes = await henceforthApi.Products.export(start_date, end_date)
            downloadCSV("Product", apiRes?.data)
          } catch (error) {
            console.log(error);
          } finally {
            setLoading(false)
            setValue(null)
          }
        }} />
      </section>
    </Fragment>
  )
}

Staff.getLayout = (page: ReactNode) => (
  <MainLayout>
    {page}
  </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
  return { props: { params: 'all' } };
}

export default Staff
