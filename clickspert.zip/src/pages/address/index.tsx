import HenceforthGoogleMap from "@/utils/HenceforthGoogleMap"
import { useRouter } from "next/router";
import { useEffect, useMemo, useRef, useState } from "react";
// var userMarker: Array<google.maps.Marker> = [];
var previewClearwayPolyline: any;
var gLoading = false
const defaultProps = {
    center: {
        lat: -37.82168417163056,
        lng: 145.05854992101723
    },
    zoom: 12
};
const Address = () => {
    const [previewCenter, setPreviewCenter] = useState(defaultProps.center)
    const googleMapRef = useRef(null as any)
    const [count ,setCount]=useState(0)
    const router = useRouter()
    const [one, setOne] = useState(false)
    const handleAddPreviewMap = async (select: string, googlePreviewMapRef: any) => {
        // debugger
        // if (select !== 'Add') {
        //   setShowPreview(true)
        // }
        try {
            const directionsService = new google.maps.DirectionsService();
            let locationMarker = [{
                location: { lat: Number(router.query.startLat), lng: Number(router.query.startlng) }
            }, {
                location: { lat: Number(router.query.endLat), lng: Number(router.query.endLng) }
            }]
            // var userMarker: Array<google.maps.Marker> = [{}];
            // let originMarker = userMarker[0]
            // let destinationMarker = userMarker[userMarker.length - 1]
            // for (let index = 1; index <= userMarker.length - 2; index++) {
            //     const element = userMarker[index];
            //     locationMarker.push({ location: { lat: element.getPosition()?.lat(), lng: element.getPosition()?.lng() }, stopover: true })
            // }
            var request = {
                origin: { lat: Number(router.query.startLat), lng: Number(router.query.startlng) },
                destination: { lat: Number(router.query.endLat), lng: Number(router.query.endLng) },
                travelMode: google.maps.TravelMode.DRIVING
            } as any;
            if (locationMarker.length) {
                request['waypoints'] = locationMarker;
            }
            directionsService.route(request as any, async (response: any, status: any) => {
                if (status == 'OK') {
                    const myroute = (response as google.maps.DirectionsResult).routes[0];
                    const clearwayCoordinates = myroute.overview_path.map(res => { return { lat: res.lat(), lng: res.lng() } })
                    let info = {
                        // name: name,
                        location: 'location_address',
                        description: 'message',
                        locations: clearwayCoordinates,
                        // days_name: [daysOf]
                    }
                    if (clearwayCoordinates.length) {
                        if (previewClearwayPolyline) {
                            previewClearwayPolyline?.setMap(null)
                        }
                        const clearwayPolyline = await selectedMarkersShow(info, googlePreviewMapRef)
                        previewClearwayPolyline = clearwayPolyline
                    }
                }
            });
        } catch (error: any) {
            console.log('hello')
        } finally {
            gLoading = false
            //   setLoading(gLoading)
        }
    }
    const selectedMarkersShow = async ({ description, locations }: any, googleMapRef: any) => {
        console.log(description, locations, "ssssssssssssss");

        const stepDisplay = new google.maps.InfoWindow;
        const path = locations.map((res: any) => (
            { lat: Number(res.lat), lng: Number(res.lng) })
        );
        const clearwayPolyline = new google.maps.Polyline({
            path,
            geodesic: true,
            strokeColor: "#FF0000",
            strokeOpacity: 1.0,
            strokeWeight: 2,
        });
        // let days = uiSettings.WeekName.find(res => res.value === days_name[0])?.label
        const info = {
            path,
            //   days,
            proposed: description,
        } as any
        clearwayPolyline.setMap(googleMapRef);
        google.maps.event.addListener(clearwayPolyline, 'click', (evt: any) => {
            //   stepDisplay.setContent(htmlTable(info));
            stepDisplay.setPosition(evt.latLng);
            stepDisplay.open(googleMapRef);
        })
        return clearwayPolyline
    }
    const createMerker = (position: google.maps.LatLng | google.maps.LatLngLiteral, map: google.maps.Map, text: string, icon?: any) => {
        // window.location.reload();
        return new google.maps.Marker({
            position,
            map,
            draggable: false,
            label: { text, color: '#FFFFFF' },
            icon: icon,
        });
    }
    const onGoogleApiLoaded = ({ map, maps, ref }: any) => {
        // setShowGoogleAddressInput(true)
        // map.addListener("click", (event: google.maps.MapMouseEvent) => {
        //   if (!gLoading) {
        setPreviewCenter({ lat: Number(router.query.startLat), lng: Number(router.query.startlng) })
        let latlng = new (window as any).google.maps.LatLng(Number(router.query.startLat), Number(router.query.startlng))
        createMerker(latlng, map, "A")
        let latlng1 = new (window as any).google.maps.LatLng(Number(router.query.endLat), Number(router.query.endLng))
        createMerker(latlng1, map, "B")
        // addMarkerByMapEvent(event.latLng!, map);
        handleAddPreviewMap('Prev', map)
        //   }
        // });
        // initPlaceAPI()
    }
    useEffect(() => {
        setTimeout(()=>{
            setCount((count)=>count+1) 
        },10)
    }, [])
    return (
        <>
            <div style={{ height: '100vh', width: '100%' }}>
                <HenceforthGoogleMap
                    ref={googleMapRef}
                    defaultCenter={defaultProps.center}
                    center={previewCenter}
                    zoom={15}
                    count={count}
                    defaultZoom={defaultProps.zoom}
                    // onZoomAnimationEnd={(e: any) => {
                    //     // setPreviewZoom(e)
                    // }}
                    // onDrag={(e: any) => {
                    //     setPreviewCenter({
                    //         lat: e.center.lat(),
                    //         lng: e.center.lng()
                    //     })
                    // }}
                    onGoogleApiLoaded={useMemo(() => onGoogleApiLoaded, [])} />
            </div>
        </>
    )
}
export default Address