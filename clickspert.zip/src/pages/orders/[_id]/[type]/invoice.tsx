import CustomerInvoicePdf from "@/components/customer-invoice/customer-invoice-pdf";
import henceforthApi from "@/utils/henceforthApi";
import { GetServerSideProps } from "next";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const Invoice=(props:any)=>{
    console.log(props,"ddd");
    const router=useRouter()
    const [pageLoad, setPage] = useState(false)
    useEffect(()=>{
        setPage(true)
    },[])
    if (!pageLoad) return <></>
    return(
        <div  >
           {/* {typeof window === 'undefined' ? null : */}
        <CustomerInvoicePdf {...props} type={router.query.type} />
        </div>
    )
    
}

export const getServerSideProps: GetServerSideProps = async (context) => {
    try {
        let apiRes = await henceforthApi.Order.inVoice(context.query._id as string)
        // console.log(apiRes,'');
        
        return { props: { ...apiRes } };
    } catch (error) {
        return {
            props: {}
        }
    }

}
export default Invoice;