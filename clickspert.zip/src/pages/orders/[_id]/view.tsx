"use client"
import { OrderInfoInterface } from '@/interfaces';
import MainLayout from '@/layouts/MainLayout';
import { Avatar, Breadcrumb, Button, Card, Col, Divider, Form, Input, Modal, Row, Space, Switch, Table, Typography } from 'antd';
import Link from 'next/link';
import React, { Fragment, ReactNode, useEffect, useState } from 'react'
import Image from 'next/image';
import HenceforthIcons from '@/components/HenceforthIcons';
import Star from '../../../assets/svg/star.svg'
import henceforthApi from '@/utils/henceforthApi';
import placeholder from "@/assets/images/placeholder.png"
import henceofrthEnums from '@/utils/henceofrthEnums';
import dayjs from 'dayjs';
import { GlobalContext } from '@/context/Provider';
import { useRouter } from 'next/router';
import SearchPage from '@/components/common/SearchInput';
import ModalAssign from '@/components/common/ModalAssign';
import { capitalize } from 'lodash';
import Feedback from '@/pages/feedback/page/[pagination]';

const ViewOrders = (props: any) => {
    const [state, setState] = useState<any>()
    const { userInfo, downloadCSV, Toast, currency } = React.useContext(GlobalContext)
    const [form] = Form.useForm();
    const [form1] = Form.useForm();

    console.log(state, "props");
    const [isModalOpenAssign, setIsModalOpenAssign] = useState(false);
    const [isVendorAssignModalOpen, setIsVendorAssignModalOpen] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [vendor, setVendor] = useState<any>('')
    const [isModalOpen1, setIsModalOpen1] = useState(false);
    const [pageLoad, setPage] = useState(false)
    const [assignlist, setAssignList] = useState({
        data: []
    })
    const subServiceName = state?.sub_services?.name
    const NoRecurring = ([henceofrthEnums.Cleaning.WomenSaloonAndSpa,
    henceofrthEnums.Cleaning.MenSaloonAndSpa, henceofrthEnums.Cleaning.PacksMove, henceofrthEnums.Cleaning.GroomingPackage, henceofrthEnums.Cleaning.smartInteriorAutomation, henceofrthEnums.Cleaning.windowCleaning, henceofrthEnums.Cleaning.smartInteriorAutomation, henceofrthEnums.Cleaning.AnnualMaintainceContract])
    const [serviceId, setServiceId] = useState('')
    const [workQuotation, setWorkQuotation] = useState(false)
    const assignModal = () => {
        setIsModalOpenAssign(true)
    }
    // const [orderId, setOrderId] = useState('')
    const [service, setService] = useState<any>('')
    const showModal = () => {
        setIsModalOpen(true);
        // setOrderId(_id)
    };
    const showVendorAssignModal = () => {
        setIsVendorAssignModalOpen(true);
        // setOrderId(_id)
    };
    const showModal1 = () => {
        setIsModalOpen1(true);
    };

    const handleOk = () => {
        setIsModalOpen(false);
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };
    const handleCancel1 = () => {
        setIsModalOpen1(false);
    };
    const [loader, setLoader] = useState(false)
    const [loading, setLoading] = useState({
        loading1: false,
        loading2: false,
        loading3: false,
    });
    const street_address = state?.address ? `${state?.address?.house_no ? `${state?.address?.house_no} , ` : " "}${state?.address?.city ? `${state?.address?.city} , ` : " "}${state?.address?.postal_code ? `${state?.address?.postal_code} , ` : ""}${state?.address?.state ? `${state?.address?.state} , ` : " "}${state?.address?.country ? `${state?.address?.country} , ` : " "}${capitalize(state?.address?.address_type ? `${state?.address?.address_type} , ` : "")}` : "N/A"


    const vat = (+state?.work_quotation_amount + +state?.work_quotation_commision_price) * 5 / 100;
    const grand_total = +state?.total_amount + vat + +state?.work_quotation_commision_price + state?.work_quotation_amount
    const router = useRouter()
    const [data, setData] = useState<any[]>([]);
    const CLICKSPERTPOINTS = state?.points_used_amount ? state?.payment_mode != "OTHER" ? ` & Clickspert Points` : ' Clickspert Points' : "";
    const WALLETPAYMENT = state?.wallets_used ? state?.payment_mode != "OTHER" ? ` & Wallet` : "Wallet" : "";
    const PAYMENTMODE = state?.payment_mode != "OTHER" ? capitalize(state?.payment_mode) : ""
    const onChangeDecline = async (name: string) => {
        try {
            setLoading({
                ...loading,
                loading1: true
            })

            let apiRes = await henceforthApi.Order.decline(`order_id=${router.query._id}&is_quotation_status=${name}`)
            Toast.success(apiRes.message)
            router.back()
        } catch (error) {
            Toast.error(error)
            setLoading({
                ...loading,
                loading1: false
            })
        }
    }
    const initialiseAssign = async (id: any) => {
        try {
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Order.listvendor(id)
            setAssignList(apiRes)
            setServiceId(id)
        } catch (error) {

        }
    }
    const onChangeExtra = async (values: any) => {
        if (!values?.work_quotation_amount) {
            return Toast.warn("Please enter amount")
        }
        if (!values?.quotation_commission) {
            return Toast.warn("Please enter commission")
        }
        if (!values?.quotation_total_amount) {
            return Toast.warn("Please enter total amount")
        }
        try {
            setLoading({
                ...loading,
                loading3: true
            })
            const info = {
                order_id: router.query._id,
                work_quotation_amount: +values.work_quotation_amount,
                quotation_commission: values.quotation_commission,
                quotation_total_amount: +values.quotation_total_amount,
                quotation_total_amount_currency_id: currency?._id
            }
            let apiRes = await henceforthApi.Order.extra(info)
            Toast.success(apiRes.message)
            initialise()
            // setState((state: any) => {
            //     return {
            //         ...state,
            //         work_quotation_amount: +values?.work_quotation_amount,
            //     }
            // })
        } catch (error) {
            Toast.error(error)
        } finally {
            setLoading({
                ...loading,
                loading3: false
            })
            setIsModalOpen(false)
        }
    }
    const initialise = async () => {
        try {
            let apiRes = await henceforthApi.Order.getById(router.query._id as string)
            setState(apiRes)
        } catch (error) {

        } finally {
            setPage(true)
        }
    }
    useEffect(() => {
        initialise()
    }, [])
    const loadMoreData = () => {
        if (loader) {
            return;
        }
        setLoader(true);
        fetch('https://randomuser.me/api/?results=10&inc=name,gender,email,nat,picture&noinfo')
            .then((res) => res.json())
            .then((body) => {
                setData([...data, ...body.results]);
                setLoader(false);
            })
            .catch(() => {
                setLoader(false);
            });
    };
    const handlechange = async (_id: any) => {
        try {
            let apiRes = await henceforthApi.Vendor.getById(_id)
            setVendor(apiRes)
            setIsModalOpen(false)
        } catch (error) {

        }
    }
    const servicefee = async () => {
        try {
            let apiRes = await henceforthApi.Service.detail()
            setService(apiRes)
        } catch (error) {
            console.log(error);
        }
    }
    const handleCancelAssign = () => {
        setIsModalOpenAssign(false);
    };
    const dataSource = state?.furniture_data?.map((res: any, index: number) => {
        return {
            srno: index + 1,
            furniture: capitalize(res.material_type),
            material: res.material,
            size: res.size ? `${res.size} ${res.material_type == 'SOFA' ? `seater` : "piece"}` : '',
            description: res.description
        }
    })
    const columns = [
        {
            title: 'Sr.no.',
            dataIndex: 'srno',
            width: 200
        },
        {
            title: 'Furniture',
            dataIndex: 'furniture',
            width: 200
        },
        {
            title: 'Material',
            dataIndex: 'material',
            width: 200
        },
        {
            title: 'Size',
            dataIndex: 'size',
            width: 200
        },
        {
            title: 'Description',
            dataIndex: 'description',
            width: 200
        },
    ]

    function success(pos: any) {
        const crd = pos.coords;
        router.push({
            pathname: '/address',
            query: {
                startLat: crd?.latitude,
                startlng: crd?.longitude,
                endLat: state?.address?.location?.coordinates[1],
                endLng: state?.address?.location?.coordinates[0],
            }
        })
    }
    //   function error(err:any) {
    //     console.warn(`ERROR(${err?.code}): ${err?.message}`);
    //   }


    useEffect(() => {
        form1.setFieldValue("work_quotation_amount", state?.work_quotation_amount)
        form1.setFieldValue("quotation_commission", state?.quotation_commission)
        form1.setFieldValue("quotation_total_amount", state?.work_quotation_amount)
    }, [isModalOpen])
    React.useEffect(() => {
        loadMoreData();
        servicefee()
    }, []);
    console.log(state, "state");
    if (!pageLoad) return <></>
    return (
        <Fragment>
            <Row gutter={[20, 20]} className="mb-4">
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='mb-4'>
                            <Breadcrumb separator=">">
                                <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                                <Breadcrumb.Item><Link href="/orders/page/1" className='text-decoration-none'>Orders</Link></Breadcrumb.Item>
                                <Breadcrumb.Item className='text-decoration-none'>Order details</Breadcrumb.Item>
                            </Breadcrumb>
                        </div>
                        {/* Title  */}
                        <div>
                            <Typography.Title level={3} className='mb-4 fw-bold'>Order Details</Typography.Title>
                        </div>

                        <div className='order-detail-img'>
                            <img src={henceforthApi.FILES.imageSmall(state?.sub_services?.image) || placeholder.src} alt='img' />

                        </div>
                        <div className='flex-center mt-3 mb-5'>
                            <div>
                                <Typography.Title level={4} className='mb-1 fw-bold'>{state?.sub_services?.name || 'N/A'}</Typography.Title>
                                <p className='m-0'><span className='text-gray'>Order Id:</span><span className='fw-600'> {state?.order_id ? `${state?.order_id}` : 'N/A'}</span></p>
                            </div>
                            <div>
                                <div className={`upcoming ${state?.status == "ACTIVE" ? 'bg-theme' : state?.status == "CANCELLED" ? 'bg-danger' : state?.status == "UPCOMING" ? 'bg-success' : 'bg-blue'}`}>
                                    {capitalize(state?.status)}
                                </div>
                                {/* <div className="upcoming bg-theme">
                                    Active
                                </div>
                                <div className="upcoming bg-blue">
                                    Completed
                                </div> */}
                            </div>
                        </div>
                        <Row justify={'space-between'}>
                            <Col span={24} md={12} xl={7}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Job details</Typography.Title>

                                {/* {state.is_quotation_based==true  ? <> */}
                                {/* <p><span className='text-gray'>No. of rooms in villa:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                <p><span className='text-gray'>No. of floors:</span><span className='fw-600 ms-2'>{state?.no_of_floors || 'N/A'}</span></p> */}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.HomeCleaning ?
                                    <>       <p><span className='text-gray'>No. of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                        <p><span className='text-gray'>No. of cleaners:</span><span className='fw-600 ms-2'>{state?.no_of_cleaners || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Need of Cleaning Materials:</span><span className='fw-600 ms-2'>{state?.normal_cleaning_price?.cleaning_material == false ? "No" : "Yes"}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.DeepCleaning ?
                                    <>
                                        <p><span className='text-gray'>Type:</span><span className='fw-600 ms-2'>{state?.type?.toLowerCase() || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Size of Yours Home:</span><span className='fw-600 ms-2'>{state?.no_of_rooms ? `${state?.no_of_rooms}BHK` : 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.FurnitureCleaning ?
                                    <>
                                        {/* <p><span className='text-gray'>Furniture Type:</span>{Array.isArray(state?.furniture_type) && state?.furniture_type?.length ? state?.furniture_type.map((res: any, index: any) => (<span className='fw-600 ms-2' key={index}>{(index !== 0 ? ', ' : '') + res?.toLowerCase()}</span>)) : "N/A"}</p>
                                        <p><span className='text-gray'>Number of Sofa:</span><span className='fw-600 ms-2'>{state?.no_of_sofa || 'N/A'}</span></p> */}
                                        <Button>Job Deatils</Button>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.windowCleaning ?
                                    <>
                                        <p><span className='text-gray'>No. of rooms in villa:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'>No. of floors:</span><span className='fw-600 ms-2'>{state?.no_of_floors || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.petTriming ?
                                    <>
                                        <p><span className='text-gray'>Number of Cats:</span><span className='fw-600 ms-2'>{state?.no_of_cat || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Small Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_small_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Medium Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_medium_dog || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Large Dogs:</span><span className='fw-600 ms-2'>{state?.no_of_large_dog || 'N/A'}</span></p>

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PestControl ?
                                    <>
                                        <p><span className='text-gray'>Pest Type:</span><span className='fw-600 ms-2'>{state?.pest_type || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Number of Rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Cleaning Space:</span><span className='fw-600 ms-2'>{state?.cleaning_space || 'N/A'}</span></p>
                                    </>
                                    : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Disinfection ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </>
                                    : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.SaloonSpa ?
                                    <>
                                        <p><span className='text-gray'> Men Saloon:</span><span className='fw-600 ms-2'>{state?.men_saloon || 'N/A'}</span></p>
                                        {/* <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.same_emirates || 'N/A'}</span></p>
                                <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p> */}

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PacksMove ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.is_same_emirates == false ? 'NO' : "Yes"}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.PacksPoints ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.is_same_emirates == false ? 'NO' : "Yes"}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Color :</span><span className='fw-600 ms-2' >{state?.color_id?.name || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location from :</span><span className='fw-600 ms-2' title={state?.location_from}>{state?.location_from?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Location to :</span><span className='fw-600 ms-2' title={state?.location_to}>{state?.location_to?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                        {!state?.is_same_emirates && <>  <p><span className='text-gray'> Emirates from  :</span><span className='fw-600 ms-2' title={state?.from_emirates}>{state?.from_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p>
                                            <p><span className='text-gray'> Emirates to :</span><span className='fw-600 ms-2' title={state?.to_emirates}>{state?.to_emirates?.slice(0, 20) + "..." || 'N/A'}</span></p></>}
                                        {/* <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Same Emirates:</span><span className='fw-600 ms-2'>{state?.is_same_emirates == false ? 'NO' : "Yes"}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p> */}

                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.MoveOutInspection ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> No of rooms:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.smartInteriorAutomation ?
                                    <>
                                        <p><span className='text-gray'> Type:</span>{state?.sia.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>{(index !== 0 ? ', ' : '') + res.name}</span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.AcCleaning ?
                                    <>
                                        <p><span className='text-gray'> Duct Cleaning:</span><span className='fw-600 ms-2'>{state?.no_of_duct_cleaning || 'N/A'}</span></p>
                                        <p><span className='text-gray'> A/c Cleaning or filter cleaning:</span><span className='fw-600 ms-2'>{state?.no_of_ac_filter_cleaning || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Electrical ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Plumber ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Handyman ?
                                    <>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_hours || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Painting ?
                                    <>
                                        <p><span className='text-gray'> Type:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                        <p><span className='text-gray'> Number of hours:</span><span className='fw-600 ms-2'>{state?.no_of_rooms || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.Landscaping ?
                                    <>
                                        <p><span className='text-gray'> Size of garden:</span><span className='fw-600 ms-2'>{state?.type || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.MenSaloonAndSpa ?
                                    <>
                                        <p><span className='text-gray'>Type of Saloon:</span>{state?.men_saloon_price.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>
                                            <p>{res?.item_name}</p>
                                            <p>No of Items:{res?.no_of_item}</p>
                                            <p>Type:{res?.type.toLowerCase()}</p>

                                        </span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.SwimmingPoolMaintenance ?
                                    <>
                                        <p><span className='text-gray'> description:</span><span className='fw-600 ms-2'>{state?.description || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.SwimmingPoolCleaning ?
                                    <>
                                        <p><span className='text-gray'> Pool Size:</span><span className='fw-600 ms-2'>{state?.size || 'N/A'}</span></p>
                                    </> : ""}
                                {state?.sub_services?.name === henceofrthEnums.Cleaning.WomenSaloonAndSpa ?
                                    <>
                                        <p><span className='text-gray'>Type of Saloon:</span>{state?.women_saloon_price.map((res: any, index: number) => <span key={index} className='fw-600 ms-2'>
                                            <p>{res?.item_name}</p>
                                            <p>No of Items:{res?.no_of_item}</p>
                                            <p>Type:{res?.type.toLowerCase()}</p>

                                        </span>)}</p>
                                    </> : ""}
                                {state?.sub_services?.name == henceofrthEnums.Cleaning.AnnualMaintainceContract ?
                                    <>
                                        <p><span className='text-gray'>No. of rooms :</span><span className='fw-600 ms-2'>{state?.no_of_rooms ? state?.no_of_rooms + " BHK" : 'N/A'}</span></p>
                                        <p><span className='text-gray'>Home Type:</span><span className='fw-600 ms-2'>{capitalize(state?.type) || 'N/A'}</span></p>
                                        <p><span className='text-gray'>Plan:</span><span className='fw-600 ms-2'>{capitalize(state?.plan_type) || 'N/A'}</span></p>
                                    </> : ""}
                            </Col>
                            <Col span={24} md={12} xl={7}>
                                <div className='flex-between gap-2 mb-3'>

                                    <Typography.Title level={4} className='mb-0 fw-bold'>Address</Typography.Title>
                                    <Button onClick={() => navigator.geolocation.getCurrentPosition(success)} type="primary" htmlType='button' className='' ghost>
                                        Open Google Map
                                    </Button>
                                </div>
                                <p className='text-gray' role='button' >{street_address}</p>
                            </Col>
                            <Col span={24} md={12} xl={7}>
                                <Typography.Title level={4} className='mb-3 fw-bold'>Date & Time</Typography.Title>
                                <p className='text-gray'>{dayjs(state?.time).format('ddd, MMM DD-YYYY - hh:mm A ')} </p>
                            </Col>
                            {NoRecurring ? "" : state?.sub_services?.name === henceofrthEnums.Cleaning.Disinfection || state?.sub_services?.name === henceofrthEnums.Cleaning.petTriming
                                || state?.sub_services?.name === henceofrthEnums.Cleaning.AcCleaning ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Electrical ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Plumber ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Handyman ||
                                state?.sub_services?.name === henceofrthEnums.Cleaning.Painting ? '' :
                                <Col span={24} md={12} xl={4}>
                                    {state?.sub_services?.name === henceofrthEnums.Cleaning.WomenSaloonAndSpa ||
                                        state?.sub_services?.name === henceofrthEnums.Cleaning.MenSaloonAndSpa || state?.sub_services?.name === henceofrthEnums.Cleaning.AnnualMaintainceContract ? '' : <Typography.Title level={4} className='mb-3 fw-bold'>Recurring</Typography.Title>}
                                    {state?.recurring == null ? '' : <p className='text-gray'>{state?.recurring || 'N/A'}</p>}
                                    {state?.cleaning_multiple_times?.length ? state?.cleaning_multiple_times?.map((res: any, index: number) => <span key={index} className='fw-700'>{state?.cleaning_multiple_times?.length > index + 1 ? res + ", " : res}</span>) : ""}
                                    {state?.recurring == "Once" || state?.recurring == null ? "" :
                                        <p className='fw-700'>Next Payment:- {dayjs(state?.next_payment_date).format('ddd, MMM DD-YYYY - hh:mm A ') || 'N/A'}</p>}
                                </Col>}
                        </Row>
                    </Card>
                </Col>
                {state?.sub_services?.name == henceofrthEnums.Cleaning.FurnitureCleaning &&
                    <Col span={24}>
                        <div className="common-card">
                            <Typography.Paragraph>Job Details</Typography.Paragraph>
                            <Table dataSource={dataSource} columns={columns} pagination={false} scroll={{ x: '100%' }} />
                        </div>
                    </Col>}
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>User details</Typography.Title>
                        <div className='flex-center flex-wrap gap-2'>
                            <div className='d-flex align-items-center gap-2'>
                                <div className='user-profile user-detail'>
                                    <img src={henceforthApi.FILES.imageSmall(state?.users?.image) || placeholder.src} alt='img' />
                                </div>
                                <p className='m-0'>{state?.users?.name || 'N/A'}</p>
                            </div>
                            <div>
                                <Button icon={<HenceforthIcons.Download />} onClick={() => router.push(`/orders/${state?._id}/user/invoice`)} type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                    Download Invoice
                                </Button>
                            </div>
                        </div>
                    </Card>
                </Col>

                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <div className='flex-center'>
                            <Typography.Title level={5} className='mb-3 fw-bold'>Vendor details</Typography.Title>
                            <span>
                                {/* {(!state?.is_quotation_based && state?.status != "COMPLETED") && <Button size='middle' type='primary' onClick={() => {
                                    showVendorAssignModal(); setTimeout(() => {
                                        initialiseAssign(state?.sub_services?._id)
                                    }, 100);
                                }}>Reassign Vendor</Button>} */}
                                {(state?.status != "COMPLETED") && (state?.status !="CANCELLED") && <Button size='middle' type='primary' onClick={() => {
                                    showVendorAssignModal(); setTimeout(() => {
                                        initialiseAssign(state?.sub_services?._id)
                                    }, 100);
                                }}>Reassign Vendor</Button>}
                            </span>
                            {/* <Button type='primary' size='large' onClick={showModal1}>Change Vendor</Button> */}
                        </div>
                        <div>
                            <div className='flex-center  flex-wrap w-100 gap-2'>
                                <div className='user-detail d-flex align-items-center gap-2'>
                                    <div className='user-profile user-detail'>
                                        <img src={henceforthApi.FILES.imageSmall(state?.vendor?.image) || placeholder.src} alt='img' />
                                    </div>
                                    <p className='m-0'>{state?.vendor?.name || 'N/A'}</p>
                                </div>
                                <div>
                                    <Button icon={<HenceforthIcons.Download />} onClick={() => router.push(`/orders/${state?._id}/vendor/invoice`)} type="primary" htmlType='button' className='flex-grow-1 w-100' size='large' ghost>
                                        Download Invoice
                                    </Button>
                                </div>
                            </div>
                            {/* <div className='flex-center'> */}
                            <Space direction='vertical' className='mt-3' size={'middle'}>
                                <span style={{ background: '#ECC263', color: 'black' }} className='px-2 py-1 rounded-3'>
                                    Start Time : {state?.start_time ? dayjs(state?.start_time).format('ddd, MMM DD-YYYY - hh:mm A ') : "This order not started yet"}
                                </span>
                                <span style={{ background: '#ECC263', color: 'black' }} className='px-2 py-1 rounded-3'>
                                    End Time : {state?.end_time ? dayjs(state?.end_time).format('ddd, MMM DD-YYYY - hh:mm A ') : "This order is under progress"}
                                </span>
                            </Space>
                            {/* </div> */}
                        </div>

                    </Card>
                </Col>
                {/* <Col span={3} md={12}>
                    <Card className='common-card h-100'>
                        <div className='flex-center'>
                            <div>
                               Start Time : {state?.start_time ? dayjs(state?.start_time).format('ddd, MMM DD-YYYY - hh:mm A ') : ""}
                            </div>
                            <div>
                               End Time : {state?.end_time ? dayjs(state?.end_time).format('ddd, MMM DD-YYYY - hh:mm A ') : ""}
                            </div>
                        </div>
                    </Card>
                </Col> */}
                <Col span={24} md={12}>
                    <Card className='common-card h-100'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Payment Summary ({PAYMENTMODE}{CLICKSPERTPOINTS}{WALLETPAYMENT})</Typography.Title>
                        <div className='payment-card'>
                            <ul>
                                <li><span>Subtotal</span><span>{state?.subtotal ? `AED ${state?.subtotal}` : 'N/A'}</span></li>
                                {state?.promo_code ?
                                    <li>
                                        <span>Promo Code ({state?.promo_code || 'N/A'})</span><span>{state?.promo_code_discount || 'N/A'}</span>
                                    </li> : ""}
                                <Divider />
                                {!state?.is_quotation_based && <li>
                                    <span>Total before taxes</span><span className='fw-bold'>{`AED ${state?.total_before_tax?.toFixed(2)}`}</span>
                                </li>}
                                {!state?.is_quotation_based && <li><span className='underline'>Service fee </span><span>{state?.service_fee ? `AED ${state?.service_fee}` : 'N/A'}</span></li>}
                                <li><span className='underline'>VAT (5%) </span><span>{state?.vat ? `AED ${state?.vat}` : "N/A"}</span></li>
                                {state?.wallets_used ? <li><span>App Wallet</span><span className='fw-bold'>{state?.wallets_used ? `- AED ${state?.wallets_used?.toFixed(2)}` : 'N/A'}</span></li> : ""}
                                {state?.points_used_amount ? <li><span className='underline'>Clickspert points  </span><span>{state?.points_used_amount ? `- AED${state?.points_used_amount?.toFixed(2)} ` : "N/A"}</span></li> : ""}
                                <Divider />
                                <li><span>Total</span><span className='fw-bold'>{`AED ${state?.total_amount?.toFixed(2)}` ?? "N/A"}</span></li>
                                <Divider />
                                {/* <Divider /> */}
                                {state?.is_accpted_ewq ?
                                    <>
                                        <li>
                                            <span>Extra Work Quotation</span><span>{state?.work_quotation_amount ? `AED ${state?.work_quotation_amount}` : 'N/A'}</span>
                                        </li>

                                        {/* <li>
                                            <span>Commission({state?.quotation_commission}%) </span><span>{state?.work_quotation_commision_price ? `${state?.work_quotation_commision_price} AED` : 'N/A'}</span>
                                        </li> */}
                                        {/* <li>
                                            <span>Vat (5%)</span><span>{(+state?.work_quotation_amount + +state?.work_quotation_commision_price) * 5 / 100} AED</span>
                                        </li> */}
                                        <li>
                                            <span>Vat (5%)</span><span>{state?.work_quotation_vat ? `AED ${state?.work_quotation_vat}` : "N/A"} </span>
                                        </li>
                                        <li>
                                            <span>Extra Work Total</span><span>{`AED ${state?.work_quotation_amount + state?.work_quotation_vat}`} </span>
                                        </li>
                                        <Divider />
                                        <li><span>Grand Total {state?.is_accpted_ewq ? '(Total + Extra Work Total)' : ""}</span><span className='fw-bold'>{grand_total ? `AED ${grand_total?.toFixed(2)}` : 'N/A'}</span></li>
                                        <Divider />
                                    </> : ''}
                                {/* {state?.vat ?
                                    <li><span className='underline'>VAT </span><span>{state?.vat || 'N/A'}</span></li> : ""} */}

                                <li><span>Vendor Subtotal</span><span>{state?.vendor_subtotal ? `AED ${state?.vendor_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                <li><span>VAT(5%)</span><span>{state?.vendor_vat ? `AED ${state?.vendor_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                <li><span>Vendor earns</span><span>{state?.vendor_earning ? `AED ${state?.vendor_earning?.toFixed(2)}` : 'N/A'}</span></li>
                                {state?.is_accpted_ewq ?
                                    <>
                                        <li>
                                            <span>Extra Work Quotation</span>
                                        </li>
                                        <li><span>SubTotal</span><span className='fw-bold'>{state?.vendor_quotation_subtotal ? `AED ${state?.vendor_quotation_subtotal}` : 'N/A'}</span></li>
                                        <li>
                                            <span>Vat (5%)</span><span>{state?.vendor_quotation_vat ? `AED ${state?.vendor_quotation_vat}` : "N/A"} </span>
                                        </li>
                                        {/* <Divider /> */}
                                        <li><span>Total </span><span className='fw-bold'>{state?.vendor_quotation_earns ? `AED ${state?.vendor_quotation_earns?.toFixed(2)}` : 'N/A'}</span></li>
                                        <Divider />
                                        <li><span className='text-dark'>Grand Total (Total + Vendor earns) </span><span className='fw-bold text-dark'>{state?.vendor_quotation_earns ? `AED ${(state?.vendor_earning + state?.vendor_quotation_earns)?.toFixed(2)}` : 'N/A'}</span></li>
                                    </> : ''}

                                <Divider />
                                <li><span>Admin Subtotal</span><span>{state?.admin_subtotal ? `AED ${state?.admin_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                {!state?.is_quotation_based && <li><span className='underline'>Service fee (AED {state?.service_fee_percent}%) </span><span>{state?.service_fee ? `AED ${state?.service_fee}` : 'N/A'}</span></li>}
                                {/* <li><span>Commision(5%)</span><span>{state?.service_fee ? `${state?.service_fee?.toFixed(2)} AED` : "N/A"}</span></li> */}
                                <li><span>VAT(5%)</span><span>{state?.admin_vat ? `AED ${state?.admin_vat?.toFixed(2)}` : 'N/A'}</span></li>
                                <li><span>Admin earns</span><span className='fw-bold'>{state?.admin_earning ? `AED ${state?.admin_earning.toFixed('2')}` : 'N/A'}</span></li>
                                {state?.is_accpted_ewq ?
                                    <>
                                        <li>
                                            <span>Extra Work Quotation</span>
                                        </li>
                                        <li><span>SubTotal</span><span className='fw-bold'>{state?.admin_quotation_subtotal ? `AED ${state?.admin_quotation_subtotal?.toFixed(2)}` : 'N/A'}</span></li>
                                        <li>
                                            <span>Vat (5%)</span><span>{state?.admin_quotation_vat ? `AED ${state?.admin_quotation_vat}` : "N/A"} </span>
                                        </li>
                                        {/* <Divider /> */}
                                        <li><span>Total </span><span className='fw-bold'>{state?.admin_quotation_earns ? `AED ${state?.admin_quotation_earns?.toFixed(2)}` : 'N/A'}</span></li>
                                        <Divider />
                                        <li><span className='text-dark'>Grand Total (Total + Admin earns) </span><span className='fw-bold'>{state?.admin_quotation_earns ? `AED ${(state?.admin_earning + state?.admin_quotation_earns)?.toFixed(2)}` : 'N/A'}</span></li>
                                    </> : ''}
                            </ul>
                        </div>
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    <Card className='common-card'>
                        <Typography.Title level={5} className='mb-3 fw-bold'>Additional Info</Typography.Title>
                        {state?.special_instruction || state?.recording || state?.image ?
                            <div className="add-info">
                                <ul>
                                    {state?.special_instruction ?
                                        <li>
                                            <span>Notes:</span>
                                            <p>{state?.special_instruction.split("_")?.join(" ") || 'N/A'}</p>
                                        </li> : ""}
                                    {state?.recording ?
                                        <li>
                                            <span>Recording:</span>
                                            <div className='recording'>
                                                <audio controls>
                                                    <source src={henceforthApi.FILES.audio(state?.recording)} type='audio/ogg' />
                                                </audio>
                                            </div>
                                        </li> : ""}
                                    {state?.image ?
                                        <li>
                                            <span>Images</span>
                                            <div className='add-info-img'>
                                                <img src={henceforthApi.FILES.imageSmall(state?.image) || placeholder.src} alt='img' />
                                            </div>
                                        </li> : ""}

                                </ul>
                            </div> : <div className='w-100 text-center '><HenceforthIcons.NoData /></div>}
                    </Card>
                </Col>
                <Col span={24} md={12}>
                    {(state?.quotation_status == "null" || state?.quotation_status == null || state?.quotation_status == "USER_ACCEPTED_QUOTATION") ? "" :
                        <Card className='common-card h-100'>
                            <div className='flex-center mb-3'>
                                <Typography.Title level={5} className='mb-3 fw-bold'>Extra Work Quotation</Typography.Title>
                                {/* <Switch onChange={onChange} /> */}
                            </div>
                            {/* {workQuotation == false ? '' : */}
                            <div className="add-info">
                                <ul>
                                    <li>
                                        <span>Vendor description:</span>
                                        <p>{state?.work_quotation_description ?? 'N/A'}</p>
                                    </li>

                                    <li className='mb-0'>
                                        <ul className='flex-center flex-wrap'>
                                            <li>
                                                <span>Amount</span>
                                                <p>{state?.work_quotation_amount ? `AED ` + state?.work_quotation_amount : "N/A"} </p>
                                            </li>
                                            {state?.quotation_status != "PENDING_FROM_ADMIN" &&
                                                <>
                                                    <li>
                                                        <span>Commission</span>
                                                        <p>{state?.quotation_commission} %</p>
                                                    </li>
                                                    <li>
                                                        <span>VAT(5%)</span>
                                                        <p>AED {state?.work_quotation_vat ? state?.work_quotation_vat : "N/A"} </p>
                                                    </li>
                                                    <li>
                                                        <span>Total Amount</span>
                                                        <p>AED {+state?.quotation_total_amount ? (+state?.quotation_total_amount) : ""} </p>
                                                    </li>
                                                </>}
                                        </ul>
                                    </li>

                                    {state?.quotation_status != "PENDING_FROM_ADMIN" &&
                                        <li>
                                            <span>Status</span>
                                            <p>{capitalize(state?.quotation_status?.split("_").join(" ")?.toLowerCase()) || 'N/A'}</p>
                                        </li>}
                                    <li className='mb-0'>
                                        {state?.quotation_status == "PENDING_FROM_ADMIN" && state?.status!=="COMPLETED" ?
                                            <div className='d-flex align-items-center gap-2'>
                                                <Button type="primary" htmlType='button' className=' w-100' size='large' onClick={showModal}><span className='text-dark'>Edit</span></Button>
                                                <Button type="primary" htmlType='button' className=' w-100 ' loading={loading.loading1} size='large' danger onClick={() => onChangeDecline("REJECTED")}><span className='text-white'  >Decline</span></Button>
                                            </div> : ""}
                                    </li>
                                </ul>
                            </div>
                        </Card>}
                </Col>
                <Col span={24}>
                    <Card className='common-card'>
                        <div className='feedback'>
                            <div className="flex-center">
                                <Typography.Title level={5} className='mb-3 fw-bold'>User Feedback</Typography.Title>
                            </div>
                            {state?.feedback ?
                                <div>
                                    <div className='d-flex align-items-center gap-1 mb-3'>
                                        <Image src={Star} alt='img' />
                                        <span className='text-theme fw-700'>{state?.feedback?.rating_number || "N/A"}</span>
                                    </div>
                                    <div>
                                        <p className='text-gray mb-2'>Feedback message:</p>
                                        <p>{state?.feedback?.description || 'N/A'}</p>
                                    </div>
                                </div> : <div className='w-100 text-center '><HenceforthIcons.NoData /></div>}

                        </div>
                    </Card>
                </Col>
            </Row>
            <Modal footer={null} centered={true} open={isModalOpen} onOk={handleOk} onCancel={handleCancel}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700 mb-1 mt-2'>Edit Extra Work Quotation Amount</Typography.Title>
                    <Form size='large' form={form1} onFinish={onChangeExtra} layout='vertical' className='mt-3'>
                        <Form.Item name="work_quotation_amount" label='Amount (AED)' rules={[{ required: true, message: 'Please Enter Amount' }, ({ getFieldValue }) => ({
                            validator(_, value) {
                                if (value) {
                                    const amount = getFieldValue('quotation_commission')
                                    form1.setFieldValue("quotation_total_amount", (+value + (Number(value)) * Number(amount) / 100))
                                    return Promise.resolve()
                                }
                                else {
                                    return Promise.reject()
                                }
                            },
                        })]}>
                            <Input placeholder='Amount' className='border-0' onKeyPress={(e: any) => {
                                if (!/[0-9]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                                    e.preventDefault();
                                }
                            }} />
                        </Form.Item>
                        <Form.Item name="quotation_commission" label='Commission (%)' rules={[{ required: true, message: 'Please Enter Commission' }, ({ getFieldValue }) => ({
                            validator(_, value) {
                                if (value) {
                                    const amount = getFieldValue('work_quotation_amount')
                                    form1.setFieldValue("quotation_total_amount", (+ amount / (1 - (value / 100)))?.toFixed(2))
                                    return Promise.resolve()
                                }
                                else {
                                    form1.setFieldValue("quotation_total_amount", getFieldValue('work_quotation_amount'))
                                    return Promise.reject()
                                }
                            },
                        })]} >
                            <Input placeholder='Commission' className='border-0' onKeyPress={(e: any) => {
                                if (!/[0-9]/.test(e.key) || (e.key === ' ' && !e.target.value)) {
                                    e.preventDefault();
                                }
                            }} />
                        </Form.Item>
                        <Form.Item name="quotation_total_amount" label='Total (AED)' >
                            <Input placeholder='Total' className='border-0' disabled={true} />
                        </Form.Item>
                        <Form.Item className='mb-2 mt-4'>
                            <Button type='primary' loading={loading.loading3} htmlType='submit' block>Send Request</Button>
                        </Form.Item>
                    </Form>
                </div>
            </Modal>
            <Modal footer={null} centered={true} open={isVendorAssignModalOpen} onOk={handleOk} onCancel={() => setIsVendorAssignModalOpen(false)}>
                <div className='text-center'>
                    <Typography.Title level={3} className='fw-700  mt-2'>Assign Vendor</Typography.Title>
                    <Form size='large' layout='vertical'>

                        <Row gutter={[12, 12]}>
                            <Col span={24}>
                                <Form.Item>
                                    <SearchPage placeholder="Search" pathname={`/order-request/page/${router.query.pagination}`} />
                                    {/* <Input placeholder="Search" className='border-0' size='large' prefix={<SearchOutlined />} /> */}
                                </Form.Item>
                            </Col>
                            {/* <Col span={24} md={12}>
                                        <Form.Item className='mb-0'>
                                            <Select placeholder='Select services' className='text-start'>
                                                <Select.Option>a</Select.Option>
                                                <Select.Option>b</Select.Option>
                                                <Select.Option>c</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </Col>
                                    <Col span={24} md={12}>
                                        <Form.Item className='mb-0'>
                                            <Select placeholder='Select subservice' className='text-start'>
                                                <Select.Option>a</Select.Option>
                                                <Select.Option>b</Select.Option>
                                                <Select.Option>c</Select.Option>
                                            </Select>
                                        </Form.Item>
                                    </Col> */}
                            {assignlist?.data.map((res: any, index: number) => {
                                return (
                                    <Col span={24} md={12} key={index}>
                                        <ul className='modal-list'>
                                            <li role='button' onClick={() => {
                                                handlechange(res._id);
                                                setTimeout(() => {
                                                    assignModal()
                                                }, 1000);
                                            }}>
                                                <div className='user-detail d-inline-flex gap-2 align-items-center' >
                                                    <div className="user-detail-img" role='button'>
                                                        <img src={henceforthApi.FILES.imageSmall(res.image) || placeholder.src} alt='img' />
                                                    </div>
                                                    <Typography.Text >{res.name || 'N/A'}</Typography.Text>
                                                </div>
                                            </li>

                                        </ul>
                                    </Col>
                                )
                            })}
                        </Row>
                    </Form>
                </div>
            </Modal>
            <ModalAssign isModalOpenAssign={isModalOpenAssign} setIsModalOpenAssign={setIsModalOpenAssign} handleCancelAssign={handleCancelAssign} vendor={vendor} orderId={router.query._id} initialise={initialise} />
        </Fragment>
    )
}
// export const getServerSideProps: GetServerSideProps = async (context) => {
//     try {
//         let apiRes = await henceforthApi.Order.getById(context.query._id as string)
//         let data = apiRes
//         return { props: { data } };
//     } catch (error) {
//         return {
//             props: {}
//         }
//     }

// }

ViewOrders.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);
export default ViewOrders