import type { GetServerSideProps, NextPage } from 'next'
import Head from 'next/head';
import React, { Fragment, ReactNode, useState } from 'react'
import MainLayout from '@/layouts/MainLayout';
import { Table, Input, Breadcrumb, Tabs, Typography, Upload, Select, DatePicker } from 'antd';
import Link from 'next/link';
import type { DatePickerProps, TabsProps } from 'antd';
import { UploadOutlined } from '@ant-design/icons'
import { useRouter } from 'next/router';
import henceforthApi from '@/utils/henceforthApi';
import { GlobalContext } from '@/context/Provider';
import ColumnsType from '@/interfaces/ColumnsType';
import dynamic from 'next/dynamic';
import ExportFile from '@/components/ExportFile';
import HenceforthIcons from '@/components/HenceforthIcons';
import placeholder from "@/assets/images/placeholder.png"
import dayjs, { Dayjs } from 'dayjs';
import SearchPage from '@/components/common/SearchInput';
import { capitalize } from 'lodash';
import { count } from 'console';
const { Row, Col, Card, Button, Pagination, Tooltip } = {
    Button: dynamic(() => import("antd").then(module => module.Button), { ssr: false }),
    Row: dynamic(() => import("antd").then(module => module.Row), { ssr: false }),
    Col: dynamic(() => import("antd").then(module => module.Col), { ssr: false }),
    Card: dynamic(() => import("antd").then(module => module.Card), { ssr: false }),
    Pagination: dynamic(() => import("antd").then(module => module.Pagination), { ssr: false }),
    Tooltip: dynamic(() => import("antd").then(module => module.Tooltip), { ssr: false }),
}
type Page<P = {}> = NextPage<P> & {
    getLayout?: (page: ReactNode) => ReactNode;
};
type RangeValue = [Dayjs | null, Dayjs | null] | null;
const Orders: Page = () => {
    const [value, setValue] = useState<RangeValue>(null)
    const router = useRouter()
    const { downloadCSV, Toast, count } = React.useContext(GlobalContext)
    const [state, setState] = React.useState({
        data: [],
        count: 0
    })
    const [subService, setSub_service] = useState({
        sub_services: []
    } as any)
    const [limit, setLimit] = useState(10)
    const [loading, setLoading] = React.useState(false)
    const [exportModal, setExportModal] = React.useState(false);
    const [service, setService] = useState({
        data: [],
    })
    const onChangeRouter = (key: string, value: string) => {
        router.replace({
            query: { ...router.query, [key]: value }
        })
        console.log("router query", router.query);
    }

    const onChange = (value: string) => {
        onChangeRouter("type", value)
    };
    const handlePagination = (page: number, pageSize: number) => {
        console.log('page: number, pageSize', page, pageSize);
        setLimit(pageSize)
        router.replace({
            query: { ...router.query, pagination: page, limit: pageSize }
        })
    }
    const handleSelect = (_id: any) => {
        try {
            let sub_service = service?.data.find((res: any) => res._id == _id)
            setSub_service(sub_service)
            handleChange(null, _id)
        } catch (error) {
            Toast.error(error)
        }
    }
    const onDate = (dateString: any) => {
        router.push({ pathname: `/orders/page/${router.query.pagination}`, query: { start_date: router.query.start_date, end_date: dayjs(dateString).valueOf() } }, undefined, { shallow: true })
    }
    const serviceInitialse = async () => {
        try {
            let apiRes = await henceforthApi.Service.listing('')
            setService(apiRes)
        } catch (error) {
            Toast.error(error)
        }
    }
    const dataSource = state.data.map((res: any, index: number) => {
        const  street_address=res?.address ? `${res?.address?.house_no ? `${res?.address?.house_no} , ` : " "}${res?.address?.city ? `${res?.address?.city} , ` : " "}${res?.address?.postal_code ? `${res?.address?.postal_code } , ` :  ""}${res?.address?.state ? `${res?.address?.state} , ` : " "}${res?.address?.country ? `${res?.address?.country} , ` : " "}${capitalize(res?.address?.address_type ? `${res?.address?.address_type} , ` : "")}` : "N/A"

        return {
            key: router.query.pagination ? (Number(router.query.pagination) - 1) * limit + (index + 1) : index + 1,
            username: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <div className="user-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.user_id?.image) || placeholder.src} alt='img' />
                </div>
                <Typography.Text>{res?.user_id?.name?.split('_')?.join(" ") || 'N/A'}</Typography.Text>
            </div>,
            vendorname: <div className='user-detail d-inline-flex gap-2 align-items-center'>
                <div className="user-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.vendor_id?.image) || placeholder.src} alt='img' />
                </div>
                <Typography.Text>{res?.vendor_id?.name || "N/A"}</Typography.Text>
            </div>,
            orderid: `${res.order_id}` || 'N/A',
            service: <div className='service-detail d-inline-flex gap-2 align-items-center'>
                <div className="service-detail-img">
                    <img src={henceforthApi.FILES.imageSmall(res?.sub_service_id?.image) || placeholder.src} alt='img' />
                </div>
                <div>
                    <Typography.Text className='text-gray fw-700'>{res?.service_id?.name || 'N/A'}</Typography.Text><br />
                    <Typography.Paragraph className='mb-0'>{res?.sub_service_id?.name}</Typography.Paragraph>
                </div>
            </div>,
            city: res?.address?.city || 'N/A',
            area: <span>{street_address?.slice(0, 23) || 'N/A'}</span> ,
            date: dayjs(res.time).format('ddd, MMM DD - hh:mm A'),
            status: <div className={`upcoming ${res?.status == "ACTIVE" ? 'bg-theme' : res?.status == "CANCELLED" ? 'bg-danger' : res?.status == "UPCOMING" ? 'bg-success' : 'bg-blue'}`}>
                {capitalize(res?.status)}
            </div>,
            clickspertPoint: res?.points_used_amount ? `AED ${res?.points_used_amount}` : "N/A",
            wallet: res?.wallets_used_amount ? `AED ${res?.wallets_used_amount}` : "N/A",
            recurring: res?.recurring || 'N/A',
            promoCode: res?.promo_id?.name || 'N/A',
            amount: res?.total_amount ? `AED ${res?.total_amount?.toFixed(2)}` : 'N/A',
            action: <Link href={`/orders/${res._id}/view`}>
                <Button type='primary' shape='circle' className='bg-transparent'><HenceforthIcons.ViewTwo /></Button>
            </Link>
        }
    })

    const TableData = () => <Row gutter={[20, 20]} >
        <Col span={24} >
            <Table dataSource={dataSource} columns={ColumnsType.orderColumns} pagination={false} scroll={{ x: '100%' }} />
        </Col>
    </Row>

    const items: TabsProps['items'] = [
        {
            key: 'All',
            label: 'All',
            children: <TableData />,
        },
        {
            key: 'Upcoming',
            label: 'Upcoming',
            children: <TableData />,
        },
        {
            key: 'Active',
            label: 'Active',
            children: <TableData />,
        },
        {
            key: 'Completed',
            label: 'Completed',
            children: <TableData />,
        },
        {
            key: 'Cancelled',
            label: 'Cancelled',
            children: <TableData />,
        }
    ];

    const initialise = async () => {
        console.log("latest router query", router.query);
        try {
            setLoading(true)
            let query = router.query
            let urlSearchParam = new URLSearchParams()
            if (query.pagination) {
                urlSearchParam.set('pagination', `${Number(router.query.pagination) - 1}`)
            }
            if (query.search) {
                urlSearchParam.set('search', router.query.search as string)
            }
            if (query.type) {
                urlSearchParam.set('type', String(router.query.type).toUpperCase() as string)
            } if (query.service_id) {
                urlSearchParam.set('service_id', String(router.query.service_id).toUpperCase() as string)
            }
            if (query.sub_service_id) {
                urlSearchParam.set('sub_service_id', String(router.query.sub_service_id).toUpperCase() as string)
            } if (query.start_date) {
                urlSearchParam.set('start_date', String(router.query.start_date).toUpperCase() as string)
            } if (query.end_date) {
                urlSearchParam.set('end_date', String(router.query.end_date).toUpperCase() as string)
            }
            let apiRes = await henceforthApi.Order.listing(urlSearchParam.toString(), limit)
            setState(apiRes)
        } catch (error) {

        } finally {
            setLoading(false)
        }
    }

    React.useEffect(() => {
        initialise()
    }, [router.query.pagination, router.query.limit,
    router.query.search, router.query.type, router.query.service_id,
    router.query.sub_service_id, router.query.start_date, router.query.end_date])
    React.useEffect(() => {
        serviceInitialse()
    }, [])

    const handleUploadCsvFile = async (info: any) => {
        setLoading(true)
        if (info.file.status === 'done' || info.file.status === 'error') {
            try {
                let apiRes = await henceforthApi.User.import(info.file.originFileObj)
                Toast.success((apiRes.count2 + apiRes.count1) == 0 ? "No user added" : `${apiRes.message2} ${apiRes.count2} and ${apiRes.message1} ${apiRes.count1}`);
            } catch (error) {
            }
            setLoading(false)
        }
    }
    const onDateSelect: DatePickerProps['onChange'] = (dateString) => {
        if (router.query.end_date) {
            router.push({ pathname: `/orders/page/${router.query.pagination}`, query: { start_date: dayjs(dateString).valueOf(), end_date: router.query.end_date } })
        } else {
            router.push({ pathname: `/orders/page/${router.query.pagination}`, query: { start_date: dayjs(dateString).valueOf() } })
        }
    };

    const handleChange = (sub_ser: any, id: string) => {
        try {
            if (sub_ser) {
                router.push({ pathname: `/orders/page/${router.query.pagination}`, query: { service_id: id, sub_service_id: sub_ser } }, undefined, { shallow: true })
            } else {
                router.push({ pathname: `/orders/page/${router.query.pagination}`, query: { service_id: id } }, undefined, { shallow: true })
            }
        } catch (error) {

        }
    }
    return (
        <Fragment>
            <Head>
                <title>Orders</title>
                <meta name="description" content="Users" />
            </Head>
            <section>
                <Row gutter={[20, 20]}>
                    <Col span={24}>
                        <Card className='common-card'>
                            <div className='mb-4'>
                                <Breadcrumb separator=">">
                                    <Breadcrumb.Item>Main menu</Breadcrumb.Item>
                                    <Breadcrumb.Item className='text-decoration-none'>Orders</Breadcrumb.Item>
                                </Breadcrumb>
                            </div>
                            {/* title  */}
                            <div className='flex-center flex-column flex-md-row  gap-3'>
                                <Typography.Title level={3} className='m-0 fw-bold'>Orders</Typography.Title>
                                <div className='d-flex gap-2'>
                                    <Upload onChange={handleUploadCsvFile} showUploadList={false} accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'>
                                        {/* <Button type="primary" htmlType="button" size='large'  icon={<DownloadOutlined />} >Import</Button> */}
                                    </Upload>
                                    <Button type="primary" htmlType="button" size='large' icon={<UploadOutlined />} onClick={() => setExportModal(true)}>Export</Button>
                                </div>
                            </div>
                            <Row gutter={[10, 15]} className='my-4'>
                                {/* Search  */}
                                <Col span={24}>
                                    <SearchPage placeholder="Search" pathname="/orders/page/1" />
                                </Col>

                                <Col span={24} md={12}>
                                    <Select
                                        showSearch
                                        size='large'
                                        className='w-100'
                                        placeholder="Select service"
                                        optionFilterProp="children"
                                        allowClear
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        filterOption={(input, option) => (option?.label ?? '').includes(input)}
                                        filterSort={(optionA, optionB) =>
                                            (optionA?.label ?? '').toLowerCase().localeCompare((optionB?.label ?? '').toLowerCase())
                                        }
                                        onChange={handleSelect}
                                        options={service?.data?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}

                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <Select
                                        size='large'
                                        showSearch
                                        className='w-100 bg-transparent'
                                        placeholder="Select sub service"
                                        optionFilterProp="children"
                                        allowClear
                                        suffixIcon={<HenceforthIcons.DownArrow />}
                                        onChange={(e: any) => handleChange(e, String(router.query.service_id))}
                                        options={subService?.sub_services?.map((res: any, index: number) => { return { value: res._id, label: res.name } })}

                                    />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDateSelect}
                                        placeholder='From' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                                <Col span={24} md={12}>
                                    <DatePicker
                                        onChange={onDate}

                                        placeholder='To' size='large' className='w-100' suffixIcon={<HenceforthIcons.CalenderIcon />} />
                                </Col>
                            </Row>

                            {/* Tabs  */}
                            <div className='tabs-wrapper '>
                                <Tabs activeKey={router.query.type as string} items={items} onChange={onChange} />
                            </div>
                            {/* Pagination  */}
                            <Row justify={'center'} className="mt-4">
                                <Col span={24}>
                                    <Pagination current={Number(router.query.pagination) || 1} pageSize={limit} total={state.count} hideOnSinglePage={true} disabled={loading} onChange={handlePagination} />
                                </Col>
                            </Row>
                        </Card>
                    </Col>
                </Row>
                <ExportFile value={value} setValue={setValue} open={exportModal} setOpen={setExportModal} title="Order Export" export={async (start_date?: number, end_date?: number) => {
                    try {
                        setLoading(true)
                        let apiRes = await henceforthApi.Order.export(start_date, end_date)
                        const exportData = apiRes?.data?.map((item: any, index: number) => {
                            const  street_address=`${item?.address?.house_no ? `${item?.address?.house_no} , ` : " "}${item?.address?.city ? `${item?.address?.city} , ` : " "}${item?.address?.postal_code ? `${item?.address?.postal_code } , ` :  ""}${item?.address?.state ? `${item?.address?.state} , ` : " "}${item?.address?.country ? `${item?.address?.country} , ` : " "}${capitalize(item?.address?.address_type ? `${item?.address?.address_type} , ` : "")}` 
                            return {
                                User_Name: item?.user_id?.name ?? "N/A",
                                vendor_name: item?.vendor_id?.name ?? "N/A",
                                order_id: item?.order_id?.replace("#", "") || "N/A",
                                date_time: dayjs(item?.created_at)?.format("DD MMM YYYY") ?? "N/A",
                                recurring: item?.recurring ?? "N/A",
                                status: item?.status ?? "N/A",
                                promo_code: item?.promo_id?.name ?? "N/A",
                                amount: item?.total_amount?.toFixed(2) ?? "N/A",
                                city: item?.address?.city?.split(",")?.join(" ") ?? "N/A",
                                area: street_address?.split(",")?.join(" ") ?? "N/A",
                                Service: item?.service_id?.name ?? "N/A",
                                subService: item?.sub_service_id?.name ?? "N/A"

                            }
                        })
                        downloadCSV("Order", exportData)
                    } catch (error) {
                        console.log(error)
                    } finally {
                        setLoading(false)
                        setValue(null)
                    }
                }} />

            </section>
        </Fragment>
    )
}

Orders.getLayout = (page: ReactNode) => (
    <MainLayout>
        {page}
    </MainLayout>
);

export const getServerSideProps: GetServerSideProps = async (context) => {
    return { props: { params: 'all' } };
}

export default Orders
