let n = 5;
let space = "";
for(let i = 0; i<n-1; i++){
    for( let j=1; j<=i; j++){
        space += "";
    }
    for(let k=0; k <(n-i)-i; k++){
        space += "*"
        console.log(space);
    }
}